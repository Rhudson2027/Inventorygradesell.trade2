import React, { useEffect, useMemo, useRef, useState } from "react";
import { Search, Plus, Trash2, Pencil, Download, Upload, Check, X, Trophy, Layers, Package, DollarSign, ListChecks, Database, ArrowDownWideNarrow, Minus, Boxes } from "lucide-react";

type SubsetType = "Base Card" | "Base Subset" | "Insert" | "Parallel" | "Auto" | "Relic";
type CardValue = {
  setId: string; cardNumber: string; player: string; team: string; parallel: string;
  condition: string; gradedCompany: string; grade: string; owned: boolean; wantlist: boolean;
  forTrade: boolean; purchasePrice: number; currentValue: number; notes: string; dateAdded: string;
  subsetName?: string; subsetType?: SubsetType;
  qtyOwned?: number; qtyForTrade?: number; qtyGraded?: number; location?: string;
};
type Rec = { id: string; value: CardValue; created_at: string; updated_at: string };
type SetDef = { id: string; name: string; category: string; releaseDate: string; baseCards: number; config: string; notes: string };
type OverrideRec = { id: string; value: { setId: string; baseCards: number } };
type SubsetDef = { id: string; setId: string; name: string; type: "Base Subset" | "Insert" | "Parallel" | "Auto" | "Relic" | "Insert / Parallel"; size: number; approx?: boolean; notes: string };

const SETS: SetDef[] = [
  {id:"s1",name:"Series 1",category:"Flagship",releaseDate:"2020-02-05",baseCards:350,config:"24 packs Hobby / 14 cards per pack",notes:"Cards #1-350 of flagship. Veterans, rookies, Future Stars, League Leaders."},
  {id:"s2",name:"Series 2",category:"Flagship",releaseDate:"2020-06-26",baseCards:350,config:"Hobby / Jumbo",notes:"Cards #351-700 of flagship."},
  {id:"update",name:"Update Series",category:"Flagship",releaseDate:"2020-11-06",baseCards:300,config:"Hobby / Jumbo",notes:"Cards #701-1000 equivalent. Rookies, trades, highlights. Final flagship installment."},
  {id:"factory",name:"Factory Set / Complete Set",category:"Flagship",releaseDate:"2020-09-30",baseCards:700,config:"Complete box",notes:"All Series 1 + Series 2 base cards #1-700 in one box."},
  {id:"chrome",name:"Chrome",category:"Chrome",releaseDate:"2020-08-07",baseCards:200,config:"Hobby / Retail",notes:"200 names from Series 1 + Series 2 on Chrome stock. Many Refractor parallels."},
  {id:"chrome-update",name:"Chrome Update",category:"Chrome",releaseDate:"2021-01-15",baseCards:100,config:"Hobby",notes:"2020 season Update on Chrome. Released Jan 2021 but part of 2020 Chrome family."},
  {id:"chrome-sapphire",name:"Chrome Sapphire",category:"Chrome",releaseDate:"2020-12-01",baseCards:200,config:"Online exclusive",notes:"Sapphire parallel edition of Chrome."},
  {id:"chrome-black",name:"Chrome Black",category:"Chrome",releaseDate:"2020-11-01",baseCards:100,config:"Hobby",notes:"Black Chrome, autograph-focused."},
  {id:"heritage",name:"Heritage",category:"Heritage",releaseDate:"2020-02-26",baseCards:500,config:"Hobby / Retail",notes:"1971 Topps design. Last 100 are short-prints."},
  {id:"heritage-hn",name:"Heritage High Number",category:"Heritage",releaseDate:"2020-12-30",baseCards:225,config:"Hobby",notes:"High Number extension. 500 + 225 = 725 total Heritage base."},
  {id:"heritage-ml",name:"Heritage Minor League",category:"Heritage",releaseDate:"2020-10-01",baseCards:200,config:"Hobby",notes:"Prospects on 1971 design."},
  {id:"ag",name:"Allen & Ginter",category:"Allen & Ginter",releaseDate:"2020-09-16",baseCards:350,config:"Hobby",notes:"Baseball + pop culture. Cards #1-300 base + #301-350 short prints (SP), including non-baseball personalities."},
  {id:"ag-chrome",name:"Allen & Ginter Chrome",category:"Allen & Ginter",releaseDate:"2020-12-04",baseCards:300,config:"Hobby-only",notes:"Chrome version of A&G design."},
  {id:"ag-x",name:"Allen & Ginter X",category:"Allen & Ginter",releaseDate:"2020-11-01",baseCards:100,config:"Topps.com exclusive",notes:"Online variant of A&G."},
  {id:"archives",name:"Archives",category:"Core",releaseDate:"2020-08-19",baseCards:324,config:"Hobby",notes:"Designs from 1955, 1974, and 2002 Topps."},
  {id:"big-league",name:"Big League",category:"Core",releaseDate:"2020-06-19",baseCards:300,config:"Retail-focused",notes:"Full-border, minimal design."},
  {id:"opening-day",name:"Opening Day",category:"Core",releaseDate:"2020-03-11",baseCards:201,config:"Retail",notes:"Rehash of 200 flagship cards + original inserts. Cards #1-200 base + #201 Luis Robert short-print (SP)."},
  {id:"gypsy",name:"Gypsy Queen",category:"Core",releaseDate:"2020-03-25",baseCards:320,config:"Hobby",notes:"300 base + 20 SPs. 10th year of Gypsy Queen."},
  {id:"stadium",name:"Stadium Club",category:"Core",releaseDate:"2020-09-02",baseCards:300,config:"Hobby",notes:"Glossy photography set."},
  {id:"stadium-chrome",name:"Stadium Club Chrome",category:"Core",releaseDate:"2020-12-09",baseCards:300,config:"Hobby",notes:"Optichrome version of Stadium Club."},
  {id:"finest",name:"Finest",category:"Core",releaseDate:"2020-06-19",baseCards:125,config:"Hobby",notes:"Chrome, colorful. 2 autos per box."},
  {id:"finest-flash",name:"Finest Flashbacks",category:"Core",releaseDate:"2020-11-01",baseCards:100,config:"Hobby",notes:"Retro Finest designs."},
  {id:"fire",name:"Fire",category:"Core",releaseDate:"2020-08-21",baseCards:200,config:"Retail",notes:"Tyson Beck designs."},
  {id:"gold-label",name:"Gold Label",category:"Core",releaseDate:"2020-10-14",baseCards:100,config:"Hobby",notes:"Class 1 / 2 / 3, on-card autos."},
  {id:"gallery",name:"Gallery",category:"Core",releaseDate:"2020-11-01",baseCards:200,config:"Hobby",notes:"Art-style portraits."},
  {id:"inception",name:"Inception",category:"Core",releaseDate:"2020-03-20",baseCards:100,config:"Hobby-only",notes:"Rookie / prospect focused."},
  {id:"museum",name:"Museum Collection",category:"High-End",releaseDate:"2020-07-29",baseCards:100,config:"Hobby",notes:"Premium, framed-style base + autos/relics."},
  {id:"tier-one",name:"Tier One",category:"High-End",releaseDate:"2020-06-05",baseCards:0,config:"3 cards/box: 2 autos + 1 relic",notes:"No base set. All hits."},
  {id:"tribute",name:"Tribute",category:"High-End",releaseDate:"2020-04-10",baseCards:100,config:"Hobby",notes:"Premium base + autos/relics."},
  {id:"triple",name:"Triple Threads",category:"High-End",releaseDate:"2020-10-07",baseCards:100,config:"Hobby",notes:"Base + triple relic / auto combos."},
  {id:"five-star",name:"Five Star",category:"High-End",releaseDate:"2020-11-01",baseCards:0,config:"Hobby",notes:"All autos / jumbo patches. No base."},
  {id:"definitive",name:"Definitive Collection",category:"High-End",releaseDate:"2020-04-24",baseCards:0,config:"Hobby",notes:"All autos / relics. No base."},
  {id:"diamond-icons",name:"Diamond Icons",category:"High-End",releaseDate:"2020-06-10",baseCards:0,config:"Hobby",notes:"Ultra high-end, all hits."},
  {id:"transcendent",name:"Transcendent",category:"High-End",releaseDate:"2020-12-01",baseCards:0,config:"VIP / 50 sets",notes:"Ultra limited VIP set."},
  {id:"project",name:"Project 2020",category:"Online / On-Demand",releaseDate:"2020-03-25",baseCards:400,config:"Topps.com, $20 per card",notes:"20 artists x 20 iconic cards. Sold daily."},
  {id:"now",name:"Topps NOW",category:"Online / On-Demand",releaseDate:"2020-01-01",baseCards:483,config:"Topps.com, print-to-order",notes:"Cards for moments during 2020 season."},
  {id:"total",name:"Total",category:"Online / On-Demand",releaseDate:"2020-03-13",baseCards:897,config:"Hobby",notes:"Massive 897-card set covering all teams."},
  {id:"clearly",name:"Clearly Authentic",category:"Online / On-Demand",releaseDate:"2020-07-01",baseCards:0,config:"Hobby",notes:"Encased autographs only."},
  {id:"pro-debut",name:"Pro Debut",category:"Online / On-Demand",releaseDate:"2020-06-01",baseCards:200,config:"Hobby",notes:"Minor League prospects."},
  {id:"bowman",name:"Bowman",category:"Bowman",releaseDate:"2020-05-27",baseCards:100,config:"Hobby / Jumbo",notes:"Bowman — In Progress / Part 1 Done + 1990 Bowman Insert (90B, 50 cards) added. 100-card base set (1-100). Prospects are tracked as the separate Bowman Prospects set (BP-1 to BP-150). 100 base + 150 Prospects = 250 Bowman cards. Other inserts / autos come in Part 2 / Part 3 — not added yet."},
  {id:"bowman-prospects",name:"Bowman Prospects",category:"Bowman",releaseDate:"2020-05-27",baseCards:150,config:"Hobby / Jumbo",notes:"Bowman — In Progress / Part 1 Done. 150-card Prospects subset of Bowman — BP-1 to BP-150. Paper prospects, same names as Chrome Prospects BCP-1 to BCP-150."},
  {id:"bowman-chrome",name:"Bowman Chrome",category:"Bowman",releaseDate:"2020-09-18",baseCards:250,config:"Hobby",notes:"Bowman — In Progress / Part 1 Done. 100-card base set + 150 Chrome Prospects (BCP-1 to BCP-150). Veterans/rookies + prospects on Chrome. Inserts / autos come in Part 2 / Part 3 — not added yet."},
  {id:"bowman-draft",name:"Bowman Draft",category:"Bowman",releaseDate:"2020-12-09",baseCards:200,config:"HTA Jumbo / Super Jumbo",notes:"200-card base set (BD-1 to BD-200) in paper + Chrome versions. Top 2020 Draft picks + prospects."},
  {id:"bowman-draft-1st",name:"Bowman Draft 1st Edition",category:"Bowman",releaseDate:"2020-12-01",baseCards:150,config:"Topps.com / Retail",notes:"150 prospects on Bowman Draft design with 1st Edition stamp. Foil parallels only."},
  {id:"bowman-draft-sapphire",name:"Bowman Draft Sapphire",category:"Bowman",releaseDate:"2020-12-01",baseCards:200,config:"Topps.com",notes:"Sapphire parallel edition of Bowman Draft (200 cards)."},
  {id:"bowman-chrome-sapphire",name:"Bowman Chrome Sapphire",category:"Bowman",releaseDate:"2020-06-24",baseCards:200,config:"Topps.com",notes:"Sapphire edition of Bowman Chrome. 100 base + 100 prospects in Sapphire."},
  {id:"bowman-chrome-x",name:"Bowman Chrome X",category:"Bowman",releaseDate:"2020-11-22",baseCards:100,config:"StockX exclusive",notes:"100-card skip-numbered parallel of Bowman Chrome. All slabbed by PSA. Green X-Fractor /31, Gold /3, Red 1/1."},
  {id:"bowman-heritage",name:"Bowman Heritage",category:"Bowman",releaseDate:"2021-01-15",baseCards:150,config:"Hobby",notes:"2020 season, released Jan 2021. Retro Bowman design, 150 cards."},
  {id:"bowmans-best",name:"Bowman's Best",category:"Bowman",releaseDate:"2020-12-01",baseCards:100,config:"Hobby",notes:"100-card Chrome base: 50 veterans/rookies + 50 prospects."},
  {id:"bowman-platinum",name:"Bowman Platinum",category:"Bowman",releaseDate:"2020-11-04",baseCards:100,config:"Hobby",notes:"100-card base, Platinum parallels."},
  {id:"bowman-sterling",name:"Bowman Sterling",category:"Bowman",releaseDate:"2020-08-14",baseCards:100,config:"Hobby",notes:"100-card base: 50 Rookies + 50 Prospects. 1 on-card auto per pack."},
  {id:"bowman-transcendent",name:"Bowman Transcendent",category:"Bowman",releaseDate:"2020-12-01",baseCards:0,config:"VIP",notes:"Hit-only, no base set. VIP Transcendent autos/relics."},
];

const SUBSETS: SubsetDef[] = [
  {id:"sub-s1-1",setId:"s1",name:"Veterans",type:"Base Subset",size:250,approx:true,notes:"Core veterans in base #1-350"},
  {id:"sub-s1-2",setId:"s1",name:"Future Stars",type:"Base Subset",size:30,approx:true,notes:"Rookie / young star subset in base"},
  {id:"sub-s1-3",setId:"s1",name:"Rookies",type:"Base Subset",size:40,approx:true,notes:"RCs in base"},
  {id:"sub-s1-4",setId:"s1",name:"Team Cards",type:"Base Subset",size:30,notes:"Team checklist cards in base"},
  {id:"sub-s1-5",setId:"s1",name:"League Leaders / World Series Highlights",type:"Base Subset",size:20,notes:"Leaders + highlights in base"},
  {id:"sub-s1-6",setId:"s1",name:"1985 Topps",type:"Insert",size:100,notes:"1985 Topps Baseball 35th Anniversary. Codes 85-1 to 85-100. Parallels: Black /199, Gold /50, Red /25, Platinum 1/1."},
  {id:"sub-s1-7",setId:"s1",name:"Decades Best",type:"Insert",size:100,notes:"Decades' Best. Codes DB-1 to DB-100. Parallels: Blue, Green, Black /299, Gold /50, Red /10, Platinum 1/1."},
  {id:"sub-s1-7b",setId:"s1",name:"Decades Best Chrome",type:"Insert",size:100,notes:"Decades' Best Chrome. Codes DBC-1 to DBC-100, same player order as DB-1 to DB-100. Parallel: Gold /50."},
  {id:"sub-s1-8",setId:"s1",name:"Decade's Next",type:"Insert",size:30,notes:"Decade's Next. Codes DN-1 to DN-30. Parallels: Blue, Black /299, Gold /50, Red /10, Platinum 1/1."},
  {id:"sub-s1-9",setId:"s1",name:"Decade of Dominance",type:"Insert",size:20,notes:"Decade of Dominance die-cut. Codes DOD-1 to DOD-20. Parallels: Blue, Black /299, Gold /50, Red /10, Platinum 1/1."},
  {id:"sub-s1-10",setId:"s1",name:"Topps Choice",type:"Insert",size:25,notes:"Topps Choice. Codes TC-1 to TC-25. Parallels: Blue, Black /299, Gold /50, Red /10, Platinum 1/1."},
  {id:"sub-s1-11",setId:"s1",name:"Turkey Red",type:"Insert",size:100,notes:"Turkey Red 2020. Codes TR-1 to TR-100. Retail exclusive. Parallels: Blue /50, Green /10, Black 1/1."},
  {id:"sub-s1-12",setId:"s1",name:"Chrome Turkey Red",type:"Insert",size:100,notes:"Chrome Turkey Red 2020. Codes TRC-1 to TRC-100, same player order as TR-1 to TR-100. Hobby Jumbo exclusive. Parallels: Blue /50, Green /10, SuperFractor 1/1."},
  {id:"sub-s1-13",setId:"s1",name:"Topps Now Review",type:"Insert",size:10,notes:"Topps Now Review 2019. Codes TNR-1 to TNR-10."},
  {id:"sub-s1-14",setId:"s1",name:"HR Challenge",type:"Insert",size:30,notes:"HR Challenge code cards. Codes HRC-1 to HRC-30."},
  {id:"sub-s1-15",setId:"s1",name:"Clear Variation",type:"Parallel",size:100,notes:"Series 1 Clear Variation — 100 base card numbers. Use Parallel / Variant = Clear Variation."},
  {id:"sub-s1-16",setId:"s1",name:"Global Game Medallion",type:"Relic",size:50,notes:"Global Game Medallion manufactured relics. Codes GGM-*. Parallels: Black /149, Gold /50, Red /10, Platinum 1/1. Key players tracked."},
  {id:"sub-s1-17",setId:"s1",name:"In The Name",type:"Relic",size:60,notes:"In The Name relics. Codes ITN-*. Enter a Code in Add Card; Player auto-fills when known."},
  {id:"sub-s1-18",setId:"s1",name:"Major League Material",type:"Relic",size:50,notes:"Major League Material relics. Codes MLM-*. Parallels: Black /199, Gold /50, Red /25, Platinum 1/1."},
  {id:"sub-s1-19",setId:"s1",name:"Rookie Card Retrospective",type:"Relic",size:50,notes:"Rookie Card Retrospective RC Logo Medallion manufactured relics. Codes RCR-*. Parallels: Black /199, Gold /50, Red /10, Platinum 1/1."},
  {id:"sub-s1-20",setId:"s1",name:"Jumbo Jersey Sleeve Patch",type:"Relic",size:46,notes:"Jumbo Jersey Sleeve Patch manufactured relics. Codes JJSP-*. Parallels: Black /149, Gold /50, Red /10, Platinum 1/1."},
  {id:"sub-s1-21",setId:"s1",name:"Postseason Performance",type:"Relic",size:28,notes:"Postseason Performance relics. Codes PPR-*. Parallels: Red /25, Platinum 1/1."},
  {id:"sub-s1-22",setId:"s1",name:"1985 Topps Baseball Relics",type:"Relic",size:50,notes:"1985 Topps Baseball Relics. Codes 85R-*."},
  {id:"sub-s1-23",setId:"s1",name:"Baseball Stars Autographs",type:"Auto",size:64,notes:"Baseball Stars Autographs. Codes BSA-*."},
  {id:"sub-s1-24",setId:"s1",name:"1985 Topps Baseball Autographs",type:"Auto",size:80,notes:"1985 Topps Baseball Autographs. Codes 85A-*."},
  {id:"sub-s1-25",setId:"s1",name:"Silver Pack — 1985 Topps Chrome Variation",type:"Insert",size:50,notes:"Silver Pack 1985 Topps Chrome Variation. Codes 85C-1 to 85C-50."},
  {id:"sub-s1-26",setId:"s1",name:"Target Player Highlight",type:"Insert",size:30,notes:"Target Player Highlight. Codes VGJ-1 to VGJ-30, all Vladimir Guerrero Jr. Retail."},
  {id:"sub-s1-27",setId:"s1",name:"Walmart Player Highlight",type:"Insert",size:30,notes:"Walmart Player Highlight. Codes RH-1 to RH-30, all Rhys Hoskins."},
  {id:"sub-s1-28",setId:"s1",name:"Turkey Red Boxtoppers",type:"Insert",size:50,notes:"Turkey Red Boxtoppers. Codes OTR-1 to OTR-50."},
  {id:"sub-s2-1",setId:"s2",name:"Veterans / Rookies / Future Stars",type:"Base Subset",size:350,notes:"Same structure, cards #351-700"},
  {id:"sub-s2-2",setId:"s2",name:"1985 Topps Baseball",type:"Insert",size:100,notes:"Continuation of Series 1 insert"},
  {id:"sub-s2-3",setId:"s2",name:"Decade's Best / Decades Next",type:"Insert",size:100,notes:"Continuation"},
  {id:"sub-s2-clear",setId:"s2",name:"Clear Variation",type:"Parallel",size:100,notes:"Series 2 Clear Variation — 100 base card numbers. Use Parallel / Variant = Clear Variation."},
  {id:"sub-s2-db",setId:"s2",name:"Decades Best S2",type:"Insert",size:100,notes:"Decades' Best Series 2. Codes DB-1 to DB-100. Parallels: Blue, Green, Black /299, Gold /50, Red /10, Platinum 1/1."},
  {id:"sub-s2-dbc",setId:"s2",name:"Decades Best Chrome S2",type:"Insert",size:100,notes:"Decades' Best Chrome Series 2. Codes DBC-1 to DBC-100, same player order as DB-1 to DB-100. Parallel: Gold /50. Hobby Jumbo exclusive."},
  {id:"sub-s2-wod",setId:"s2",name:"Warriors of the Diamond",type:"Insert",size:50,notes:"Warriors of the Diamond. Codes WOD-1 to WOD-50."},
  {id:"sub-s2-mt",setId:"s2",name:"Player of the Decade",type:"Insert",size:25,notes:"Topps Player of the Decade. Codes MT-1 to MT-25, all Mike Trout."},
  {id:"sub-s2-mta",setId:"s2",name:"Player of the Decade Auto",type:"Auto",size:25,notes:"Player of the Decade Auto Parallel. Codes TMTA-1 to TMTA-25, all Mike Trout."},
  {id:"sub-s2-ss",setId:"s2",name:"Significant Statistics",type:"Insert",size:25,notes:"Significant Statistics. Codes SS-1 to SS-25."},
  {id:"sub-s2-2030",setId:"s2",name:"Topps 2030",type:"Insert",size:20,notes:"Topps 2030. Codes T2030-1 to T2030-20."},
  {id:"sub-s2-85tb",setId:"s2",name:"1985 Topps S2",type:"Insert",size:50,notes:"1985 Topps Baseball Series 2. Codes 85TB-1 to 85TB-50."},
  {id:"sub-s2-85as",setId:"s2",name:"1985 All Stars",type:"Insert",size:50,notes:"1985 Topps Baseball All Stars. Codes 85AS-1 to 85AS-50."},
  {id:"sub-s2-esaw",setId:"s2",name:"Empire State",type:"Insert",size:30,notes:"Empire State Awards Winners. Codes ESAW-1 to ESAW-30, all Pete Alonso. Walmart exclusive."},
  {id:"sub-s2-esawa",setId:"s2",name:"Empire State Auto",type:"Auto",size:30,notes:"Empire State Auto Parallel. Codes ESAWA-1 to ESAWA-30, all Pete Alonso."},
  {id:"sub-s2-fth",setId:"s2",name:"Tatis Highlights",type:"Insert",size:30,notes:"Fernando Tatis Jr Highlights. Codes FTH-1 to FTH-30, all Fernando Tatis Jr. Target exclusive."},
  {id:"sub-s2-ftjha",setId:"s2",name:"Tatis Highlights Auto",type:"Auto",size:30,notes:"Tatis Highlights Auto Parallel. Codes FTJHA-1 to FTJHA-30, all Fernando Tatis Jr."},
  {id:"sub-s2-tr",setId:"s2",name:"Turkey Red S2",type:"Insert",size:100,notes:"Turkey Red 2020 Series 2. Codes TR-1 to TR-100. Retail exclusive. Parallels: Blue /50, Green /10, Black 1/1."},
  {id:"sub-s2-trc",setId:"s2",name:"Chrome Turkey Red S2",type:"Insert",size:100,notes:"Chrome Turkey Red Series 2. Codes TRC-1 to TRC-100, same player order as TR-1 to TR-100."},
  {id:"sub-s2-hrc",setId:"s2",name:"HR Challenge",type:"Insert",size:30,notes:"HR Challenge Series 2. Codes HRC-1 to HRC-30."},
  {id:"sub-s2-85tc",setId:"s2",name:"1985 Chrome Promo",type:"Insert",size:50,notes:"1985 Topps Baseball Chrome Promo. Codes 85TC-1 to 85TC-50. Silver Pack exclusive."},
  {id:"sub-s2-btn",setId:"s2",name:"Best of Topps Now",type:"Insert",size:10,notes:"Best of Topps Now. Codes BTN-1 to BTN-10."},
  {id:"sub-s2-bsa",setId:"s2",name:"Baseball Stars Autographs S2",type:"Auto",size:60,notes:"Baseball Stars Autographs Series 2. Codes BSA-* (e.g. BSA-LR Luis Robert, BSA-GL Gavin Lux, BSA-JS Juan Soto)."},
  {id:"sub-s2-bsda",setId:"s2",name:"Baseball Stars Dual Autographs S2",type:"Auto",size:25,notes:"Baseball Stars Dual Autographs Series 2. Codes BSDA-*."},
  {id:"sub-s2-dba",setId:"s2",name:"Decades Best Autograph Parallel",type:"Auto",size:100,notes:"Decades Best Autograph Parallel. Codes DBA-*."},
  {id:"sub-s2-wara",setId:"s2",name:"Warriors of the Diamond Autograph Parallel",type:"Auto",size:50,notes:"Warriors of the Diamond Autograph Parallel. Codes WARA-*."},
  {id:"sub-s2-85asa",setId:"s2",name:"1985 All Stars Autograph Variation",type:"Auto",size:50,notes:"1985 All Stars Autograph Variation. Codes 85ASA-*."},
  {id:"sub-s2-85a",setId:"s2",name:"1985 Topps Autograph Variation",type:"Auto",size:50,notes:"1985 Topps Autograph Variation. Codes 85A-*."},
  {id:"sub-s2-ssa",setId:"s2",name:"Significant Statistics Autograph Variation",type:"Auto",size:25,notes:"Significant Statistics Autograph Variation. Codes SSA-*."},
  {id:"sub-s2-jses",setId:"s2",name:"Jumbo Special Event Jersey Sleeve Team Patch",type:"Relic",size:30,notes:"Jumbo Special Event Jersey Sleeve Team Patch. Codes JSES-*."},
  {id:"sub-s2-85ca",setId:"s2",name:"1985 Chrome Promo Autograph Variation",type:"Auto",size:50,notes:"1985 Chrome Promo Autograph Variation. Codes 85CA-*."},
  {id:"sub-upd-1",setId:"update",name:"Rookies / Traded Players / Highlights",type:"Base Subset",size:300,notes:"Update base structure"},
  {id:"sub-upd-2",setId:"update",name:"1985 Topps Baseball Update",type:"Insert",size:50,notes:"Update version"},
  {id:"sub-upd-db",setId:"update",name:"Decades Best Update",type:"Insert",size:80,notes:"Decades' Best Update. Codes DB-1 to DB-80. Parallels: Blue, Green, Black /299, Gold /50, Red /10, Platinum 1/1."},
  {id:"sub-upd-p",setId:"update",name:"Prospects",type:"Insert",size:30,notes:"Prospects Insert. Codes P-1 to P-30."},
  {id:"sub-upd-ng",setId:"update",name:"A Numbers Game",type:"Insert",size:25,notes:"A Numbers Game. Codes NG-1 to NG-25."},
  {id:"sub-upd-85tb",setId:"update",name:"1985 Topps Update",type:"Insert",size:50,notes:"1985 Topps Baseball Update. Codes 85TB-1 to 85TB-50."},
  {id:"sub-upd-yoc",setId:"update",name:"20 Years of the Captain",type:"Insert",size:20,notes:"20 Years of the Captain. Codes YOC-95 to YOC-14, all Derek Jeter. Auto Parallel 20CA-95 to 20CA-14 and Commemorative Patch Auto 20CPA-95 to 20CPA-14, all Derek Jeter."},
  {id:"sub-upd-tra",setId:"update",name:"Acuna Highlights",type:"Insert",size:20,notes:"Ronald Acuna Jr. Highlights. Codes TRA-1 to TRA-20, all Ronald Acuna Jr. Target Exclusive. Auto Parallel TRA-1 to TRA-20, all Acuna (same codes, Variant=Auto)."},
  {id:"sub-upd-tr",setId:"update",name:"Turkey Red Update",type:"Insert",size:50,notes:"Turkey Red 2020 Update. Codes TR-1 to TR-50. Retail Exclusive. Parallels: Blue /50, Green /10, Black 1/1."},
  {id:"sub-upd-trc",setId:"update",name:"Chrome Turkey Red Update",type:"Insert",size:50,notes:"Chrome Turkey Red Update. Codes TRC-1 to TRC-50, same player order as TR-1 to TR-50."},
  {id:"sub-upd-cpc",setId:"update",name:"Chrome Promo Update",type:"Insert",size:50,notes:"1985 Topps Baseball Chrome Promo Update. Codes CPC-1 to CPC-50. Silver Pack Exclusive."},
  {id:"sub-upd-sp",setId:"update",name:"SP Variation",type:"Parallel",size:50,notes:"Update SP Variation — 50 cards. CMP code ends #631. Use Parallel / Variant = SP Variation."},
  {id:"sub-upd-ssp",setId:"update",name:"SSP Variation",type:"Parallel",size:25,notes:"Update SSP Variation — 25 cards. CMP code ends #632. Use Parallel / Variant = SSP Variation."},
  {id:"sub-upd-sssp",setId:"update",name:"SSSP Variation",type:"Parallel",size:5,notes:"Update SSSP Variation — 5 cards. CMP code ends #633. Use Parallel / Variant = SSSP Variation."},
  {id:"sub-upd-clear",setId:"update",name:"Clear Variation",type:"Parallel",size:10,notes:"Update Clear Variation — Hobby /10. Variant type Clear Variation. Checklist is SP-based; no full 100 list invented."},
  {id:"sub-upd-dba",setId:"update",name:"Decades Best Autograph Parallel Update",type:"Auto",size:39,notes:"Decades Best Autograph Parallel Update. Full checklist — Codes DBA-*."},
  {id:"sub-upd-pa",setId:"update",name:"Prospects Insert Autographs",type:"Auto",size:20,notes:"Prospects Insert Autographs. Full checklist — Codes PA-*."},
  {id:"sub-upd-nga",setId:"update",name:"A Numbers Game Autographs",type:"Auto",size:15,notes:"A Numbers Game Autographs. Full checklist — Codes NGA-*."},
  {id:"sub-upd-bsa",setId:"update",name:"Baseball Stars Autographs Update",type:"Auto",size:43,notes:"Baseball Stars Autographs Update. Full checklist — Codes BSA-*."},
  {id:"sub-upd-bsda",setId:"update",name:"Baseball Stars Dual Autographs Update",type:"Auto",size:12,notes:"Baseball Stars Dual Autographs Update. Full checklist — Codes BSDA-* (one row per code, two players)."},
  {id:"sub-upd-85a",setId:"update",name:"1985 Topps Autographs Update",type:"Auto",size:49,notes:"1985 Topps Autographs Update. Full checklist — Codes 85A-* / 85BA-*."},
  {id:"sub-upd-85ca",setId:"update",name:"1985 Chrome Promo Autograph Parallel",type:"Auto",size:44,notes:"1985 Chrome Promo Autograph Parallel. Full checklist — Codes 85CA-*."},
  {id:"sub-upd-mla",setId:"update",name:"Major League Material Autographs",type:"Auto",size:35,notes:"Major League Material Autographs. Full checklist — Codes MLA-*."},
  {id:"sub-upd-assa",setId:"update",name:"All Star Stitch Autographs",type:"Auto",size:28,notes:"All Star Stitch Autographs. Full checklist — Codes ASSA-*."},
  {id:"sub-upd-jfpa",setId:"update",name:"Jeter Final Season Commemorative Patch Auto",type:"Auto",size:9,notes:"Jeter Final Season Commemorative Patch Auto. Full checklist — Codes JFPA-*."},
  {id:"sub-upd-20ca",setId:"update",name:"20 Years of the Captain Autographs",type:"Auto",size:20,notes:"20 Years of the Captain Autographs. Full checklist — Codes 20CA-00 to 20CA-99, all Derek Jeter."},
  {id:"sub-upd-20cpa",setId:"update",name:"20 Years of the Captain Patch Autograph",type:"Auto",size:20,notes:"20 Years of the Captain Patch Autograph. Full checklist — Codes 20CPA-00 to 20CPA-99, all Derek Jeter."},
  {id:"sub-upd-tra-auto",setId:"update",name:"Ronald Acuna Jr Highlights Autographs",type:"Auto",size:20,notes:"Ronald Acuna Jr Highlights Autographs. Full checklist — Codes TRA-1 to TRA-20, all Ronald Acuna Jr."},
  {id:"sub-upd-asda",setId:"update",name:"All Star Stitch Dual Autograph",type:"Auto",size:10,notes:"All Star Stitch Dual Autograph. Full checklist — Codes ASDA-* (one row per code, two players)."},
  {id:"sub-upd-asja",setId:"update",name:"All Star Autographed Jumbo Patch",type:"Auto",size:19,notes:"All Star Autographed Jumbo Patch. Full checklist — Codes ASJA-*."},
  {id:"sub-upd-bca",setId:"update",name:"Coin Cards Autograph Parallel",type:"Auto",size:38,notes:"Coin Cards Autograph Parallel. Full checklist — Codes BCA-*."},
  {id:"sub-upd-trap",setId:"update",name:"Topps Reverence Autograph Patch Update",type:"Auto",size:21,notes:"Topps Reverence Autograph Patch Update. Full checklist — Codes TRAP-* / RAP-*."},
  {id:"sub-upd-20ycc",setId:"update",name:"20 Years of the Captain Patch",type:"Relic",size:20,notes:"20 Years of the Captain Patch. Full checklist — Codes 20YCC-95 to 20YCC-14, all Derek Jeter."},
  {id:"sub-upd-jfp",setId:"update",name:"Jeter Final Season Patch",type:"Relic",size:10,notes:"Jeter Final Season Patch. Full checklist — Codes JFP-*."},
  {id:"sub-upd-mlm",setId:"update",name:"Major League Material Update",type:"Relic",size:39,notes:"Major League Material Update. Full checklist — Codes MLM-*."},
  {id:"sub-upd-coin",setId:"update",name:"2020 Topps Baseball Coin Cards",type:"Relic",size:30,notes:"2020 Topps Baseball Coin Cards — Retail Relic Box Only."},
  {id:"sub-chr-par",setId:"chrome",name:"Base Parallels",type:"Parallel",size:22,notes:"Chrome base parallels — 22 parallel types. Refractor, Prism, Pink (Value Pack), Sepia (Value Box), X-Fractor (Monster Box), Negative, Purple /299, Blue /150, Green /99, Green Wave /99 (Hobby/Jumbo), Blue Wave /75 (Hobby/Jumbo), Gold /50, Gold Wave /50 (Hobby/Jumbo), Orange /25 (Hobby), Orange Wave /25 (Hobby/Jumbo), Red /5, Red Wave /5 (Hobby/Jumbo), SuperFractor 1/1, Cyan / Magenta / Yellow / Black Printing Plate 1/1."},
  {id:"sub-chr-sp",setId:"chrome",name:"SP Variation",type:"Parallel",size:20,notes:"Chrome Base SP Image Variations — 20 cards. CMP code ends 635. Use Parallel / Variant = SP Variation."},
  {id:"sub-chr-ssp",setId:"chrome",name:"SSP Variation",type:"Parallel",size:5,notes:"Chrome Base SSP Image Variations — 5 cards. CMP code ends 641. Use Parallel / Variant = SSP Variation."},
  {id:"sub-chr-85tc",setId:"chrome",name:"1985 Topps Baseball",type:"Insert",size:25,notes:"1985 Topps Baseball. Codes 85TC-1 to 85TC-25. Parallels: Green /99, Gold /50, Orange /25, Red /5, SuperFractor 1/1."},
  {id:"sub-chr-dod",setId:"chrome",name:"Decade of Dominance",type:"Insert",size:15,notes:"Decade of Dominance die-cut. Codes DOD-1 to DOD-15. Parallels: Green /99, Gold /50, Orange /25, Red /5, SuperFractor 1/1."},
  {id:"sub-chr-ff",setId:"chrome",name:"Freshman Flash",type:"Insert",size:15,notes:"Freshman Flash. Codes FF-1 to FF-15. Parallels: Green /99, Gold /50, Orange /25, Red /5, SuperFractor 1/1."},
  {id:"sub-chr-fs",setId:"chrome",name:"Future Stars",type:"Insert",size:20,notes:"Future Stars. Codes FS-1 to FS-20. Parallels: Green /99, Gold /50, Orange /25, Red /5, SuperFractor 1/1 (SuperFractor Hobby/Jumbo only)."},
  {id:"sub-chr-fp",setId:"chrome",name:"Topps Fire Preview NBCD",type:"Insert",size:9,notes:"Topps Fire Preview NBCD. Codes FP-1 to FP-9."},
  {id:"sub-chr-gp",setId:"chrome",name:"Topps Gallery Preview NBCD",type:"Insert",size:10,notes:"Topps Gallery Preview NBCD. Codes GP-1 to GP-10."},
  {id:"sub-chr-up",setId:"chrome",name:"Topps Update Preview NBCD",type:"Insert",size:8,notes:"Topps Update Preview NBCD. Codes UP-1 to UP-8."},
  {id:"sub-chr-85tca",setId:"chrome",name:"1985 Topps Baseball Autographs",type:"Auto",size:17,notes:"1985 Topps Baseball Autographs. Codes 85TCA-*. Parallels: Orange /25, Red /5, SuperFractor 1/1, Printing Plates 1/1."},
  {id:"sub-chr-ffa",setId:"chrome",name:"Freshman Flash Autographs",type:"Auto",size:18,notes:"Freshman Flash Autographs. Codes FFA-* (/99). Parallels: Orange /25, Red /5, SuperFractor 1/1, Printing Plates 1/1."},
  {id:"sub-chr-fsa",setId:"chrome",name:"Future Stars Autographs",type:"Auto",size:18,notes:"Future Stars Autographs. Codes FSA-*. Parallels: Orange /25, Red /5, SuperFractor 1/1, Printing Plates 1/1."},
  {id:"sub-chr-dra",setId:"chrome",name:"Dual Rookie Autographs",type:"Auto",size:5,notes:"Dual Rookie Autographs. Codes DRA-* (/25). Parallels: Red /5, SuperFractor 1/1."},
  {id:"sub-chr-ra",setId:"chrome",name:"Rookie Autographs",type:"Auto",size:77,notes:"Rookie Autographs. Codes RA-* (77 cards). Parallels: Refractor /499, Purple /250, Blue /150, Blue Wave /150, Green /99, Gold /50, Gold Wave /50, Orange /25, Orange Wave /25, Red /5, Red Wave /5, SuperFractor 1/1, Printing Plates 1/1."},
  {id:"sub-chr-rcta",setId:"chrome",name:"Topps All-Star Rookie Team Autographs",type:"Auto",size:14,notes:"Topps All-Star Rookie Team Autographs. Codes RCTA-*. Parallels: Orange /25, Red /5, SuperFractor 1/1, Printing Plates 1/1."},
  {id:"sub-chr-rrcr",setId:"chrome",name:"Retro Rookie Chrome Relics",type:"Relic",size:35,notes:"Retro Rookie Chrome Relics. Codes RRCR-*. Parallels: Green /99, Orange /25, Red /5, SuperFractor 1/1."},
  {id:"sub-chr-arrcr",setId:"chrome",name:"Retro Rookie Chrome Autograph Relics",type:"Auto",size:18,notes:"Retro Rookie Chrome Autograph Relics. Codes ARRCR-*."},
  {id:"sub-her-1",setId:"heritage",name:"Base Short Prints",type:"Base Subset",size:100,notes:"Last 100 of Heritage 500 are SPs"},
  {id:"sub-her-2",setId:"heritage",name:"Chrome Variations",type:"Parallel",size:100,notes:"Chrome versions of 100 base players"},
  {id:"sub-ag-1",setId:"ag",name:"Short Prints",type:"Base Subset",size:50,notes:"50 SPs (#301-350) in 350-card base"},
  {id:"sub-ag-2",setId:"ag",name:"Mini / A&G Back Minis",type:"Parallel",size:300,notes:"Mini parallels"},
  {id:"sub-bow-base",setId:"bowman",name:"Base Paper 1–100",type:"Base Subset",size:100,notes:"Bowman Part 1 — Base Paper 1–100. Bowman — In Progress / Part 1 Done."},
  {id:"sub-bow-base-par",setId:"bowman",name:"Base Paper Parallels",type:"Parallel",size:10,notes:"Bowman Part 1 — Base parallels: Sky Blue /499, Purple /250, Blue /150, Green /99 Retail, Yellow /75, Gold /50, Orange /25 Hobby, Red /5, Platinum 1/1, Printing Plates 1/1."},
  {id:"sub-bow-1",setId:"bowman",name:"Bowman Prospects (Paper + Chrome)",type:"Base Subset",size:150,notes:"Bowman Part 1 — BP-1 to BP-150. INSIDE Bowman 250 total - 150 prospects, primary driver. Same names/teams/order as Chrome Prospects BCP-1 to BCP-150."},
  {id:"sub-bow-paper-par",setId:"bowman-prospects",name:"Paper Prospect Parallels",type:"Parallel",size:11,notes:"Bowman Part 1 — Paper Prospect parallels: Camo Value Pack, Sky Blue /499, Purple /250, Blue /150, Green /99 Retail, Yellow /75, Gold /50, Orange /25 Hobby, Red /5, Platinum 1/1, Printing Plates 1/1."},
  {id:"sub-bow-2",setId:"bowman-chrome",name:"Bowman Chrome Prospects",type:"Base Subset",size:150,notes:"Bowman Part 1 — BCP-1 to BCP-150. Same names/teams/order as Paper Prospects BP-1 to BP-150."},
  {id:"sub-bow-chrome-par",setId:"bowman-chrome",name:"Chrome Prospect Parallels",type:"Parallel",size:19,notes:"Bowman Part 1 — Chrome Prospect parallels: Atomic Hobby, Refractor /499, Speckle /299, Purple /250, Blue /150, Blue Shimmer /150, Aqua /125, Aqua Shimmer /125, Green /99 Retail, Green Shimmer /99 Retail, Yellow /75, Gold /50, Gold Shimmer /50, Orange /25 Hobby, Orange Shimmer /25 Hobby, Red /5, Red Shimmer /5, SuperFractor 1/1, Printing Plates 1/1."},
  {id:"sub-bow-3",setId:"bowman-draft",name:"Bowman Draft Prospects",type:"Base Subset",size:200,notes:"Bowman Draft IS all prospects/draft picks - BD-1 to BD-200"},
  {id:"sub-bow-90b",setId:"bowman",name:"1990 Bowman Insert",type:"Insert",size:50,notes:"1990 Bowman Insert. Codes 90B-AA to 90B-YA. Parallels: Atomic /150, Green /99 Retail, Gold /50, Orange /25 Hobby, Red /5, SuperFractor 1/1."},
  {id:"sub-bow-btp",setId:"bowman",name:"Bowman Scouts Top 100",type:"Insert",size:100,notes:"Bowman Scouts Top 100 Insert. Codes BTP-1 to BTP-100. Parallels: Atomic /150, Green /99 Retail, Gold /50, Orange /25 Hobby, Red /5, SuperFractor 1/1."},
  {id:"sub-bow-btp-gv",setId:"bowman",name:"Bowman Scouts Top 100 — Gary Vee Variation",type:"Insert",size:18,notes:"Gary Vee Variation (18): BTP-1, BTP-2, BTP-3, BTP-4, BTP-7, BTP-8, BTP-16, BTP-25, BTP-31, BTP-52, BTP-53, BTP-56, BTP-63, BTP-70, BTP-80, BTP-86, BTP-95, BTP-99."},
  {id:"sub-bow-hf",setId:"bowman",name:"Bowman Hidden Finds",type:"Insert",size:20,notes:"Bowman Hidden Finds. Codes HF-CM to HF-SH. Parallels: Refractor /99, Orange /25, Red /5, SuperFractor 1/1."},
  {id:"sub-bow-hf-auto",setId:"bowman",name:"Hidden Finds Autographs",type:"Auto",size:12,notes:"Hidden Finds Autograph Variation. Codes HF-CP, HF-GV, HF-IG, HF-JC, HF-JDM, HF-JM, HF-JY, HF-LA, HF-MM, HF-PG, HF-RH, HF-SH. Parallels: Refractor /99, Orange /25, Red /5, SuperFractor 1/1."},
  {id:"sub-gypsy-1",setId:"gypsy",name:"Gypsy Queen SPs",type:"Base Subset",size:20,notes:"SPs #301-320 in 320 total"},
  {id:"sub-arch-1",setId:"archives",name:"Archives - 1955 / 1974 / 2002 Designs",type:"Base Subset",size:324,notes:"Archives base split across 3 retro designs"},
  {id:"sub-stad-1",setId:"stadium",name:"Stadium Club Chrome Parallels",type:"Parallel",size:300,notes:"Chrome parallels of Stadium Club base"},
];

// ---- SERIES 1 EXPANSION: FULL PARALLELS, CLEAR VARIATION, INSERTS HUB ----
const CLEAR_VARIATION_NUMBERS: number[] = [1,7,9,14,20,35,40,46,49,50,51,52,56,64,69,70,74,75,78,99,100,107,110,111,115,117,118,119,123,124,125,127,129,131,140,145,147,150,155,162,166,167,168,172,173,175,178,180,182,188,190,196,200,201,203,207,208,214,223,224,228,229,230,235,241,242,249,250,251,255,259,264,265,267,269,271,272,273,276,278,279,281,283,292,296,300,304,314,317,324,326,330,332,336,340,345,346,348,349,350];
const S1_BASE_PARALLELS: {name:string; rarity:string; notes:string}[] = [
  {name:"Base",rarity:"Base",notes:"Standard base card"},
  {name:"Yellow (Retail)",rarity:"Retail",notes:"Yellow parallel — Retail"},
  {name:"Purple (Retail)",rarity:"Retail",notes:"Purple parallel — Retail"},
  {name:"Rainbow Foil",rarity:"Foil",notes:"Rainbow foil parallel"},
  {name:"Gold Foil (Jumbo)",rarity:"Foil",notes:"Gold foil parallel — Jumbo"},
  {name:"Gold /2020",rarity:"/2020",notes:"Numbered to 2020"},
  {name:"Advanced Stat /300",rarity:"/300",notes:"Advanced Stat parallel, numbered to 300"},
  {name:"Vintage Stock /99",rarity:"/99",notes:"Vintage stock, numbered to 99"},
  {name:"Independence Day /76",rarity:"/76",notes:"Numbered to 76"},
  {name:"Black /69 (Hobby/Jumbo)",rarity:"/69",notes:"Black parallel, numbered to 69 — Hobby / Jumbo"},
  {name:"Mother's Day Hot Pink /50",rarity:"/50",notes:"Numbered to 50"},
  {name:"Father's Day Blue /50",rarity:"/50",notes:"Numbered to 50"},
  {name:"Memorial Day Camo /25",rarity:"/25",notes:"Numbered to 25"},
  {name:"Platinum 1/1",rarity:"1/1",notes:"One of one"},
  {name:"Cyan Printing Plate 1/1",rarity:"1/1",notes:"Cyan printing plate, one of one"},
  {name:"Magenta Printing Plate 1/1",rarity:"1/1",notes:"Magenta printing plate, one of one"},
  {name:"Yellow Printing Plate 1/1",rarity:"1/1",notes:"Yellow printing plate, one of one"},
  {name:"Black Printing Plate 1/1",rarity:"1/1",notes:"Black printing plate, one of one"},
];
type S1InsertDef = { id:string; name:string; prefix:string; size:number; parallels:string; notes:string; type:SubsetType; players:string[]; known?:Record<string,string>; knownTeams?:Record<string,string>; knownNotes?:Record<string,string>; teams?:string[]; codes?:string[] };
const L = (s:string)=>s.split("|");
const DB_PLAYERS = L("Willie Mays|Ernie Banks|Ernie Banks|Hank Aaron|Warren Spahn|Willie Mays|Frank Robinson|Orlando Cepeda|Luis Aparicio|Phil Rizzuto|Larry Doby|Eddie Mathews|Duke Snider|Ted Williams|Stan Musial|Jackie Robinson|Willie Mays|Monte Irvin|Ralph Kiner|Hank Aaron|Pittsburgh Pirates Team|New York Yankees Team|San Francisco Giants Team|Los Angeles Dodgers Team|St. Louis Cardinals Team|Minnesota Twins Team|Baltimore Orioles Team|Cincinnati Reds Team|Detroit Tigers Team|New York Mets Team|Bob Gibson|Jim Palmer|Tom Seaver|Fergie Jenkins|Catfish Hunter|Steve Carlton|Nolan Ryan|Bert Blyleven|Don Sutton|Phil Niekro|Wade Boggs|Don Mattingly|Ryne Sandberg|Cal Ripken Jr.|Darryl Strawberry|Eddie Murray|Dale Murphy|George Brett|Robin Yount|Andre Dawson|Ken Griffey Jr.|Frank Thomas|Sammy Sosa|Mark McGwire|Jeff Bagwell|Tony Gwynn|Roberto Alomar|Barry Larkin|Chipper Jones|Edgar Martinez|Cal Ripken Jr.|Pedro Martinez|Rickey Henderson|Roger Clemens|Sammy Sosa|Ken Griffey Jr.|Chipper Jones|Jeff Bagwell|Barry Larkin|Frank Thomas|Pedro Martinez|Randy Johnson|Andy Pettitte|Roger Clemens|Mike Mussina|Mariano Rivera|Tom Glavine|John Smoltz|CC Sabathia|Roy Oswalt|Boston Red Sox Team|New York Yankees Team|Chicago Cubs Team|Houston Astros Team|Los Angeles Dodgers Team|Cleveland Indians Team|San Francisco Giants Team|St. Louis Cardinals Team|Texas Rangers Team|Kansas City Royals Team|Miguel Cabrera|Shohei Ohtani|Mike Trout|Kris Bryant|Jacob deGrom|Bryce Harper|Max Scherzer|Felix Hernandez|Mookie Betts|Aaron Judge");
const TR_PLAYERS = L("Bryce Harper|Ronald Acuna Jr.|Ketel Marte|Adam Jones|Zack Greinke|Freddie Freeman|Nick Markakis|Ozzie Albies|Trey Mancini|Sean Murphy|Dustin May|John Means|Mookie Betts|J.D. Martinez|Chris Sale|Tim Anderson|Yoan Moncada|Eloy Jimenez|Willson Contreras|Javier Baez|Kris Bryant|Kyle Schwarber|Nick Senzel|Yasiel Puig|Luis Castillo|Francisco Lindor|Rafael Devers|Jose Ramirez|Nolan Arenado|Charlie Blackmon|Brendan Rodgers|Brendan McKay|Matthew Boyd|Miguel Cabrera|Jose Altuve|Alex Bregman|Yordan Alvarez|Justin Verlander|A.J. Puk|Whit Merrifield|Nico Hoerner|Cody Bellinger|Clayton Kershaw|Walker Buehler|Albert Pujols|Mike Trout|Shohei Ohtani|Brian Anderson|Jesus Luzardo|Zac Gallen|Christian Yelich|Lorenzo Cain|Josh Hader|Eddie Rosario|Nelson Cruz|Xander Bogaerts|Max Kepler|Gary Sanchez|Gleyber Torres|Aaron Judge|Giancarlo Stanton|Masahiro Tanaka|Pete Alonso|Jeff McNeil|Jacob deGrom|Matt Chapman|Khris Davis|Matt Olson|Rhys Hoskins|Aaron Nola|Gerrit Cole|Josh Bell|Gavin Lux|Chris Archer|Manny Machado|Fernando Tatis Jr.|Buster Posey|Brandon Crawford|Yusei Kikuchi|Keston Hiura|Yadier Molina|Marcell Ozuna|Paul Goldschmidt|Austin Meadows|Blake Snell|Charlie Morton|Joey Gallo|Shin-Soo Choo|Kyle Lewis|Cavan Biggio|Vladimir Guerrero Jr.|Marcus Stroman|Aristides Aquino|Bo Bichette|Juan Soto|Max Scherzer|Anthony Rendon|Sean Doolittle|Gio Urshela|George Springer");
const S1_INSERT_DEFS: S1InsertDef[] = [
  {id:"s1-85",name:"1985 Topps",prefix:"85",size:100,parallels:"Black /199, Gold /50, Red /25, Platinum 1/1",notes:"1985 Topps Baseball 35th Anniversary",type:"Insert",players:L("Mike Trout|Shohei Ohtani|Albert Pujols|Matt Thaiss|Alex Young|Zac Gallen|Chipper Jones|Dale Murphy|Hank Aaron|Mike Soroka|Ozzie Albies|Ronald Acuna Jr.|Cal Ripken Jr.|Mike Mussina|Chris Sale|J.D. Martinez|Rafael Devers|Roger Clemens|Wade Boggs|Xander Bogaerts|Mookie Betts|Jackie Robinson|Rod Carew|Anthony Rizzo|Kris Bryant|Kyle Schwarber|Ryne Sandberg|Willson Contreras|Robel Garcia|Dylan Cease|Eloy Jimenez|Frank Thomas|Zack Collins|Joey Votto|Johnny Bench|Nick Senzel|Trevor Bauer|Aristides Aquino|Francisco Lindor|Shane Bieber|Nolan Arenado|Al Kaline|Miguel Cabrera|Jake Rogers|George Springer|Gerrit Cole|Jeff Bagwell|Jose Altuve|Nolan Ryan|Yordan Alvarez|Alex Bregman|Whit Merrifield|George Brett|Clayton Kershaw|Sandy Koufax|Walker Buehler|Dustin May|Jordan Yamamoto|Christian Yelich|Keston Hiura|Robin Yount|Jose Berrios|Max Kepler|Vladimir Guerrero|Darryl Strawberry|Jacob deGrom|Noah Syndergaard|Pete Alonso|Aaron Judge|Don Mattingly|Luis Severino|Mariano Rivera|Reggie Jackson|Gleyber Torres|Mark McGwire|Ramon Laureano|Rickey Henderson|Matt Chapman|Bryce Harper|Rhys Hoskins|Roberto Clemente|Manny Machado|Chris Paddack|Fernando Tatis Jr.|Tony Gwynn|Will Clark|Willie Mays|Ichiro|Ken Griffey Jr.|Paul Goldschmidt|Ozzie Smith|Gavin Lux|Yadier Molina|Blake Snell|Nico Hoerner|Brendan McKay|Bo Bichette|Vladimir Guerrero Jr.|Juan Soto|Max Scherzer")},
  {id:"s1-db",name:"Decades Best",prefix:"DB",size:100,parallels:"Blue, Green, Black /299, Gold /50, Red /10, Platinum 1/1",notes:"Decades' Best",type:"Insert",players:DB_PLAYERS},
  {id:"s1-dbc",name:"Decades Best Chrome",prefix:"DBC",size:100,parallels:"Gold /50",notes:"Decades' Best Chrome — same player order as Decades Best",type:"Insert",players:DB_PLAYERS},
  {id:"s1-dn",name:"Decade's Next",prefix:"DN",size:30,parallels:"Blue, Black /299, Gold /50, Red /10, Platinum 1/1",notes:"Decade's Next",type:"Insert",players:L("Vladimir Guerrero Jr.|Austin Riley|Fernando Tatis Jr.|Yordan Alvarez|Ronald Acuna Jr.|Gleyber Torres|Keston Hiura|Brendan Rodgers|Eloy Jimenez|Gavin Lux|Pete Alonso|Juan Soto|Bo Bichette|Kyle Tucker|Nick Senzel|Ozzie Albies|Walker Buehler|Rafael Devers|Cody Bellinger|Victor Robles|Lucas Giolito|Nico Hoerner|Shohei Ohtani|Julio Urias|Chris Paddack|Brendan McKay|Ramon Laureano|Jesus Luzardo|Carter Kieboom|Mike Soroka")},
  {id:"s1-dod",name:"Decade of Dominance",prefix:"DOD",size:20,parallels:"Blue, Black /299, Gold /50, Red /10, Platinum 1/1",notes:"Decade of Dominance die-cut",type:"Insert",players:L("Babe Ruth|Willie Mays|Hank Aaron|Mark McGwire|Ken Griffey Jr.|Roger Clemens|Sandy Koufax|Ty Cobb|Mike Trout|Lou Gehrig|Tony Gwynn|Ichiro|Alex Rodriguez|Randy Johnson|Mariano Rivera|Ted Williams|Honus Wagner|Nolan Ryan|Rickey Henderson|Johnny Bench")},
  {id:"s1-tc",name:"Topps Choice",prefix:"TC",size:25,parallels:"Blue, Black /299, Gold /50, Red /10, Platinum 1/1",notes:"Topps Choice",type:"Insert",players:L("Vladimir Guerrero Jr.|Yordan Alvarez|Gavin Lux|Babe Ruth|Pete Alonso|Ronald Acuna Jr.|Mike Trout|Clayton Kershaw|Ichiro|Don Mattingly|Randy Johnson|Ty Cobb|Fernando Tatis Jr.|Mookie Betts|Yadier Molina|Kris Bryant|Christian Yelich|Aaron Judge|Cody Bellinger|Bryce Harper|Jose Altuve|Cal Ripken Jr.|Ken Griffey Jr.|Shohei Ohtani|Ryne Sandberg")},
  {id:"s1-tr",name:"Turkey Red",prefix:"TR",size:100,parallels:"Blue /50, Green /10, Black 1/1",notes:"Turkey Red 2020 — Retail exclusive",type:"Insert",players:TR_PLAYERS},
  {id:"s1-trc",name:"Chrome Turkey Red",prefix:"TRC",size:100,parallels:"Blue /50, Green /10, SuperFractor 1/1",notes:"Chrome Turkey Red 2020 — Hobby Jumbo exclusive, same player order as Turkey Red",type:"Insert",players:TR_PLAYERS},
  {id:"s1-tnr",name:"Topps Now Review",prefix:"TNR",size:10,parallels:"—",notes:"Topps Now Review 2019",type:"Insert",players:L("Mike Trout|Vladimir Guerrero Jr.|Albert Pujols|Yordan Alvarez|Shohei Ohtani|Pete Alonso|Mariano Rivera|Bryce Harper|Pete Alonso|Justin Verlander")},
  {id:"s1-hrc",name:"HR Challenge",prefix:"HRC",size:30,parallels:"—",notes:"HR Challenge code cards",type:"Insert",players:L("Bryce Harper|Ronald Acuna Jr.|J.D. Martinez|Freddie Freeman|Mookie Betts|Nolan Arenado|Javier Baez|Kris Bryant|Anthony Rizzo|Francisco Lindor|Aaron Judge|Giancarlo Stanton|Vladimir Guerrero Jr.|George Springer|Juan Soto|Joey Gallo|Paul Goldschmidt|Manny Machado|Fernando Tatis Jr.|Josh Bell|Pete Alonso|Gleyber Torres|Christian Yelich|Mike Trout|Cody Bellinger|Alex Bregman|Yordan Alvarez|Max Kepler|Max Muncy|Rhys Hoskins")},
  {id:"s1-ggm",name:"Global Game Medallion",prefix:"GGM",size:50,parallels:"Black /149, Gold /50, Red /10, Platinum 1/1",notes:"Global Game Medallion manufactured relics — key players tracked",type:"Relic",players:[],known:{"GGM-1":"Mike Trout","GGM-2":"Shohei Ohtani","GGM-3":"Juan Soto","GGM-4":"Ronald Acuna Jr.","GGM-5":"Vladimir Guerrero Jr.","GGM-6":"Yordan Alvarez","GGM-7":"Ichiro","GGM-8":"Ken Griffey Jr."}},
  {id:"s1-itn",name:"In The Name",prefix:"ITN",size:60,parallels:"Relic",notes:"In The Name relics",type:"Relic",players:[]},
  {id:"s1-mlm",name:"Major League Material",prefix:"MLM",size:50,parallels:"Black /199, Gold /50, Red /25, Platinum 1/1",notes:"Major League Material relics",type:"Relic",players:[]},
  {id:"s1-rcr",name:"Rookie Card Retrospective",prefix:"RCR",size:50,parallels:"Black /199, Gold /50, Red /10, Platinum 1/1",notes:"Rookie Card Retrospective RC Logo Medallion manufactured relics",type:"Relic",players:[]},
  {id:"s1-jjsp",name:"Jumbo Jersey Sleeve Patch",prefix:"JJSP",size:46,parallels:"Black /149, Gold /50, Red /10, Platinum 1/1",notes:"Jumbo Jersey Sleeve Patch manufactured relics",type:"Relic",players:[]},
  {id:"s1-ppr",name:"Postseason Performance",prefix:"PPR",size:28,parallels:"Red /25, Platinum 1/1",notes:"Postseason Performance relics",type:"Relic",players:[]},
  {id:"s1-85r",name:"1985 Topps Baseball Relics",prefix:"85R",size:50,parallels:"—",notes:"1985 Topps Baseball Relics",type:"Relic",players:[]},
  {id:"s1-bsa",name:"Baseball Stars Autographs",prefix:"BSA",size:64,parallels:"Auto",notes:"Baseball Stars Autographs",type:"Auto",players:[]},
  {id:"s1-85a",name:"1985 Topps Baseball Autographs",prefix:"85A",size:80,parallels:"Auto",notes:"1985 Topps Baseball Autographs",type:"Auto",players:[]},
  {id:"s1-85c",name:"Silver Pack — 1985 Topps Chrome Variation",prefix:"85C",size:50,parallels:"—",notes:"Silver Pack 1985 Topps Chrome Variation",type:"Insert",players:L("Mike Trout|Shohei Ohtani|Ronald Acuna Jr.|Cal Ripken Jr.|Rafael Devers|Nico Hoerner|Mookie Betts|Kris Bryant|Ryne Sandberg|Dylan Cease|Frank Thomas|Francisco Lindor|Nolan Arenado|Jose Altuve|Nolan Ryan|Yordan Alvarez|Whit Merrifield|Clayton Kershaw|Dustin May|Jordan Yamamoto|Christian Yelich|Keston Hiura|Max Kepler|Darryl Strawberry|Jacob deGrom|Pete Alonso|Aaron Judge|Don Mattingly|Gleyber Torres|Mark McGwire|Bryce Harper|Manny Machado|Fernando Tatis Jr.|Sean Murphy|Will Clark|Ichiro|Ken Griffey Jr.|Paul Goldschmidt|Kyle Lewis|Brendan McKay|Bo Bichette|Vladimir Guerrero Jr.|Juan Soto|Matt Thaiss|Zac Gallen|Aristides Aquino|Robel Garcia|Gavin Lux|Jesus Luzardo|Trent Grisham")},
  {id:"s1-vgj",name:"Target Player Highlight",prefix:"VGJ",size:30,parallels:"Retail",notes:"Target Player Highlight — all Vladimir Guerrero Jr.",type:"Insert",players:Array(30).fill("Vladimir Guerrero Jr.")},
  {id:"s1-rh",name:"Walmart Player Highlight",prefix:"RH",size:30,parallels:"—",notes:"Walmart Player Highlight — all Rhys Hoskins",type:"Insert",players:Array(30).fill("Rhys Hoskins")},
  {id:"s1-otr",name:"Turkey Red Boxtoppers",prefix:"OTR",size:50,parallels:"—",notes:"Turkey Red Boxtoppers",type:"Insert",players:L("Mike Trout|Shohei Ohtani|Ketel Marte|Ronald Acuna Jr.|Freddie Freeman|Trey Mancini|Mookie Betts|Rafael Devers|Javier Baez|Kris Bryant|Nico Hoerner|Eloy Jimenez|Aristides Aquino|Francisco Lindor|Nolan Arenado|Miguel Cabrera|Jose Altuve|Alex Bregman|Yordan Alvarez|Justin Verlander|Whit Merrifield|Cody Bellinger|Clayton Kershaw|Gavin Lux|Christian Yelich|Keston Hiura|Max Kepler|Pete Alonso|Jacob deGrom|Gleyber Torres|Aaron Judge|Giancarlo Stanton|Matt Chapman|Jesus Luzardo|Bryce Harper|Rhys Hoskins|Josh Bell|Manny Machado|Fernando Tatis Jr.|Buster Posey|Kyle Lewis|Yadier Molina|Paul Goldschmidt|Brendan McKay|Joey Gallo|Vladimir Guerrero Jr.|Bo Bichette|Juan Soto|Max Scherzer|Anthony Rendon")},
];
const S1_INSERT_FULL_TOTAL = 515; // 1985 100 + Decades Best 100 + Decades Best Chrome counted in hub total per brief: 100+100+30+20+25+100+100+10+30 = 515 — Chrome Turkey Red is the 100 in that sum (TRC), Decades Best Chrome shares DB order and is listed separately in the hub
const LEGEND_TEAMS: Record<string,string> = {"Dale Murphy":"Braves","Wade Boggs":"Red Sox","Ryne Sandberg":"Cubs","Rod Carew":"Angels","Phil Rizzuto":"Yankees","Larry Doby":"Indians","Eddie Mathews":"Braves","Duke Snider":"Dodgers","Monte Irvin":"Giants","Ralph Kiner":"Pirates","Bert Blyleven":"Twins","Don Sutton":"Dodgers","Phil Niekro":"Braves","Dale Murphy ":"Braves","Lou Gehrig":"Yankees","Honus Wagner":"Pirates","Ty Cobb":"Tigers","Babe Ruth":"Yankees","Sandy Koufax":"Dodgers","Willie Mays":"Giants","Hank Aaron":"Braves","Warren Spahn":"Braves","Frank Robinson":"Reds","Orlando Cepeda":"Giants","Luis Aparicio":"White Sox","Stan Musial":"Cardinals","Jackie Robinson":"Dodgers","Ted Williams":"Red Sox","Johnny Bench":"Reds","Al Kaline":"Tigers","George Brett":"Royals","Robin Yount":"Brewers","Andre Dawson":"Cubs","Roberto Alomar":"Blue Jays","Barry Larkin":"Reds","Edgar Martinez":"Mariners","Mike Mussina":"Orioles","Tom Glavine":"Braves","John Smoltz":"Braves","Roy Oswalt":"Astros","Felix Hernandez":"Mariners","CC Sabathia":"Yankees","Tom Seaver":"Mets","Jim Palmer":"Orioles","Bob Gibson":"Cardinals","Fergie Jenkins":"Cubs","Catfish Hunter":"Athletics","Steve Carlton":"Phillies","Nolan Ryan":"Astros","Don Mattingly":"Yankees","Darryl Strawberry":"Mets","Eddie Murray":"Orioles","George Springer":"Astros","Reggie Jackson":"Athletics","Mark McGwire":"Athletics","Rickey Henderson":"Athletics","Roberto Clemente":"Pirates","Tony Gwynn":"Padres","Will Clark":"Giants","Vladimir Guerrero":"Expos","Ozzie Smith":"Cardinals","Yasiel Puig":"Reds","Adam Jones":"Orioles","Alex Rodriguez":"Yankees"};
function s1InsertTeam(player:string): string {
  if(player.endsWith(" Team")) return player.replace(" Team","");
  for(const key of Object.keys(CARD_NAMES)){ const e = CARD_NAMES[key] && Object.values(CARD_NAMES[key]).find(v=>v.player===player); if(e) return e.team; }
  return LEGEND_TEAMS[player] || "—";
}
function s1InsertRowsFor(def:S1InsertDef): {code:string; player:string; team:string; note:string}[] {
  if(def.players.length) return def.players.map((player,i)=>({code:`${def.prefix}-${i+1}`,player,team:s1InsertTeam(player),note: player.endsWith(" Team") ? "Team Card" : ""}));
  if(def.known) return Object.entries(def.known).map(([code,player])=>({code,player,team:s1InsertTeam(player),note:"Key player — full set tracked by Code"}));
  return [];
}
function getS1InsertEntry(code:string): CardNameEntry | undefined {
  const upper = String(code||"").trim().toUpperCase();
  for(const def of S1_INSERT_DEFS){
    if(def.known && def.known[upper]) { const player = def.known[upper]; return {player, team: s1InsertTeam(player), note: def.name}; }
    if(def.players.length){
      const m = upper.match(new RegExp(`^${def.prefix.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}-?(\\d+)$`));
      if(m){ const n = parseInt(m[1],10); if(n>=1 && n<=def.players.length){ const player = def.players[n-1]; return {player, team: s1InsertTeam(player), note: def.name}; } }
    }
  }
  return undefined;
}

// ---- SERIES 2 EXPANSION: FULL PARALLELS, CLEAR VARIATION, INSERTS HUB ----
const CLEAR_VARIATION_NUMBERS_S2: number[] = [351,355,359,364,366,367,369,370,372,374,376,380,381,386,390,391,392,397,400,401,407,408,410,415,420,421,432,433,434,437,440,442,447,449,450,455,456,458,459,464,465,467,471,475,476,480,485,492,495,497,507,509,514,521,523,526,527,530,531,533,539,540,541,548,549,551,552,555,559,562,567,574,577,583,585,590,597,602,612,615,620,627,631,637,646,654,658,661,665,669,671,672,674,676,678,681,687,691,693,699];
const S2_BASE_PARALLELS = S1_BASE_PARALLELS;
const S2_DB_PLAYERS = L("Detroit Tigers Team|Philadelphia Phillies Team|St. Louis Cardinals Team|Boston Red Sox Team|New York Giants Team|New York Yankees Team|Brooklyn Dodgers Team|Milwaukee Braves Team|Cleveland Indians Team|Chicago White Sox Team|Whitey Ford|Juan Marichal|Jim Bunning|Bob Gibson|Sandy Koufax|Warren Spahn|Hoyt Wilhelm|Fergie Jenkins|Phil Niekro|Don Sutton|Hank Aaron|Frank Robinson|Brooks Robinson|Carl Yastrzemski|Harmon Killebrew|Willie Mays|Willie McCovey|Orlando Cepeda|Roberto Clemente|Roger Maris|Eddie Murray|Carlton Fisk|Andre Dawson|Johnny Bench|Joe Morgan|Rod Carew|Steve Carlton|Tom Seaver|Jim Palmer|Catfish Hunter|Johnny Bench|Jim Rice|Willie Stargell|Rod Carew|Joe Morgan|Reggie Jackson|Mike Schmidt|Willie McCovey|George Foster|Hank Aaron|New York Yankees Team|Oakland Athletics Team|St. Louis Cardinals Team|Detroit Tigers Team|New York Mets Team|Kansas City Royals Team|Los Angeles Dodgers Team|Philadelphia Phillies Team|Minnesota Twins Team|Baltimore Orioles Team|Bert Blyleven|Steve Carlton|Dwight Gooden|Roger Clemens|Nolan Ryan|Jack Morris|Rollie Fingers|Goose Gossage|Bruce Sutter|Dennis Eckersley|Houston Astros Team|Montreal Expos Team|Cleveland Indians Team|Atlanta Braves Team|New York Yankees Team|Toronto Blue Jays Team|Cincinnati Reds Team|Pittsburgh Pirates Team|Texas Rangers Team|Boston Red Sox Team|Albert Pujols|Joe Mauer|Ryan Howard|Alex Rodriguez|Ichiro|Albert Pujols|Randy Johnson|Tim Lincecum|Barry Zito|Pedro Martinez|Justin Verlander|Clayton Kershaw|Max Scherzer|Stephen Strasburg|Felix Hernandez|Chris Sale|Zack Greinke|Jacob deGrom|Corey Kluber|Jon Lester");
const S2_TR_PLAYERS = L("Ken Griffey Jr.|Stephen Strasburg|Joey Votto|Noah Syndergaard|Chris Paddack|Jack Flaherty|Don Mattingly|Frank Thomas|Cal Ripken Jr.|Matt Thaiss|Randy Johnson|Alex Young|Josh Rojas|Chipper Jones|Hank Aaron|Hunter Harvey|Andrew Benintendi|Roger Clemens|Ted Williams|Jackie Robinson|Rod Carew|Nolan Ryan|Robel Garcia|Adbert Alzolay|Anthony Rizzo|Ryne Sandberg|Ernie Banks|Dylan Cease|Zack Collins|Lucas Giolito|Barry Larkin|Sonny Gray|Eugenio Suarez|Shane Bieber|Jim Thome|Trevor Story|Sam Hilliard|David Dahl|Jake Rogers|Nolan Ryan|Jeff Bagwell|George Brett|Jorge Soler|Hyun-Jin Ryu|Corey Seager|Joc Pederson|Sandy Koufax|Isan Diaz|Jordan Yamamoto|Trent Grisham|Robin Yount|Brusdar Graterol|Jose Berrios|Vladimir Guerrero|Michael Conforto|Darryl Strawberry|Luis Severino|Babe Ruth|Reggie Jackson|Lou Gehrig|Rickey Henderson|Mark McGwire|Seth Brown|Sheldon Neuse|Mike Schmidt|J.T. Realmuto|Steve Carlton|Bryan Reynolds|Roberto Clemente|Tony Gwynn|Mauricio Dubon|Jaylin Davis|Ty Cobb|Honus Wagner|Max Muncy|Will Clark|Willie Mays|Ichiro|Edgar Martinez|Justin Dunn|Jake Fraley|Junior Fernandez|Randy Arozarena|Ozzie Smith|Tommy Edman|Tyler Glasnow|Nick Solak|Brock Burke|Elvis Andrus|Roberto Alomar|Anthony Kay|T.J. Zeuch|Lourdes Gurriel Jr.|Victor Robles|Patrick Corbin|Ryan Zimmerman|Stan Musial|Mariano Rivera|Joe Mauer|Andres Munoz");
const S2_WOD_PLAYERS = L("Babe Ruth|Joe Morgan|Hank Aaron|Willie Mays|Roger Clemens|Tom Seaver|Rickey Henderson|Lou Gehrig|Alex Rodriguez|Honus Wagner|Stan Musial|Ted Williams|Ty Cobb|Mike Schmidt|Randy Johnson|Albert Pujols|Carl Yastrzemski|Warren Spahn|Mike Trout|Dwight Gooden|Steve Carlton|Bob Gibson|Pedro Martinez|Sandy Koufax|Jacob deGrom|Justin Verlander|Max Scherzer|Nolan Ryan|Clayton Kershaw|Tom Glavine|Cal Ripken Jr.|Mookie Betts|Chipper Jones|Ernie Banks|Cody Bellinger|Christian Yelich|Alex Bregman|Bryce Harper|Ken Griffey Jr.|George Brett|Jackie Robinson|Roberto Clemente|Frank Robinson|Frank Thomas|Johnny Bench|Eddie Mathews|Rod Carew|Robin Yount|Al Kaline|Wade Boggs");
const S2_SS_PLAYERS = L("Vladimir Guerrero Jr.|Aaron Judge|Mike Trout|Mike Trout|Mike Trout|Miguel Sano|Jorge Soler|Nelson Cruz|Joey Gallo|Rafael Devers|Cody Bellinger|Mike Trout|Nomar Mazara|Christian Yelich|Mike Trout|Josh Hader|Jordan Hicks|Jacob deGrom|Victor Robles|Harrison Bader|Byron Buxton|Lorenzo Cain|J.T. Realmuto|Trea Turner|Austin Hedges");
const S2_2030_PLAYERS = L("Mike Trout|Aaron Judge|Luis Robert|Francisco Lindor|Christian Yelich|Gavin Lux|Ronald Acuna Jr.|Bo Bichette|Kris Bryant|Nolan Arenado|Pete Alonso|Juan Soto|Fernando Tatis Jr.|Bryce Harper|Alex Bregman|Mookie Betts|Cody Bellinger|Vladimir Guerrero Jr.|Javier Baez|Shohei Ohtani");
const S2_85TB_PLAYERS = L("Anthony Rendon|Ketel Marte|Freddie Freeman|Austin Riley|Trey Mancini|Andrew Benintendi|David Ortiz|Javier Baez|Tim Anderson|Jose Abreu|Sonny Gray|Eugenio Suarez|Barry Larkin|Mike Clevinger|Carlos Santana|Trevor Story|Charlie Blackmon|Gerrit Cole|Carlos Correa|Jorge Soler|Cody Bellinger|Corey Seager|Lorenzo Cain|Nelson Cruz|Miguel Sano|Robinson Cano|Marcus Stroman|Masahiro Tanaka|Giancarlo Stanton|DJ LeMahieu|Matt Olson|Mookie Betts|Marcus Semien|Aaron Nola|J.T. Realmuto|Andrew McCutchen|Josh Bell|Trent Grisham|Buster Posey|Mike Yastrzemski|Kyle Lewis|Randy Johnson|Jack Flaherty|Jose Canseco|Tyler Glasnow|Joey Gallo|Luis Robert|Roberto Alomar|Stephen Strasburg|Trea Turner");
const S2_85AS_PLAYERS = L("Mike Trout|Aaron Judge|Roger Clemens|Cal Ripken Jr.|Reggie Jackson|Rickey Henderson|Carl Yastrzemski|Mark McGwire|Johnny Bench|Hideki Matsui|Bo Jackson|Ryne Sandberg|Andre Dawson|Chris Sale|Tom Glavine|Willson Contreras|Jacob deGrom|Francisco Lindor|Christian Yelich|Luis Severino|Wade Boggs|Robin Yount|Don Mattingly|Ozzie Smith|Jose Altuve|Bob Gibson|Carlton Fisk|Dale Murphy|Will Clark|Darryl Strawberry|Edgar Martinez|Blake Snell|Ozzie Albies|Jim Rice|Rod Carew|Paul Goldschmidt|George Springer|Max Scherzer|Ronald Acuna Jr.|Ken Griffey Jr.|Ketel Marte|Nolan Arenado|Gleyber Torres|Pete Alonso|Jeff McNeil|Lucas Giolito|Shane Bieber|Jose Berrios|Clayton Kershaw|Kris Bryant");
const S2_85TC_PLAYERS = L("Ketel Marte|Shogo Akiyama|Chipper Jones|Ozzie Albies|Hunter Harvey|Xander Bogaerts|Adbert Alzolay|Anthony Rizzo|Javier Baez|Eloy Jimenez|Zack Collins|Joey Votto|Aaron Civale|Kwang-Hyun Kim|Sam Hilliard|Jake Rogers|Alex Bregman|Justin Verlander|Abraham Toro|Jose Urquidy|George Brett|Jorge Soler|Cody Bellinger|Isan Diaz|Robin Yount|Noah Syndergaard|Shun Yamaguchi|Masahiro Tanaka|A.J. Puk|Sheldon Neuse|Matt Chapman|Rickey Henderson|Roberto Clemente|Tony Gwynn|Giancarlo Stanton|Mauricio Dubon|Jaylin Davis|Buster Posey|Justin Dunn|Randy Johnson|Randy Arozarena|Yadier Molina|Brandon Lowe|Nick Solak|Josh Rojas|Danny Mendick|Anthony Kay|Luis Robert|Carter Kieboom|Max Scherzer");
const S2_BTN_PLAYERS = L("Juan Soto|Howie Kendrick|Juan Soto|Justin Verlander|Mike Trout|Yordan Alvarez / Pete Alonso|Anthony Rendon|Gerrit Cole|Luis Robert|Mookie Betts");
const S2_HRC_PLAYERS = L("Bryce Harper|Ronald Acuna Jr.|J.D. Martinez|Freddie Freeman|Mookie Betts|Nolan Arenado|Javier Baez|Kris Bryant|Anthony Rizzo|Francisco Lindor|Aaron Judge|Giancarlo Stanton|Vladimir Guerrero Jr.|George Springer|Juan Soto|Joey Gallo|Paul Goldschmidt|Manny Machado|Fernando Tatis Jr.|Josh Bell|Pete Alonso|Gleyber Torres|Christian Yelich|Mike Trout|Cody Bellinger|Alex Bregman|Yordan Alvarez|Max Kepler|Max Muncy|Rhys Hoskins");
const S2_INSERT_DEFS: S1InsertDef[] = [
  {id:"s2-db",name:"Decades Best S2",prefix:"DB",size:100,parallels:"Blue, Green, Black /299, Gold /50, Red /10, Platinum 1/1",notes:"Decades' Best Series 2",type:"Insert",players:S2_DB_PLAYERS},
  {id:"s2-dbc",name:"Decades Best Chrome S2",prefix:"DBC",size:100,parallels:"Gold /50",notes:"Decades' Best Chrome Series 2 — same player order as Decades Best S2. Hobby Jumbo exclusive.",type:"Insert",players:S2_DB_PLAYERS},
  {id:"s2-wod",name:"Warriors of the Diamond",prefix:"WOD",size:50,parallels:"—",notes:"Warriors of the Diamond",type:"Insert",players:S2_WOD_PLAYERS},
  {id:"s2-mt",name:"Player of the Decade",prefix:"MT",size:25,parallels:"—",notes:"Topps Player of the Decade — all Mike Trout",type:"Insert",players:Array(25).fill("Mike Trout")},
  {id:"s2-ss",name:"Significant Statistics",prefix:"SS",size:25,parallels:"—",notes:"Significant Statistics",type:"Insert",players:S2_SS_PLAYERS},
  {id:"s2-2030",name:"Topps 2030",prefix:"T2030",size:20,parallels:"—",notes:"Topps 2030",type:"Insert",players:S2_2030_PLAYERS},
  {id:"s2-85tb",name:"1985 Topps S2",prefix:"85TB",size:50,parallels:"—",notes:"1985 Topps Baseball Series 2",type:"Insert",players:S2_85TB_PLAYERS},
  {id:"s2-85as",name:"1985 All Stars",prefix:"85AS",size:50,parallels:"—",notes:"1985 Topps Baseball All Stars",type:"Insert",players:S2_85AS_PLAYERS},
  {id:"s2-esaw",name:"Empire State",prefix:"ESAW",size:30,parallels:"—",notes:"Empire State Awards Winners — all Pete Alonso. Walmart exclusive.",type:"Insert",players:Array(30).fill("Pete Alonso")},
  {id:"s2-fth",name:"Tatis Highlights",prefix:"FTH",size:30,parallels:"—",notes:"Fernando Tatis Jr Highlights — all Fernando Tatis Jr. Target exclusive.",type:"Insert",players:Array(30).fill("Fernando Tatis Jr.")},
  {id:"s2-tr",name:"Turkey Red S2",prefix:"TR",size:100,parallels:"Blue /50, Green /10, Black 1/1",notes:"Turkey Red 2020 Series 2 — Retail exclusive",type:"Insert",players:S2_TR_PLAYERS},
  {id:"s2-trc",name:"Chrome Turkey Red S2",prefix:"TRC",size:100,parallels:"Blue /50, Green /10, SuperFractor 1/1",notes:"Chrome Turkey Red Series 2 — same player order as Turkey Red S2",type:"Insert",players:S2_TR_PLAYERS},
  {id:"s2-hrc",name:"HR Challenge",prefix:"HRC",size:30,parallels:"—",notes:"HR Challenge Series 2 code cards",type:"Insert",players:S2_HRC_PLAYERS},
  {id:"s2-85tc",name:"1985 Chrome Promo",prefix:"85TC",size:50,parallels:"—",notes:"1985 Topps Baseball Chrome Promo — Silver Pack exclusive",type:"Insert",players:S2_85TC_PLAYERS},
  {id:"s2-btn",name:"Best of Topps Now",prefix:"BTN",size:10,parallels:"—",notes:"Best of Topps Now",type:"Insert",players:S2_BTN_PLAYERS},
];
const S2_INSERT_AUTO_DEFS: S1InsertDef[] = [
  {id:"s2-tmta",name:"Player of the Decade Auto",prefix:"TMTA",size:25,parallels:"Auto",notes:"Player of the Decade Auto Parallel — all Mike Trout",type:"Auto",players:Array(25).fill("Mike Trout")},
  {id:"s2-esawa",name:"Empire State Auto",prefix:"ESAWA",size:30,parallels:"Auto",notes:"Empire State Auto Parallel — all Pete Alonso",type:"Auto",players:Array(30).fill("Pete Alonso")},
  {id:"s2-ftjha",name:"Tatis Highlights Auto",prefix:"FTJHA",size:30,parallels:"Auto",notes:"Tatis Highlights Auto Parallel — all Fernando Tatis Jr.",type:"Auto",players:Array(30).fill("Fernando Tatis Jr.")},
];
const S2_HUB_DEFS: S1InsertDef[] = [...S2_INSERT_DEFS, ...S2_INSERT_AUTO_DEFS];
const S2_OTHER_INSERTS: {name:string; codes:string; examples:string; parallels:string; size:string}[] = [
  {name:"Baseball Stars Autographs S2",codes:"BSA-*",examples:"BSA-LR Luis Robert · BSA-GL Gavin Lux · BSA-JS Juan Soto",parallels:"Auto",size:"60+"},
  {name:"Baseball Stars Dual Autographs S2",codes:"BSDA-*",examples:"Enter a BSDA code in Add Card",parallels:"Auto",size:"—"},
  {name:"Decades Best Autograph Parallel",codes:"DBA-*",examples:"Enter a DBA code in Add Card",parallels:"Auto",size:"—"},
  {name:"Warriors of the Diamond Autograph Parallel",codes:"WARA-*",examples:"Enter a WARA code in Add Card",parallels:"Auto",size:"—"},
  {name:"1985 All Stars Autograph Variation",codes:"85ASA-*",examples:"Enter an 85ASA code in Add Card",parallels:"Auto",size:"—"},
  {name:"1985 Topps Autograph Variation",codes:"85A-*",examples:"Enter an 85A code in Add Card",parallels:"Auto",size:"—"},
  {name:"Significant Statistics Autograph Variation",codes:"SSA-*",examples:"Enter an SSA code in Add Card",parallels:"Auto",size:"—"},
  {name:"Jumbo Special Event Jersey Sleeve Team Patch",codes:"JSES-*",examples:"Enter a JSES code in Add Card",parallels:"Relic",size:"—"},
  {name:"1985 Chrome Promo Autograph Variation",codes:"85CA-*",examples:"Enter an 85CA code in Add Card",parallels:"Auto",size:"—"},
];
const S2_OTHER_KNOWN: Record<string,string> = {"BSA-LR":"Luis Robert","BSA-GL":"Gavin Lux","BSA-JS":"Juan Soto"};
const S2_LEGEND_TEAMS: Record<string,string> = {"Whitey Ford":"Yankees","Juan Marichal":"Giants","Jim Bunning":"Phillies","Hoyt Wilhelm":"Orioles","Jack Morris":"Tigers","Bruce Sutter":"Cardinals","Rollie Fingers":"Athletics","Goose Gossage":"Yankees","Dennis Eckersley":"Athletics","Dwight Gooden":"Mets","Tim Lincecum":"Giants","Barry Zito":"Athletics","Joe Mauer":"Twins","Ryan Howard":"Phillies","Jim Rice":"Red Sox","Willie Stargell":"Pirates","George Foster":"Reds","Brooks Robinson":"Orioles","Carl Yastrzemski":"Red Sox","Harmon Killebrew":"Twins","Roger Maris":"Yankees","Carlton Fisk":"Red Sox","Hideki Matsui":"Yankees","Bo Jackson":"Royals","Jim Thome":"Indians","Jose Canseco":"Athletics","Vladimir Guerrero":"Expos"};
function s2InsertTeam(player:string): string {
  if(player.endsWith(" Team")) return player.replace(" Team","");
  if(player.includes(" / ")) { const first = player.split(" / ")[0]; const t = s2InsertTeam(first); if(t!=="—") return t; }
  for(const key of Object.keys(CARD_NAMES)){ const e = CARD_NAMES[key] && Object.values(CARD_NAMES[key]).find(v=>v.player===player); if(e) return e.team; }
  return S2_LEGEND_TEAMS[player] || LEGEND_TEAMS[player] || "—";
}
function s2InsertRowsFor(def:S1InsertDef): {code:string; player:string; team:string; note:string}[] {
  if(def.players.length) return def.players.map((player,i)=>({code:`${def.prefix}-${i+1}`,player,team:s2InsertTeam(player),note: player.endsWith(" Team") ? "Team Card" : ""}));
  if(def.known) return Object.entries(def.known).map(([code,player])=>({code,player,team:s2InsertTeam(player),note:"Key player — full set tracked by Code"}));
  return [];
}
function getS2InsertEntry(code:string): CardNameEntry | undefined {
  const upper = String(code||"").trim().toUpperCase();
  if(S2_OTHER_KNOWN[upper]) { const player=S2_OTHER_KNOWN[upper]; return {player, team: s2InsertTeam(player), note: "Baseball Stars Autographs S2"}; }
  for(const def of S2_HUB_DEFS){
    if(def.known && def.known[upper]) { const player = def.known[upper]; return {player, team: s2InsertTeam(player), note: def.name}; }
    if(def.players.length){
      const m = upper.match(new RegExp(`^${def.prefix.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}-?(\\d+)$`));
      if(m){ const n = parseInt(m[1],10); if(n>=1 && n<=def.players.length){ const player = def.players[n-1]; return {player, team: s2InsertTeam(player), note: def.name}; } }
    }
  }
  return undefined;
}
const S2_INSERT_FULL_TOTAL = 770;

// ---- UPDATE EXPANSION: FULL PARALLELS, SP / SSP / SSSP / CLEAR, INSERTS HUB ----
const UPD_BASE_PARALLELS: {name:string; rarity:string; notes:string}[] = [
  {name:"Purple (Meijer)",rarity:"Retail",notes:"Purple parallel — Meijer"},
  {name:"Royal Blue (Walmart Blaster)",rarity:"Retail",notes:"Royal Blue parallel — Walmart Blaster"},
  {name:"Yellow (Walgreens Hanger)",rarity:"Retail",notes:"Yellow parallel — Walgreens Hanger"},
  {name:"Rainbow Foil",rarity:"Foil",notes:"Rainbow foil parallel"},
  {name:"Gold Foil (Jumbo)",rarity:"Foil",notes:"Gold foil parallel — Jumbo"},
  {name:"Gold /2020",rarity:"/2020",notes:"Numbered to 2020"},
  {name:"Advanced Stat /300",rarity:"/300",notes:"Advanced Stat parallel, numbered to 300"},
  {name:"Vintage Stock /99",rarity:"/99",notes:"Vintage stock, numbered to 99"},
  {name:"Independence Day /76",rarity:"/76",notes:"Numbered to 76"},
  {name:"Black /69",rarity:"/69",notes:"Black parallel, numbered to 69"},
  {name:"Mother's Day Hot Pink /50",rarity:"/50",notes:"Numbered to 50"},
  {name:"Father's Day Powder Blue /50",rarity:"/50",notes:"Numbered to 50"},
  {name:"Memorial Day Camo /25",rarity:"/25",notes:"Numbered to 25"},
  {name:"Platinum 1/1",rarity:"1/1",notes:"One of one"},
  {name:"Cyan Printing Plate 1/1",rarity:"1/1",notes:"Cyan printing plate, one of one"},
  {name:"Magenta Printing Plate 1/1",rarity:"1/1",notes:"Magenta printing plate, one of one"},
  {name:"Yellow Printing Plate 1/1",rarity:"1/1",notes:"Yellow printing plate, one of one"},
  {name:"Black Printing Plate 1/1",rarity:"1/1",notes:"Black printing plate, one of one"},
];
const UPD_DB_PLAYERS = L("Whitey Ford|Bob Lemon|Early Wynn|Robin Roberts|Warren Spahn|Hoyt Wilhelm|Bob Feller|Jim Bunning|Sandy Koufax|Hal Newhouser|Rod Carew|Tom Seaver|Frank Robinson|Carl Yastrzemski|Brooks Robinson|Sandy Koufax|Bob Gibson|Roberto Clemente|Willie Mays|Sandy Koufax|Cincinnati Reds Team|Baltimore Orioles Team|Pittsburgh Pirates Team|Los Angeles Dodgers Team|Boston Red Sox Team|New York Yankees Team|Oakland Athletics Team|Philadelphia Phillies Team|Kansas City Royals Team|New York Mets Team|Mike Schmidt|Ryne Sandberg|Cal Ripken Jr.|Dale Murphy|Dwight Gooden|Jose Canseco|Roger Clemens|Don Mattingly|Steve Carlton|Mark McGwire|Roger Clemens|Randy Johnson|Tom Glavine|Pedro Martinez|Mike Mussina|John Smoltz|David Cone|Dennis Eckersley|Andy Pettitte|Mariano Rivera|Boston Red Sox Team|New York Yankees Team|St. Louis Cardinals Team|Angels Team|Philadelphia Phillies Team|Arizona Diamondbacks Team|Chicago White Sox Team|Atlanta Braves Team|Oakland Athletics Team|Houston Astros Team|Albert Pujols|Ichiro|Miguel Cabrera|Ryan Howard|Alex Rodriguez|Vladimir Guerrero|Jim Thome|David Ortiz|Todd Helton|Chipper Jones|Mike Trout|Andrew McCutchen|Joey Votto|Paul Goldschmidt|Mookie Betts|Miguel Cabrera|Christian Yelich|Nolan Arenado|Freddie Freeman|Jose Altuve");
const UPD_DB_TEAMS = L("Yankees|Indians|Indians|Phillies|Braves|Orioles|Indians|Phillies|Dodgers|Tigers|Angels|Mets|Reds|Red Sox|Orioles|Dodgers|Cardinals|Pirates|Giants|Dodgers|Reds|Orioles|Pirates|Dodgers|Red Sox|Yankees|Athletics|Phillies|Royals|Mets|Phillies|Cubs|Orioles|Braves|Mets|Athletics|Yankees|Yankees|Phillies|Athletics|Yankees|Diamondbacks|Braves|Red Sox|Orioles|Braves|Yankees|Athletics|Yankees|Yankees|Red Sox|Yankees|Cardinals|Angels|Phillies|Diamondbacks|White Sox|Braves|Athletics|Astros|Angels|Mariners|Tigers|Phillies|Yankees|Expos|Indians|Red Sox|Rockies|Braves|Angels|Pirates|Reds|Cardinals|Dodgers|Tigers|Brewers|Rockies|Braves|Astros");
const UPD_PROSPECT_PLAYERS = L("Evan White|Nate Pearson|Wander Franco|Jo Adell|Tyler Stephenson|MacKenzie Gore|Cristian Pache|Josh Jung|Ke'Bryan Hayes|Bobby Dalbec|Colton Welker|Alec Bohm|Nick Allen|Ethan Small|Ryan Mountcastle|Andres Gimenez|Brady Singer|Casey Mize|Alex Kirilloff|Forrest Whitley|Keibert Ruiz|Brennen Davis|Sixto Sanchez|Nick Madrigal|Joey Bart|Daulton Varsho|Dylan Carlson|Nolan Jones|Luis Garcia|Clarke Schmidt");
const UPD_PROSPECT_TEAMS = L("Mariners|Blue Jays|Rays|Angels|Reds|Padres|Braves|Rangers|Pirates|Red Sox|Rockies|Phillies|Athletics|Brewers|Orioles|Mets|Royals|Tigers|Twins|Astros|Dodgers|Cubs|Marlins|White Sox|Giants|Diamondbacks|Cardinals|Indians|Nationals|Yankees");
const UPD_NG_PLAYERS = L("Roberto Alomar|Ryne Sandberg|Roberto Clemente|Randy Johnson|Rickey Henderson|Nolan Ryan|Jackie Robinson|Jeff Bagwell|Chipper Jones|Ken Griffey Jr.|Stan Musial|Robin Yount|Mariano Rivera|Ted Williams|Tony Gwynn|Cal Ripken Jr.|Mike Piazza|Willie Mays|Ernie Banks|Sandy Koufax|Ozzie Smith|Derek Jeter|Mike Schmidt|Johnny Bench|Hank Aaron");
const UPD_NG_TEAMS = L("Blue Jays|Cubs|Pirates|Diamondbacks|Athletics|Astros|Dodgers|Astros|Braves|Mariners|Cardinals|Brewers|Yankees|Red Sox|Padres|Orioles|Mets|Giants|Cubs|Dodgers|Cardinals|Yankees|Phillies|Reds|Braves");
const UPD_85TB_PLAYERS = L("Derek Jeter|Josh Donaldson|Yoshi Tsutsugo|Shogo Akiyama|Mike Trout|Starling Marte|Ronald Acuna Jr.|Fred McGriff|Eddie Murray|Jackie Robinson|Ernie Banks|Andre Dawson|Javier Baez|Luis Robert|Yoan Moncada|Frank Robinson|Joe Morgan|Yordan Alvarez|Gavin Lux|Cody Bellinger|David Price|Mookie Betts|Christian Yelich|Tim Raines|Willie Mays|Dwight Gooden|David Wright|Pete Alonso|Aaron Judge|Thurman Munson|Jesus Luzardo|A.J. Puk|Bryce Harper|Ryan Howard|Mike Schmidt|Willie Stargell|Fernando Tatis Jr.|Dave Winfield|Willie McCovey|Tim Lincecum|Ken Griffey Jr.|Bob Gibson|Lou Brock|Nolan Ryan|Bo Bichette|Juan Soto|Shohei Ohtani|Austin Meadows|Roberto Clemente|Lewis Brinson");
const UPD_85TB_TEAMS = L("Yankees|Twins|Rays|Reds|Angels|Diamondbacks|Braves|Braves|Orioles|Dodgers|Cubs|Cubs|Cubs|White Sox|White Sox|Reds|Reds|Astros|Dodgers|Dodgers|Dodgers|Dodgers|Brewers|Expos|Giants|Mets|Mets|Mets|Yankees|Yankees|Athletics|Athletics|Phillies|Phillies|Phillies|Pirates|Padres|Yankees|Giants|Giants|Mariners|Cardinals|Cardinals|Astros|Blue Jays|Nationals|Angels|Rays|Pirates|Marlins");
const UPD_YOC_YEARS = [95,96,97,98,99,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14];
const UPD_YOC_CODES = UPD_YOC_YEARS.map(y=>`YOC-${String(y).padStart(2,"0")}`);
const UPD_TR_PLAYERS = L("CC Sabathia|Willie McCovey|Ozzie Albies|Hunter Pence|Mookie Betts|Yordan Alvarez|David Price|Gavin Lux|Craig Biggio|Dave Winfield|Bo Bichette|Carlton Fisk|Andrew McCutchen|Shogo Akiyama|Ken Griffey Jr.|Thurman Munson|Shun Yamaguchi|Gary Carter|Lewis Brinson|Kwang-Hyun Kim|Tom Seaver|Gerrit Cole|Trea Turner|Yoshi Tsutsugo|Marcus Semien|Nick Castellanos|Luis Robert|Andy Pettitte|Anthony Rendon|Ron Santo|Johnny Bench|Mike Piazza|Yasmani Grandal|Eddie Murray|Dale Murphy|Mark Grace|Mike Clevinger|Mike Mussina|Trevor Bauer|Kerry Wood|Corey Kluber|Brooks Robinson|John Smoltz|Byron Buxton|Carter Kieboom|Wade Boggs|Larry Walker|Willie Stargell|Derek Jeter|Nolan Ryan");
const UPD_TR_TEAMS = L("Yankees|Giants|Braves|Giants|Dodgers|Astros|Dodgers|Dodgers|Astros|Yankees|Blue Jays|Red Sox|Pirates|Reds|Mariners|Yankees|Blue Jays|Mets|Marlins|Cardinals|Mets|Yankees|Nationals|Rays|Athletics|Reds|White Sox|Yankees|Angels|Cubs|Reds|Mets|White Sox|Orioles|Braves|Cubs|Indians|Orioles|Reds|Cubs|Rangers|Orioles|Braves|Twins|Nationals|Red Sox|Rockies|Pirates|Yankees|Astros");
const UPD_CPC_PLAYERS = L("Yordan Alvarez|Derek Jeter|Mariano Rivera|Rhys Hoskins|Travis Demeritte|Walker Buehler|Shohei Ohtani|Michael Brosseau|Luis Robert|Sonny Gray|Cody Bellinger|Nick Castellanos|Willson Contreras|Bo Bichette|Hyun-Jin Ryu|Jesus Luzardo|Josh Staumont|Yoshi Tsutsugo|Mookie Betts|Shogo Akiyama|A.J. Puk|Gerrit Cole|Gavin Lux|Willi Castro|Roger Clemens|Andrew Benintendi|Brusdar Graterol|Zac Gallen|Rangel Ravelo|Ronald Acuna Jr.|Stephen Strasburg|Cavan Biggio|Shane Bieber|Josh Donaldson|Fernando Tatis Jr.|Brock Burke|Tommy Edman|Tony Gonsolin|Genesis Cabrera|Bobby Bradley|George Springer|Mike Yastrzemski|Trent Grisham|Dale Murphy|Mike Trout|Anthony Rendon|Yonathan Daza|Seth Brown|Juan Soto|Christian Yelich");
const UPD_CPC_TEAMS = L("Astros|Yankees|Yankees|Phillies|Tigers|Dodgers|Angels|Rays|White Sox|Reds|Dodgers|Reds|Cubs|Blue Jays|Blue Jays|Athletics|Royals|Rays|Dodgers|Reds|Athletics|Yankees|Dodgers|Tigers|Yankees|Red Sox|Dodgers|Diamondbacks|Cardinals|Braves|Nationals|Blue Jays|Indians|Twins|Padres|Rangers|Cardinals|Dodgers|Cardinals|Indians|Astros|Giants|Padres|Braves|Angels|Angels|Rockies|Athletics|Nationals|Brewers");
const UPD_INSERT_DEFS: S1InsertDef[] = [
  {id:"upd-db",name:"Decades Best Update",prefix:"DB",size:80,parallels:"Blue, Green, Black /299, Gold /50, Red /10, Platinum 1/1",notes:"Decades' Best Update",type:"Insert",players:UPD_DB_PLAYERS,teams:UPD_DB_TEAMS},
  {id:"upd-p",name:"Prospects",prefix:"P",size:30,parallels:"—",notes:"Prospects Insert",type:"Insert",players:UPD_PROSPECT_PLAYERS,teams:UPD_PROSPECT_TEAMS},
  {id:"upd-ng",name:"A Numbers Game",prefix:"NG",size:25,parallels:"—",notes:"A Numbers Game",type:"Insert",players:UPD_NG_PLAYERS,teams:UPD_NG_TEAMS},
  {id:"upd-85tb",name:"1985 Topps Update",prefix:"85TB",size:50,parallels:"—",notes:"1985 Topps Baseball Update",type:"Insert",players:UPD_85TB_PLAYERS,teams:UPD_85TB_TEAMS},
  {id:"upd-yoc",name:"20 Years of the Captain",prefix:"YOC",size:20,parallels:"Auto Parallel 20CA-95 to 20CA-14 · Commemorative Patch Auto 20CPA-95 to 20CPA-14",notes:"20 Years of the Captain — all Derek Jeter",type:"Insert",players:Array(20).fill("Derek Jeter"),teams:Array(20).fill("Yankees"),codes:UPD_YOC_CODES},
  {id:"upd-tra",name:"Acuna Highlights",prefix:"TRA",size:20,parallels:"Auto Parallel TRA-1 to TRA-20 (same codes, Variant=Auto)",notes:"Ronald Acuna Jr. Highlights — all Ronald Acuna Jr. Target Exclusive",type:"Insert",players:Array(20).fill("Ronald Acuna Jr."),teams:Array(20).fill("Braves")},
  {id:"upd-tr",name:"Turkey Red Update",prefix:"TR",size:50,parallels:"Blue /50, Green /10, Black 1/1",notes:"Turkey Red 2020 Update — Retail Exclusive",type:"Insert",players:UPD_TR_PLAYERS,teams:UPD_TR_TEAMS},
  {id:"upd-trc",name:"Chrome Turkey Red Update",prefix:"TRC",size:50,parallels:"Blue /50, Green /10, SuperFractor 1/1",notes:"Chrome Turkey Red Update — same player order as Turkey Red Update",type:"Insert",players:UPD_TR_PLAYERS,teams:UPD_TR_TEAMS},
  {id:"upd-cpc",name:"Chrome Promo Update",prefix:"CPC",size:50,parallels:"—",notes:"1985 Topps Baseball Chrome Promo Update — Silver Pack Exclusive",type:"Insert",players:UPD_CPC_PLAYERS,teams:UPD_CPC_TEAMS},
];
type UpdCodeEntry = [string,string,string,string?];
function updCodeDef(id:string,name:string,prefix:string,parallels:string,notes:string,type:SubsetType,entries:UpdCodeEntry[]): S1InsertDef {
  const known:Record<string,string>={}; const knownTeams:Record<string,string>={}; const knownNotes:Record<string,string>={};
  for(const [code,player,team,note] of entries){ known[code]=player; knownTeams[code]=team; if(note) knownNotes[code]=note; }
  return {id,name,prefix,size:entries.length,parallels,notes,type,players:[],known,knownTeams,knownNotes};
}
const UPD_20CA_CODES = ["00","01","02","03","04","05","06","07","08","09","10","11","12","13","14","95","96","97","98","99"];
const UPD_20YCC_CODES = ["95","96","97","98","99","00","01","02","03","04","05","06","07","08","09","10","11","12","13","14"];
const UPD_CODE_DEFS: S1InsertDef[] = [
  updCodeDef("upd-dba","Decades Best Autograph Parallel Update","DBA","Auto","Decades Best Autograph Parallel Update — full checklist","Auto",[["DBA-AP","Andy Pettitte","Yankees"],["DBA-AR","Alex Rodriguez","Yankees"],["DBA-BG","Bob Gibson","Cardinals"],["DBA-CJ","Chipper Jones","Braves"],["DBA-CR","Cal Ripken Jr.","Orioles"],["DBA-CY","Carl Yastrzemski","Red Sox"],["DBA-DC","David Cone","Royals"],["DBA-DE","Dennis Eckersley","Athletics"],["DBA-DG","Dwight Gooden","Mets"],["DBA-DM","Dale Murphy","Braves"],["DBA-DMA","Don Mattingly","Yankees"],["DBA-DO","David Ortiz","Red Sox"],["DBA-FF","Freddie Freeman","Braves"],["DBA-FR","Frank Robinson","Orioles"],["DBA-I","Ichiro","Mariners"],["DBA-JA","Jose Altuve","Astros"],["DBA-JS","John Smoltz","Braves"],["DBA-JT","Jim Thome","Indians"],["DBA-JV","Joey Votto","Reds"],["DBA-MC","Miguel Cabrera","Tigers"],["DBA-MM","Mark McGwire","Athletics"],["DBA-MMU","Mike Mussina","Orioles"],["DBA-MR","Mariano Rivera","Yankees"],["DBA-MS","Mike Schmidt","Phillies"],["DBA-MT","Mike Trout","Angels"],["DBA-NA","Nolan Arenado","Rockies"],["DBA-PG","Miguel Cabrera","Tigers"],["DBA-PGO","Paul Goldschmidt","Cardinals"],["DBA-PM","Pedro Martinez","Red Sox"],["DBA-RCL","Roger Clemens","Red Sox"],["DBA-RH","Ryan Howard","Phillies"],["DBA-RJ","Randy Johnson","Mariners"],["DBA-ROC","Roger Clemens","Red Sox"],["DBA-RS","Ryne Sandberg","Cubs"],["DBA-SC","Steve Carlton","Phillies"],["DBA-SK","Sandy Koufax","Dodgers"],["DBA-TG","Tom Glavine","Braves"],["DBA-TH","Todd Helton","Rockies"],["DBA-VG","Vladimir Guerrero","Expos"]]),
  updCodeDef("upd-pa","Prospects Insert Autographs","PA","Auto","Prospects Insert Autographs — full checklist","Auto",[["PA-AB","Alec Bohm","Phillies"],["PA-BD","Bobby Dalbec","Red Sox"],["PA-BDA","Brennen Davis","Cubs"],["PA-BS","Brady Singer","Royals"],["PA-CM","Casey Mize","Tigers"],["PA-CP","Cristian Pache","Braves"],["PA-CS","Clarke Schmidt","Yankees"],["PA-CW","Colton Welker","Rockies"],["PA-ES","Ethan Small","Brewers"],["PA-EW","Evan White","Mariners"],["PA-JA","Jo Adell","Angels"],["PA-JB","Joey Bart","Giants"],["PA-JJ","Josh Jung","Rangers"],["PA-KR","Keibert Ruiz","Dodgers"],["PA-LG","Luis Garcia","Nationals"],["PA-MG","MacKenzie Gore","Padres"],["PA-NM","Nick Madrigal","White Sox"],["PA-NP","Nate Pearson","Blue Jays"],["PA-RM","Ryan Mountcastle","Orioles"],["PA-WF","Wander Franco","Rays"]]),
  updCodeDef("upd-nga","A Numbers Game Autographs","NGA","Auto","A Numbers Game Autographs — full checklist","Auto",[["NGA-CJ","Chipper Jones","Braves"],["NGA-CR","Cal Ripken Jr.","Orioles"],["NGA-DJ","Derek Jeter","Yankees"],["NGA-JB","Jeff Bagwell","Astros"],["NGA-JBE","Johnny Bench","Reds"],["NGA-MR","Mariano Rivera","Yankees"],["NGA-MS","Mike Schmidt","Phillies"],["NGA-NR","Nolan Ryan","Rangers"],["NGA-OS","Ozzie Smith","Cardinals"],["NGA-RA","Roberto Alomar","Blue Jays"],["NGA-RH","Rickey Henderson","Athletics"],["NGA-RJ","Randy Johnson","Diamondbacks"],["NGA-RS","Ryne Sandberg","Cubs"],["NGA-RY","Robin Yount","Brewers"],["NGA-SK","Sandy Koufax","Dodgers"]]),
  updCodeDef("upd-20ca","20 Years of the Captain Autographs","20CA","Auto","20 Years of the Captain Autographs — all Derek Jeter","Auto",UPD_20CA_CODES.map(c=>[`20CA-${c}`,"Derek Jeter","Yankees"] as UpdCodeEntry)),
  updCodeDef("upd-tra-auto","Ronald Acuna Jr Highlights Autographs","TRA","Auto","Ronald Acuna Jr Highlights Autographs — all Ronald Acuna Jr.","Auto",Array.from({length:20},(_,i)=>[`TRA-${i+1}`,"Ronald Acuna Jr.","Braves"] as UpdCodeEntry)),
  updCodeDef("upd-bsa","Baseball Stars Autographs Update","BSA","Auto","Baseball Stars Autographs Update — full checklist","Auto",[["BSA-AK","Andrew Knapp","Phillies"],["BSA-AR","Anthony Rendon","Angels"],["BSA-BO","Brian O'Grady","Rays","Rookie"],["BSA-CD","Corey Dickerson","Marlins"],["BSA-CM","Charlie Morton","Rays"],["BSA-DA","Dario Agrazal","Tigers","Rookie"],["BSA-DB","David Bote","Cubs"],["BSA-DJ","Danny Jansen","Blue Jays"],["BSA-DP","David Price","Dodgers"],["BSA-ER","Eduardo Rodriguez","Red Sox"],["BSA-ET","Eric Thames","Nationals"],["BSA-GC","Gerrit Cole","Yankees"],["BSA-HR","Hyun-Jin Ryu","Blue Jays"],["BSA-JB","Jon Berti","Marlins","Rookie"],["BSA-JG","Joey Gallo","Rangers"],["BSA-JH","J.D. Hammer","Phillies"],["BSA-JM","Jack Mayfield","Astros","Rookie"],["BSA-JS","Juan Soto","Nationals"],["BSA-KK","Kwang-Hyun Kim","Cardinals","Rookie"],["BSA-KM","Ketel Marte","Diamondbacks"],["BSA-KMA","Kenta Maeda","Twins"],["BSA-KN","Kevin Newman","Pirates"],["BSA-KW","Kolten Wong","Cardinals"],["BSA-LB","Lewis Brinson","Marlins"],["BSA-LR","Luis Robert","White Sox","Rookie"],["BSA-LW","LaMonte Wade Jr.","Twins","Rookie"],["BSA-MM","Mike Moustakas","Reds"],["BSA-MS","Marcus Stroman","Mets"],["BSA-MSE","Marcus Semien","Athletics"],["BSA-MST","Myles Straw","Astros"],["BSA-NC","Nick Castellanos","Reds"],["BSA-PS","Patrick Sandoval","Angels","Rookie"],["BSA-RG","Robel Garcia","Cubs","Rookie"],["BSA-RM","Ryan McMahon","Rockies"],["BSA-RV","Daniel Vogelbach","Mariners"],["BSA-SA","Shogo Akiyama","Reds","Rookie"],["BSA-SH","Scott Heineman","Rangers","Rookie"],["BSA-SMA","Sean Manaea","Athletics"],["BSA-TE","Tom Eshelman","Orioles","Rookie"],["BSA-TP","Tommy Pham","Padres"],["BSA-YD","Yonathan Daza","Rockies","Rookie"],["BSA-YG","Yasmani Grandal","White Sox"],["BSA-ZG","Zac Gallen","Diamondbacks","Rookie"]]),
  updCodeDef("upd-bsda","Baseball Stars Dual Autographs Update","BSDA","Auto","Baseball Stars Dual Autographs Update — one row per code, two players","Auto",[["BSDA-AR","Yordan Alvarez + Luis Robert","Astros + White Sox","Rookie + Rookie"],["BSDA-AS","Ronald Acuna Jr. + Juan Soto","Braves + Nationals"],["BSDA-BB","Alex Bregman + Jeff Bagwell","Astros + Astros"],["BSDA-GI","Ichiro + Ken Griffey Jr.","Mariners + Mariners"],["BSDA-GS","Juan Soto + Vladimir Guerrero","Nationals + Expos"],["BSDA-KB","Cody Bellinger + Clayton Kershaw","Dodgers + Dodgers"],["BSDA-MJ","Aaron Judge + Don Mattingly","Yankees + Yankees"],["BSDA-OD","Rafael Devers + David Ortiz","Red Sox + Red Sox"],["BSDA-SA","Darryl Strawberry + Pete Alonso","Mets + Mets"],["BSDA-TA","Ronald Acuna Jr. + Mike Trout","Braves + Angels"],["BSDA-TB","Cody Bellinger + Mike Trout","Dodgers + Angels"],["BSDA-TR","Mike Trout + Nolan Ryan","Angels + Angels"]]),
  updCodeDef("upd-85a","1985 Topps Autographs Update","85A","Auto","1985 Topps Autographs Update — full checklist, 85A-* / 85BA-*","Auto",[["85A-ARE","Anthony Rendon","Angels"],["85A-DJ","Derek Jeter","Yankees"],["85A-JM","Joe Mauer","Twins"],["85A-LR","Luis Robert","White Sox","Rookie"],["85A-MT","Mike Trout","Angels"],["85A-PA","Pete Alonso","Mets"],["85A-RDO","Randy Dobnak","Twins","Rookie"],["85A-RM","Ryan McBroom","Royals","Rookie"],["85A-SG","Sonny Gray","Reds"],["85A-TA","Tyler Alexander","Tigers","Rookie"],["85A-TL","Tim Lincecum","Giants"],["85A-YD","Yonathan Daza","Rockies","Rookie"],["85A-YT","Yoshi Tsutsugo","Rays"],["85A-JRO","Josh Rojas","Diamondbacks","Rookie"],["85BA-HD","Hunter Dozier","Royals"],["85BA-TLS","Tommy La Stella","Angels"],["85A-SC","Shin-Soo Choo","Rangers"],["85BA-JA","Jim Abbott","Angels"],["85BA-YC","Yu Chang","Indians","Rookie"],["85BA-JD","Justin Dunn","Mariners","Rookie"],["85A-ZG","Zac Gallen","Diamondbacks","Rookie"],["85A-RHE","Rickey Henderson","Athletics"],["85A-RLA","Ramon Laureano","Athletics"],["85BA-DL","Domingo Leyba","Diamondbacks","Rookie"],["85A-OM","Oscar Mercado","Indians"],["85A-MO","Matt Olson","Athletics"],["85A-MA","Max Kepler","Twins"],["85A-KS","Kyle Schwarber","Cubs"],["85A-MS","Max Scherzer","Nationals"],["85BA-SN","Sheldon Neuse","Athletics","Rookie"],["85A-RD","Rafael Devers","Red Sox"],["85BA-MB","Mike Brosseau","Rays","Rookie"],["85BA-JBU","Jay Buhner","Mariners"],["85A-MCA","Miguel Cabrera","Tigers"],["85A-JC","Jose Canseco","Athletics"],["85A-PC","Patrick Corbin","Nationals"],["85A-JH","Josh Hader","Brewers"],["85BA-DV","Dan Vogelbach","Mariners"],["85A-JJ","Josh James","Astros"],["85A-AKA","Anthony Kay","Blue Jays","Rookie"],["85A-MK","Mitch Keller","Pirates"],["85BA-SL","Shed Long","Mariners"],["85A-JMA","James Marvel","Pirates","Rookie"],["85BA-AO","Adam Ottavino","Yankees"],["85BA-JS","Jorge Soler","Royals"],["85A-GS","George Springer","Astros"],["85BA-GU","Gio Urshela","Yankees"],["85A-BR","Bryan Reynolds","Pirates"],["85A-DGO","Dwight Gooden","Mets"]]),
  updCodeDef("upd-85ca","1985 Chrome Promo Autograph Update","85CA","Auto","1985 Chrome Promo Autograph Update — full checklist","Auto",[["85CA-AB","Andrew Benintendi","Red Sox"],["85CA-AR","Anthony Rendon","Angels"],["85CA-BBI","Bo Bichette","Blue Jays","Rookie"],["85CA-BBU","Brock Burke","Rangers","Rookie"],["85CA-BG","Brusdar Graterol","Dodgers","Rookie"],["85CA-CB","Cavan Biggio","Blue Jays"],["85CA-CBE","Cody Bellinger","Dodgers"],["85CA-CY","Christian Yelich","Brewers"],["85CA-DJ","Derek Jeter","Yankees"],["85CA-DM","Dale Murphy","Braves"],["85CA-FT","Fernando Tatis Jr.","Padres"],["85CA-GC","Gerrit Cole","Yankees"],["85CA-GCA","Genesis Cabrera","Cardinals","Rookie"],["85CA-GL","Gavin Lux","Dodgers","Rookie"],["85CA-GS","George Springer","Astros"],["85CA-HR","Hyun-Jin Ryu","Blue Jays"],["85CA-JL","Jesus Luzardo","Athletics","Rookie"],["85CA-JS","Josh Staumont","Royals","Rookie"],["85CA-JSO","Juan Soto","Nationals"],["85CA-LR","Luis Robert","White Sox","Rookie"],["85CA-MBR","Michael Brosseau","Rays"],["85CA-MR","Mariano Rivera","Yankees"],["85CA-MT","Mike Trout","Angels"],["85CA-MY","Mike Yastrzemski","Giants"],["85CA-NC","Nick Castellanos","Reds"],["85CA-RA","Ronald Acuna Jr.","Braves"],["85CA-RC","Roger Clemens","Red Sox"],["85CA-RH","Rhys Hoskins","Phillies"],["85CA-RR","Rangel Ravelo","Cardinals","Rookie"],["85CA-SA","Shogo Akiyama","Reds"],["85CA-SB","Shane Bieber","Indians"],["85CA-SBR","Seth Brown","Athletics","Rookie"],["85CA-SG","Sonny Gray","Reds"],["85CA-SO","Shohei Ohtani","Angels"],["85CA-SS","Stephen Strasburg","Nationals"],["85CA-TE","Tommy Edman","Cardinals"],["85CA-TG","Tony Gonsolin","Dodgers","Rookie"],["85CA-TGR","Trent Grisham","Padres","Rookie"],["85CA-WB","Walker Buehler","Dodgers"],["85CA-WCA","Willi Castro","Tigers","Rookie"],["85CA-YA","Yordan Alvarez","Astros","Rookie"],["85CA-YD","Yonathan Daza","Rockies","Rookie"],["85CA-YT","Yoshi Tsutsugo","Rays"],["85CA-ZG","Zac Gallen","Diamondbacks","Rookie"]]),
  updCodeDef("upd-20cpa","20 Years of the Captain Patch Autograph","20CPA","Auto Relic","20 Years of the Captain Patch Autograph — all Derek Jeter","Auto",UPD_20CA_CODES.map(c=>[`20CPA-${c}`,"Derek Jeter","Yankees"] as UpdCodeEntry)),
  updCodeDef("upd-jfpa","Jeter Final Season Patch Autograph","JFPA","Auto Relic","Jeter Final Season Patch Autograph — full checklist","Auto",[["JFPA-AS","Alfonso Soriano","Yankees"],["JFPA-CS","CC Sabathia","Yankees"],["JFPA-DJ1","Derek Jeter","Yankees"],["JFPA-DJ2","Derek Jeter","Yankees"],["JFPA-DJ3","Derek Jeter","Yankees"],["JFPA-DJ4","Derek Jeter","Yankees"],["JFPA-I","Ichiro","Yankees"],["JFPA-MT","Mark Teixeira","Yankees"],["JFPA-MTA","Masahiro Tanaka","Yankees"]]),
  updCodeDef("upd-mla","Major League Material Autograph Update","MLA","Auto Relic","Major League Material Autograph Update — full checklist","Auto",[["MLA-AB","Alex Bregman","Astros"],["MLA-AJ","Aaron Judge","Yankees"],["MLA-AJO","Andruw Jones","Braves"],["MLA-AR","Anthony Rendon","Angels"],["MLA-BB","Bo Bichette","Blue Jays","Rookie"],["MLA-BM","Brendan McKay","Rays","Rookie"],["MLA-CB","Cody Bellinger","Dodgers"],["MLA-DJ","David Justice","Braves"],["MLA-EA","Elvis Andrus","Rangers"],["MLA-EH","Eric Hosmer","Padres"],["MLA-FT","Fernando Tatis Jr.","Padres"],["MLA-GT","Gleyber Torres","Yankees"],["MLA-JG","Joey Gallo","Rangers"],["MLA-JR","J.T. Realmuto","Phillies"],["MLA-JSO","Jorge Soler","Royals"],["MLA-KH","Keston Hiura","Brewers"],["MLA-LG","Lucas Giolito","White Sox"],["MLA-LR","Luis Robert","White Sox","Rookie"],["MLA-MC","Matt Chapman","Athletics"],["MLA-MG","Mark Grace","Cubs"],["MLA-MT","Mike Trout","Angels"],["MLA-NC","Nick Castellanos","Reds"],["MLA-NS","Noah Syndergaard","Mets"],["MLA-PA","Pete Alonso","Mets"],["MLA-RA","Ronald Acuna Jr.","Braves"],["MLA-RD","Rafael Devers","Red Sox"],["MLA-RH","Rhys Hoskins","Phillies"],["MLA-SG","Sonny Gray","Reds"],["MLA-TE","Tommy Edman","Cardinals"],["MLA-VG","Vladimir Guerrero Jr.","Blue Jays"],["MLA-WB","Walker Buehler","Dodgers"],["MLA-WC","Willson Contreras","Cubs"],["MLA-XB","Xander Bogaerts","Red Sox"],["MLA-YA","Yordan Alvarez","Astros","Rookie"],["MLA-ZG","Zac Gallen","Diamondbacks","Rookie"]]),
  updCodeDef("upd-assa","All Star Stitch Autograph","ASSA","Auto Relic","All Star Stitch Autograph — full checklist","Auto",[["ASSA-AB","Alex Bregman","Astros"],["ASSA-AJ","Aaron Judge","Yankees"],["ASSA-AM","Andrew McCutchen","Pirates"],["ASSA-BH","Bryce Harper","Nationals"],["ASSA-BP","Buster Posey","Giants"],["ASSA-CB","Cody Bellinger","Dodgers"],["ASSA-CS","Chris Sale","Red Sox"],["ASSA-CSA","CC Sabathia","Yankees"],["ASSA-DJ","Derek Jeter","Yankees"],["ASSA-DO","David Ortiz","Red Sox"],["ASSA-GC","Gerrit Cole","Astros"],["ASSA-GS","George Springer","Astros"],["ASSA-GT","Gleyber Torres","Yankees"],["ASSA-JA","Jose Altuve","Astros"],["ASSA-JBE","Jose Berrios","Twins"],["ASSA-JD","Jacob deGrom","Mets"],["ASSA-JV","Joey Votto","Reds"],["ASSA-JVO","Joey Votto","Reds"],["ASSA-KB","Kris Bryant","Cubs"],["ASSA-MC","Miguel Cabrera","Tigers"],["ASSA-MR","Mariano Rivera","Yankees"],["ASSA-MT","Mike Trout","Angels"],["ASSA-NA","Nolan Arenado","Rockies"],["ASSA-RA","Ronald Acuna Jr.","Braves"],["ASSA-SS","Stephen Strasburg","Nationals"],["ASSA-WC","Willson Contreras","Cubs"],["ASSA-XB","Xander Bogaerts","Red Sox"],["ASSA-YM","Yadier Molina","Cardinals"]]),
  updCodeDef("upd-asda","All Star Stitch Dual Autograph","ASDA","Auto Relic","All Star Stitch Dual Autograph — one row per code, two players","Auto",[["ASDA-AS","George Springer + Jose Altuve","Astros + Astros"],["ASDA-AT","Ronald Acuna Jr. + Gleyber Torres","Braves + Yankees"],["ASDA-BR","Kris Bryant + Anthony Rizzo","Cubs + Cubs"],["ASDA-BS","George Springer + Alex Bregman","Astros + Astros"],["ASDA-KB","Clayton Kershaw + Cody Bellinger","Dodgers + Dodgers"],["ASDA-MC","Andrew McCutchen + Gerrit Cole","Pirates + Pirates"],["ASDA-RJ","Derek Jeter + Mariano Rivera","Yankees + Yankees"],["ASDA-SH","Bryce Harper + Stephen Strasburg","Nationals + Nationals"],["ASDA-TA","Ronald Acuna Jr. + Mike Trout","Braves + Angels"],["ASDA-YW","Yadier Molina + Willson Contreras","Cardinals + Cubs"]]),
  updCodeDef("upd-asja","All Star Autographed Jumbo Patch","ASJA","Auto Relic","All Star Autographed Jumbo Patch — full checklist","Auto",[["ASJA-AJ","Aaron Judge","Yankees"],["ASJA-AR","Anthony Rizzo","Cubs"],["ASJA-BH","Bryce Harper","Nationals"],["ASJA-BP","Buster Posey","Giants"],["ASJA-CS","Chris Sale","Red Sox"],["ASJA-CY","Christian Yelich","Brewers"],["ASJA-DJ","Derek Jeter","Yankees"],["ASJA-DO","David Ortiz","Red Sox"],["ASJA-GC","Gerrit Cole","Astros"],["ASJA-GT","Gleyber Torres","Yankees"],["ASJA-JA","Jose Altuve","Astros"],["ASJA-JD","Jacob deGrom","Mets"],["ASJA-KB","Kris Bryant","Cubs"],["ASJA-MC","Miguel Cabrera","Tigers"],["ASJA-MT","Mike Trout","Angels"],["ASJA-NA","Nolan Arenado","Rockies"],["ASJA-NS","Noah Syndergaard","Mets"],["ASJA-SS","Stephen Strasburg","Nationals"],["ASJA-YM","Yadier Molina","Cardinals"]]),
  updCodeDef("upd-bca","Coin Cards Autograph Parallel","BCA","Auto Relic","Coin Cards Autograph Parallel — full checklist","Auto",[["BCA-AA","Aristides Aquino","Reds","Rookie"],["BCA-AB","Alex Bregman","Astros"],["BCA-AJ","Aaron Judge","Yankees"],["BCA-AR","Anthony Rendon","Angels"],["BCA-ARI","Anthony Rizzo","Cubs"],["BCA-BH","Bryce Harper","Phillies"],["BCA-BM","Brendan McKay","Rays","Rookie"],["BCA-BP","Buster Posey","Giants"],["BCA-CB","Cody Bellinger","Dodgers"],["BCA-CK","Clayton Kershaw","Dodgers"],["BCA-FF","Freddie Freeman","Braves"],["BCA-FT","Fernando Tatis Jr.","Padres"],["BCA-GC","Gerrit Cole","Yankees"],["BCA-GL","Gavin Lux","Dodgers","Rookie"],["BCA-GT","Gleyber Torres","Yankees"],["BCA-JD","Jacob deGrom","Mets"],["BCA-JG","Joey Gallo","Rangers"],["BCA-JL","Jesus Luzardo","Athletics","Rookie"],["BCA-JS","Juan Soto","Nationals"],["BCA-JVO","Joey Votto","Reds"],["BCA-KB","Kris Bryant","Cubs"],["BCA-KH","Keston Hiura","Brewers"],["BCA-LR","Luis Robert","White Sox","Rookie"],["BCA-MC","Matt Chapman","Athletics"],["BCA-MM","Manny Machado","Padres"],["BCA-MT","Mike Trout","Angels"],["BCA-NA","Nolan Arenado","Rockies"],["BCA-NH","Nico Hoerner","Cubs","Rookie"],["BCA-PA","Pete Alonso","Mets"],["BCA-PG","Paul Goldschmidt","Cardinals"],["BCA-RA","Ronald Acuna Jr.","Braves"],["BCA-RD","Rafael Devers","Red Sox"],["BCA-RH","Rhys Hoskins","Phillies"],["BCA-SO","Shohei Ohtani","Angels"],["BCA-VG","Vladimir Guerrero Jr.","Blue Jays"],["BCA-WB","Walker Buehler","Dodgers"],["BCA-YA","Yordan Alvarez","Astros","Rookie"],["BCA-YM","Yadier Molina","Cardinals"]]),
  updCodeDef("upd-trap","Topps Reverence Autograph Patch Update","TRAP","Auto Relic","Topps Reverence Autograph Patch Update — full checklist, TRAP-* / RAP-*","Auto",[["TRAP-LR","Luis Robert","White Sox","Rookie"],["TRAP-MT","Mike Trout","Angels"],["TRAP-RJ","Randy Johnson","Diamondbacks"],["TRAP-JH","Josh Hader","Brewers"],["RAP-RH","Ryan Howard","Phillies"],["TRAP-RAL","Roberto Alomar","Mets"],["TRAP-MS","Max Scherzer","Nationals"],["TRAP-PD","Paul DeJong","Cardinals"],["TRAP-FF","Freddie Freeman","Braves"],["TRAP-KS","Kyle Schwarber","Cubs"],["TRAP-GS","George Springer","Astros"],["RAP-JM","Jeff McNeil","Mets"],["RAP-AM","Austin Meadows","Rays"],["RAP-JSO","Jorge Soler","Royals"],["RAP-GU","Gio Urshela","Yankees"],["TRAP-RD","Rafael Devers","Red Sox"],["RAP-RAJ","Ronald Acuna Jr.","Braves"],["TRAP-MA","Miguel Andujar","Yankees"],["TRAP-PG","Paul Goldschmidt","Cardinals"],["RAP-TL","Tim Lincecum","Giants"],["RAP-JMA","Joe Mauer","Twins"]]),
  updCodeDef("upd-20ycc","20 Years of the Captain Patch","20YCC","Relic","20 Years of the Captain Patch — all Derek Jeter","Relic",UPD_20YCC_CODES.map(c=>[`20YCC-${c}`,"Derek Jeter","Yankees"] as UpdCodeEntry)),
  updCodeDef("upd-jfp","Jeter Final Season Patch","JFP","Relic","Jeter Final Season Patch — full checklist","Relic",[["JFP-AS","Alfonso Soriano","Yankees"],["JFP-CS","CC Sabathia","Yankees"],["JFP-DJ1","Derek Jeter","Yankees"],["JFP-DJ2","Derek Jeter","Yankees"],["JFP-DJ3","Derek Jeter","Yankees"],["JFP-DJ4","Derek Jeter","Yankees"],["JFP-I","Ichiro","Yankees"],["JFP-JG","Joe Girardi","Yankees"],["JFP-MT","Mark Teixeira","Yankees"],["JFP-MTA","Masahiro Tanaka","Yankees"]]),
  updCodeDef("upd-mlm","Major League Material Update","MLM","Relic","Major League Material Update — full checklist","Relic",[["MLM-AA","Aristides Aquino","Reds","Rookie"],["MLM-AB","Alex Bregman","Astros"],["MLM-AMC","Andrew McCutchen","Phillies"],["MLM-AP","Albert Pujols","Angels"],["MLM-AR","Anthony Rizzo","Cubs"],["MLM-BH","Bryce Harper","Phillies"],["MLM-CK","Clayton Kershaw","Dodgers"],["MLM-CS","CC Sabathia","Yankees"],["MLM-CY","Christian Yelich","Brewers"],["MLM-DJL","DJ LeMahieu","Yankees"],["MLM-DO","David Ortiz","Red Sox"],["MLM-EA","Elvis Andrus","Rangers"],["MLM-FTJ","Fernando Tatis Jr.","Padres"],["MLM-GSP","George Springer","Astros"],["MLM-GT","Gleyber Torres","Yankees"],["MLM-JB","Javier Baez","Cubs"],["MLM-JS","Jorge Soler","Royals"],["MLM-JTR","J.T. Realmuto","Phillies"],["MLM-JVO","Joey Votto","Reds"],["MLM-KBR","Kris Bryant","Cubs"],["MLM-KH","Keston Hiura","Brewers"],["MLM-LCA","Lorenzo Cain","Brewers"],["MLM-LG","Lucas Giolito","White Sox"],["MLM-MC","Miguel Cabrera","Tigers"],["MLM-MCH","Matt Chapman","Athletics"],["MLM-MCO","Michael Conforto","Mets"],["MLM-MK","Max Kepler","Twins"],["MLM-MO","Matt Olson","Athletics"],["MLM-MS","Max Scherzer","Nationals"],["MLM-MTR","Mike Trout","Angels"],["MLM-NA","Nolan Arenado","Rockies"],["MLM-OHT","Shohei Ohtani","Angels"],["MLM-PG","Paul Goldschmidt","Cardinals"],["MLM-RD","Rafael Devers","Red Sox"],["MLM-RH","Rhys Hoskins","Phillies"],["MLM-SG","Sonny Gray","Reds"],["MLM-VG","Vladimir Guerrero Jr.","Blue Jays"],["MLM-VR","Victor Robles","Nationals"],["MLM-YM","Yadier Molina","Cardinals"]]),
];
const UPD_HUB_DEFS = [...UPD_INSERT_DEFS, ...UPD_CODE_DEFS];
const UPD_INSERT_FULL_TOTAL = 886;
const UPD_OTHER_INSERTS: {name:string; codes:string; examples:string; parallels:string; size:string}[] = [
  {name:"2020 Topps Baseball Coin Cards",codes:"Coin Cards",examples:"Retail Relic Box Only",parallels:"Relic",size:"30"},
];
const UPD_SP_NUMBERS: number[] = [1,4,8,15,21,29,33,42,50,55,60,64,65,80,83,94,100,121,124,134,143,145,149,154,169,173,185,187,190,194,200,201,209,216,229,234,235,237,251,257,266,267,268,269,272,277,279,287,299,300];
const UPD_SSP_MAP: Record<string,{player:string; team:string; note:string}> = {"U-1":{player:"Bo Bichette",team:"Blue Jays",note:""},"U-4":{player:"Mike Trout",team:"Angels",note:""},"U-15":{player:"Aaron Judge",team:"Yankees",note:""},"U-52":{player:"Babe Ruth",team:"Yankees",note:"SSP legend — replaces base Kyle Higashioka photo"},"U-63":{player:"Jackie Robinson",team:"Dodgers",note:"SSP legend — replaces Terrance Gore"},"U-68":{player:"Fernando Tatis Jr.",team:"Padres",note:"SSP — replaces Greg Garcia"},"U-80":{player:"Cody Bellinger",team:"Dodgers",note:""},"U-90":{player:"Sandy Koufax",team:"Dodgers",note:"SSP legend — replaces Clayton Kershaw"},"U-121":{player:"Ichiro",team:"Mariners",note:""},"U-122":{player:"Lou Gehrig",team:"Yankees",note:"SSP legend — replaces Tino Martinez"},"U-129":{player:"Willie Mays",team:"Giants",note:"SSP legend — replaces Hunter Pence"},"U-145":{player:"Ronald Acuna Jr.",team:"Braves",note:""},"U-154":{player:"Mariano Rivera",team:"Yankees",note:""},"U-158":{player:"Ernie Banks",team:"Cubs",note:"SSP legend — replaces Jason Kipnis"},"U-173":{player:"Luis Robert",team:"White Sox",note:""},"U-178":{player:"Roberto Clemente",team:"Pirates",note:"SSP legend — replaces Jarrod Dyson"},"U-190":{player:"Ken Griffey Jr.",team:"Mariners",note:""},"U-199":{player:"Hank Aaron",team:"Braves",note:"SSP legend — replaces Adeiny Hechavarria"},"U-209":{player:"Cal Ripken Jr.",team:"Orioles",note:""},"U-234":{player:"Gavin Lux",team:"Dodgers",note:""},"U-255":{player:"Juan Soto",team:"Nationals",note:"SSP — replaces Bryce Harper"},"U-257":{player:"Derek Jeter",team:"Yankees",note:""},"U-269":{player:"Christian Yelich",team:"Brewers",note:""},"U-271":{player:"Ted Williams",team:"Red Sox",note:"SSP legend — replaces Kevin Pillar"},"U-279":{player:"Bryce Harper",team:"Nationals",note:""}};
const UPD_SSP_NUMBERS: number[] = [1,4,15,52,63,68,80,90,121,122,129,145,154,158,173,178,190,199,209,234,255,257,269,271,279];
const UPD_SSSP_MAP: Record<string,{player:string; team:string; note:string}> = {"U-82":{player:"Magic Johnson",team:"Dodgers",note:"Owner — replaces Kenley Jansen"},"U-121":{player:"Ichiro",team:"Mariners",note:"Special Assistant"},"U-124":{player:"David Ortiz",team:"Red Sox",note:"Special Assistant"},"U-233":{player:"George Brett",team:"Royals",note:"SSSP legend — replaces Mike Montgomery"},"U-257":{player:"Derek Jeter",team:"Yankees",note:""}};
const UPD_SSSP_NUMBERS: number[] = [82,121,124,233,257];
function updInsertTeam(player:string, teamOverride?:string): string { if(teamOverride) return teamOverride; if(player.endsWith(" Team")) return player.replace(" Team",""); return "—"; }
function updInsertRowsFor(def:S1InsertDef): {code:string; player:string; team:string; note:string}[] {
  if(def.codes) return def.codes.map((code,i)=>({code,player:def.players[i]||"",team:updInsertTeam(def.players[i]||"",def.teams?.[i]),note: def.players[i]?.endsWith(" Team") ? "Team Card" : ""}));
  if(def.players.length) return def.players.map((player,i)=>({code:`${def.prefix}-${i+1}`,player,team:updInsertTeam(player,def.teams?.[i]),note: player.endsWith(" Team") ? "Team Card" : ""}));
  if(def.known) return Object.entries(def.known).map(([code,player])=>({code,player,team:def.knownTeams?.[code]||updInsertTeam(player),note:def.knownNotes?.[code]||""}));
  return [];
}
function updVariationEntry(code:string, parallel:string): CardNameEntry | undefined {
  const norm = `U-${parseInt(String(code||"").replace(/^U-/i,""),10)}`;
  if(Number.isNaN(parseInt(norm.slice(2),10))) return undefined;
  const base = CARD_NAMES["Update"]?.[norm];
  if(parallel==="SP Variation"){ if(!UPD_SP_NUMBERS.includes(parseInt(norm.slice(2),10))) return undefined; if(norm==="U-173") return {player:"Luis Robert",team:"White Sox",note:"SP image variation — different photo than base U-173"}; return base ? {player:base.player,team:base.team,note:"SP Variation"} : undefined; }
  if(parallel==="SSP Variation"){ const v=UPD_SSP_MAP[norm]; if(!v) return undefined; return {player:v.player,team:v.team,note:"SSP Variation" + (v.note?` — ${v.note}`:"")}; }
  if(parallel==="SSSP Variation"){ const v=UPD_SSSP_MAP[norm]; if(!v) return undefined; return {player:v.player,team:v.team,note:"SSSP Variation" + (v.note?` — ${v.note}`:"")}; }
  return undefined;
}
function getUpdateInsertEntry(code:string): CardNameEntry | undefined {
  const upper = String(code||"").trim().toUpperCase();
  if(/^20CA-?\d+$/.test(upper) || /^20CPA-?\d+$/.test(upper)) { const y=upper.replace(/^20C(PA|A)-?/,""); if(UPD_YOC_YEARS.includes(parseInt(y,10)) || y==="00") return {player:"Derek Jeter",team:"Yankees",note: upper.startsWith("20CPA") ? "20 Years of the Captain Commemorative Patch Auto" : "20 Years of the Captain Auto Parallel"}; }
  for(const def of UPD_HUB_DEFS){
    if(def.known && def.known[upper]) return {player:def.known[upper],team:def.knownTeams?.[upper]||"—",note:def.name + (def.knownNotes?.[upper]?` — ${def.knownNotes[upper]}`:"")};
    if(def.codes){ const idx=def.codes.indexOf(upper); if(idx>=0) return {player:def.players[idx],team:def.teams?.[idx]||"—",note:def.name}; }
    if(def.players.length){
      const m = upper.match(new RegExp(`^${def.prefix.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}-?(\\d+)$`));
      if(m){ const n = parseInt(m[1],10); if(n>=1 && n<=def.players.length){ const player = def.players[n-1]; return {player, team: def.teams?.[n-1]||updInsertTeam(player), note: def.name}; } }
    }
  }
  return undefined;
}
function updVariationRowsFor(variation:"SP Variation"|"SSP Variation"|"SSSP Variation"): {code:string; player:string; team:string; note:string}[] {
  const nums = variation==="SP Variation" ? UPD_SP_NUMBERS : variation==="SSP Variation" ? UPD_SSP_NUMBERS : UPD_SSSP_NUMBERS;
  return nums.map(n=>{ const code=`U-${n}`; const v=updVariationEntry(code,variation); const base=CARD_NAMES["Update"]?.[code]; return {code,player:v?.player||base?.player||"",team:v?.team||base?.team||"—",note:v?.note||""}; });
}

// ---- CHROME EXPANSION: FULL PARALLELS, SP / SSP VARIATIONS, INSERTS / AUTOS / RELICS HUB ----
const CHROME_BASE_PARALLELS: {name:string; rarity:string; notes:string}[] = [
  {name:"Refractor",rarity:"Refractor",notes:"Refractor parallel"},
  {name:"Prism",rarity:"Prism",notes:"Prism parallel"},
  {name:"Pink (Value Pack)",rarity:"Retail",notes:"Pink parallel — Value Pack"},
  {name:"Sepia (Value Box)",rarity:"Retail",notes:"Sepia parallel — Value Box"},
  {name:"X-Fractor (Monster Box)",rarity:"Retail",notes:"X-Fractor parallel — Monster Box"},
  {name:"Negative",rarity:"Negative",notes:"Negative parallel"},
  {name:"Purple /299",rarity:"/299",notes:"Numbered to 299"},
  {name:"Blue /150",rarity:"/150",notes:"Numbered to 150"},
  {name:"Green /99",rarity:"/99",notes:"Numbered to 99"},
  {name:"Green Wave /99 (Hobby/Jumbo)",rarity:"/99",notes:"Green Wave parallel, numbered to 99 — Hobby / Jumbo"},
  {name:"Blue Wave /75 (Hobby/Jumbo)",rarity:"/75",notes:"Blue Wave parallel, numbered to 75 — Hobby / Jumbo"},
  {name:"Gold /50",rarity:"/50",notes:"Numbered to 50"},
  {name:"Gold Wave /50 (Hobby/Jumbo)",rarity:"/50",notes:"Gold Wave parallel, numbered to 50 — Hobby / Jumbo"},
  {name:"Orange /25 (Hobby)",rarity:"/25",notes:"Numbered to 25 — Hobby"},
  {name:"Orange Wave /25 (Hobby/Jumbo)",rarity:"/25",notes:"Orange Wave parallel, numbered to 25 — Hobby / Jumbo"},
  {name:"Red /5",rarity:"/5",notes:"Numbered to 5"},
  {name:"Red Wave /5 (Hobby/Jumbo)",rarity:"/5",notes:"Red Wave parallel, numbered to 5 — Hobby / Jumbo"},
  {name:"SuperFractor 1/1",rarity:"1/1",notes:"One of one"},
  {name:"Cyan Printing Plate 1/1",rarity:"1/1",notes:"Cyan printing plate, one of one"},
  {name:"Magenta Printing Plate 1/1",rarity:"1/1",notes:"Magenta printing plate, one of one"},
  {name:"Yellow Printing Plate 1/1",rarity:"1/1",notes:"Yellow printing plate, one of one"},
  {name:"Black Printing Plate 1/1",rarity:"1/1",notes:"Black printing plate, one of one"},
];
const CHROME_SP_NUMBERS: number[] = [1,12,50,60,77,80,81,84,97,111,112,125,138,148,150,161,174,186,198,200];
const CHROME_SSP_MAP: Record<string,{player:string; team:string; note:string}> = {
  "1":{player:"Mike Trout",team:"Angels",note:"SSP image variation"},
  "50":{player:"Derek Jeter",team:"Yankees",note:"SSP image variation — replaces base Aaron Judge photo"},
  "60":{player:"Luis Robert",team:"White Sox",note:"SSP image variation"},
  "77":{player:"Jackie Robinson",team:"Dodgers",note:"SSP image variation — replaces base Cody Bellinger photo"},
  "157":{player:"Willie Mays",team:"Giants",note:"SSP image variation — replaces base Buster Posey photo"},
};
const CHROME_LEGEND_TEAMS: Record<string,string> = {"Derek Jeter":"Yankees","Jackie Robinson":"Dodgers","Willie Mays":"Giants","Babe Ruth":"Yankees","Ted Williams":"Red Sox","Johnny Bench":"Reds","Sandy Koufax":"Dodgers","Randy Johnson":"Diamondbacks","Nolan Ryan":"Rangers","Honus Wagner":"Pirates","Mark McGwire":"Athletics","Alex Rodriguez":"Yankees","Ichiro":"Mariners","Ken Griffey Jr.":"Mariners","David Ortiz":"Red Sox","Chipper Jones":"Braves","Cal Ripken Jr.":"Orioles","Ozzie Smith":"Cardinals","Mark Teixeira":"Yankees","Eddie Mathews":"Braves","Frank Thomas":"White Sox","George Brett":"Royals","Roberto Clemente":"Pirates","Rickey Henderson":"Athletics","Reggie Jackson":"Athletics","Tony Gwynn":"Padres","Mariano Rivera":"Yankees","Carl Yastrzemski":"Red Sox","Don Mattingly":"Yankees"};
function chromeInsertTeam(player:string): string {
  if(player.includes(" & ")){ return player.split(" & ").map(p=>chromeInsertTeam(p.trim())).join(" + "); }
  if(player.includes(" + ")){ return player.split(" + ").map(p=>chromeInsertTeam(p.trim())).join(" + "); }
  for(const key of Object.keys(CARD_NAMES)){ const e = CARD_NAMES[key] && Object.values(CARD_NAMES[key]).find(v=>v.player===player); if(e) return e.team; }
  return CHROME_LEGEND_TEAMS[player] || "—";
}
const CHROME_INSERT_DEFS: S1InsertDef[] = [
  {id:"chr-85tc",name:"1985 Topps Baseball",prefix:"85TC",size:25,parallels:"Green /99, Gold /50, Orange /25, Red /5, SuperFractor 1/1",notes:"1985 Topps Baseball — Chrome",type:"Insert",players:L("Mike Trout|Bo Bichette|Juan Soto|Yordan Alvarez|Gavin Lux|Vladimir Guerrero Jr.|Shohei Ohtani|Rafael Devers|Kris Bryant|Jesus Luzardo|Eloy Jimenez|Nico Hoerner|Brendan McKay|A.J. Puk|Christian Yelich|Keston Hiura|Luis Robert|Pete Alonso|Jose Altuve|Rhys Hoskins|Aristides Aquino|Kyle Lewis|Austin Riley|Nolan Arenado|Ronald Acuna Jr.")},
  {id:"chr-dod",name:"Decade of Dominance",prefix:"DOD",size:15,parallels:"Green /99, Gold /50, Orange /25, Red /5, SuperFractor 1/1",notes:"Decade of Dominance die-cut",type:"Insert",players:L("Mike Trout|Mariano Rivera|Rickey Henderson|Hank Aaron|Ted Williams|Johnny Bench|Willie Mays|Sandy Koufax|Randy Johnson|Nolan Ryan|Honus Wagner|Mark McGwire|Alex Rodriguez|Ichiro|Babe Ruth")},
  {id:"chr-ff",name:"Freshman Flash",prefix:"FF",size:15,parallels:"Green /99, Gold /50, Orange /25, Red /5, SuperFractor 1/1",notes:"Freshman Flash",type:"Insert",players:L("Bo Bichette|Aristides Aquino|Dylan Cease|Dustin May|Luis Robert|Brendan McKay|Sheldon Neuse|Jesus Luzardo|A.J. Puk|Nico Hoerner|Sean Murphy|Gavin Lux|Kyle Lewis|Isan Diaz|Yordan Alvarez")},
  {id:"chr-fs",name:"Future Stars",prefix:"FS",size:20,parallels:"Green /99, Gold /50, Orange /25, Red /5, SuperFractor 1/1 (Hobby/Jumbo only for SuperFractor)",notes:"Future Stars",type:"Insert",players:L("Pete Alonso|Will Smith|Eloy Jimenez|Michael Chavis|Mike Yastrzemski|Carter Kieboom|Victor Robles|Chris Paddack|Bryan Reynolds|Mitch Keller|Fernando Tatis Jr.|Brendan Rodgers|Cavan Biggio|Ramon Laureano|Keston Hiura|Austin Riley|Willians Astudillo|John Means|Mike Tauchman|Vladimir Guerrero Jr.")},
  {id:"chr-fp",name:"Topps Fire Preview NBCD",prefix:"FP",size:9,parallels:"—",notes:"Topps Fire Preview NBCD",type:"Insert",players:L("Aaron Judge|Mike Trout|Ken Griffey Jr.|Luis Robert|Fernando Tatis Jr.|Juan Soto|Bryce Harper|David Ortiz|Pete Alonso")},
  {id:"chr-gp",name:"Topps Gallery Preview NBCD",prefix:"GP",size:10,parallels:"—",notes:"Topps Gallery Preview NBCD",type:"Insert",players:L("Mike Trout|Ronald Acuna Jr.|Fernando Tatis Jr.|Aaron Judge|Christian Yelich|Bryce Harper|Juan Soto|Pete Alonso|Yordan Alvarez|Cody Bellinger")},
  {id:"chr-up",name:"Topps Update Preview NBCD",prefix:"UP",size:8,parallels:"—",notes:"Topps Update Preview NBCD",type:"Insert",players:L("Bo Bichette|Brendan McKay|Yordan Alvarez|Gavin Lux|Kyle Lewis|Nico Hoerner|Jesus Luzardo|Aristides Aquino")},
  {id:"chr-85tca",name:"1985 Topps Baseball Autographs",prefix:"85TCA",size:17,parallels:"Orange /25, Red /5, SuperFractor 1/1, Printing Plates 1/1",notes:"1985 Topps Baseball Autographs",type:"Auto",players:[],known:{"85TCA-AA":"Aristides Aquino","85TCA-AR":"Austin Riley","85TCA-BB":"Bo Bichette","85TCA-GL":"Gavin Lux","85TCA-JA":"Jose Altuve","85TCA-JL":"Jesus Luzardo","85TCA-JS":"Juan Soto","85TCA-KB":"Kris Bryant","85TCA-KH":"Keston Hiura","85TCA-KL":"Kyle Lewis","85TCA-MT":"Mike Trout","85TCA-NH":"Nico Hoerner","85TCA-PA":"Pete Alonso","85TCA-RAJ":"Ronald Acuna Jr.","85TCA-RH":"Rhys Hoskins","85TCA-SO":"Shohei Ohtani","85TCA-YA":"Yordan Alvarez"}},
  {id:"chr-ffa",name:"Freshman Flash Autographs",prefix:"FFA",size:18,parallels:"Orange /25, Red /5, SuperFractor 1/1, Printing Plates 1/1",notes:"Freshman Flash Autographs — /99",type:"Auto",players:[],known:{"FFA-AA":"Aristides Aquino","FFA-AAL":"Adbert Alzolay","FFA-AT":"Abraham Toro","FFA-BB":"Bo Bichette","FFA-BM":"Brendan McKay","FFA-DC":"Dylan Cease","FFA-DM":"Dustin May","FFA-GL":"Gavin Lux","FFA-ID":"Isan Diaz","FFA-JL":"Jesus Luzardo","FFA-JY":"Jordan Yamamoto","FFA-KL":"Kyle Lewis","FFA-MD":"Mauricio Dubon","FFA-NH":"Nico Hoerner","FFA-SB":"Seth Brown","FFA-SM":"Sean Murphy","FFA-SN":"Sheldon Neuse","FFA-YA":"Yordan Alvarez"}},
  {id:"chr-fsa",name:"Future Stars Autographs",prefix:"FSA",size:18,parallels:"Orange /25, Red /5, SuperFractor 1/1, Printing Plates 1/1",notes:"Future Stars Autographs",type:"Auto",players:[],known:{"FSA-AR":"Austin Riley","FSA-BR":"Bryan Reynolds","FSA-BRE":"Brendan Rodgers","FSA-CB":"Cavan Biggio","FSA-CK":"Carter Kieboom","FSA-CP":"Chris Paddack","FSA-EJ":"Eloy Jimenez","FSA-FTJ":"Fernando Tatis Jr.","FSA-JM":"John Means","FSA-KH":"Keston Hiura","FSA-MC":"Michael Chavis","FSA-MK":"Mitch Keller","FSA-MT":"Mike Tauchman","FSA-MY":"Mike Yastrzemski","FSA-PA":"Pete Alonso","FSA-RL":"Ramon Laureano","FSA-VR":"Victor Robles","FSA-WS":"Will Smith"}},
  {id:"chr-dra",name:"Dual Rookie Autographs",prefix:"DRA",size:5,parallels:"Red /5, SuperFractor 1/1",notes:"Dual Rookie Autographs — /25",type:"Auto",players:["Yordan Alvarez & Abraham Toro","Robel Garcia & Nico Hoerner","Justin Dunn & Kyle Lewis","Dustin May & Gavin Lux","Sheldon Neuse & Sean Murphy"]},
  {id:"chr-ra",name:"Rookie Autographs",prefix:"RA",size:77,parallels:"Refractor /499, Purple /250, Blue /150, Blue Wave /150, Green /99, Gold /50, Gold Wave /50, Orange /25, Orange Wave /25, Red /5, Red Wave /5, SuperFractor 1/1, Printing Plates 1/1",notes:"Rookie Autographs",type:"Auto",players:[],known:{"RA-AA":"Adbert Alzolay","RA-AAQ":"Aristides Aquino","RA-AC":"Aaron Civale","RA-AJP":"A.J. Puk","RA-AK":"Anthony Kay","RA-AMU":"Andres Munoz","RA-AN":"Austin Nola","RA-AT":"Abraham Toro","RA-AY":"Alex Young","RA-BA":"Bryan Abreu","RA-BB":"Bobby Bradley","RA-BBI":"Bo Bichette","RA-BBU":"Brock Burke","RA-BG":"Brusdar Graterol","RA-BM":"Brendan McKay","RA-CPO":"Colin Poche","RA-DA":"Dario Agrazal","RA-DCE":"Dylan Cease","RA-DL":"Domingo Leyba","RA-DM":"Dustin May","RA-DME":"Danny Mendick","RA-DN":"Dom Nunez","RA-EC":"Emmanuel Clase","RA-GL":"Gavin Lux","RA-HH":"Hunter Harvey","RA-ID":"Isan Diaz","RA-JD":"Justin Dunn","RA-JDA":"Jaylin Davis","RA-JF":"Jake Fraley","RA-JFE":"Junior Fernandez","RA-JH":"Jonathan Hernandez","RA-JL":"Jesus Luzardo","RA-JMA":"James Marvel","RA-JPO":"Joe Palumbo","RA-JR":"Jake Rogers","RA-JRO":"Jose Rodriguez","RA-JS":"Josh Staumont","RA-JT":"Jesus Tinoco","RA-JU":"Jose Urquidy","RA-JW":"Jacob Waguespack","RA-JY":"Jordan Yamamoto","RA-KG":"Kyle Garlick","RA-KL":"Kyle Lewis","RA-KW":"Kean Wong","RA-LA":"Logan Allen","RA-LR":"Luis Robert","RA-LT":"Lewis Thorpe","RA-LW":"Logan Webb","RA-MB":"Michel Baez","RA-MBR":"Michael Brosseau","RA-MD":"Mauricio Dubon","RA-MK":"Mike King","RA-MT":"Matt Thaiss","RA-NH":"Nico Hoerner","RA-NS":"Nick Solak","RA-RA":"Rogelio Armenteros","RA-RAR":"Randy Arozarena","RA-RD":"Robert Dugger","RA-RG":"Robel Garcia","RA-RR":"Rangel Ravelo","RA-SA":"Shogo Akiyama","RA-SB":"Seth Brown","RA-SH":"Sam Hilliard","RA-SM":"Sean Murphy","RA-SN":"Sheldon Neuse","RA-TA":"Tyler Alexander","RA-TD":"Travis Demeritte","RA-TE":"Tom Eshelman","RA-TG":"Tony Gonsolin","RA-TGR":"Trent Grisham","RA-TL":"Tim Lopes","RA-TLA":"Travis Lakins","RA-TZ":"T.J. Zeuch","RA-WC":"Willi Castro","RA-YA":"Yordan Alvarez","RA-ZC":"Zack Collins","RA-ZG":"Zac Gallen"}},
  {id:"chr-rcta",name:"Topps All-Star Rookie Team Autographs",prefix:"RCTA",size:14,parallels:"Orange /25, Red /5, SuperFractor 1/1, Printing Plates 1/1",notes:"Topps All-Star Rookie Team Autographs",type:"Auto",players:[],known:{"RCTA-AJ":"Aaron Judge","RCTA-AR":"Anthony Rizzo","RCTA-BH":"Bryce Harper","RCTA-CJ":"Chipper Jones","RCTA-CRJ":"Cal Ripken Jr.","RCTA-I":"Ichiro","RCTA-JB":"Johnny Bench","RCTA-KB":"Kris Bryant","RCTA-MM":"Mark McGwire","RCTA-MT":"Mike Trout","RCTA-MTE":"Mark Teixeira","RCTA-OS":"Ozzie Smith","RCTA-RAJ":"Ronald Acuna Jr.","RCTA-RS":"Ryne Sandberg"}},
  {id:"chr-rrcr",name:"Retro Rookie Chrome Relics",prefix:"RRCR",size:35,parallels:"Green /99, Orange /25, Red /5, SuperFractor 1/1",notes:"Retro Rookie Chrome Relics",type:"Relic",players:[],known:{"RRCR-AB":"Alex Bregman","RRCR-AJ":"Aaron Judge","RRCR-AP":"Albert Pujols","RRCR-AR":"Anthony Rizzo","RRCR-BH":"Bryce Harper","RRCR-BP":"Buster Posey","RRCR-CB":"Cody Bellinger","RRCR-CJ":"Chipper Jones","RRCR-CK":"Clayton Kershaw","RRCR-CRJ":"Cal Ripken Jr.","RRCR-CY":"Carl Yastrzemski","RRCR-DM":"Don Mattingly","RRCR-EM":"Eddie Mathews","RRCR-FT":"Frank Thomas","RRCR-GB":"George Brett","RRCR-GT":"Gleyber Torres","RRCR-I":"Ichiro","RRCR-JA":"Jose Altuve","RRCR-JB":"Johnny Bench","RRCR-JBA":"Javier Baez","RRCR-JV":"Justin Verlander","RRCR-JVO":"Joey Votto","RRCR-KB":"Kris Bryant","RRCR-KGJ":"Ken Griffey Jr.","RRCR-MB":"Mookie Betts","RRCR-MT":"Mark Teixeira","RRCR-MTA":"Masahiro Tanaka","RRCR-MTR":"Mike Trout","RRCR-OS":"Ozzie Smith","RRCR-RAJ":"Ronald Acuna Jr.","RRCR-RC":"Roberto Clemente","RRCR-RH":"Rickey Henderson","RRCR-RJ":"Reggie Jackson","RRCR-TG":"Tony Gwynn","RRCR-TW":"Ted Williams"}},
  {id:"chr-arrcr",name:"Retro Rookie Chrome Autograph Relics",prefix:"ARRCR",size:18,parallels:"—",notes:"Retro Rookie Chrome Autograph Relics",type:"Auto",players:[],known:{"ARRCR-AJ":"Aaron Judge","ARRCR-BH":"Bryce Harper","ARRCR-CJ":"Chipper Jones","ARRCR-CRJ":"Cal Ripken Jr.","ARRCR-CY":"Carl Yastrzemski","ARRCR-DM":"Don Mattingly","ARRCR-FT":"Frank Thomas","ARRCR-GT":"Gleyber Torres","ARRCR-I":"Ichiro","ARRCR-JA":"Jose Altuve","ARRCR-JS":"Juan Soto","ARRCR-KB":"Kris Bryant","ARRCR-KGJ":"Ken Griffey Jr.","ARRCR-MT":"Mark Teixeira","ARRCR-MTR":"Mike Trout","ARRCR-RAJ":"Ronald Acuna Jr.","ARRCR-RH":"Rickey Henderson","ARRCR-RJ":"Reggie Jackson"}},
];
const CHROME_HUB_DEFS = CHROME_INSERT_DEFS;
const CHROME_INSERT_FULL_TOTAL = 304; // Inserts 102 + Autos 149 + Relics/Auto-Relics 53
const CHROME_TOTAL_ENTRIES = 529; // Base 200 + SP Variation 20 + SSP Variation 5 + Hub 304
function chromeInsertRowsFor(def:S1InsertDef): {code:string; player:string; team:string; note:string}[] {
  if(def.players.length) return def.players.map((player,i)=>({code:`${def.prefix}-${i+1}`,player,team:chromeInsertTeam(player),note:""}));
  if(def.known) return Object.entries(def.known).map(([code,player])=>({code,player,team:chromeInsertTeam(player),note:""}));
  return [];
}
function getChromeInsertEntry(code:string): CardNameEntry | undefined {
  const upper = String(code||"").trim().toUpperCase();
  for(const def of CHROME_INSERT_DEFS){
    if(def.known && def.known[upper]) { const player = def.known[upper]; return {player, team: chromeInsertTeam(player), note: def.name}; }
    if(def.players.length){
      const m = upper.match(new RegExp(`^${def.prefix.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}-?(\\d+)$`));
      if(m){ const n = parseInt(m[1],10); if(n>=1 && n<=def.players.length){ const player = def.players[n-1]; return {player, team: chromeInsertTeam(player), note: def.name}; } }
    }
  }
  return undefined;
}
function chromeVariationEntry(code:string, parallel:string): CardNameEntry | undefined {
  const n = parseInt(String(code||"").trim(),10);
  if(!Number.isFinite(n)) return undefined;
  const base = CARD_NAMES["Chrome"]?.[String(n)];
  if(parallel==="SP Variation"){ if(!CHROME_SP_NUMBERS.includes(n) || !base) return undefined; return {player:base.player,team:base.team,note:"SP Variation — CMP ends 635"}; }
  if(parallel==="SSP Variation"){ const v = CHROME_SSP_MAP[String(n)]; if(!v) return undefined; return {player:v.player,team:v.team,note:"SSP Variation — CMP ends 641" + (v.note?` — ${v.note}`:"")}; }
  return undefined;
}
// ---- BOWMAN EXPANSION: 1990 BOWMAN INSERT (90B, 50 CARDS) ----
const BOWMAN_90B_ROWS: {code:string; player:string; team:string}[] = [
  {code:"90B-AA",player:"Aristides Aquino",team:"Reds"},
  {code:"90B-AB",player:"Alec Bohm",team:"Phillies"},
  {code:"90B-AK",player:"Alex Kirilloff",team:"Twins"},
  {code:"90B-AP",player:"A.J. Puk",team:"Athletics"},
  {code:"90B-AR",player:"Adley Rutschman",team:"Orioles"},
  {code:"90B-AV",player:"Andrew Vaughn",team:"White Sox"},
  {code:"90B-BB",player:"Bo Bichette",team:"Blue Jays"},
  {code:"90B-BH",player:"Bryce Harper",team:"Phillies"},
  {code:"90B-BWJ",player:"Bobby Witt Jr.",team:"Royals"},
  {code:"90B-CA",player:"CJ Abrams",team:"Padres"},
  {code:"90B-CK",player:"Clayton Kershaw",team:"Dodgers"},
  {code:"90B-CM",player:"Casey Mize",team:"Tigers"},
  {code:"90B-CP",player:"Cristian Pache",team:"Braves"},
  {code:"90B-CY",player:"Christian Yelich",team:"Brewers"},
  {code:"90B-DC",player:"Dylan Carlson",team:"Cardinals"},
  {code:"90B-DCE",player:"Dylan Cease",team:"White Sox"},
  {code:"90B-DH",player:"DL Hall",team:"Orioles"},
  {code:"90B-DW",player:"Drew Waters",team:"Braves"},
  {code:"90B-FW",player:"Forrest Whitley",team:"Astros"},
  {code:"90B-GL",player:"Gavin Lux",team:"Dodgers"},
  {code:"90B-GT",player:"Gleyber Torres",team:"Yankees"},
  {code:"90B-IA",player:"Ian Anderson",team:"Braves"},
  {code:"90B-JA",player:"Jo Adell",team:"Angels"},
  {code:"90B-JB",player:"Joey Bart",team:"Giants"},
  {code:"90B-JJB",player:"JJ Bleday",team:"Marlins"},
  {code:"90B-JK",player:"Jarred Kelenic",team:"Mariners"},
  {code:"90B-JL",player:"Jesus Luzardo",team:"Athletics"},
  {code:"90B-JR",player:"Julio Rodriguez",team:"Mariners"},
  {code:"90B-JS",player:"Juan Soto",team:"Nationals"},
  {code:"90B-KL",player:"Kyle Lewis",team:"Mariners"},
  {code:"90B-LR",player:"Luis Robert",team:"White Sox"},
  {code:"90B-MG",player:"MacKenzie Gore",team:"Padres"},
  {code:"90B-ML",player:"Matthew Liberatore",team:"Cardinals"},
  {code:"90B-MM",player:"Matt Manning",team:"Tigers"},
  {code:"90B-MS",player:"Max Scherzer",team:"Nationals"},
  {code:"90B-MT",player:"Mike Trout",team:"Angels"},
  {code:"90B-NG",player:"Nolan Gorman",team:"Cardinals"},
  {code:"90B-NH",player:"Nico Hoerner",team:"Cubs"},
  {code:"90B-NP",player:"Nate Pearson",team:"Blue Jays"},
  {code:"90B-PA",player:"Pete Alonso",team:"Mets"},
  {code:"90B-RAJ",player:"Ronald Acuna Jr.",team:"Braves"},
  {code:"90B-RG",player:"Riley Greene",team:"Tigers"},
  {code:"90B-RL",player:"Royce Lewis",team:"Twins"},
  {code:"90B-SH",player:"Spencer Howard",team:"Phillies"},
  {code:"90B-SM",player:"Sean Murphy",team:"Athletics"},
  {code:"90B-SS",player:"Sixto Sanchez",team:"Marlins"},
  {code:"90B-TT",player:"Taylor Trammell",team:"Padres"},
  {code:"90B-WF",player:"Wander Franco",team:"Rays"},
  {code:"90B-XB",player:"Xander Bogaerts",team:"Red Sox"},
  {code:"90B-YA",player:"Yordan Alvarez",team:"Astros"},
];
const BOWMAN_BTP_ROWS: {code:string; player:string}[] = [
  {code:"BTP-1",player:"Franco"},
  {code:"BTP-2",player:"Robert"},
  {code:"BTP-3",player:"Adell"},
  {code:"BTP-4",player:"Gore"},
  {code:"BTP-5",player:"Lux"},
  {code:"BTP-6",player:"Luzardo"},
  {code:"BTP-7",player:"Rutschman"},
  {code:"BTP-8",player:"Whitley"},
  {code:"BTP-9",player:"Bart"},
  {code:"BTP-10",player:"Pearson"},
  {code:"BTP-11",player:"Mize"},
  {code:"BTP-12",player:"Kelenic"},
  {code:"BTP-13",player:"Pache"},
  {code:"BTP-14",player:"McKay"},
  {code:"BTP-15",player:"Carlson"},
  {code:"BTP-16",player:"Rodriguez"},
  {code:"BTP-17",player:"Manning"},
  {code:"BTP-18",player:"Kirilloff"},
  {code:"BTP-19",player:"Kieboom"},
  {code:"BTP-20",player:"May"},
  {code:"BTP-21",player:"Lewis"},
  {code:"BTP-22",player:"Rodgers"},
  {code:"BTP-23",player:"Sanchez"},
  {code:"BTP-24",player:"Anderson"},
  {code:"BTP-25",player:"Witt Jr."},
  {code:"BTP-26",player:"Patino"},
  {code:"BTP-27",player:"Puk"},
  {code:"BTP-28",player:"Vaughn"},
  {code:"BTP-29",player:"Bohm"},
  {code:"BTP-30",player:"Waters"},
  {code:"BTP-31",player:"Kopech"},
  {code:"BTP-32",player:"Hall"},
  {code:"BTP-33",player:"Hoerner"},
  {code:"BTP-34",player:"Trammell"},
  {code:"BTP-35",player:"Greene"},
  {code:"BTP-36",player:"Howard"},
  {code:"BTP-37",player:"Liberatore"},
  {code:"BTP-38",player:"Keller"},
  {code:"BTP-39",player:"Skubal"},
  {code:"BTP-40",player:"Abrams"},
  {code:"BTP-41",player:"Graterol"},
  {code:"BTP-42",player:"Madrigal"},
  {code:"BTP-43",player:"Gorman"},
  {code:"BTP-44",player:"Hayes"},
  {code:"BTP-45",player:"Lynch"},
  {code:"BTP-46",player:"Gilbert"},
  {code:"BTP-47",player:"Groshans"},
  {code:"BTP-48",player:"Sanchez"},
  {code:"BTP-49",player:"Rodriguez"},
  {code:"BTP-50",player:"Jones"},
  {code:"BTP-51",player:"Greene"},
  {code:"BTP-52",player:"Casas"},
  {code:"BTP-53",player:"Dominguez"},
  {code:"BTP-54",player:"Morejon"},
  {code:"BTP-55",player:"Wright"},
  {code:"BTP-56",player:"Bleday"},
  {code:"BTP-57",player:"Luciano"},
  {code:"BTP-58",player:"White"},
  {code:"BTP-59",player:"Dalbec"},
  {code:"BTP-60",player:"Downs"},
  {code:"BTP-61",player:"Thomas"},
  {code:"BTP-62",player:"Singer"},
  {code:"BTP-63",player:"Robinson"},
  {code:"BTP-64",player:"Dunn"},
  {code:"BTP-65",player:"Ruiz"},
  {code:"BTP-66",player:"India"},
  {code:"BTP-67",player:"Mauricio"},
  {code:"BTP-68",player:"Muller"},
  {code:"BTP-69",player:"Cruz"},
  {code:"BTP-70",player:"Garcia"},
  {code:"BTP-71",player:"Wilson"},
  {code:"BTP-72",player:"Sheffield"},
  {code:"BTP-73",player:"Gimenez"},
  {code:"BTP-74",player:"Mata"},
  {code:"BTP-75",player:"Varsho"},
  {code:"BTP-76",player:"Lodolo"},
  {code:"BTP-77",player:"Alvarez"},
  {code:"BTP-78",player:"Gray"},
  {code:"BTP-79",player:"Murphy"},
  {code:"BTP-80",player:"Ramos"},
  {code:"BTP-81",player:"Kowar"},
  {code:"BTP-82",player:"Brujan"},
  {code:"BTP-83",player:"Baz"},
  {code:"BTP-84",player:"Diaz"},
  {code:"BTP-85",player:"McKenzie"},
  {code:"BTP-86",player:"Valera"},
  {code:"BTP-87",player:"Bishop"},
  {code:"BTP-88",player:"Mountcastle"},
  {code:"BTP-89",player:"Larnach"},
  {code:"BTP-90",player:"Carroll"},
  {code:"BTP-91",player:"Freeman"},
  {code:"BTP-92",player:"Crouse"},
  {code:"BTP-93",player:"McClanahan"},
  {code:"BTP-94",player:"Cabrera"},
  {code:"BTP-95",player:"Garcia"},
  {code:"BTP-96",player:"Campusano"},
  {code:"BTP-97",player:"Marquez"},
  {code:"BTP-98",player:"Gonsolin"},
  {code:"BTP-99",player:"Montero"},
  {code:"BTP-100",player:"Hernandez"},
];
const BOWMAN_HF_ROWS: {code:string; player:string; team:string; note:string}[] = [
  {code:"HF-CM",player:"Cedric Mullins",team:"Baltimore Orioles",note:""},
  {code:"HF-CP",player:"Chris Paddack",team:"San Diego Padres",note:""},
  {code:"HF-DJ",player:"Danny Jansen",team:"Toronto Blue Jays",note:""},
  {code:"HF-GV",player:"Gus Varland",team:"Oakland Athletics",note:""},
  {code:"HF-IG",player:"Isiah Gilliam",team:"New York Yankees",note:""},
  {code:"HF-JB",player:"Jordan Balazovic",team:"Minnesota Twins",note:""},
  {code:"HF-JC",player:"Joey Cantillo",team:"San Diego Padres",note:""},
  {code:"HF-JCA",player:"Jake Cave",team:"Minnesota Twins",note:""},
  {code:"HF-JD",player:"Jarren Duran",team:"Boston Red Sox",note:""},
  {code:"HF-JDM",player:"J.D. Martinez",team:"Boston Red Sox",note:""},
  {code:"HF-JM",player:"Jeff McNeil",team:"New York Mets",note:""},
  {code:"HF-JY",player:"Jordan Yamamoto",team:"Miami Marlins",note:"RC"},
  {code:"HF-LA",player:"Logan Allen",team:"Cleveland Indians",note:"RC"},
  {code:"HF-MK",player:"Mike King",team:"New York Yankees",note:""},
  {code:"HF-MM",player:"Max Muncy",team:"Los Angeles Dodgers",note:""},
  {code:"HF-PG",player:"Paul Goldschmidt",team:"St. Louis Cardinals",note:""},
  {code:"HF-RB",player:"Ryan Borucki",team:"Toronto Blue Jays",note:""},
  {code:"HF-RH",player:"Rhys Hoskins",team:"Philadelphia Phillies",note:""},
  {code:"HF-RT",player:"Rowdy Tellez",team:"Toronto Blue Jays",note:""},
  {code:"HF-SH",player:"Sam Huff",team:"Texas Rangers",note:""},
];
const BOWMAN_HF_AUTO_CODES = ["HF-CP","HF-GV","HF-IG","HF-JC","HF-JDM","HF-JM","HF-JY","HF-LA","HF-MM","HF-PG","HF-RH","HF-SH"];
const BOWMAN_HF_AUTO_ROWS: {code:string; player:string; team:string; note:string}[] = BOWMAN_HF_ROWS.filter(r=>BOWMAN_HF_AUTO_CODES.includes(r.code)).map(r=>({...r,note:"Autograph Variation"}));
const BOWMAN_INSERT_DEFS: S1InsertDef[] = [
  {id:"bow-90b",name:"1990 Bowman Insert",prefix:"90B",size:50,parallels:"Atomic /150, Green /99 Retail, Gold /50, Orange /25 Hobby, Red /5, SuperFractor 1/1",notes:"1990 Bowman Insert",type:"Insert",players:[],known:Object.fromEntries(BOWMAN_90B_ROWS.map(r=>[r.code,r.player])),knownTeams:Object.fromEntries(BOWMAN_90B_ROWS.map(r=>[r.code,r.team]))},
  {id:"bow-btp",name:"Bowman Scouts Top 100",prefix:"BTP",size:100,parallels:"Atomic /150, Green /99 Retail, Gold /50, Orange /25 Hobby, Red /5, SuperFractor 1/1",notes:"Bowman Scouts Top 100 Insert. Gary Vee Variation (18): BTP-1, BTP-2, BTP-3, BTP-4, BTP-7, BTP-8, BTP-16, BTP-25, BTP-31, BTP-52, BTP-53, BTP-56, BTP-63, BTP-70, BTP-80, BTP-86, BTP-95, BTP-99.",type:"Insert",players:[],known:Object.fromEntries(BOWMAN_BTP_ROWS.map(r=>[r.code,r.player]))},
  {id:"bow-hf",name:"Bowman Hidden Finds",prefix:"HF",size:20,parallels:"Refractor /99, Orange /25, Red /5, SuperFractor 1/1",notes:"Bowman Hidden Finds",type:"Insert",players:[],known:Object.fromEntries(BOWMAN_HF_ROWS.map(r=>[r.code,r.player])),knownTeams:Object.fromEntries(BOWMAN_HF_ROWS.map(r=>[r.code,r.team]))},
  {id:"bow-hf-auto",name:"Hidden Finds Autographs",prefix:"HF",size:12,parallels:"Refractor /99, Orange /25, Red /5, SuperFractor 1/1",notes:"Hidden Finds Autograph Variation",type:"Auto",players:[],known:Object.fromEntries(BOWMAN_HF_AUTO_ROWS.map(r=>[r.code,r.player])),knownTeams:Object.fromEntries(BOWMAN_HF_AUTO_ROWS.map(r=>[r.code,r.team]))},
];
function bowmanInsertRowsFor(def:S1InsertDef): {code:string; player:string; team:string; note:string}[] {
  if(def.known) return Object.entries(def.known).map(([code,player])=>({code,player,team:def.knownTeams?.[code]||"—",note:""}));
  return [];
}
function getBowmanInsertEntry(code:string): CardNameEntry | undefined {
  const upper = String(code||"").trim().toUpperCase().replace(/^90B-?/,"90B-");
  const row = BOWMAN_90B_ROWS.find(r=>r.code===upper);
  if(row) return {player:row.player, team:row.team, note:"1990 Bowman Insert"};
  const btpUpper = String(code||"").trim().toUpperCase().replace(/^BTP-?/,"BTP-");
  const btpRow = BOWMAN_BTP_ROWS.find(r=>r.code===btpUpper);
  if(btpRow) return {player:btpRow.player, team:"—", note:"Bowman Scouts Top 100"};
  const hfUpper = String(code||"").trim().toUpperCase();
  const hfRow = BOWMAN_HF_ROWS.find(r=>r.code===hfUpper);
  if(hfRow) return {player:hfRow.player, team:hfRow.team, note:"Bowman Hidden Finds"};
  return undefined;
}
type CardNameEntry = { player: string; team: string; note: string };
const CARD_NAMES: Record<string, Record<string, CardNameEntry>> = {
  "Series 1": {
    "1": {player:"Mike Trout",team:"Angels",note:""},
    "2": {player:"Gerrit Cole",team:"Astros",note:"League Leaders"},
    "3": {player:"Nicky Lopez",team:"Royals",note:""},
    "4": {player:"Robinson Cano",team:"Mets",note:""},
    "5": {player:"JaCoby Jones",team:"Tigers",note:""},
    "6": {player:"Juan Soto",team:"Nationals",note:"World Series Highlights"},
    "7": {player:"Aaron Judge",team:"Yankees",note:""},
    "8": {player:"Jonathan Villar",team:"Orioles",note:""},
    "9": {player:"Trent Grisham",team:"Brewers",note:"Rookie"},
    "10": {player:"Austin Meadows",team:"Rays",note:""},
    "11": {player:"Anthony Rendon",team:"Nationals",note:"League Leaders"},
    "12": {player:"Sam Hilliard",team:"Rockies",note:"Rookie"},
    "13": {player:"Miles Mikolas",team:"Cardinals",note:""},
    "14": {player:"Anthony Rendon",team:"Nationals",note:""},
    "15": {player:"Hollywood Heroes",team:"Padres",note:""},
    "16": {player:"Gleyber Torres",team:"Yankees",note:""},
    "17": {player:"Franmil Reyes",team:"Indians",note:""},
    "18": {player:"Christian & Nolan",team:"Twins",note:""},
    "19": {player:"Angels",team:"Angels",note:"Team Card"},
    "20": {player:"Aristides Aquino",team:"Reds",note:"Rookie"},
    "21": {player:"Shane Greene",team:"Braves",note:""},
    "22": {player:"Emilio Pagan",team:"Rays",note:""},
    "23": {player:"Christin Stewart",team:"Tigers",note:""},
    "24": {player:"Kenley Jansen",team:"Dodgers",note:""},
    "25": {player:"Kirby Yates",team:"Padres",note:""},
    "26": {player:"Kyle Hendricks",team:"Cubs",note:""},
    "27": {player:"Brewers",team:"Brewers",note:"Team Card"},
    "28": {player:"Tim Anderson",team:"White Sox",note:""},
    "29": {player:"Starlin Castro",team:"Marlins",note:""},
    "30": {player:"Josh VanMeter",team:"Reds",note:""},
    "31": {player:"Close Call",team:"AL",note:""},
    "32": {player:"Brandon Woodruff",team:"Brewers",note:""},
    "33": {player:"Astros",team:"Astros",note:"Team Card"},
    "34": {player:"Ian Kinsler",team:"Padres",note:""},
    "35": {player:"Adalberto Mondesi",team:"Royals",note:""},
    "36": {player:"Sean Doolittle",team:"Nationals",note:""},
    "37": {player:"Albert Almora",team:"Cubs",note:""},
    "38": {player:"Austin Nola",team:"Mariners",note:"Rookie"},
    "39": {player:"Tyler O'Neill",team:"Cardinals",note:""},
    "40": {player:"Bobby Bradley",team:"Indians",note:"Rookie"},
    "41": {player:"Brian Anderson",team:"Marlins",note:""},
    "42": {player:"Lewis Brinson",team:"Marlins",note:""},
    "43": {player:"Leury Garcia",team:"White Sox",note:""},
    "44": {player:"Tommy Edman",team:"Cardinals",note:"Future Stars"},
    "45": {player:"Mitch Haniger",team:"Mariners",note:""},
    "46": {player:"Gary Sanchez",team:"Yankees",note:""},
    "47": {player:"Dansby Swanson",team:"Braves",note:""},
    "48": {player:"Jeff McNeil",team:"Mets",note:"Future Stars"},
    "49": {player:"Eloy Jimenez",team:"White Sox",note:"Rookie Cup"},
    "50": {player:"Cody Bellinger",team:"Dodgers",note:""},
    "51": {player:"Anthony Rizzo",team:"Cubs",note:""},
    "52": {player:"Yasmani Grandal",team:"Brewers",note:""},
    "53": {player:"Pete Alonso",team:"Mets",note:"League Leaders"},
    "54": {player:"Hunter Dozier",team:"Royals",note:""},
    "55": {player:"Jose Martinez",team:"Cardinals",note:""},
    "56": {player:"Andres Munoz",team:"Padres",note:"Rookie"},
    "57": {player:"Travis Demeritte",team:"Tigers",note:"Rookie"},
    "58": {player:"Jesse Winker",team:"Reds",note:""},
    "59": {player:"Chris Archer",team:"Pirates",note:""},
    "60": {player:"Matt Barnes",team:"Red Sox",note:""},
    "61": {player:"Manny Being Manny",team:"Blue Jays",note:""},
    "62": {player:"Chase Anderson",team:"Brewers",note:""},
    "63": {player:"Christian Vazquez",team:"Red Sox",note:""},
    "64": {player:"Kyle Lewis",team:"Mariners",note:"Rookie"},
    "65": {player:"Indians",team:"Indians",note:"Team Card"},
    "66": {player:"Andrew Heaney",team:"Angels",note:""},
    "67": {player:"Tyler Beede",team:"Giants",note:""},
    "68": {player:"James Paxton",team:"Yankees",note:""},
    "69": {player:"Brendan McKay",team:"Rays",note:"Rookie"},
    "70": {player:"Nico Hoerner",team:"Cubs",note:"Rookie"},
    "71": {player:"Sandy Alcantara",team:"Marlins",note:""},
    "72": {player:"Good-Bye, Home Run!",team:"Brewers",note:""},
    "73": {player:"Athletics",team:"Athletics",note:"Team Card"},
    "74": {player:"Bubba Starling",team:"Royals",note:"Rookie"},
    "75": {player:"Michael Conforto",team:"Mets",note:""},
    "76": {player:"Stephen Strasburg",team:"Nationals",note:"World Series Highlights"},
    "77": {player:"Charlie Culberson",team:"Braves",note:""},
    "78": {player:"Bo Bichette",team:"Blue Jays",note:"Rookie"},
    "79": {player:"Brad Keller",team:"Royals",note:""},
    "80": {player:"Austin Barnes",team:"Dodgers",note:""},
    "81": {player:"Ryan Yarbrough",team:"Rays",note:""},
    "82": {player:"Jorge Polanco",team:"Twins",note:""},
    "83": {player:"Yankees",team:"Yankees",note:"Team Card"},
    "84": {player:"Ken Giles",team:"Blue Jays",note:""},
    "85": {player:"Soaking It All In",team:"White Sox",note:""},
    "86": {player:"Hyun-Jin Ryu",team:"Dodgers",note:"League Leaders"},
    "87": {player:"Cardinals",team:"Cardinals",note:"Team Card"},
    "88": {player:"Jorge Alfaro",team:"Marlins",note:""},
    "89": {player:"Kurt Suzuki",team:"Nationals",note:""},
    "90": {player:"Brock Holt",team:"Red Sox",note:""},
    "91": {player:"Yolmer Sanchez",team:"White Sox",note:""},
    "92": {player:"Blake Treinen",team:"Athletics",note:""},
    "93": {player:"Alex Colome",team:"White Sox",note:""},
    "94": {player:"Marwin Gonzalez",team:"Twins",note:""},
    "95": {player:"Ian Kennedy",team:"Royals",note:""},
    "96": {player:"Jose Abreu",team:"White Sox",note:"League Leaders"},
    "97": {player:"Lewis Thorpe",team:"Twins",note:"Rookie"},
    "98": {player:"Jesus Aguilar",team:"Rays",note:""},
    "99": {player:"Dan Vogelbach",team:"Mariners",note:""},
    "100": {player:"Alex Bregman",team:"Astros",note:""},
    "101": {player:"Brad Hand",team:"Indians",note:""},
    "102": {player:"Josh Phegley",team:"Athletics",note:""},
    "103": {player:"Danny Hultzen",team:"Cubs",note:"Rookie"},
    "104": {player:"Marco Gonzales",team:"Mariners",note:""},
    "105": {player:"Niko Goodrum",team:"Tigers",note:""},
    "106": {player:"Rogelio Armenteros",team:"Astros",note:"Rookie"},
    "107": {player:"Luis Castillo",team:"Reds",note:""},
    "108": {player:"Josh Rojas",team:"Diamondbacks",note:"Rookie"},
    "109": {player:"Reese McGuire",team:"Blue Jays",note:""},
    "110": {player:"Jesus Luzardo",team:"Athletics",note:"Rookie"},
    "111": {player:"Buster Posey",team:"Giants",note:""},
    "112": {player:"Max Stassi",team:"Angels",note:""},
    "113": {player:"Matt Carpenter",team:"Cardinals",note:""},
    "114": {player:"Ildemaro Vargas",team:"Diamondbacks",note:""},
    "115": {player:"Matt Thaiss",team:"Angels",note:"Rookie"},
    "116": {player:"Daniel Murphy",team:"Rockies",note:""},
    "117": {player:"Max Kepler",team:"Twins",note:""},
    "118": {player:"Clayton Kershaw",team:"Dodgers",note:""},
    "119": {player:"Kyle Schwarber",team:"Cubs",note:""},
    "120": {player:"Kenta Maeda",team:"Dodgers",note:""},
    "121": {player:"DJ LeMahieu",team:"Yankees",note:""},
    "122": {player:"Caleb Smith",team:"Marlins",note:""},
    "123": {player:"Seth Brown",team:"Athletics",note:"Rookie"},
    "124": {player:"Jose Berrios",team:"Twins",note:""},
    "125": {player:"Shohei Ohtani",team:"Angels",note:""},
    "126": {player:"German Marquez",team:"Rockies",note:""},
    "127": {player:"Matt Chapman",team:"Athletics",note:""},
    "128": {player:"Steven Matz",team:"Mets",note:""},
    "129": {player:"Yoan Moncada",team:"White Sox",note:""},
    "130": {player:"Michael Chavis",team:"Red Sox",note:"Future Stars"},
    "131": {player:"Ketel Marte",team:"Diamondbacks",note:""},
    "132": {player:"Jay Bruce",team:"Phillies",note:""},
    "133": {player:"Michael Brosseau",team:"Rays",note:"Rookie"},
    "134": {player:"David Fletcher",team:"Angels",note:""},
    "135": {player:"Enrique Hernandez",team:"Dodgers",note:""},
    "136": {player:"Amed Rosario",team:"Mets",note:""},
    "137": {player:"Merrill Kelly",team:"Diamondbacks",note:""},
    "138": {player:"Jackie Bradley Jr.",team:"Red Sox",note:""},
    "139": {player:"Jose Quintana",team:"Cubs",note:""},
    "140": {player:"Trevor Bauer",team:"Reds",note:""},
    "141": {player:"Roberto Osuna",team:"Astros",note:""},
    "142": {player:"Tyler Flowers",team:"Braves",note:""},
    "143": {player:"Christian Yelich",team:"Brewers",note:"League Leaders"},
    "144": {player:"Jake Arrieta",team:"Phillies",note:""},
    "145": {player:"Paul Goldschmidt",team:"Cardinals",note:""},
    "146": {player:"Dwight Smith Jr.",team:"Orioles",note:""},
    "147": {player:"Jake Rogers",team:"Tigers",note:"Rookie"},
    "148": {player:"Willy Adames",team:"Rays",note:""},
    "149": {player:"Orlando Arcia",team:"Brewers",note:""},
    "150": {player:"Ronald Acuna Jr.",team:"Braves",note:""},
    "151": {player:"Tommy La Stella",team:"Angels",note:""},
    "152": {player:"Zack Wheeler",team:"Mets",note:""},
    "153": {player:"Andrew Cashner",team:"Red Sox",note:""},
    "154": {player:"C.J. Cron",team:"Twins",note:""},
    "155": {player:"Jack Flaherty",team:"Cardinals",note:""},
    "156": {player:"Nick Markakis",team:"Braves",note:""},
    "157": {player:"Master & Apprentice",team:"Yankees",note:""},
    "158": {player:"Jake Lamb",team:"Diamondbacks",note:""},
    "159": {player:"Jorge Soler",team:"Royals",note:"League Leaders"},
    "160": {player:"Tim & Yolmer",team:"NL",note:""},
    "161": {player:"Aroldis Chapman",team:"Yankees",note:""},
    "162": {player:"Michel Baez",team:"Padres",note:"Rookie"},
    "163": {player:"Ryan Pressly",team:"Astros",note:""},
    "164": {player:"Matt Strahm",team:"Padres",note:""},
    "165": {player:"Matthew Boyd",team:"Tigers",note:""},
    "166": {player:"Nick Solak",team:"Rangers",note:"Rookie"},
    "167": {player:"Anthony Kay",team:"Blue Jays",note:"Rookie"},
    "168": {player:"Fernando Tatis Jr.",team:"Padres",note:"Rookie Cup"},
    "169": {player:"Jacob Waguespack",team:"Blue Jays",note:"Rookie"},
    "170": {player:"Gregory Polanco",team:"Pirates",note:""},
    "171": {player:"Kole Calhoun",team:"Angels",note:""},
    "172": {player:"Sonny Gray",team:"Reds",note:""},
    "173": {player:"Yadier Molina",team:"Cardinals",note:""},
    "174": {player:"Alex Verdugo",team:"Dodgers",note:""},
    "175": {player:"Lucas Giolito",team:"White Sox",note:""},
    "176": {player:"Brandon Belt",team:"Giants",note:""},
    "177": {player:"Craig Kimbrel",team:"Cubs",note:""},
    "178": {player:"Mauricio Dubon",team:"Giants",note:"Rookie"},
    "179": {player:"Ramon Laureano",team:"Athletics",note:"Future Stars"},
    "180": {player:"Max Scherzer",team:"Nationals",note:""},
    "181": {player:"Stephen Strasburg",team:"Nationals",note:"League Leaders"},
    "182": {player:"Vladimir Guerrero Jr.",team:"Blue Jays",note:"Rookie Cup"},
    "183": {player:"Starling Marte",team:"Pirates",note:""},
    "184": {player:"Mychal Givens",team:"Orioles",note:""},
    "185": {player:"Johnny Cueto",team:"Giants",note:""},
    "186": {player:"Roberto Perez",team:"Indians",note:""},
    "187": {player:"Chance Sisco",team:"Orioles",note:""},
    "188": {player:"Manny Machado",team:"Padres",note:""},
    "189": {player:"Mike Moustakas",team:"Brewers",note:""},
    "190": {player:"Aaron Nola",team:"Phillies",note:""},
    "191": {player:"Jeremy Jeffress",team:"Brewers",note:""},
    "192": {player:"Yusei Kikuchi",team:"Mariners",note:""},
    "193": {player:"Anibal Sanchez",team:"Nationals",note:""},
    "194": {player:"Liam Hendriks",team:"Athletics",note:""},
    "195": {player:"Julio Teheran",team:"Braves",note:""},
    "196": {player:"Andrew Benintendi",team:"Red Sox",note:""},
    "197": {player:"Raisel Iglesias",team:"Reds",note:""},
    "198": {player:"Erick Fedde",team:"Nationals",note:""},
    "199": {player:"Domingo Santana",team:"Mariners",note:""},
    "200": {player:"Christian Yelich",team:"Brewers",note:""},
    "201": {player:"Francisco Lindor",team:"Indians",note:""},
    "202": {player:"Mets",team:"Mets",note:"Team Card"},
    "203": {player:"Joc Pederson",team:"Dodgers",note:""},
    "204": {player:"Hector Neris",team:"Phillies",note:""},
    "205": {player:"Patrick Sandoval",team:"Angels",note:"Rookie"},
    "206": {player:"Tommy Pham",team:"Rays",note:""},
    "207": {player:"Zac Gallen",team:"Diamondbacks",note:"Rookie"},
    "208": {player:"Zack Collins",team:"White Sox",note:"Rookie"},
    "209": {player:"Derek Dietrich",team:"Reds",note:""},
    "210": {player:"Mitch Garver",team:"Twins",note:""},
    "211": {player:"Trevor Richards",team:"Rays",note:""},
    "212": {player:"Mike Fiers",team:"Athletics",note:""},
    "213": {player:"Twins",team:"Twins",note:"Team Card"},
    "214": {player:"Trea Turner",team:"Nationals",note:""},
    "215": {player:"Luke Jackson",team:"Braves",note:""},
    "216": {player:"Scott Kingery",team:"Phillies",note:""},
    "217": {player:"Amir Garrett",team:"Reds",note:""},
    "218": {player:"Braves",team:"Braves",note:"Team Card"},
    "219": {player:"Jean Segura",team:"Phillies",note:""},
    "220": {player:"J.T. Realmuto",team:"Phillies",note:""},
    "221": {player:"Nick Pivetta",team:"Phillies",note:""},
    "222": {player:"Andrew Chafin",team:"Diamondbacks",note:""},
    "223": {player:"Aaron Civale",team:"Indians",note:"Rookie"},
    "224": {player:"Juan Soto",team:"Nationals",note:""},
    "225": {player:"Oscar Mercado",team:"Indians",note:"Future Stars"},
    "226": {player:"Trent Thornton",team:"Blue Jays",note:""},
    "227": {player:"David Peralta",team:"Diamondbacks",note:""},
    "228": {player:"Logan Allen",team:"Indians",note:"Rookie"},
    "229": {player:"Randy Arozarena",team:"Cardinals",note:"Rookie"},
    "230": {player:"Nolan Arenado",team:"Rockies",note:""},
    "231": {player:"Randal Grichuk",team:"Blue Jays",note:""},
    "232": {player:"Justin Verlander",team:"Astros",note:"League Leaders"},
    "233": {player:"David Dahl",team:"Rockies",note:""},
    "234": {player:"Cesar Hernandez",team:"Phillies",note:""},
    "235": {player:"Dustin May",team:"Dodgers",note:"Rookie"},
    "236": {player:"Brandon Crawford",team:"Giants",note:""},
    "237": {player:"Luis Garcia",team:"Angels",note:""},
    "238": {player:"Freddy Peralta",team:"Brewers",note:""},
    "239": {player:"Anthony Rendon",team:"Nationals",note:"World Series Highlights"},
    "240": {player:"Jameson Taillon",team:"Pirates",note:""},
    "241": {player:"Mike Clevinger",team:"Indians",note:""},
    "242": {player:"Alex Young",team:"Diamondbacks",note:"Rookie"},
    "243": {player:"Jeimer Candelario",team:"Tigers",note:""},
    "244": {player:"Chris Paddack",team:"Padres",note:"Future Stars"},
    "245": {player:"Dodgers",team:"Dodgers",note:"Team Card"},
    "246": {player:"Phillies",team:"Phillies",note:"Team Card"},
    "247": {player:"Garrett Cooper",team:"Marlins",note:""},
    "248": {player:"Hunter Renfroe",team:"Padres",note:""},
    "249": {player:"Jordan Yamamoto",team:"Marlins",note:"Rookie"},
    "250": {player:"Bryce Harper",team:"Phillies",note:""},
    "251": {player:"A.J. Puk",team:"Athletics",note:"Rookie"},
    "252": {player:"Aaron Hicks",team:"Yankees",note:""},
    "253": {player:"Brandon Drury",team:"Blue Jays",note:""},
    "254": {player:"Andrew Miller",team:"Cardinals",note:""},
    "255": {player:"Max Muncy",team:"Dodgers",note:""},
    "256": {player:"Roman Quinn",team:"Phillies",note:""},
    "257": {player:"Joey Lucchesi",team:"Padres",note:""},
    "258": {player:"Max Scherzer",team:"Nationals",note:"World Series Highlights"},
    "259": {player:"Jaylin Davis",team:"Giants",note:"Rookie"},
    "260": {player:"Zack Greinke",team:"Astros",note:""},
    "261": {player:"Daniel Mengden",team:"Athletics",note:""},
    "262": {player:"Anthony Santander",team:"Orioles",note:""},
    "263": {player:"J.P. Crawford",team:"Mariners",note:""},
    "264": {player:"Abraham Toro",team:"Astros",note:"Rookie"},
    "265": {player:"Patrick Corbin",team:"Nationals",note:""},
    "266": {player:"Austin Riley",team:"Braves",note:"Future Stars"},
    "267": {player:"Joey Votto",team:"Reds",note:""},
    "268": {player:"Ian Desmond",team:"Rockies",note:""},
    "269": {player:"J.D. Martinez",team:"Red Sox",note:""},
    "270": {player:"Jose Urena",team:"Marlins",note:""},
    "271": {player:"Josh Bell",team:"Pirates",note:""},
    "272": {player:"Carlos Santana",team:"Indians",note:""},
    "273": {player:"Bryan Abreu",team:"Astros",note:"Rookie"},
    "274": {player:"Red Sox",team:"Red Sox",note:"Team Card"},
    "275": {player:"JT Riddle",team:"Marlins",note:""},
    "276": {player:"Yordan Alvarez",team:"Astros",note:"Rookie"},
    "277": {player:"Dominic Smith",team:"Mets",note:""},
    "278": {player:"Isan Diaz",team:"Marlins",note:"Rookie"},
    "279": {player:"Masahiro Tanaka",team:"Yankees",note:""},
    "280": {player:"Tony Gonsolin",team:"Dodgers",note:"Rookie"},
    "281": {player:"Nelson Cruz",team:"Twins",note:""},
    "282": {player:"Jake Marisnick",team:"Astros",note:""},
    "283": {player:"Robel Garcia",team:"Cubs",note:"Rookie"},
    "284": {player:"Jason Kipnis",team:"Indians",note:""},
    "285": {player:"Tyler Alexander",team:"Tigers",note:"Rookie"},
    "286": {player:"Blake Parker",team:"Phillies",note:""},
    "287": {player:"Jose Peraza",team:"Reds",note:""},
    "288": {player:"Jon Gray",team:"Rockies",note:""},
    "289": {player:"Yuli Gurriel",team:"Astros",note:""},
    "290": {player:"Nick Senzel",team:"Reds",note:"Future Stars"},
    "291": {player:"Tyler Naquin",team:"Indians",note:""},
    "292": {player:"Gavin Lux",team:"Dodgers",note:"Rookie"},
    "293": {player:"Wade Davis",team:"Rockies",note:""},
    "294": {player:"Jordan Zimmermann",team:"Tigers",note:""},
    "295": {player:"Jeff Samardzija",team:"Giants",note:""},
    "296": {player:"Whit Merrifield",team:"Royals",note:""},
    "297": {player:"Mike Yastrzemski",team:"Giants",note:"Future Stars"},
    "298": {player:"Big Air, Big Hair",team:"Dodgers",note:""},
    "299": {player:"David Price",team:"Red Sox",note:""},
    "300": {player:"Javier Baez",team:"Cubs",note:""},
    "301": {player:"Mike Tauchman",team:"Yankees",note:""},
    "302": {player:"Tim Anderson",team:"White Sox",note:"League Leaders"},
    "303": {player:"Mallex Smith",team:"Mariners",note:""},
    "304": {player:"Shane Bieber",team:"Indians",note:""},
    "305": {player:"Tyler Glasnow",team:"Rays",note:""},
    "306": {player:"Jon Lester",team:"Cubs",note:""},
    "307": {player:"Daniel Palka",team:"White Sox",note:""},
    "308": {player:"Carlos Rodon",team:"White Sox",note:""},
    "309": {player:"Robbie Grossman",team:"Athletics",note:""},
    "310": {player:"Jose Urquidy",team:"Astros",note:"Rookie"},
    "311": {player:"David Bote",team:"Cubs",note:""},
    "312": {player:"Billy Hamilton",team:"Braves",note:""},
    "313": {player:"Melky Cabrera",team:"Pirates",note:""},
    "314": {player:"Rafael Devers",team:"Red Sox",note:""},
    "315": {player:"Adam Frazier",team:"Pirates",note:""},
    "316": {player:"Justin Turner",team:"Dodgers",note:""},
    "317": {player:"Sean Murphy",team:"Athletics",note:"Rookie"},
    "318": {player:"Omar Narvaez",team:"Mariners",note:""},
    "319": {player:"Matt Olson",team:"Athletics",note:""},
    "320": {player:"Austin Hedges",team:"Padres",note:""},
    "321": {player:"Eduardo Rodriguez",team:"Red Sox",note:""},
    "322": {player:"Dario Agrazal",team:"Pirates",note:"Rookie"},
    "323": {player:"Tyler White",team:"Dodgers",note:""},
    "324": {player:"Mike Soroka",team:"Braves",note:"Rookie Cup"},
    "325": {player:"Like Father, Like Son",team:"Cubs",note:""},
    "326": {player:"Dylan Cease",team:"White Sox",note:"Rookie"},
    "327": {player:"Cavan Biggio",team:"Blue Jays",note:"Future Stars"},
    "328": {player:"Chris Davis",team:"Orioles",note:""},
    "329": {player:"Nationals",team:"Nationals",note:"Team Card"},
    "330": {player:"George Springer",team:"Astros",note:""},
    "331": {player:"Kevin McCarthy",team:"Royals",note:""},
    "332": {player:"Jacob deGrom",team:"Mets",note:""},
    "333": {player:"Evan Longoria",team:"Giants",note:""},
    "334": {player:"Kevin Pillar",team:"Giants",note:""},
    "335": {player:"Luke Voit",team:"Yankees",note:""},
    "336": {player:"Miguel Cabrera",team:"Tigers",note:""},
    "337": {player:"Michael Pineda",team:"Twins",note:""},
    "338": {player:"Cubs",team:"Cubs",note:"Team Card"},
    "339": {player:"Hansel Robles",team:"Angels",note:""},
    "340": {player:"Adbert Alzolay",team:"Cubs",note:"Rookie"},
    "341": {player:"Hanser Alberto",team:"Orioles",note:""},
    "342": {player:"Taylor Rogers",team:"Twins",note:""},
    "343": {player:"Carson Kelly",team:"Diamondbacks",note:""},
    "344": {player:"Ben Gamel",team:"Brewers",note:""},
    "345": {player:"Justin Verlander",team:"Astros",note:""},
    "346": {player:"Lourdes Gurriel Jr.",team:"Blue Jays",note:""},
    "347": {player:"Ryan Braun",team:"Brewers",note:""},
    "348": {player:"Adrian Morejon",team:"Padres",note:"Rookie"},
    "349": {player:"Carlos Correa",team:"Astros",note:""},
    "350": {player:"Pete Alonso",team:"Mets",note:"Rookie Cup"}
  },
  "Series 2": {
    "351": {player:"Gerrit Cole",team:"Yankees",note:""},
    "352": {player:"Tanner Roark",team:"Blue Jays",note:""},
    "353": {player:"DJ Stewart",team:"Orioles",note:""},
    "354": {player:"Luke Weaver",team:"Diamondbacks",note:""},
    "355": {player:"Max Fried",team:"Braves",note:"Future Stars"},
    "356": {player:"Franklin Barreto",team:"Athletics",note:""},
    "357": {player:"Homer Bailey",team:"Twins",note:""},
    "358": {player:"Rio Ruiz",team:"Orioles",note:""},
    "359": {player:"Domingo Leyba",team:"Diamondbacks",note:"Rookie"},
    "360": {player:"Luis Rengifo",team:"Angels",note:""},
    "361": {player:"Zach Eflin",team:"Phillies",note:""},
    "362": {player:"Chris Shaw",team:"Giants",note:""},
    "363": {player:"Shed Long",team:"Mariners",note:""},
    "364": {player:"Hunter Harvey",team:"Orioles",note:"Rookie"},
    "365": {player:"Philly Special",team:"Rangers",note:""},
    "366": {player:"Marcus Semien",team:"Athletics",note:""},
    "367": {player:"Giancarlo Stanton",team:"Yankees",note:""},
    "368": {player:"Wade Miley",team:"Reds",note:""},
    "369": {player:"Kolten Wong",team:"Cardinals",note:""},
    "370": {player:"Seth Mejias-Brean",team:"Padres",note:"Rookie"},
    "371": {player:"Victor Caratini",team:"Cubs",note:""},
    "372": {player:"Josh Donaldson",team:"Twins",note:""},
    "373": {player:"Kevin Cron",team:"Diamondbacks",note:""},
    "374": {player:"Jose Ramirez",team:"Indians",note:""},
    "375": {player:"Jose Osuna",team:"Pirates",note:""},
    "376": {player:"Shogo Akiyama",team:"Reds",note:"Rookie"},
    "377": {player:"Phillip Ervin",team:"Reds",note:""},
    "378": {player:"Nathan Eovaldi",team:"Red Sox",note:""},
    "379": {player:"Ivan Nova",team:"Tigers",note:""},
    "380": {player:"James Karinchak",team:"Indians",note:"Rookie"},
    "381": {player:"Kyle Garlick",team:"Dodgers",note:"Rookie"},
    "382": {player:"Archie Bradley",team:"Diamondbacks",note:""},
    "383": {player:"Steven Brault",team:"Pirates",note:""},
    "384": {player:"Carlos Carrasco",team:"Indians",note:""},
    "385": {player:"Ryan Zimmerman",team:"Nationals",note:""},
    "386": {player:"Dakota Hudson",team:"Cardinals",note:"Future Stars"},
    "387": {player:"Tony Wolters",team:"Rockies",note:""},
    "388": {player:"Dustin Pedroia",team:"Red Sox",note:""},
    "389": {player:"Ryan O'Hearn",team:"Royals",note:""},
    "390": {player:"Emmanuel Clase",team:"Indians",note:"Rookie"},
    "391": {player:"Justin Upton",team:"Angels",note:""},
    "392": {player:"Luis Robert",team:"White Sox",note:"Rookie"},
    "393": {player:"Dereck Rodriguez",team:"Giants",note:""},
    "394": {player:"Keone Kela",team:"Pirates",note:""},
    "395": {player:"Scott Oberg",team:"Rockies",note:""},
    "396": {player:"Marlins",team:"Marlins",note:"Team Card"},
    "397": {player:"Charlie Blackmon",team:"Rockies",note:""},
    "398": {player:"Miguel Andujar",team:"Yankees",note:""},
    "399": {player:"Adrian Houser",team:"Brewers",note:""},
    "400": {player:"Hyun-Jin Ryu",team:"Blue Jays",note:""},
    "401": {player:"Jake Fraley",team:"Mariners",note:"Rookie"},
    "402": {player:"Vince Velazquez",team:"Phillies",note:""},
    "403": {player:"Jose Trevino",team:"Rangers",note:""},
    "404": {player:"Raimel Tapia",team:"Rockies",note:""},
    "405": {player:"Giants",team:"Giants",note:"Team Card"},
    "406": {player:"Charlie Morton",team:"Rays",note:""},
    "407": {player:"T.J. Zeuch",team:"Blue Jays",note:"Rookie"},
    "408": {player:"Brendan Rodgers",team:"Rockies",note:"Future Stars"},
    "409": {player:"Jake Odorizzi",team:"Twins",note:""},
    "410": {player:"Luis Urias",team:"Brewers",note:"Future Stars"},
    "411": {player:"Mark Melancon",team:"Braves",note:""},
    "412": {player:"Bomba Brothers",team:"Twins",note:""},
    "413": {player:"Rich Hill",team:"Twins",note:""},
    "414": {player:"Gio Gonzalez",team:"White Sox",note:""},
    "415": {player:"Joey Gallo",team:"Rangers",note:""},
    "416": {player:"Chris Taylor",team:"Dodgers",note:""},
    "417": {player:"Rockies",team:"Rockies",note:"Team Card"},
    "418": {player:"Alex Dickerson",team:"Giants",note:""},
    "419": {player:"J.A. Happ",team:"Yankees",note:""},
    "420": {player:"Mookie Betts",team:"Dodgers",note:""},
    "421": {player:"Garrett Stubbs",team:"Astros",note:"Rookie"},
    "422": {player:"Will Smith",team:"Braves",note:""},
    "423": {player:"Andrelton Simmons",team:"Angels",note:""},
    "424": {player:"Miguel Sano",team:"Twins",note:""},
    "425": {player:"Mike Foltynewicz",team:"Braves",note:""},
    "426": {player:"Yoenis Cespedes",team:"Mets",note:""},
    "427": {player:"Edwin Diaz",team:"Mets",note:""},
    "428": {player:"Jaime Barria",team:"Angels",note:""},
    "429": {player:"Joe Musgrove",team:"Pirates",note:""},
    "430": {player:"Darwinzon Hernandez",team:"Red Sox",note:""},
    "431": {player:"Reds",team:"Reds",note:"Team Card"},
    "432": {player:"Walker Buehler",team:"Dodgers",note:""},
    "433": {player:"Noah Syndergaard",team:"Mets",note:""},
    "434": {player:"Brusdar Graterol",team:"Dodgers",note:"Rookie"},
    "435": {player:"Mitch Keller",team:"Pirates",note:""},
    "436": {player:"Travis d'Arnaud",team:"Braves",note:""},
    "437": {player:"Scott Heineman",team:"Rangers",note:"Rookie"},
    "438": {player:"Danny Duffy",team:"Royals",note:""},
    "439": {player:"Dee Gordon",team:"Mariners",note:""},
    "440": {player:"Carter Kieboom",team:"Nationals",note:"Future Stars"},
    "441": {player:"Nick Wittgren",team:"Indians",note:""},
    "442": {player:"Tom Eshelman",team:"Orioles",note:"Rookie"},
    "443": {player:"Johan Camargo",team:"Braves",note:""},
    "444": {player:"Martin Perez",team:"Red Sox",note:""},
    "445": {player:"Spencer Turnbull",team:"Tigers",note:""},
    "446": {player:"Braves New World",team:"Phillies",note:""},
    "447": {player:"Griffin Canning",team:"Angels",note:"Future Stars"},
    "448": {player:"Ian Happ",team:"Cubs",note:""},
    "449": {player:"Shun Yamaguchi",team:"Blue Jays",note:"Rookie"},
    "450": {player:"Jorge Soler",team:"Royals",note:""},
    "451": {player:"Justus Sheffield",team:"Mariners",note:""},
    "452": {player:"Joe Jimenez",team:"Tigers",note:""},
    "453": {player:"Miguel Rojas",team:"Marlins",note:""},
    "454": {player:"Austin Voth",team:"Nationals",note:""},
    "455": {player:"Kris Bryant",team:"Cubs",note:""},
    "456": {player:"Dom Nunez",team:"Rockies",note:"Rookie"},
    "457": {player:"Kevin Gausman",team:"Giants",note:""},
    "458": {player:"Trey Mancini",team:"Orioles",note:""},
    "459": {player:"Kwang-Hyun Kim",team:"Cardinals",note:"Rookie"},
    "460": {player:"Tyler Mahle",team:"Reds",note:""},
    "461": {player:"Harrison Bader",team:"Cardinals",note:""},
    "462": {player:"Tony Kemp",team:"Athletics",note:""},
    "463": {player:"Frankie Montas",team:"Athletics",note:""},
    "464": {player:"Randy Dobnak",team:"Twins",note:"Rookie"},
    "465": {player:"Eugenio Suarez",team:"Reds",note:""},
    "466": {player:"Garrett Hampson",team:"Rockies",note:""},
    "467": {player:"Andrew McCutchen",team:"Phillies",note:""},
    "468": {player:"Chad Green",team:"Yankees",note:""},
    "469": {player:"Rev'd Up",team:"Cubs",note:""},
    "470": {player:"Yan Gomes",team:"Nationals",note:""},
    "471": {player:"Lorenzo Cain",team:"Brewers",note:""},
    "472": {player:"Steven Duggar",team:"Giants",note:""},
    "473": {player:"Lance McCullers Jr.",team:"Astros",note:""},
    "474": {player:"Mark Canha",team:"Athletics",note:""},
    "475": {player:"Robert Dugger",team:"Marlins",note:"Rookie"},
    "476": {player:"James Marvel",team:"Pirates",note:"Rookie"},
    "477": {player:"Brent Suter",team:"Brewers",note:""},
    "478": {player:"Cole Tucker",team:"Pirates",note:""},
    "479": {player:"Dexter Fowler",team:"Cardinals",note:""},
    "480": {player:"Ozzie Albies",team:"Braves",note:""},
    "481": {player:"Victor Reyes",team:"Tigers",note:""},
    "482": {player:"Adam Duvall",team:"Braves",note:""},
    "483": {player:"Eddie Rosario",team:"Twins",note:""},
    "484": {player:"Brian Goodwin",team:"Angels",note:""},
    "485": {player:"Jack Mayfield",team:"Astros",note:"Rookie"},
    "486": {player:"Dawel Lugo",team:"Tigers",note:""},
    "487": {player:"Yandy Diaz",team:"Rays",note:""},
    "488": {player:"Reynaldo Lopez",team:"White Sox",note:""},
    "489": {player:"Colin Moran",team:"Pirates",note:""},
    "490": {player:"Austin Slater",team:"Giants",note:""},
    "491": {player:"Will Smith",team:"Dodgers",note:"Rookie Cup"},
    "492": {player:"Paul DeJong",team:"Cardinals",note:""},
    "493": {player:"Christian Walker",team:"Diamondbacks",note:""},
    "494": {player:"Rowan Wick",team:"Cubs",note:""},
    "495": {player:"LaMonte Wade Jr.",team:"Twins",note:"Rookie"},
    "496": {player:"Lucas Sims",team:"Reds",note:""},
    "497": {player:"Albert Pujols",team:"Angels",note:""},
    "498": {player:"Brandon Workman",team:"Red Sox",note:""},
    "499": {player:"Sam Tuivailala",team:"Mariners",note:""},
    "500": {player:"Nick Anderson",team:"Rays",note:"Rookie Cup"},
    "501": {player:"Rays",team:"Rays",note:"Team Card"},
    "502": {player:"Willians Astudillo",team:"Twins",note:""},
    "503": {player:"Dylan Bundy",team:"Angels",note:""},
    "504": {player:"Pablo Lopez",team:"Marlins",note:""},
    "505": {player:"Billy McKinney",team:"Blue Jays",note:""},
    "506": {player:"Delino DeShields",team:"Indians",note:""},
    "507": {player:"Blake Snell",team:"Rays",note:""},
    "508": {player:"Carlos Martinez",team:"Cardinals",note:""},
    "509": {player:"Willi Castro",team:"Tigers",note:"Rookie"},
    "510": {player:"Michael Lorenzen",team:"Reds",note:""},
    "511": {player:"Jordan Hicks",team:"Cardinals",note:""},
    "512": {player:"Josh James",team:"Astros",note:""},
    "513": {player:"Michael Brantley",team:"Astros",note:""},
    "514": {player:"Logan Webb",team:"Giants",note:"Rookie"},
    "515": {player:"Maikel Franco",team:"Royals",note:""},
    "516": {player:"Rangers",team:"Rangers",note:"Team Card"},
    "517": {player:"Dylan Moore",team:"Mariners",note:""},
    "518": {player:"Shin-Soo Choo",team:"Rangers",note:""},
    "519": {player:"Didi Gregorius",team:"Phillies",note:""},
    "520": {player:"Justin Smoak",team:"Brewers",note:""},
    "521": {player:"Felix Hernandez",team:"Braves",note:""},
    "522": {player:"J.D. Davis",team:"Mets",note:""},
    "523": {player:"Corey Kluber",team:"Rangers",note:""},
    "524": {player:"Jurickson Profar",team:"Padres",note:""},
    "525": {player:"Jake Cave",team:"Twins",note:""},
    "526": {player:"Byron Buxton",team:"Twins",note:""},
    "527": {player:"Khris Davis",team:"Athletics",note:""},
    "528": {player:"Harold Ramirez",team:"Marlins",note:""},
    "529": {player:"Ender Inciarte",team:"Braves",note:""},
    "530": {player:"Xander Bogaerts",team:"Red Sox",note:""},
    "531": {player:"David Bednar",team:"Padres",note:"Rookie"},
    "532": {player:"Robbie Ray",team:"Diamondbacks",note:""},
    "533": {player:"Nick Castellanos",team:"Reds",note:""},
    "534": {player:"Michael Wacha",team:"Mets",note:""},
    "535": {player:"Avisail Garcia",team:"Brewers",note:""},
    "536": {player:"Elvis Luciano",team:"Blue Jays",note:""},
    "537": {player:"Marcell Ozuna",team:"Braves",note:""},
    "538": {player:"Walk-off Winner",team:"Braves",note:""},
    "539": {player:"Tyrone Taylor",team:"Brewers",note:"Rookie"},
    "540": {player:"Kean Wong",team:"Giants",note:"Rookie"},
    "541": {player:"Danny Mendick",team:"White Sox",note:"Rookie"},
    "542": {player:"Tom Murphy",team:"Mariners",note:""},
    "543": {player:"Harold Castro",team:"Tigers",note:""},
    "544": {player:"Wil Myers",team:"Padres",note:""},
    "545": {player:"Kevin Kiermaier",team:"Rays",note:""},
    "546": {player:"Ross Stripling",team:"Dodgers",note:""},
    "547": {player:"Victor Robles",team:"Nationals",note:"Rookie Cup"},
    "548": {player:"Brian O'Grady",team:"Rays",note:"Rookie"},
    "549": {player:"Freddie Freeman",team:"Braves",note:""},
    "550": {player:"John Means",team:"Orioles",note:"Rookie Cup"},
    "551": {player:"Clint Frazier",team:"Yankees",note:""},
    "552": {player:"Yu Darvish",team:"Cubs",note:""},
    "553": {player:"Salvador Perez",team:"Royals",note:""},
    "554": {player:"Mike Zunino",team:"Rays",note:""},
    "555": {player:"Marcus Stroman",team:"Mets",note:""},
    "556": {player:"Josh Naylor",team:"Padres",note:""},
    "557": {player:"Adam Ottavino",team:"Yankees",note:""},
    "558": {player:"Sean Manaea",team:"Athletics",note:""},
    "559": {player:"Josh Hader",team:"Brewers",note:""},
    "560": {player:"Chad Pinder",team:"Athletics",note:""},
    "561": {player:"Trevor Williams",team:"Pirates",note:""},
    "562": {player:"Gio Urshela",team:"Yankees",note:""},
    "563": {player:"Danny Jansen",team:"Blue Jays",note:""},
    "564": {player:"Matt Beaty",team:"Dodgers",note:""},
    "565": {player:"Jordan Luplow",team:"Indians",note:""},
    "566": {player:"Mariners",team:"Mariners",note:"Team Card"},
    "567": {player:"Yonathan Daza",team:"Rockies",note:"Rookie"},
    "568": {player:"Adam Eaton",team:"Nationals",note:""},
    "569": {player:"Role Reversal",team:"White Sox",note:""},
    "570": {player:"Manny Pina",team:"Brewers",note:""},
    "571": {player:"Keston Hiura",team:"Brewers",note:"Rookie Cup"},
    "572": {player:"Manuel Margot",team:"Rays",note:""},
    "573": {player:"Jason Heyward",team:"Cubs",note:""},
    "574": {player:"Brandon Lowe",team:"Rays",note:"Future Stars"},
    "575": {player:"Kyle Seager",team:"Mariners",note:""},
    "576": {player:"Sergio Romo",team:"Twins",note:""},
    "577": {player:"Elvis Andrus",team:"Rangers",note:""},
    "578": {player:"Chris Bassitt",team:"Athletics",note:""},
    "579": {player:"Kevin Kramer",team:"Pirates",note:""},
    "580": {player:"Dellin Betances",team:"Mets",note:""},
    "581": {player:"Michael Taylor",team:"Nationals",note:""},
    "582": {player:"Willie Calhoun",team:"Rangers",note:""},
    "583": {player:"Josh Staumont",team:"Royals",note:"Rookie"},
    "584": {player:"Michael Kopech",team:"White Sox",note:""},
    "585": {player:"Kyle Tucker",team:"Astros",note:"Future Stars"},
    "586": {player:"Stevie Wilkerson",team:"Orioles",note:""},
    "587": {player:"Lou Trivino",team:"Athletics",note:""},
    "588": {player:"Tommy Kahnle",team:"Yankees",note:""},
    "589": {player:"Eric Lauer",team:"Brewers",note:""},
    "590": {player:"Yu Chang",team:"Indians",note:"Rookie"},
    "591": {player:"South Side Swag",team:"Yankees",note:""},
    "592": {player:"Corey Dickerson",team:"Marlins",note:""},
    "593": {player:"Stephen Piscotty",team:"Athletics",note:""},
    "594": {player:"Pirates",team:"Pirates",note:"Team Card"},
    "595": {player:"Eduardo Escobar",team:"Diamondbacks",note:""},
    "596": {player:"Daniel Norris",team:"Tigers",note:""},
    "597": {player:"Jonathan Hernandez",team:"Rangers",note:"Rookie"},
    "598": {player:"Jacob Stallings",team:"Pirates",note:""},
    "599": {player:"Ryan McMahon",team:"Rockies",note:""},
    "600": {player:"Drew Steckenrider",team:"Marlins",note:""},
    "601": {player:"Tucker Barnhart",team:"Reds",note:""},
    "602": {player:"Jose Altuve",team:"Astros",note:""},
    "603": {player:"Dinelson Lamet",team:"Padres",note:""},
    "604": {player:"Derek Fisher",team:"Blue Jays",note:""},
    "605": {player:"Stephen Vogt",team:"Diamondbacks",note:""},
    "606": {player:"Martin Maldonado",team:"Astros",note:""},
    "607": {player:"Cal Quantrill",team:"Padres",note:""},
    "608": {player:"Sam Gaviglio",team:"Blue Jays",note:""},
    "609": {player:"Ronald Guzman",team:"Rangers",note:""},
    "610": {player:"Cole Hamels",team:"Braves",note:""},
    "611": {player:"Roll Out The Barrel",team:"Brewers",note:""},
    "612": {player:"Luis Arraez",team:"Twins",note:"Future Stars"},
    "613": {player:"Isiah Kiner-Falefa",team:"Rangers",note:""},
    "614": {player:"Brett Gardner",team:"Yankees",note:""},
    "615": {player:"Junior Fernandez",team:"Cardinals",note:"Rookie"},
    "616": {player:"Cam Gallagher",team:"Royals",note:""},
    "617": {player:"Bryan Reynolds",team:"Pirates",note:"Rookie Cup"},
    "618": {player:"Joey Wendle",team:"Rays",note:""},
    "619": {player:"Rick Porcello",team:"Mets",note:""},
    "620": {player:"Corey Seager",team:"Dodgers",note:""},
    "621": {player:"Dallas Keuchel",team:"White Sox",note:""},
    "622": {player:"Brett Phillips",team:"Royals",note:""},
    "623": {player:"Mike Ford",team:"Yankees",note:""},
    "624": {player:"Renato Nunez",team:"Orioles",note:""},
    "625": {player:"Tigers",team:"Tigers",note:"Team Card"},
    "626": {player:"Nate Lowe",team:"Rays",note:""},
    "627": {player:"Eric Hosmer",team:"Padres",note:""},
    "628": {player:"Julio Urias",team:"Dodgers",note:""},
    "629": {player:"Blue Jays",team:"Blue Jays",note:"Team Card"},
    "630": {player:"Francisco Mejia",team:"Padres",note:""},
    "631": {player:"Stephen Strasburg",team:"Nationals",note:""},
    "632": {player:"Austin Hays",team:"Orioles",note:""},
    "633": {player:"Lance Lynn",team:"Rangers",note:""},
    "634": {player:"Padres",team:"Padres",note:"Team Card"},
    "635": {player:"Sean Newcomb",team:"Braves",note:""},
    "636": {player:"Jake Bauers",team:"Indians",note:""},
    "637": {player:"Trevor Story",team:"Rockies",note:""},
    "638": {player:"Nomar Mazara",team:"White Sox",note:""},
    "639": {player:"Kolby Allard",team:"Rangers",note:""},
    "640": {player:"NY State of Mind",team:"Nationals",note:""},
    "641": {player:"A.J. Pollock",team:"Dodgers",note:""},
    "642": {player:"Ryan Borucki",team:"Blue Jays",note:""},
    "643": {player:"Wilson Ramos",team:"Mets",note:""},
    "644": {player:"Teoscar Hernandez",team:"Blue Jays",note:""},
    "645": {player:"Jeff Mathis",team:"Rangers",note:""},
    "646": {player:"Kevin Newman",team:"Pirates",note:"Future Stars"},
    "647": {player:"Joe Ross",team:"Nationals",note:""},
    "648": {player:"Mike Leake",team:"Diamondbacks",note:""},
    "649": {player:"Jed Lowrie",team:"Mets",note:""},
    "650": {player:"Kelvin Herrera",team:"White Sox",note:""},
    "651": {player:"Diamondbacks",team:"Diamondbacks",note:"Team Card"},
    "652": {player:"Pedro Severino",team:"Orioles",note:""},
    "653": {player:"Zach Plesac",team:"Indians",note:""},
    "654": {player:"Tim Lopes",team:"Mariners",note:"Rookie"},
    "655": {player:"Howie Kendrick",team:"Nationals",note:""},
    "656": {player:"Alex Cobb",team:"Orioles",note:""},
    "657": {player:"Rougned Odor",team:"Rangers",note:""},
    "658": {player:"Chad Wallach",team:"Marlins",note:"Rookie"},
    "659": {player:"Aledmys Diaz",team:"Astros",note:""},
    "660": {player:"Brandon Nimmo",team:"Mets",note:""},
    "661": {player:"Justin Dunn",team:"Mariners",note:"Rookie"},
    "662": {player:"Andrew Knapp",team:"Phillies",note:""},
    "663": {player:"White Sox",team:"White Sox",note:"Team Card"},
    "664": {player:"Yonny Chirinos",team:"Rays",note:""},
    "665": {player:"Willson Contreras",team:"Cubs",note:""},
    "666": {player:"Kyle Freeland",team:"Rockies",note:""},
    "667": {player:"Adam Haseley",team:"Phillies",note:""},
    "668": {player:"Royals",team:"Royals",note:"Team Card"},
    "669": {player:"Luis Severino",team:"Yankees",note:""},
    "670": {player:"Aaron Barrett",team:"Nationals",note:""},
    "671": {player:"Ryan McBroom",team:"Royals",note:"Rookie"},
    "672": {player:"Chris Sale",team:"Red Sox",note:""},
    "673": {player:"Anthony DeSclafani",team:"Reds",note:""},
    "674": {player:"Jose Abreu",team:"White Sox",note:""},
    "675": {player:"David Robertson",team:"Phillies",note:""},
    "676": {player:"Rangel Ravelo",team:"Cardinals",note:"Rookie"},
    "677": {player:"Ji-Man Choi",team:"Rays",note:""},
    "678": {player:"Jose Rodriguez",team:"Angels",note:"Rookie"},
    "679": {player:"Glenn Sparkman",team:"Royals",note:""},
    "680": {player:"Nick Ahmed",team:"Diamondbacks",note:""},
    "681": {player:"Edwin Rios",team:"Dodgers",note:"Rookie"},
    "682": {player:"Ronny Rodriguez",team:"Brewers",note:""},
    "683": {player:"Jakob Junis",team:"Royals",note:""},
    "684": {player:"Mike Minor",team:"Rangers",note:""},
    "685": {player:"Freddy Galvis",team:"Reds",note:""},
    "686": {player:"Josh Reddick",team:"Astros",note:""},
    "687": {player:"Rhys Hoskins",team:"Phillies",note:""},
    "688": {player:"Austin Romine",team:"Tigers",note:""},
    "689": {player:"James McCann",team:"White Sox",note:""},
    "690": {player:"Ehire Adrianza",team:"Twins",note:""},
    "691": {player:"Brock Burke",team:"Rangers",note:"Rookie"},
    "692": {player:"Jonathan Schoop",team:"Tigers",note:""},
    "693": {player:"Jon Berti",team:"Marlins",note:"Rookie"},
    "694": {player:"Orioles",team:"Orioles",note:"Team Card"},
    "695": {player:"Danny Santana",team:"Rangers",note:""},
    "696": {player:"Three's Company",team:"AL",note:""},
    "697": {player:"Eric Sogard",team:"Brewers",note:""},
    "698": {player:"Tyler Chatwood",team:"Cubs",note:""},
    "699": {player:"Sheldon Neuse",team:"Athletics",note:"Rookie"},
    "700": {player:"Adam Wainwright",team:"Cardinals",note:""}
  },
  "Update": {
    "U-1": {player:"Bo Bichette",team:"Blue Jays",note:"RC Debut"},
    "U-2": {player:"Adam Engel",team:"White Sox",note:""},
    "U-3": {player:"Turner/Difo",team:"Nationals",note:"Combo"},
    "U-4": {player:"Mike Trout",team:"Angels",note:"AS"},
    "U-5": {player:"Starlin Castro",team:"Nationals",note:""},
    "U-6": {player:"Mike Moustakas",team:"Reds",note:""},
    "U-7": {player:"Bregman/Alvarez",team:"Astros",note:"Combo"},
    "U-8": {player:"Buster Posey",team:"Giants",note:"AS"},
    "U-9": {player:"Ken Griffey Jr.",team:"Mariners",note:"HR Derby"},
    "U-10": {player:"Anthony Alford",team:"Blue Jays",note:""},
    "U-11": {player:"Chris Owings",team:"Rockies",note:""},
    "U-12": {player:"Aaron Bummer",team:"White Sox",note:""},
    "U-13": {player:"Jose Martinez",team:"Rays",note:""},
    "U-14": {player:"Giancarlo Stanton",team:"Marlins",note:"HR Derby"},
    "U-15": {player:"Aaron Judge",team:"Yankees",note:"AS"},
    "U-16": {player:"Phillip Diehl",team:"Rockies",note:"RC"},
    "U-17": {player:"Josh Fuentes",team:"Rockies",note:""},
    "U-18": {player:"Felix Pena",team:"Angels",note:""},
    "U-19": {player:"Yasmani Grandal",team:"White Sox",note:""},
    "U-20": {player:"Francisco Cervelli",team:"Marlins",note:""},
    "U-21": {player:"Kyle Lewis",team:"Mariners",note:"RC Debut"},
    "U-22": {player:"Cody Stashak",team:"Twins",note:"RC"},
    "U-23": {player:"Cheslor Cuthbert",team:"White Sox",note:""},
    "U-24": {player:"Buck Farmer",team:"Tigers",note:""},
    "U-25": {player:"Josh Taylor",team:"Red Sox",note:"RC"},
    "U-26": {player:"Kyle Gibson",team:"Rangers",note:""},
    "U-27": {player:"Kyle Ryan",team:"Cubs",note:""},
    "U-28": {player:"Eduardo Nunez",team:"Mets",note:""},
    "U-29": {player:"Aristides Aquino",team:"Reds",note:"RC Debut"},
    "U-30": {player:"Yasmany Tomas",team:"Diamondbacks",note:""},
    "U-31": {player:"Curt Casali",team:"Reds",note:""},
    "U-32": {player:"Drew Pomeranz",team:"Padres",note:""},
    "U-33": {player:"Alex Verdugo",team:"Red Sox",note:""},
    "U-34": {player:"Justin Verlander",team:"Astros",note:"Active Leaders"},
    "U-35": {player:"Kyle Farmer",team:"Reds",note:""},
    "U-36": {player:"Robinson Cano",team:"Yankees",note:"HR Derby"},
    "U-37": {player:"Yoenis Cespedes",team:"Athletics",note:"HR Derby"},
    "U-38": {player:"Albert Pujols",team:"Angels",note:"Active Leaders"},
    "U-39": {player:"Kevin Plawecki",team:"Red Sox",note:""},
    "U-40": {player:"Antonio Senzatela",team:"Rockies",note:""},
    "U-41": {player:"Josh Lindblom",team:"Brewers",note:""},
    "U-42": {player:"Kris Bryant",team:"Cubs",note:"AS"},
    "U-43": {player:"Alex Blandino",team:"Reds",note:""},
    "U-44": {player:"Jorge Alcala",team:"Twins",note:"RC"},
    "U-45": {player:"Zack Wheeler",team:"Phillies",note:""},
    "U-46": {player:"Jose Suarez",team:"Angels",note:""},
    "U-47": {player:"Jose Peraza",team:"Red Sox",note:""},
    "U-48": {player:"Sandy Leon",team:"Indians",note:""},
    "U-49": {player:"Jared Walsh",team:"Angels",note:""},
    "U-50": {player:"Nolan Arenado",team:"Rockies",note:"AS"},
    "U-51": {player:"Matt Davidson",team:"Reds",note:""},
    "U-52": {player:"Kyle Higashioka",team:"Yankees",note:""},
    "U-53": {player:"Brad Miller",team:"Cardinals",note:""},
    "U-54": {player:"Alex Avila",team:"Twins",note:""},
    "U-55": {player:"Miguel Cabrera",team:"Tigers",note:"AS"},
    "U-56": {player:"Lane Thomas",team:"Cardinals",note:""},
    "U-57": {player:"Yoan Lopez",team:"Diamondbacks",note:""},
    "U-58": {player:"Erick Mejia",team:"Royals",note:"RC"},
    "U-59": {player:"Ryan Howard",team:"Phillies",note:"HR Derby"},
    "U-60": {player:"Brendan McKay",team:"Rays",note:"RC Debut"},
    "U-61": {player:"Jedd Gyorko",team:"Brewers",note:""},
    "U-62": {player:"David Ortiz",team:"Red Sox",note:"HR Derby"},
    "U-63": {player:"Terrance Gore",team:"Dodgers",note:""},
    "U-64": {player:"Alex Bregman",team:"Astros",note:"AS"},
    "U-65": {player:"Yoshi Tsutsugo",team:"Rays",note:"RC"},
    "U-66": {player:"Max Scherzer",team:"Nationals",note:"Active Leaders"},
    "U-67": {player:"Michael Fulmer",team:"Tigers",note:""},
    "U-68": {player:"Greg Garcia",team:"Padres",note:""},
    "U-69": {player:"Derek Holland",team:"Pirates",note:""},
    "U-70": {player:"Skye Bolt",team:"Athletics",note:""},
    "U-71": {player:"Jesus Aguilar",team:"Marlins",note:""},
    "U-72": {player:"Drew Butera",team:"Rockies",note:""},
    "U-73": {player:"Todd Frazier",team:"Rangers",note:""},
    "U-74": {player:"Harper/Segura",team:"Phillies",note:"Combo"},
    "U-75": {player:"Pedro Martinez",team:"Red Sox",note:"AS"},
    "U-76": {player:"Edwin Encarnacion",team:"White Sox",note:"Active Leaders"},
    "U-77": {player:"Jalen Beeks",team:"Rays",note:""},
    "U-78": {player:"Joe Jimenez",team:"Tigers",note:""},
    "U-79": {player:"Sean Poppen",team:"Twins",note:"RC"},
    "U-80": {player:"Cody Bellinger",team:"Dodgers",note:"AS"},
    "U-81": {player:"Junior Guerra",team:"Diamondbacks",note:""},
    "U-82": {player:"Kenley Jansen",team:"Dodgers",note:"Active Leaders"},
    "U-83": {player:"Trent Grisham",team:"Padres",note:"RC"},
    "U-84": {player:"Yusmeiro Petit",team:"Athletics",note:""},
    "U-85": {player:"Felix Hernandez",team:"Mariners",note:"AS"},
    "U-86": {player:"Josh Harrison",team:"Phillies",note:""},
    "U-87": {player:"Zack Greinke",team:"Astros",note:"Active Leaders"},
    "U-88": {player:"Craig Kimbrel",team:"Cubs",note:"Active Leaders"},
    "U-89": {player:"Brian Johnson",team:"Red Sox",note:""},
    "U-90": {player:"Clayton Kershaw",team:"Dodgers",note:"Active Leaders"},
    "U-91": {player:"Julio Teheran",team:"Angels",note:""},
    "U-92": {player:"Jacob deGrom",team:"Mets",note:"Active Leaders"},
    "U-93": {player:"Tyler White",team:"Dodgers",note:""},
    "U-94": {player:"Jesus Luzardo",team:"Athletics",note:"RC Debut"},
    "U-95": {player:"Domingo Santana",team:"Indians",note:""},
    "U-96": {player:"Logan Morrison",team:"Brewers",note:""},
    "U-97": {player:"Donovan Solano",team:"Giants",note:""},
    "U-98": {player:"Jose Iglesias",team:"Orioles",note:""},
    "U-99": {player:"Cesar Hernandez",team:"Indians",note:""},
    "U-100": {player:"David Price",team:"Dodgers",note:""},
    "U-101": {player:"Nick Dini",team:"Royals",note:"RC"},
    "U-102": {player:"Kevin Ginkel",team:"Diamondbacks",note:"RC"},
    "U-103": {player:"Michael Hermosillo",team:"Angels",note:""},
    "U-104": {player:"Grayson Greiner",team:"Tigers",note:""},
    "U-105": {player:"Jake Newberry",team:"Royals",note:"RC"},
    "U-106": {player:"Meibrys Viloria",team:"Royals",note:""},
    "U-107": {player:"Eric Thames",team:"Nationals",note:""},
    "U-108": {player:"Taylor Ward",team:"Angels",note:""},
    "U-109": {player:"Pedro Strop",team:"Reds",note:""},
    "U-110": {player:"Mark McGwire",team:"Cardinals",note:"HR Derby"},
    "U-111": {player:"Rich Hill",team:"Twins",note:""},
    "U-112": {player:"Nik Turley",team:"Pirates",note:"RC"},
    "U-113": {player:"Devin Williams",team:"Brewers",note:"RC"},
    "U-114": {player:"Josh Phegley",team:"Cubs",note:""},
    "U-115": {player:"Brad Peacock",team:"Astros",note:""},
    "U-116": {player:"Robinson Chirinos",team:"Rangers",note:""},
    "U-117": {player:"Cameron Maybin",team:"Tigers",note:""},
    "U-118": {player:"Frank Schwindel",team:"Tigers",note:"RC"},
    "U-119": {player:"Mike Trout",team:"Angels",note:"Active Leaders"},
    "U-120": {player:"Stevie Wilkerson",team:"Orioles",note:""},
    "U-121": {player:"Ichiro",team:"Mariners",note:"AS"},
    "U-122": {player:"Tino Martinez",team:"Yankees",note:"HR Derby"},
    "U-123": {player:"Neil Walker",team:"Phillies",note:""},
    "U-124": {player:"David Ortiz",team:"Red Sox",note:"AS"},
    "U-125": {player:"Chris Martin",team:"Braves",note:""},
    "U-126": {player:"Jhoulys Chacin",team:"Twins",note:""},
    "U-127": {player:"Ryan Weber",team:"Red Sox",note:""},
    "U-128": {player:"Jonathan Davis",team:"Blue Jays",note:""},
    "U-129": {player:"Hunter Pence",team:"Giants",note:""},
    "U-130": {player:"Richie Martin",team:"Orioles",note:""},
    "U-131": {player:"Alex Reyes",team:"Cardinals",note:""},
    "U-132": {player:"Daniel Descalso",team:"Cubs",note:""},
    "U-133": {player:"Chris Iannetta",team:"Yankees",note:""},
    "U-134": {player:"Gleyber Torres",team:"Yankees",note:"AS"},
    "U-135": {player:"Brandon Dixon",team:"Tigers",note:""},
    "U-136": {player:"David McKay",team:"Tigers",note:""},
    "U-137": {player:"Touki Toussaint",team:"Braves",note:""},
    "U-138": {player:"Tommy Pham",team:"Padres",note:""},
    "U-139": {player:"Greg Allen",team:"Indians",note:""},
    "U-140": {player:"Clayton Kershaw",team:"Dodgers",note:"Active Leaders"},
    "U-141": {player:"Jonathan Villar",team:"Marlins",note:""},
    "U-142": {player:"Albert Pujols",team:"Angels",note:"Active Leaders"},
    "U-143": {player:"Francisco Lindor",team:"Indians",note:"AS"},
    "U-144": {player:"Betts/Torres",team:"AL",note:"Combo"},
    "U-145": {player:"Ronald Acuna Jr.",team:"Braves",note:"AS"},
    "U-146": {player:"Andrew Knizner",team:"Cardinals",note:""},
    "U-147": {player:"Robinson Cano",team:"Mets",note:"Active Leaders"},
    "U-148": {player:"Pete Alonso",team:"Mets",note:"HR Derby"},
    "U-149": {player:"Nick Solak",team:"Rangers",note:"RC Debut"},
    "U-150": {player:"Ken Griffey Jr.",team:"Mariners",note:"HR Derby"},
    "U-151": {player:"Jairo Diaz",team:"Rockies",note:""},
    "U-152": {player:"Sam Haggerty",team:"Mariners",note:"RC"},
    "U-153": {player:"Robert Stephenson",team:"Reds",note:""},
    "U-154": {player:"Mariano Rivera",team:"Yankees",note:"AS"},
    "U-155": {player:"Zach Davies",team:"Padres",note:""},
    "U-156": {player:"Wilmer Flores",team:"Giants",note:""},
    "U-157": {player:"Deivy Grullon",team:"Phillies",note:"RC"},
    "U-158": {player:"Jason Kipnis",team:"Cubs",note:""},
    "U-159": {player:"Steven Souza Jr.",team:"Cubs",note:""},
    "U-160": {player:"Richard Bleier",team:"Orioles",note:""},
    "U-161": {player:"Jake Marisnick",team:"Mets",note:""},
    "U-162": {player:"Giovanny Gallegos",team:"Cardinals",note:""},
    "U-163": {player:"JT Riddle",team:"Pirates",note:""},
    "U-164": {player:"Sam Travis",team:"Rangers",note:""},
    "U-165": {player:"Kyle Wright",team:"Braves",note:""},
    "U-166": {player:"Adolis Garcia",team:"Rangers",note:""},
    "U-167": {player:"Yoshi Hirano",team:"Mariners",note:""},
    "U-168": {player:"Keynan Middleton",team:"Angels",note:""},
    "U-169": {player:"Yadier Molina",team:"Cardinals",note:"AS"},
    "U-170": {player:"Travis Shaw",team:"Blue Jays",note:""},
    "U-171": {player:"Bryse Wilson",team:"Braves",note:""},
    "U-172": {player:"Tyler Wade",team:"Yankees",note:""},
    "U-173": {player:"Edwin Encarnacion",team:"White Sox",note:""},
    "U-174": {player:"Logan Forsythe",team:"Phillies",note:""},
    "U-175": {player:"Diego Castillo",team:"Rays",note:""},
    "U-176": {player:"Brock Holt",team:"Brewers",note:""},
    "U-177": {player:"Andy Burns",team:"Blue Jays",note:"RC"},
    "U-178": {player:"Jarrod Dyson",team:"Pirates",note:""},
    "U-179": {player:"Jeff Hoffman",team:"Rockies",note:""},
    "U-180": {player:"C.J. Cron",team:"Tigers",note:""},
    "U-181": {player:"Mitch Moreland",team:"Red Sox",note:""},
    "U-182": {player:"Josh Tomlin",team:"Braves",note:""},
    "U-183": {player:"Steve Cishek",team:"White Sox",note:""},
    "U-184": {player:"Miguel Cabrera",team:"Tigers",note:"Active Leaders"},
    "U-185": {player:"Max Scherzer",team:"Nationals",note:"AS"},
    "U-186": {player:"Rowdy Tellez",team:"Blue Jays",note:""},
    "U-187": {player:"Pete Alonso",team:"Mets",note:"AS"},
    "U-188": {player:"Luis Severino",team:"Yankees",note:""},
    "U-189": {player:"Johnny Davis",team:"Rays",note:"RC"},
    "U-190": {player:"Ken Griffey Jr.",team:"Mariners",note:"AS"},
    "U-191": {player:"Zack Greinke",team:"Astros",note:"Active Leaders"},
    "U-192": {player:"Ian Miller",team:"Cubs",note:"RC"},
    "U-193": {player:"Miguel Cabrera",team:"Tigers",note:"Active Leaders"},
    "U-194": {player:"Justin Verlander",team:"Astros",note:"AS"},
    "U-195": {player:"Daniel Hudson",team:"Nationals",note:""},
    "U-196": {player:"Nestor Cortes",team:"Mariners",note:"RC"},
    "U-197": {player:"Zach Green",team:"Giants",note:"RC"},
    "U-198": {player:"Hunter Renfroe",team:"Rays",note:""},
    "U-199": {player:"Adeiny Hechavarria",team:"Braves",note:""},
    "U-200": {player:"Anthony Rendon",team:"Angels",note:""},
    "U-201": {player:"Anthony Rizzo",team:"Cubs",note:"AS"},
    "U-202": {player:"Asdrubal Cabrera",team:"Nationals",note:""},
    "U-203": {player:"Austin Pruitt",team:"Astros",note:""},
    "U-204": {player:"Eric Davis",team:"Reds",note:"HR Derby"},
    "U-205": {player:"Kenta Maeda",team:"Twins",note:""},
    "U-206": {player:"Asher Wojciechowski",team:"Orioles",note:""},
    "U-207": {player:"Jorge Lopez",team:"Royals",note:""},
    "U-208": {player:"Randy Arozarena",team:"Rays",note:"RC"},
    "U-209": {player:"Cal Ripken Jr.",team:"Orioles",note:"AS"},
    "U-210": {player:"Gabe Speier",team:"Royals",note:"RC"},
    "U-211": {player:"Drew Smyly",team:"Giants",note:""},
    "U-212": {player:"Jordan Lyles",team:"Rangers",note:""},
    "U-213": {player:"Keury Mella",team:"Diamondbacks",note:""},
    "U-214": {player:"Kendall Graveman",team:"Mariners",note:""},
    "U-215": {player:"Joey Votto",team:"Reds",note:"Active Leaders"},
    "U-216": {player:"Sean Murphy",team:"Athletics",note:"RC Debut"},
    "U-217": {player:"Andrew Suarez",team:"Giants",note:""},
    "U-218": {player:"Chapman/Olson",team:"Athletics",note:"Combo"},
    "U-219": {player:"Zack Greinke",team:"Astros",note:"Active Leaders"},
    "U-220": {player:"Alec Mills",team:"Cubs",note:""},
    "U-221": {player:"Joe Panik",team:"Blue Jays",note:""},
    "U-222": {player:"Scott Barlow",team:"Royals",note:""},
    "U-223": {player:"Chris Devenski",team:"Astros",note:""},
    "U-224": {player:"Cy Sneed",team:"Astros",note:"RC"},
    "U-225": {player:"Jharel Cotton",team:"Cubs",note:""},
    "U-226": {player:"Franchy Cordero",team:"Padres",note:""},
    "U-227": {player:"Garrett Richards",team:"Padres",note:""},
    "U-228": {player:"Starling Marte",team:"Diamondbacks",note:""},
    "U-229": {player:"Giancarlo Stanton",team:"Marlins",note:"AS"},
    "U-230": {player:"Cal Ripken Jr.",team:"Orioles",note:"HR Derby"},
    "U-231": {player:"Jordy Mercer",team:"Tigers",note:""},
    "U-232": {player:"Jason Castro",team:"Angels",note:""},
    "U-233": {player:"Mike Montgomery",team:"Royals",note:""},
    "U-234": {player:"Gavin Lux",team:"Dodgers",note:"RC Debut"},
    "U-235": {player:"Javier Baez",team:"Cubs",note:"AS"},
    "U-236": {player:"Bartolo Colon",team:"Mets",note:"Active Leaders"},
    "U-237": {player:"Clayton Kershaw",team:"Dodgers",note:"AS"},
    "U-238": {player:"Tim Locastro",team:"Diamondbacks",note:""},
    "U-239": {player:"Jefry Rodriguez",team:"Indians",note:""},
    "U-240": {player:"Justin Verlander",team:"Astros",note:"Active Leaders"},
    "U-241": {player:"Tyler Heineman",team:"Giants",note:"RC"},
    "U-242": {player:"Ty France",team:"Padres",note:""},
    "U-243": {player:"Mike Trout",team:"Angels",note:"Active Leaders"},
    "U-244": {player:"Wade LeBlanc",team:"Orioles",note:""},
    "U-245": {player:"Justin Verlander",team:"Astros",note:"Active Leaders"},
    "U-246": {player:"Greg Holland",team:"Royals",note:""},
    "U-247": {player:"Kole Calhoun",team:"Diamondbacks",note:""},
    "U-248": {player:"Miguel Cabrera",team:"Tigers",note:"Active Leaders"},
    "U-249": {player:"Aroldis Chapman",team:"Yankees",note:"Active Leaders"},
    "U-250": {player:"Omar Narvaez",team:"Brewers",note:""},
    "U-251": {player:"Nico Hoerner",team:"Cubs",note:"RC Debut"},
    "U-252": {player:"Alex Wood",team:"Dodgers",note:""},
    "U-253": {player:"Peter Lambert",team:"Rockies",note:""},
    "U-254": {player:"Taijuan Walker",team:"Mariners",note:""},
    "U-255": {player:"Bryce Harper",team:"Nationals",note:"HR Derby"},
    "U-256": {player:"Ramirez/Lindor",team:"Indians",note:"Combo"},
    "U-257": {player:"Derek Jeter",team:"Yankees",note:"AS"},
    "U-258": {player:"Todd Frazier",team:"Reds",note:"HR Derby"},
    "U-259": {player:"Albert Pujols",team:"Angels",note:"Active Leaders"},
    "U-260": {player:"Kyle Crick",team:"Pirates",note:""},
    "U-261": {player:"Trout/Upton",team:"Angels",note:"Combo"},
    "U-262": {player:"Ty Buttrey",team:"Angels",note:""},
    "U-263": {player:"Miguel Cabrera",team:"Tigers",note:"Active Leaders"},
    "U-264": {player:"Aaron Judge",team:"Yankees",note:"HR Derby"},
    "U-265": {player:"Dario Agrazal",team:"Tigers",note:"RC"},
    "U-266": {player:"Andrew McCutchen",team:"Pirates",note:"AS"},
    "U-267": {player:"Albert Pujols",team:"Cardinals",note:"AS"},
    "U-268": {player:"Mookie Betts",team:"Red Sox",note:"AS"},
    "U-269": {player:"Christian Yelich",team:"Brewers",note:"AS"},
    "U-270": {player:"Dustin Garneau",team:"Astros",note:""},
    "U-271": {player:"Kevin Pillar",team:"Red Sox",note:""},
    "U-272": {player:"Joey Votto",team:"Reds",note:"AS"},
    "U-273": {player:"Devers/Bogaerts",team:"Red Sox",note:"Combo"},
    "U-274": {player:"Jordan Montgomery",team:"Yankees",note:""},
    "U-275": {player:"Brett Anderson",team:"Brewers",note:""},
    "U-276": {player:"Joe Kelly",team:"Dodgers",note:""},
    "U-277": {player:"Jose Altuve",team:"Astros",note:"AS"},
    "U-278": {player:"Austin Allen",team:"Athletics",note:""},
    "U-279": {player:"Bryce Harper",team:"Nationals",note:"AS"},
    "U-280": {player:"Albert Pujols",team:"Angels",note:"Active Leaders"},
    "U-281": {player:"Joel Kuhnel",team:"Reds",note:"RC"},
    "U-282": {player:"Christian Arroyo",team:"Indians",note:""},
    "U-283": {player:"Tomas Nido",team:"Mets",note:""},
    "U-284": {player:"Buehler/Martin",team:"Dodgers",note:"Combo"},
    "U-285": {player:"Billy Hamilton",team:"Giants",note:""},
    "U-286": {player:"Chase Anderson",team:"Blue Jays",note:""},
    "U-287": {player:"Chris Sale",team:"Red Sox",note:"AS"},
    "U-288": {player:"Giancarlo Stanton",team:"Yankees",note:"Active Leaders"},
    "U-289": {player:"Myles Straw",team:"Astros",note:""},
    "U-290": {player:"Alonso/McNeil",team:"Mets",note:"Combo"},
    "U-291": {player:"Trayce Thompson",team:"Diamondbacks",note:""},
    "U-292": {player:"Mike Trout",team:"Angels",note:"Active Leaders"},
    "U-293": {player:"Mike King",team:"Yankees",note:"RC"},
    "U-294": {player:"Adam Plutko",team:"Indians",note:""},
    "U-295": {player:"Chris Sale",team:"Red Sox",note:"Active Leaders"},
    "U-296": {player:"Mark McGwire",team:"Athletics",note:"HR Derby"},
    "U-297": {player:"Jesus Tinoco",team:"Rockies",note:"RC"},
    "U-298": {player:"Magneuris Sierra",team:"Marlins",note:""},
    "U-299": {player:"Jacob deGrom",team:"Mets",note:"AS"},
    "U-300": {player:"Yordan Alvarez",team:"Astros",note:"RC Debut"}
  },
  "Chrome": {
    "1": {player:"Mike Trout",team:"Angels",note:""},
    "2": {player:"Liam Hendriks",team:"Athletics",note:""},
    "3": {player:"Bobby Bradley",team:"Indians",note:"Rookie"},
    "4": {player:"Rogelio Armenteros",team:"Astros",note:"Rookie"},
    "5": {player:"Jesus Luzardo",team:"Athletics",note:"Rookie"},
    "6": {player:"Miguel Cabrera",team:"Tigers",note:""},
    "7": {player:"Trea Turner",team:"Nationals",note:""},
    "8": {player:"Brendan McKay",team:"Rays",note:"Rookie"},
    "9": {player:"Joey Votto",team:"Reds",note:""},
    "10": {player:"Domingo Leyba",team:"Diamondbacks",note:"Rookie"},
    "11": {player:"Austin Nola",team:"Mariners",note:"Rookie"},
    "12": {player:"Juan Soto",team:"Nationals",note:""},
    "13": {player:"Max Muncy",team:"Dodgers",note:""},
    "14": {player:"Archie Bradley",team:"Diamondbacks",note:""},
    "15": {player:"David Peralta",team:"Diamondbacks",note:""},
    "16": {player:"Luis Castillo",team:"Reds",note:""},
    "17": {player:"Bryan Reynolds",team:"Pirates",note:""},
    "18": {player:"Michael Fulmer",team:"Tigers",note:""},
    "19": {player:"Jeimer Candelario",team:"Tigers",note:""},
    "20": {player:"Jorge Soler",team:"Royals",note:""},
    "21": {player:"Shohei Ohtani",team:"Angels",note:""},
    "22": {player:"Cavan Biggio",team:"Blue Jays",note:""},
    "23": {player:"Seth Brown",team:"Athletics",note:"Rookie"},
    "24": {player:"Nick Senzel",team:"Reds",note:""},
    "25": {player:"Keston Hiura",team:"Brewers",note:""},
    "26": {player:"Travis Demeritte",team:"Tigers",note:"Rookie"},
    "27": {player:"Christian Walker",team:"Diamondbacks",note:""},
    "28": {player:"Andrew Heaney",team:"Angels",note:""},
    "29": {player:"Carlos Correa",team:"Astros",note:""},
    "30": {player:"Dan Vogelbach",team:"Mariners",note:""},
    "31": {player:"Adalberto Mondesi",team:"Royals",note:""},
    "32": {player:"Sean Murphy",team:"Athletics",note:"Rookie"},
    "33": {player:"Nick Solak",team:"Rangers",note:"Rookie"},
    "34": {player:"Gio Urshela",team:"Yankees",note:""},
    "35": {player:"Michael Conforto",team:"Mets",note:""},
    "36": {player:"Ian Desmond",team:"Rockies",note:""},
    "37": {player:"Mitch Haniger",team:"Mariners",note:""},
    "38": {player:"Jean Segura",team:"Phillies",note:""},
    "39": {player:"Chris Paddack",team:"Padres",note:""},
    "40": {player:"Josh Hader",team:"Brewers",note:""},
    "41": {player:"Corey Kluber",team:"Rangers",note:""},
    "42": {player:"Jose Altuve",team:"Astros",note:""},
    "43": {player:"Dylan Cease",team:"White Sox",note:"Rookie"},
    "44": {player:"German Marquez",team:"Rockies",note:""},
    "45": {player:"Gleyber Torres",team:"Yankees",note:""},
    "46": {player:"Lucas Giolito",team:"White Sox",note:""},
    "47": {player:"Jake Rogers",team:"Tigers",note:"Rookie"},
    "48": {player:"Yusei Kikuchi",team:"Mariners",note:""},
    "49": {player:"Randy Arozarena",team:"Cardinals",note:"Rookie"},
    "50": {player:"Aaron Judge",team:"Yankees",note:""},
    "51": {player:"Danny Jansen",team:"Blue Jays",note:""},
    "52": {player:"Kyle Seager",team:"Mariners",note:""},
    "53": {player:"Kris Bryant",team:"Cubs",note:""},
    "54": {player:"Chris Archer",team:"Pirates",note:""},
    "55": {player:"DJ LeMahieu",team:"Yankees",note:""},
    "56": {player:"Abraham Toro",team:"Astros",note:"Rookie"},
    "57": {player:"Andrew Benintendi",team:"Red Sox",note:""},
    "58": {player:"Noah Syndergaard",team:"Mets",note:""},
    "59": {player:"Trevor Story",team:"Rockies",note:""},
    "60": {player:"Luis Robert",team:"White Sox",note:"Rookie"},
    "61": {player:"Sheldon Neuse",team:"Athletics",note:"Rookie"},
    "62": {player:"Ozzie Albies",team:"Braves",note:""},
    "63": {player:"Hunter Dozier",team:"Royals",note:""},
    "64": {player:"Scott Kingery",team:"Phillies",note:""},
    "65": {player:"Dansby Swanson",team:"Braves",note:""},
    "66": {player:"Jose Abreu",team:"White Sox",note:""},
    "67": {player:"Sam Hilliard",team:"Rockies",note:"Rookie"},
    "68": {player:"Blake Snell",team:"Rays",note:""},
    "69": {player:"Nelson Cruz",team:"Twins",note:""},
    "70": {player:"Jeff McNeil",team:"Mets",note:""},
    "71": {player:"Anthony Rizzo",team:"Cubs",note:""},
    "72": {player:"Andrelton Simmons",team:"Angels",note:""},
    "73": {player:"Charlie Blackmon",team:"Rockies",note:""},
    "74": {player:"Matthew Boyd",team:"Tigers",note:""},
    "75": {player:"Jonathan Villar",team:"Marlins",note:""},
    "76": {player:"Manny Machado",team:"Padres",note:""},
    "77": {player:"Cody Bellinger",team:"Dodgers",note:""},
    "78": {player:"Eddie Rosario",team:"Twins",note:""},
    "79": {player:"Hanser Alberto",team:"Orioles",note:""},
    "80": {player:"Pete Alonso",team:"Mets",note:""},
    "81": {player:"Jacob deGrom",team:"Mets",note:""},
    "82": {player:"Jordan Yamamoto",team:"Marlins",note:"Rookie"},
    "83": {player:"Matt Thaiss",team:"Angels",note:"Rookie"},
    "84": {player:"Fernando Tatis Jr.",team:"Padres",note:""},
    "85": {player:"Kyle Schwarber",team:"Cubs",note:""},
    "86": {player:"Adrian Morejon",team:"Padres",note:"Rookie"},
    "87": {player:"Zack Collins",team:"White Sox",note:"Rookie"},
    "88": {player:"Brandon Crawford",team:"Giants",note:""},
    "89": {player:"Paul Goldschmidt",team:"Cardinals",note:""},
    "90": {player:"Tim Anderson",team:"White Sox",note:""},
    "91": {player:"Brusdar Graterol",team:"Dodgers",note:"Rookie"},
    "92": {player:"Nicky Lopez",team:"Royals",note:""},
    "93": {player:"Rafael Devers",team:"Red Sox",note:""},
    "94": {player:"Tommy Edman",team:"Cardinals",note:""},
    "95": {player:"Edwin Rios",team:"Dodgers",note:"Rookie"},
    "96": {player:"Mike Soroka",team:"Braves",note:""},
    "97": {player:"Bryce Harper",team:"Phillies",note:""},
    "98": {player:"Kevin Newman",team:"Pirates",note:""},
    "99": {player:"Colin Moran",team:"Pirates",note:""},
    "100": {player:"Mookie Betts",team:"Dodgers",note:""},
    "101": {player:"Trent Grisham",team:"Padres",note:"Rookie"},
    "102": {player:"Alex Bregman",team:"Astros",note:""},
    "103": {player:"Mike Yastrzemski",team:"Giants",note:""},
    "104": {player:"Walker Buehler",team:"Dodgers",note:""},
    "105": {player:"Miguel Rojas",team:"Marlins",note:""},
    "106": {player:"Harold Ramirez",team:"Marlins",note:""},
    "107": {player:"Dee Gordon",team:"Mariners",note:""},
    "108": {player:"Eric Hosmer",team:"Padres",note:""},
    "109": {player:"Nomar Mazara",team:"White Sox",note:""},
    "110": {player:"Adbert Alzolay",team:"Cubs",note:"Rookie"},
    "111": {player:"Aristides Aquino",team:"Reds",note:"Rookie"},
    "112": {player:"Ronald Acuna Jr.",team:"Braves",note:""},
    "113": {player:"Austin Meadows",team:"Rays",note:""},
    "114": {player:"Tony Gonsolin",team:"Dodgers",note:"Rookie"},
    "115": {player:"Alex Young",team:"Diamondbacks",note:"Rookie"},
    "116": {player:"A.J. Puk",team:"Athletics",note:"Rookie"},
    "117": {player:"Logan Webb",team:"Giants",note:"Rookie"},
    "118": {player:"Tyler Glasnow",team:"Rays",note:""},
    "119": {player:"Brandon Lowe",team:"Rays",note:""},
    "120": {player:"Anthony Kay",team:"Blue Jays",note:"Rookie"},
    "121": {player:"John Means",team:"Orioles",note:""},
    "122": {player:"Clayton Kershaw",team:"Dodgers",note:""},
    "123": {player:"Jon Lester",team:"Cubs",note:""},
    "124": {player:"Max Kepler",team:"Twins",note:""},
    "125": {player:"Jose Berrios",team:"Twins",note:""},
    "126": {player:"Victor Reyes",team:"Tigers",note:""},
    "127": {player:"Albert Pujols",team:"Angels",note:""},
    "128": {player:"Eugenio Suarez",team:"Reds",note:""},
    "129": {player:"Ronald Guzman",team:"Rangers",note:""},
    "130": {player:"Anthony Santander",team:"Orioles",note:""},
    "131": {player:"Freddie Freeman",team:"Braves",note:""},
    "132": {player:"Zac Gallen",team:"Diamondbacks",note:"Rookie"},
    "133": {player:"Vladimir Guerrero Jr.",team:"Blue Jays",note:""},
    "134": {player:"Eloy Jimenez",team:"White Sox",note:""},
    "135": {player:"Jack Flaherty",team:"Cardinals",note:""},
    "136": {player:"Justin Dunn",team:"Mariners",note:"Rookie"},
    "137": {player:"Xander Bogaerts",team:"Red Sox",note:""},
    "138": {player:"Christian Yelich",team:"Brewers",note:""},
    "139": {player:"Max Scherzer",team:"Nationals",note:""},
    "140": {player:"Orlando Arcia",team:"Brewers",note:""},
    "141": {player:"Rowdy Tellez",team:"Blue Jays",note:""},
    "142": {player:"Jose Urquidy",team:"Astros",note:"Rookie"},
    "143": {player:"Aaron Civale",team:"Indians",note:"Rookie"},
    "144": {player:"Marcus Semien",team:"Athletics",note:""},
    "145": {player:"Yoan Moncada",team:"White Sox",note:""},
    "146": {player:"Brian Anderson",team:"Marlins",note:""},
    "147": {player:"Brandon Belt",team:"Giants",note:""},
    "148": {player:"Gavin Lux",team:"Dodgers",note:"Rookie"},
    "149": {player:"Andres Munoz",team:"Padres",note:"Rookie"},
    "150": {player:"Bo Bichette",team:"Blue Jays",note:"Rookie"},
    "151": {player:"Ketel Marte",team:"Diamondbacks",note:""},
    "152": {player:"Pablo Lopez",team:"Marlins",note:""},
    "153": {player:"Lorenzo Cain",team:"Brewers",note:""},
    "154": {player:"Whit Merrifield",team:"Royals",note:""},
    "155": {player:"Logan Allen",team:"Indians",note:"Rookie"},
    "156": {player:"Francisco Lindor",team:"Indians",note:""},
    "157": {player:"Buster Posey",team:"Giants",note:""},
    "158": {player:"Elvis Andrus",team:"Rangers",note:""},
    "159": {player:"Brock Burke",team:"Rangers",note:"Rookie"},
    "160": {player:"Ramon Laureano",team:"Athletics",note:""},
    "161": {player:"Nico Hoerner",team:"Cubs",note:"Rookie"},
    "162": {player:"Junior Fernandez",team:"Cardinals",note:"Rookie"},
    "163": {player:"Trevor Williams",team:"Pirates",note:""},
    "164": {player:"Justin Verlander",team:"Astros",note:""},
    "165": {player:"Carlos Santana",team:"Indians",note:""},
    "166": {player:"Masahiro Tanaka",team:"Yankees",note:""},
    "167": {player:"Lourdes Gurriel Jr.",team:"Blue Jays",note:""},
    "168": {player:"Mauricio Dubon",team:"Giants",note:"Rookie"},
    "169": {player:"Luis Urias",team:"Brewers",note:""},
    "170": {player:"Isan Diaz",team:"Marlins",note:"Rookie"},
    "171": {player:"Carter Kieboom",team:"Nationals",note:""},
    "172": {player:"Luis Arraez",team:"Twins",note:""},
    "173": {player:"Yu Chang",team:"Indians",note:"Rookie"},
    "174": {player:"Nolan Arenado",team:"Rockies",note:""},
    "175": {player:"Raisel Iglesias",team:"Reds",note:""},
    "176": {player:"Dustin May",team:"Dodgers",note:"Rookie"},
    "177": {player:"Shin-Soo Choo",team:"Rangers",note:""},
    "178": {player:"Paul DeJong",team:"Cardinals",note:""},
    "179": {player:"Willy Adames",team:"Rays",note:""},
    "180": {player:"Miles Mikolas",team:"Cardinals",note:""},
    "181": {player:"Robel Garcia",team:"Cubs",note:"Rookie"},
    "182": {player:"Oscar Mercado",team:"Indians",note:""},
    "183": {player:"Matt Olson",team:"Athletics",note:""},
    "184": {player:"Rhys Hoskins",team:"Phillies",note:""},
    "185": {player:"Jose Urena",team:"Marlins",note:""},
    "186": {player:"Kyle Lewis",team:"Mariners",note:"Rookie"},
    "187": {player:"Michel Baez",team:"Padres",note:"Rookie"},
    "188": {player:"Trey Mancini",team:"Orioles",note:""},
    "189": {player:"J.D. Martinez",team:"Red Sox",note:""},
    "190": {player:"Jose Ramirez",team:"Indians",note:""},
    "191": {player:"Joey Gallo",team:"Rangers",note:""},
    "192": {player:"Robbie Ray",team:"Diamondbacks",note:""},
    "193": {player:"Matt Chapman",team:"Athletics",note:""},
    "194": {player:"George Springer",team:"Astros",note:""},
    "195": {player:"Patrick Corbin",team:"Nationals",note:""},
    "196": {player:"Corey Seager",team:"Dodgers",note:""},
    "197": {player:"Jeff Samardzija",team:"Giants",note:""},
    "198": {player:"Javier Baez",team:"Cubs",note:""},
    "199": {player:"Aaron Nola",team:"Phillies",note:""},
    "200": {player:"Yordan Alvarez",team:"Astros",note:"Rookie"}
  },
  "Bowman": {
    "1": {player:"Mike Trout",team:"Angels",note:""},
    "2": {player:"Aaron Judge",team:"Yankees",note:""},
    "3": {player:"Ketel Marte",team:"Diamondbacks",note:""},
    "4": {player:"Francisco Lindor",team:"Indians",note:""},
    "5": {player:"Isan Diaz",team:"Marlins",note:"RC"},
    "6": {player:"Jordan Yamamoto",team:"Marlins",note:"RC"},
    "7": {player:"Mike Soroka",team:"Braves",note:""},
    "8": {player:"Cavan Biggio",team:"Blue Jays",note:""},
    "9": {player:"Max Muncy",team:"Dodgers",note:""},
    "10": {player:"Juan Soto",team:"Nationals",note:""},
    "11": {player:"Sean Murphy",team:"Athletics",note:"RC"},
    "12": {player:"Rhys Hoskins",team:"Phillies",note:""},
    "13": {player:"Shane Bieber",team:"Indians",note:""},
    "14": {player:"Willie Calhoun",team:"Rangers",note:""},
    "15": {player:"Justin Dunn",team:"Mariners",note:"RC"},
    "16": {player:"Travis Demeritte",team:"Tigers",note:"RC"},
    "17": {player:"Anthony Kay",team:"Blue Jays",note:"RC"},
    "18": {player:"Luis Robert",team:"White Sox",note:"RC"},
    "19": {player:"Adbert Alzolay",team:"Cubs",note:"RC"},
    "20": {player:"Bobby Bradley",team:"Indians",note:"RC"},
    "21": {player:"Ramon Laureano",team:"Athletics",note:""},
    "22": {player:"Kris Bryant",team:"Cubs",note:""},
    "23": {player:"Abraham Toro",team:"Astros",note:"RC"},
    "24": {player:"Randy Arozarena",team:"Cardinals",note:"RC"},
    "25": {player:"Yordan Alvarez",team:"Astros",note:"RC"},
    "26": {player:"Shohei Ohtani",team:"Angels",note:""},
    "27": {player:"Ronald Acuna Jr.",team:"Braves",note:""},
    "28": {player:"Lorenzo Cain",team:"Brewers",note:""},
    "29": {player:"Eduardo Escobar",team:"Diamondbacks",note:""},
    "30": {player:"Matthew Boyd",team:"Tigers",note:""},
    "31": {player:"Bryan Reynolds",team:"Pirates",note:""},
    "32": {player:"Jose Berrios",team:"Twins",note:""},
    "33": {player:"Nolan Arenado",team:"Rockies",note:""},
    "34": {player:"John Means",team:"Orioles",note:""},
    "35": {player:"Logan Allen",team:"Indians",note:"RC"},
    "36": {player:"Robel Garcia",team:"Cubs",note:"RC"},
    "37": {player:"Whit Merrifield",team:"Royals",note:""},
    "38": {player:"Dustin May",team:"Dodgers",note:"RC"},
    "39": {player:"Junior Fernandez",team:"Cardinals",note:"RC"},
    "40": {player:"Aaron Civale",team:"Indians",note:"RC"},
    "41": {player:"George Springer",team:"Astros",note:""},
    "42": {player:"Michel Baez",team:"Padres",note:"RC"},
    "43": {player:"Joey Votto",team:"Reds",note:""},
    "44": {player:"Seth Brown",team:"Athletics",note:"RC"},
    "45": {player:"Mookie Betts",team:"Red Sox",note:""},
    "46": {player:"Austin Nola",team:"Mariners",note:"RC"},
    "47": {player:"Fernando Tatis Jr.",team:"Padres",note:""},
    "48": {player:"Zack Collins",team:"White Sox",note:"RC"},
    "49": {player:"Eddie Rosario",team:"Twins",note:""},
    "50": {player:"Vladimir Guerrero Jr.",team:"Blue Jays",note:""},
    "51": {player:"Dan Vogelbach",team:"Mariners",note:""},
    "52": {player:"Bo Bichette",team:"Blue Jays",note:"RC"},
    "53": {player:"Max Scherzer",team:"Nationals",note:""},
    "54": {player:"Bryce Harper",team:"Phillies",note:""},
    "55": {player:"Paul DeJong",team:"Cardinals",note:""},
    "56": {player:"Luis Castillo",team:"Reds",note:""},
    "57": {player:"Francisco Mejia",team:"Padres",note:""},
    "58": {player:"Dylan Cease",team:"White Sox",note:"RC"},
    "59": {player:"Lucas Giolito",team:"White Sox",note:""},
    "60": {player:"Jose Urena",team:"Marlins",note:""},
    "61": {player:"Jesus Luzardo",team:"Athletics",note:"RC"},
    "62": {player:"Kevin Newman",team:"Pirates",note:""},
    "63": {player:"Tony Gonsolin",team:"Dodgers",note:"RC"},
    "64": {player:"A.J. Puk",team:"Athletics",note:"RC"},
    "65": {player:"Adrian Morejon",team:"Padres",note:"RC"},
    "66": {player:"Yu Chang",team:"Indians",note:"RC"},
    "67": {player:"Sheldon Neuse",team:"Athletics",note:"RC"},
    "68": {player:"Blake Snell",team:"Rays",note:""},
    "69": {player:"Alex Young",team:"Diamondbacks",note:"RC"},
    "70": {player:"Nomar Mazara",team:"White Sox",note:""},
    "71": {player:"Gavin Lux",team:"Dodgers",note:"RC"},
    "72": {player:"Nico Hoerner",team:"Cubs",note:"RC"},
    "73": {player:"Matt Chapman",team:"Athletics",note:""},
    "74": {player:"Gleyber Torres",team:"Yankees",note:""},
    "75": {player:"Zac Gallen",team:"Diamondbacks",note:"RC"},
    "76": {player:"Mauricio Dubon",team:"Giants",note:"RC"},
    "77": {player:"Jeff McNeil",team:"Mets",note:""},
    "78": {player:"Kyle Lewis",team:"Mariners",note:"RC"},
    "79": {player:"Aristides Aquino",team:"Reds",note:"RC"},
    "80": {player:"Yusei Kikuchi",team:"Mariners",note:""},
    "81": {player:"Willy Adames",team:"Rays",note:""},
    "82": {player:"Trevor Story",team:"Rockies",note:""},
    "83": {player:"Trent Grisham",team:"Padres",note:"RC"},
    "84": {player:"Starlin Castro",team:"Nationals",note:""},
    "85": {player:"Cody Bellinger",team:"Dodgers",note:""},
    "86": {player:"Buster Posey",team:"Giants",note:""},
    "87": {player:"Hanser Alberto",team:"Orioles",note:""},
    "88": {player:"Jose Altuve",team:"Astros",note:""},
    "89": {player:"Brusdar Graterol",team:"Twins",note:"RC"},
    "90": {player:"Andres Munoz",team:"Padres",note:"RC"},
    "91": {player:"Hunter Dozier",team:"Royals",note:""},
    "92": {player:"Mike Yastrzemski",team:"Giants",note:""},
    "93": {player:"Miguel Cabrera",team:"Tigers",note:""},
    "94": {player:"Jack Flaherty",team:"Cardinals",note:""},
    "95": {player:"Xander Bogaerts",team:"Red Sox",note:""},
    "96": {player:"Nick Solak",team:"Rangers",note:"RC"},
    "97": {player:"Tim Anderson",team:"White Sox",note:""},
    "98": {player:"Pete Alonso",team:"Mets",note:""},
    "99": {player:"Javier Baez",team:"Cubs",note:""},
    "100": {player:"Christian Yelich",team:"Brewers",note:""}
  },
  "Bowman Prospects": {
    "BP-1": {player:"Wander Franco",team:"Rays",note:"Prospect"},
    "BP-2": {player:"Drew Waters",team:"Braves",note:"Prospect"},
    "BP-3": {player:"Jacob Amaya",team:"Dodgers",note:"Prospect"},
    "BP-4": {player:"Kody Hoese",team:"Dodgers",note:"Prospect"},
    "BP-5": {player:"Cristian Pache",team:"Braves",note:"Prospect"},
    "BP-6": {player:"Zack Thompson",team:"Cardinals",note:"Prospect"},
    "BP-7": {player:"Briam Campusano",team:"Mets",note:"Prospect"},
    "BP-8": {player:"Jasson Dominguez",team:"Yankees",note:"Prospect"},
    "BP-9": {player:"Aaron Shortridge",team:"Pirates",note:"Prospect"},
    "BP-10": {player:"Xavier Edwards",team:"Padres",note:"Prospect"},
    "BP-11": {player:"Jesus Sanchez",team:"Marlins",note:"Prospect"},
    "BP-12": {player:"Ronaldo Hernandez",team:"Rays",note:"Prospect"},
    "BP-13": {player:"Blake Rutherford",team:"White Sox",note:"Prospect"},
    "BP-14": {player:"Ulrich Bojarski",team:"Tigers",note:"Prospect"},
    "BP-15": {player:"Jordyn Adams",team:"Angels",note:"Prospect"},
    "BP-16": {player:"Austin Beck",team:"Athletics",note:"Prospect"},
    "BP-17": {player:"Niko Hulsizer",team:"Rays",note:"Prospect"},
    "BP-18": {player:"Triston Casas",team:"Red Sox",note:"Prospect"},
    "BP-19": {player:"Julio Rodriguez",team:"Mariners",note:"Prospect"},
    "BP-20": {player:"Shane Baz",team:"Rays",note:"Prospect"},
    "BP-21": {player:"Shea Langeliers",team:"Braves",note:"Prospect"},
    "BP-22": {player:"Grayson Rodriguez",team:"Orioles",note:"Prospect"},
    "BP-23": {player:"Ruben Cardenas",team:"Rays",note:"Prospect"},
    "BP-24": {player:"Mason Denaburg",team:"Nationals",note:"Prospect"},
    "BP-25": {player:"Bobby Witt Jr.",team:"Royals",note:"Prospect"},
    "BP-26": {player:"Andrew Vaughn",team:"White Sox",note:"Prospect"},
    "BP-27": {player:"Kristian Robinson",team:"Diamondbacks",note:"Prospect"},
    "BP-28": {player:"Ronny Mauricio",team:"Mets",note:"Prospect"},
    "BP-29": {player:"Alec Bohm",team:"Phillies",note:"Prospect"},
    "BP-30": {player:"Jhon Diaz",team:"Rays",note:"Prospect"},
    "BP-31": {player:"Estevan Florial",team:"Yankees",note:"Prospect"},
    "BP-32": {player:"Elehuris Montero",team:"Cardinals",note:"Prospect"},
    "BP-33": {player:"Sam Huff",team:"Rangers",note:"Prospect"},
    "BP-34": {player:"Zack Brown",team:"Brewers",note:"Prospect"},
    "BP-35": {player:"Brice Turang",team:"Brewers",note:"Prospect"},
    "BP-36": {player:"Ryan Mountcastle",team:"Orioles",note:"Prospect"},
    "BP-37": {player:"Wilfred Astudillo",team:"Mets",note:"Prospect"},
    "BP-38": {player:"Gus Varland",team:"Athletics",note:"Prospect"},
    "BP-39": {player:"Nick Lodolo",team:"Reds",note:"Prospect"},
    "BP-40": {player:"Tyler Freeman",team:"Indians",note:"Prospect"},
    "BP-41": {player:"Rece Hinds",team:"Reds",note:"Prospect"},
    "BP-42": {player:"Brady Singer",team:"Royals",note:"Prospect"},
    "BP-43": {player:"Cal Mitchell",team:"Pirates",note:"Prospect"},
    "BP-44": {player:"Ethan Hankins",team:"Indians",note:"Prospect"},
    "BP-45": {player:"Daz Cameron",team:"Tigers",note:"Prospect"},
    "BP-46": {player:"Sherten Apostel",team:"Rangers",note:"Prospect"},
    "BP-47": {player:"Hunter Greene",team:"Reds",note:"Prospect"},
    "BP-48": {player:"Josiah Gray",team:"Dodgers",note:"Prospect"},
    "BP-49": {player:"Brailyn Marquez",team:"Cubs",note:"Prospect"},
    "BP-50": {player:"Adley Rutschman",team:"Orioles",note:"Prospect"},
    "BP-51": {player:"Everson Pereira",team:"Yankees",note:"Prospect"},
    "BP-52": {player:"Bayron Lora",team:"Rangers",note:"Prospect"},
    "BP-53": {player:"Clarke Schmidt",team:"Yankees",note:"Prospect"},
    "BP-54": {player:"Brady McConnell",team:"Royals",note:"Prospect"},
    "BP-55": {player:"Spencer Howard",team:"Phillies",note:"Prospect"},
    "BP-56": {player:"Cristian Javier",team:"Astros",note:"Prospect"},
    "BP-57": {player:"Aaron Ashby",team:"Brewers",note:"Prospect"},
    "BP-58": {player:"Logan Gilbert",team:"Mariners",note:"Prospect"},
    "BP-59": {player:"Glenallen Hill Jr.",team:"Diamondbacks",note:"Prospect"},
    "BP-60": {player:"Alvaro Seijas",team:"Cardinals",note:"Prospect"},
    "BP-61": {player:"Jeremy Pena",team:"Astros",note:"Prospect"},
    "BP-62": {player:"CJ Abrams",team:"Padres",note:"Prospect"},
    "BP-63": {player:"Franklin Perez",team:"Tigers",note:"Prospect"},
    "BP-64": {player:"Tanner Houck",team:"Red Sox",note:"Prospect"},
    "BP-65": {player:"Damon Jones",team:"Phillies",note:"Prospect"},
    "BP-66": {player:"Nolan Gorman",team:"Cardinals",note:"Prospect"},
    "BP-67": {player:"Ke'Bryan Hayes",team:"Pirates",note:"Prospect"},
    "BP-68": {player:"Bryson Stott",team:"Phillies",note:"Prospect"},
    "BP-69": {player:"Canaan Smith",team:"Yankees",note:"Prospect"},
    "BP-70": {player:"Forrest Whitley",team:"Astros",note:"Prospect"},
    "BP-71": {player:"Drew Mendoza",team:"Nationals",note:"Prospect"},
    "BP-72": {player:"Jazz Chisholm",team:"Marlins",note:"Prospect"},
    "BP-73": {player:"Jonathan India",team:"Reds",note:"Prospect"},
    "BP-74": {player:"MacKenzie Gore",team:"Padres",note:"Prospect"},
    "BP-75": {player:"Seth Beer",team:"Diamondbacks",note:"Prospect"},
    "BP-76": {player:"Joey Cantillo",team:"Padres",note:"Prospect"},
    "BP-77": {player:"Evan White",team:"Mariners",note:"Prospect"},
    "BP-78": {player:"Chris Vallimont",team:"Twins",note:"Prospect"},
    "BP-79": {player:"Sixto Sanchez",team:"Marlins",note:"Prospect"},
    "BP-80": {player:"Alex Kirilloff",team:"Twins",note:"Prospect"},
    "BP-81": {player:"Tristen Lutz",team:"Brewers",note:"Prospect"},
    "BP-82": {player:"Freudis Nova",team:"Astros",note:"Prospect"},
    "BP-83": {player:"Tim Cate",team:"Nationals",note:"Prospect"},
    "BP-84": {player:"Daniel Lynch",team:"Royals",note:"Prospect"},
    "BP-85": {player:"Antonio Cabello",team:"Yankees",note:"Prospect"},
    "BP-86": {player:"Bobby Dalbec",team:"Red Sox",note:"Prospect"},
    "BP-87": {player:"Colton Welker",team:"Rockies",note:"Prospect"},
    "BP-88": {player:"Logan Davidson",team:"Athletics",note:"Prospect"},
    "BP-89": {player:"Matthew Liberatore",team:"Rays",note:"Prospect"},
    "BP-90": {player:"Adam Hall",team:"Orioles",note:"Prospect"},
    "BP-91": {player:"Jackson Rutledge",team:"Nationals",note:"Prospect"},
    "BP-92": {player:"Dane Dunning",team:"White Sox",note:"Prospect"},
    "BP-93": {player:"Royce Lewis",team:"Twins",note:"Prospect"},
    "BP-94": {player:"Jarred Kelenic",team:"Mariners",note:"Prospect"},
    "BP-95": {player:"Nolan Jones",team:"Indians",note:"Prospect"},
    "BP-96": {player:"Jerar Encarnacion",team:"Marlins",note:"Prospect"},
    "BP-97": {player:"Ian Anderson",team:"Braves",note:"Prospect"},
    "BP-98": {player:"Alek Thomas",team:"Diamondbacks",note:"Prospect"},
    "BP-99": {player:"Matt Manning",team:"Tigers",note:"Prospect"},
    "BP-100": {player:"Jo Adell",team:"Angels",note:"Prospect"},
    "BP-101": {player:"Nick Madrigal",team:"White Sox",note:"Prospect"},
    "BP-102": {player:"Owen Miller",team:"Padres",note:"Prospect"},
    "BP-103": {player:"Marco Luciano",team:"Giants",note:"Prospect"},
    "BP-104": {player:"Jordan Groshans",team:"Blue Jays",note:"Prospect"},
    "BP-105": {player:"Nick Allen",team:"Athletics",note:"Prospect"},
    "BP-106": {player:"Dylan Carlson",team:"Cardinals",note:"Prospect"},
    "BP-107": {player:"Cole Winn",team:"Rangers",note:"Prospect"},
    "BP-108": {player:"Tarik Skubal",team:"Tigers",note:"Prospect"},
    "BP-109": {player:"Oscar Gonzalez",team:"Indians",note:"Prospect"},
    "BP-110": {player:"Aramis Ademan",team:"Cubs",note:"Prospect"},
    "BP-111": {player:"Oneil Cruz",team:"Pirates",note:"Prospect"},
    "BP-112": {player:"Joey Bart",team:"Giants",note:"Prospect"},
    "BP-113": {player:"Josh Jung",team:"Rangers",note:"Prospect"},
    "BP-114": {player:"Luis Garcia",team:"Nationals",note:"Prospect"},
    "BP-115": {player:"Jasseel De La Cruz",team:"Braves",note:"Prospect"},
    "BP-116": {player:"J.J. Bleday",team:"Marlins",note:"Prospect"},
    "BP-117": {player:"Joe Ryan",team:"Rays",note:"Prospect"},
    "BP-118": {player:"Keoni Cavaco",team:"Twins",note:"Prospect"},
    "BP-119": {player:"Hans Crouse",team:"Rangers",note:"Prospect"},
    "BP-120": {player:"Isaac Paredes",team:"Tigers",note:"Prospect"},
    "BP-121": {player:"Grant Lavigne",team:"Rockies",note:"Prospect"},
    "BP-122": {player:"Riley Greene",team:"Tigers",note:"Prospect"},
    "BP-123": {player:"Jordan Balazovic",team:"Twins",note:"Prospect"},
    "BP-124": {player:"Nate Pearson",team:"Blue Jays",note:"Prospect"},
    "BP-125": {player:"Deivi Garcia",team:"Yankees",note:"Prospect"},
    "BP-126": {player:"Luis Garcia",team:"Phillies",note:"Prospect"},
    "BP-127": {player:"Leody Taveras",team:"Rangers",note:"Prospect"},
    "BP-128": {player:"Bryan Mata",team:"Red Sox",note:"Prospect"},
    "BP-129": {player:"Hunter Bishop",team:"Giants",note:"Prospect"},
    "BP-130": {player:"Taylor Trammell",team:"Padres",note:"Prospect"},
    "BP-131": {player:"Miguel Vargas",team:"Dodgers",note:"Prospect"},
    "BP-132": {player:"Luis Gil",team:"Yankees",note:"Prospect"},
    "BP-133": {player:"Grant Little",team:"Padres",note:"Prospect"},
    "BP-134": {player:"Gunnar Henderson",team:"Orioles",note:"Prospect"},
    "BP-135": {player:"Eric Pardinho",team:"Blue Jays",note:"Prospect"},
    "BP-136": {player:"Miguel Amaya",team:"Cubs",note:"Prospect"},
    "BP-137": {player:"Ryan Rolison",team:"Rockies",note:"Prospect"},
    "BP-138": {player:"Jorge Mateo",team:"Athletics",note:"Prospect"},
    "BP-139": {player:"Anthony Volpe",team:"Yankees",note:"Prospect"},
    "BP-140": {player:"Nick Bennett",team:"Brewers",note:"Prospect"},
    "BP-141": {player:"Brennen Davis",team:"Cubs",note:"Prospect"},
    "BP-142": {player:"Casey Mize",team:"Tigers",note:"Prospect"},
    "BP-143": {player:"Keibert Ruiz",team:"Dodgers",note:"Prospect"},
    "BP-144": {player:"Jarren Duran",team:"Red Sox",note:"Prospect"},
    "BP-145": {player:"Robert Puason",team:"Athletics",note:"Prospect"},
    "BP-146": {player:"Travis Swaggerty",team:"Pirates",note:"Prospect"},
    "BP-147": {player:"Will Wilson",team:"Angels",note:"Prospect"},
    "BP-148": {player:"Heliot Ramos",team:"Giants",note:"Prospect"},
    "BP-149": {player:"Alek Manoah",team:"Blue Jays",note:"Prospect"},
    "BP-150": {player:"Luis Robert",team:"White Sox",note:"Prospect"}
  }
};
CARD_NAMES["Bowman Chrome Prospects"] = Object.fromEntries(Object.entries(CARD_NAMES["Bowman Prospects"]).map(([k,v])=>[k.replace(/^BP-/,"BCP-"), v]));
CARD_NAMES["Bowman Draft"] = {
  "BD-1": {player:"Niko Hulsizer",team:"Rays",note:"Prospect"},
  "BD-2": {player:"Jackson Kowar",team:"Royals",note:"Prospect"},
  "BD-3": {player:"Korey Lee",team:"Astros",note:"Prospect"},
  "BD-4": {player:"Milan Tolentino",team:"Indians",note:"Prospect"},
  "BD-5": {player:"Jeter Downs",team:"Red Sox",note:"Prospect"},
  "BD-6": {player:"Hans Crouse",team:"Rangers",note:"Prospect"},
  "BD-7": {player:"Mike Siani",team:"Reds",note:"Prospect"},
  "BD-8": {player:"Dane Acker",team:"Athletics",note:"Prospect"},
  "BD-9": {player:"Ryan Jensen",team:"Cubs",note:"Prospect"},
  "BD-10": {player:"Shane Baz",team:"Rays",note:"Prospect"},
  "BD-11": {player:"Trei Cruz",team:"Tigers",note:"Prospect"},
  "BD-12": {player:"Emerson Hancock",team:"Mariners",note:"Prospect"},
  "BD-13": {player:"Joey Cantillo",team:"Indians",note:"Prospect"},
  "BD-14": {player:"Nick Loftin",team:"Royals",note:"Prospect"},
  "BD-15": {player:"Rece Hinds",team:"Reds",note:"Prospect"},
  "BD-16": {player:"Jared Shuster",team:"Braves",note:"Prospect"},
  "BD-17": {player:"Jesse Franklin V",team:"Braves",note:"Prospect"},
  "BD-18": {player:"Kaden Polcovich",team:"Mariners",note:"Prospect"},
  "BD-19": {player:"Ben Hernandez",team:"Royals",note:"Prospect"},
  "BD-20": {player:"Spencer Strider",team:"Braves",note:"Prospect"},
  "BD-21": {player:"Tyler Brown",team:"Astros",note:"Prospect"},
  "BD-22": {player:"Keoni Cavaco",team:"Twins",note:"Prospect"},
  "BD-23": {player:"Case Williams",team:"Rockies",note:"Prospect"},
  "BD-24": {player:"Cade Cavalli",team:"Nationals",note:"Prospect"},
  "BD-25": {player:"Burl Carraway",team:"Cubs",note:"Prospect"},
  "BD-26": {player:"Daniel Espino",team:"Indians",note:"Prospect"},
  "BD-27": {player:"Oswald Peraza",team:"Yankees",note:"Prospect"},
  "BD-28": {player:"Zach DeLoach",team:"Mariners",note:"Prospect"},
  "BD-29": {player:"Nick Yorke",team:"Red Sox",note:"Prospect"},
  "BD-30": {player:"Clayton Beeter",team:"Dodgers",note:"Prospect"},
  "BD-31": {player:"Joe Ryan",team:"Rays",note:"Prospect"},
  "BD-32": {player:"Jordan Groshans",team:"Blue Jays",note:"Prospect"},
  "BD-33": {player:"Gage Workman",team:"Tigers",note:"Prospect"},
  "BD-34": {player:"Austin Hendrick",team:"Reds",note:"Prospect"},
  "BD-35": {player:"Jimmy Glowenke",team:"Giants",note:"Prospect"},
  "BD-36": {player:"Ryan Rolison",team:"Rockies",note:"Prospect"},
  "BD-37": {player:"Logan Gilbert",team:"Mariners",note:"Prospect"},
  "BD-38": {player:"Bobby Miller",team:"Dodgers",note:"Prospect"},
  "BD-39": {player:"Robert Hassell",team:"Padres",note:"Prospect"},
  "BD-40": {player:"JJ Goss",team:"Rays",note:"Prospect"},
  "BD-41": {player:"Reid Detmers",team:"Angels",note:"Prospect"},
  "BD-42": {player:"Michael Busch",team:"Dodgers",note:"Prospect"},
  "BD-43": {player:"Chris McMahon",team:"Rockies",note:"Prospect"},
  "BD-44": {player:"Xavier Edwards",team:"Rays",note:"Prospect"},
  "BD-45": {player:"Alec Burleson",team:"Cardinals",note:"Prospect"},
  "BD-46": {player:"Freddy Zamora",team:"Brewers",note:"Prospect"},
  "BD-47": {player:"Travis Swaggerty",team:"Pirates",note:"Prospect"},
  "BD-48": {player:"Sammy Infante",team:"Nationals",note:"Prospect"},
  "BD-49": {player:"Owen Caissie",team:"Padres",note:"Prospect"},
  "BD-50": {player:"Max Meyer",team:"Marlins",note:"Prospect"},
  "BD-51": {player:"Logan Allen",team:"Indians",note:"Prospect"},
  "BD-52": {player:"Landon Knack",team:"Dodgers",note:"Prospect"},
  "BD-53": {player:"Quinn Priester",team:"Pirates",note:"Prospect"},
  "BD-54": {player:"Colt Keith",team:"Tigers",note:"Prospect"},
  "BD-55": {player:"Jarren Duran",team:"Red Sox",note:"Prospect"},
  "BD-56": {player:"Austin Wells",team:"Yankees",note:"Prospect"},
  "BD-57": {player:"Jordan Walker",team:"Cardinals",note:"Prospect"},
  "BD-58": {player:"Jordan Balazovic",team:"Twins",note:"Prospect"},
  "BD-59": {player:"Masyn Winn",team:"Cardinals",note:"Prospect"},
  "BD-60": {player:"Carson Tucker",team:"Indians",note:"Prospect"},
  "BD-61": {player:"Nick Bitsko",team:"Rays",note:"Prospect"},
  "BD-62": {player:"Daniel Cabrera",team:"Tigers",note:"Prospect"},
  "BD-63": {player:"Marco Raya",team:"Twins",note:"Prospect"},
  "BD-64": {player:"Kyle Nicolas",team:"Marlins",note:"Prospect"},
  "BD-65": {player:"Oneil Cruz",team:"Pirates",note:"Prospect"},
  "BD-66": {player:"Hunter Barnhart",team:"Rays",note:"Prospect"},
  "BD-67": {player:"Cole Henry",team:"Nationals",note:"Prospect"},
  "BD-68": {player:"Tristen Lutz",team:"Brewers",note:"Prospect"},
  "BD-69": {player:"Petey Halpin",team:"Indians",note:"Prospect"},
  "BD-70": {player:"Jared Jones",team:"Pirates",note:"Prospect"},
  "BD-71": {player:"Connor Phillips",team:"Mariners",note:"Prospect"},
  "BD-72": {player:"Pete Crow-Armstrong",team:"Mets",note:"Prospect"},
  "BD-73": {player:"Casey Martin",team:"Phillies",note:"Prospect"},
  "BD-74": {player:"Bryce Bonnin",team:"Reds",note:"Prospect"},
  "BD-75": {player:"Daniel Lynch",team:"Royals",note:"Prospect"},
  "BD-76": {player:"Tekoah Roby",team:"Rangers",note:"Prospect"},
  "BD-77": {player:"Isaiah Greene",team:"Mets",note:"Prospect"},
  "BD-78": {player:"Tyler Freeman",team:"Indians",note:"Prospect"},
  "BD-79": {player:"Heliot Ramos",team:"Giants",note:"Prospect"},
  "BD-80": {player:"Miguel Amaya",team:"Cubs",note:"Prospect"},
  "BD-81": {player:"Nick Gonzales",team:"Pirates",note:"Prospect"},
  "BD-82": {player:"DL Hall",team:"Orioles",note:"Prospect"},
  "BD-83": {player:"Triston Casas",team:"Red Sox",note:"Prospect"},
  "BD-84": {player:"Christian Chamberlain",team:"Royals",note:"Prospect"},
  "BD-85": {player:"Slade Cecconi",team:"Diamondbacks",note:"Prospect"},
  "BD-86": {player:"Tink Hence",team:"Cardinals",note:"Prospect"},
  "BD-87": {player:"Adisyn Coffey",team:"White Sox",note:"Prospect"},
  "BD-88": {player:"Asa Lacy",team:"Royals",note:"Prospect"},
  "BD-89": {player:"Geraldo Perdomo",team:"Diamondbacks",note:"Prospect"},
  "BD-90": {player:"Nick Garcia",team:"Pirates",note:"Prospect"},
  "BD-91": {player:"Nick Swiney",team:"Giants",note:"Prospect"},
  "BD-92": {player:"Matthew Dyer",team:"Mets",note:"Prospect"},
  "BD-93": {player:"CJ Van Eyk",team:"Blue Jays",note:"Prospect"},
  "BD-94": {player:"Alerick Soularie",team:"Twins",note:"Prospect"},
  "BD-95": {player:"Garrett Crochet",team:"White Sox",note:"Prospect"},
  "BD-96": {player:"Ian Seymour",team:"Rays",note:"Prospect"},
  "BD-97": {player:"Zavier Warren",team:"Brewers",note:"Prospect"},
  "BD-98": {player:"Ed Howard",team:"Cubs",note:"Prospect"},
  "BD-99": {player:"Justin Lange",team:"Padres",note:"Prospect"},
  "BD-100": {player:"Ian Bedell",team:"Cardinals",note:"Prospect"},
  "BD-101": {player:"Aaron Shortridge",team:"Pirates",note:"Prospect"},
  "BD-102": {player:"Trevor Larnach",team:"Twins",note:"Prospect"},
  "BD-103": {player:"David Calabrese",team:"Angels",note:"Prospect"},
  "BD-104": {player:"Quin Cotton",team:"Reds",note:"Prospect"},
  "BD-105": {player:"Luke Little",team:"Cubs",note:"Prospect"},
  "BD-106": {player:"Drew Romo",team:"Rockies",note:"Prospect"},
  "BD-107": {player:"Zac Veen",team:"Rockies",note:"Prospect"},
  "BD-108": {player:"Brady McConnell",team:"Royals",note:"Prospect"},
  "BD-109": {player:"Sam Weatherly",team:"Rockies",note:"Prospect"},
  "BD-110": {player:"Jordan Nwogu",team:"Cubs",note:"Prospect"},
  "BD-111": {player:"Jordan Westburg",team:"Orioles",note:"Prospect"},
  "BD-112": {player:"Zach McCambley",team:"Marlins",note:"Prospect"},
  "BD-113": {player:"Trevor Hauver",team:"Yankees",note:"Prospect"},
  "BD-114": {player:"Corbin Carroll",team:"Diamondbacks",note:"Prospect"},
  "BD-115": {player:"Tanner Burns",team:"Indians",note:"Prospect"},
  "BD-116": {player:"Jackson Miller",team:"Reds",note:"Prospect"},
  "BD-117": {player:"Carter Baumler",team:"Orioles",note:"Prospect"},
  "BD-118": {player:"Garrett Mitchell",team:"Brewers",note:"Prospect"},
  "BD-119": {player:"Tyler Soderstrom",team:"Athletics",note:"Prospect"},
  "BD-120": {player:"Holden Powell",team:"Nationals",note:"Prospect"},
  "BD-121": {player:"Spencer Torkelson",team:"Tigers",note:"Prospect"},
  "BD-122": {player:"Heston Kjerstad",team:"Orioles",note:"Prospect"},
  "BD-123": {player:"Alexander Canario",team:"Giants",note:"Prospect"},
  "BD-124": {player:"Justin Foscue",team:"Rangers",note:"Prospect"},
  "BD-125": {player:"Levi Prater",team:"Cardinals",note:"Prospect"},
  "BD-126": {player:"Evan Carter",team:"Rangers",note:"Prospect"},
  "BD-127": {player:"Bryce Jarvis",team:"Diamondbacks",note:"Prospect"},
  "BD-128": {player:"Werner Blakely",team:"Angels",note:"Prospect"},
  "BD-129": {player:"Casey Schmitt",team:"Giants",note:"Prospect"},
  "BD-130": {player:"Hudson Haskin",team:"Orioles",note:"Prospect"},
  "BD-131": {player:"Daxton Fulton",team:"Marlins",note:"Prospect"},
  "BD-132": {player:"Luis Gil",team:"Yankees",note:"Prospect"},
  "BD-133": {player:"Zach Daniels",team:"Astros",note:"Prospect"},
  "BD-134": {player:"Jeff Criswell",team:"Athletics",note:"Prospect"},
  "BD-135": {player:"Shane McClanahan",team:"Rays",note:"Prospect"},
  "BD-136": {player:"Alika Williams",team:"Rays",note:"Prospect"},
  "BD-137": {player:"Gilberto Jimenez",team:"Red Sox",note:"Prospect"},
  "BD-138": {player:"Trent Palmer",team:"Blue Jays",note:"Prospect"},
  "BD-139": {player:"Alex Santos",team:"Astros",note:"Prospect"},
  "BD-140": {player:"Bryson Stott",team:"Phillies",note:"Prospect"},
  "BD-141": {player:"Ethan Hankins",team:"Indians",note:"Prospect"},
  "BD-142": {player:"Kody Hoese",team:"Dodgers",note:"Prospect"},
  "BD-143": {player:"Francisco Alvarez",team:"Mets",note:"Prospect"},
  "BD-144": {player:"Dillon Dingler",team:"Tigers",note:"Prospect"},
  "BD-145": {player:"Carson Ragsdale",team:"Phillies",note:"Prospect"},
  "BD-146": {player:"Patrick Bailey",team:"Giants",note:"Prospect"},
  "BD-147": {player:"Liam Norris",team:"Diamondbacks",note:"Prospect"},
  "BD-148": {player:"RJ Dabovich",team:"Giants",note:"Prospect"},
  "BD-149": {player:"Carmen Mlodzinski",team:"Pirates",note:"Prospect"},
  "BD-150": {player:"AJ Vukovich",team:"Diamondbacks",note:"Prospect"},
  "BD-151": {player:"Jasson Dominguez",team:"Yankees",note:"Prospect"},
  "BD-152": {player:"Bobby Witt Jr.",team:"Royals",note:"Prospect"},
  "BD-153": {player:"Andrew Vaughn",team:"White Sox",note:"Prospect"},
  "BD-154": {player:"Adley Rutschman",team:"Orioles",note:"Prospect"},
  "BD-155": {player:"Robert Puason",team:"Athletics",note:"Prospect"},
  "BD-156": {player:"Jay Groome",team:"Red Sox",note:"Prospect"},
  "BD-157": {player:"Will Klein",team:"Royals",note:"Prospect"},
  "BD-158": {player:"Zach Britton",team:"Blue Jays",note:"Prospect"},
  "BD-159": {player:"Owen Miller",team:"Indians",note:"Prospect"},
  "BD-160": {player:"Logan Hofmann",team:"Pirates",note:"Prospect"},
  "BD-161": {player:"Ronaldo Hernandez",team:"Rays",note:"Prospect"},
  "BD-162": {player:"Jack Blomgren",team:"Rockies",note:"Prospect"},
  "BD-163": {player:"Adam Seminaris",team:"Angels",note:"Prospect"},
  "BD-164": {player:"Bailey Horn",team:"White Sox",note:"Prospect"},
  "BD-165": {player:"Joe Boyle",team:"Reds",note:"Prospect"},
  "BD-166": {player:"Ryan Murphy",team:"Giants",note:"Prospect"},
  "BD-167": {player:"Thomas Saggese",team:"Rangers",note:"Prospect"},
  "BD-168": {player:"George Kirby",team:"Mariners",note:"Prospect"},
  "BD-169": {player:"Jeremiah Jackson",team:"Angels",note:"Prospect"},
  "BD-170": {player:"Shane Drohan",team:"Red Sox",note:"Prospect"},
  "BD-171": {player:"Brandon Pfaadt",team:"Diamondbacks",note:"Prospect"},
  "BD-172": {player:"Blake Rutherford",team:"White Sox",note:"Prospect"},
  "BD-173": {player:"Hayden Cantrelle",team:"Brewers",note:"Prospect"},
  "BD-174": {player:"Mark Vientos",team:"Mets",note:"Prospect"},
  "BD-175": {player:"Michael Toglia",team:"Rockies",note:"Prospect"},
  "BD-176": {player:"Mitchell Parker",team:"Nationals",note:"Prospect"},
  "BD-177": {player:"Jackson Rutledge",team:"Nationals",note:"Prospect"},
  "BD-178": {player:"Anthony Volpe",team:"Yankees",note:"Prospect"},
  "BD-179": {player:"Nick Lodolo",team:"Reds",note:"Prospect"},
  "BD-180": {player:"Riley Greene",team:"Tigers",note:"Prospect"},
  "BD-181": {player:"JJ Bleday",team:"Marlins",note:"Prospect"},
  "BD-182": {player:"Kyle Isbel",team:"Royals",note:"Prospect"},
  "BD-183": {player:"Shea Langeliers",team:"Braves",note:"Prospect"},
  "BD-184": {player:"Brett Baty",team:"Mets",note:"Prospect"},
  "BD-185": {player:"Jerar Encarnacion",team:"Marlins",note:"Prospect"},
  "BD-186": {player:"Aaron Ashby",team:"Brewers",note:"Prospect"},
  "BD-187": {player:"Brennen Davis",team:"Cubs",note:"Prospect"},
  "BD-188": {player:"Julio Rodriguez",team:"Mariners",note:"Prospect"},
  "BD-189": {player:"CJ Abrams",team:"Padres",note:"Prospect"},
  "BD-190": {player:"Marco Luciano",team:"Giants",note:"Prospect"},
  "BD-191": {player:"Grayson Rodriguez",team:"Orioles",note:"Prospect"},
  "BD-192": {player:"Kristian Robinson",team:"Diamondbacks",note:"Prospect"},
  "BD-193": {player:"Jordyn Adams",team:"Angels",note:"Prospect"},
  "BD-194": {player:"Nolan Gorman",team:"Cardinals",note:"Prospect"},
  "BD-195": {player:"Alek Thomas",team:"Diamondbacks",note:"Prospect"},
  "BD-196": {player:"Hunter Greene",team:"Reds",note:"Prospect"},
  "BD-197": {player:"Josh Jung",team:"Rangers",note:"Prospect"},
  "BD-198": {player:"Matthew Liberatore",team:"Cardinals",note:"Prospect"},
  "BD-199": {player:"Ronny Mauricio",team:"Mets",note:"Prospect"},
  "BD-200": {player:"Hunter Bishop",team:"Giants",note:"Prospect"}
};
CARD_NAMES["Heritage"] = {
  "1": {player:"Washington Nationals - World Series Champions",team:"Nationals",note:""},
  "2": {player:"Trevor Bauer",team:"Reds",note:""},
  "3": {player:"Jesse Winker",team:"Reds",note:""},
  "4": {player:"Adam Frazier",team:"Pirates",note:""},
  "5": {player:"Gary Sanchez",team:"Yankees",note:""},
  "6": {player:"Derek Dietrich",team:"Reds",note:""},
  "7": {player:"Seth Lugo",team:"Mets",note:""},
  "8": {player:"Gio Urshela",team:"Yankees",note:""},
  "9": {player:"Donovan Solano",team:"Giants",note:""},
  "10": {player:"Jedd Gyorko",team:"Dodgers",note:""},
  "11": {player:"Tom Murphy",team:"Mariners",note:""},
  "12": {player:"Tony Wolters",team:"Rockies",note:""},
  "13": {player:"Dylan Cease / Zack Collins",team:"White Sox",note:"RC"},
  "14": {player:"Matt Beaty",team:"Dodgers",note:""},
  "15": {player:"Anibal Sanchez",team:"Nationals",note:""},
  "16": {player:"Johnny Cueto",team:"Giants",note:""},
  "17": {player:"Yuli Gurriel",team:"Astros",note:""},
  "18": {player:"Josh Reddick",team:"Astros",note:""},
  "19": {player:"Vince Velasquez",team:"Phillies",note:""},
  "20": {player:"Shed Long",team:"Mariners",note:""},
  "21": {player:"Steven Matz",team:"Mets",note:""},
  "22": {player:"Julio Teheran",team:"Braves",note:""},
  "23": {player:"Scott Kingery",team:"Phillies",note:""},
  "24": {player:"Mike Moustakas",team:"Reds",note:""},
  "25": {player:"Taylor Rogers",team:"Twins",note:""},
  "26": {player:"Jose Quintana",team:"Cubs",note:""},
  "27": {player:"Dario Agrazal / James Marvel",team:"Pirates",note:"RC"},
  "28": {player:"Omar Narvaez",team:"Mariners",note:""},
  "29": {player:"Adam Ottavino",team:"Yankees",note:""},
  "30": {player:"Justin Turner",team:"Dodgers",note:""},
  "31": {player:"Victor Caratini",team:"Cubs",note:""},
  "32": {player:"Evan Longoria",team:"Giants",note:""},
  "33": {player:"Ender Inciarte",team:"Braves",note:""},
  "34": {player:"Orlando Arcia",team:"Brewers",note:""},
  "35": {player:"Jorge Soler",team:"Royals",note:""},
  "36": {player:"Kenley Jansen",team:"Dodgers",note:""},
  "37": {player:"Luke Jackson",team:"Braves",note:""},
  "38": {player:"Rougned Odor",team:"Rangers",note:""},
  "39": {player:"Tyler Alexander / Jake Rogers",team:"Tigers",note:"RC"},
  "40": {player:"Joey Votto",team:"Reds",note:""},
  "41": {player:"Miguel Cabrera",team:"Tigers",note:""},
  "42": {player:"Albert Almora",team:"Cubs",note:""},
  "43": {player:"Emilio Pagan",team:"Rays",note:""},
  "44": {player:"Brendan Rodgers",team:"Rockies",note:""},
  "45": {player:"Kyle Tucker",team:"Astros",note:""},
  "46": {player:"Adam Engel",team:"White Sox",note:""},
  "47": {player:"J.A. Happ",team:"Yankees",note:""},
  "48": {player:"Matt Adams",team:"Nationals",note:""},
  "49": {player:"Harold Ramirez",team:"Marlins",note:""},
  "50": {player:"Chris Bassitt",team:"Athletics",note:""},
  "51": {player:"Mitch Haniger",team:"Mariners",note:""},
  "52": {player:"Anthony Kay / Bo Bichette",team:"Blue Jays",note:"RC"},
  "53": {player:"Aaron Nola",team:"Phillies",note:""},
  "54": {player:"Aristides Aquino / Yordan Alvarez",team:"Astros",note:"RC"},
  "55": {player:"Cavan Biggio",team:"Blue Jays",note:""},
  "56": {player:"Carlos Santana",team:"Indians",note:""},
  "57": {player:"Chris Taylor",team:"Dodgers",note:""},
  "58": {player:"Andrew Miller",team:"Cardinals",note:""},
  "59": {player:"Scott Oberg",team:"Rockies",note:""},
  "60": {player:"Mark Canha",team:"Athletics",note:""},
  "61": {player:"Tim Anderson / Yoan Moncada / DJ LeMahieu",team:"League Leaders",note:"LL"},
  "62": {player:"Anthony Rendon / Christian Yelich / Ketel Marte",team:"League Leaders",note:"LL"},
  "63": {player:"Jorge Soler / Jose Abreu / Xander Bogaerts",team:"League Leaders",note:"LL"},
  "64": {player:"Pete Alonso / Freddie Freeman / Anthony Rendon",team:"League Leaders",note:"LL"},
  "65": {player:"Jorge Soler / Alex Bregman / Nelson Cruz / Mike Trout",team:"League Leaders",note:"LL"},
  "66": {player:"Eugenio Suarez / Cody Bellinger / Pete Alonso",team:"League Leaders",note:"LL"},
  "67": {player:"Justin Verlander / Charlie Morton / Gerrit Cole",team:"League Leaders",note:"LL"},
  "68": {player:"Mike Soroka / Jacob deGrom / Hyun-Jin Ryu",team:"League Leaders",note:"LL"},
  "69": {player:"Eduardo Rodriguez / Justin Verlander / Gerrit Cole",team:"League Leaders",note:"LL"},
  "70": {player:"Clayton Kershaw / Dakota Hudson / Max Fried / Stephen Strasburg",team:"League Leaders",note:"LL"},
  "71": {player:"Justin Verlander / Shane Bieber / Gerrit Cole",team:"League Leaders",note:"LL"},
  "72": {player:"Max Scherzer / Jacob deGrom / Stephen Strasburg",team:"League Leaders",note:"LL"},
  "73": {player:"Antonio Senzatela",team:"Rockies",note:""},
  "74": {player:"Lewis Thorpe / Brusdar Graterol",team:"Twins",note:"RC"},
  "75": {player:"J.T. Realmuto",team:"Phillies",note:""},
  "76": {player:"Touki Toussaint",team:"Braves",note:""},
  "77": {player:"Dylan Bundy",team:"Angels",note:""},
  "78": {player:"Albert Pujols",team:"Angels",note:""},
  "79": {player:"Jay Bruce",team:"Phillies",note:""},
  "80": {player:"Harrison Bader",team:"Cardinals",note:""},
  "81": {player:"Khris Davis",team:"Athletics",note:""},
  "82": {player:"Max Scherzer",team:"Nationals",note:""},
  "83": {player:"Aaron Civale / Bobby Bradley",team:"Indians",note:"RC"},
  "84": {player:"David Bote",team:"Cubs",note:""},
  "85": {player:"Christin Stewart",team:"Tigers",note:""},
  "86": {player:"Colin Moran",team:"Pirates",note:""},
  "87": {player:"Josh Hader",team:"Brewers",note:""},
  "88": {player:"Dexter Fowler",team:"Cardinals",note:""},
  "89": {player:"Carlos Carrasco",team:"Indians",note:""},
  "90": {player:"Robinson Cano",team:"Mets",note:""},
  "91": {player:"Mike Foltynewicz",team:"Braves",note:""},
  "92": {player:"Carson Kelly",team:"Diamondbacks",note:""},
  "93": {player:"Alex Young / Zac Gallen",team:"Diamondbacks",note:"RC"},
  "94": {player:"Marco Gonzales",team:"Mariners",note:""},
  "95": {player:"Pedro Severino",team:"Orioles",note:""},
  "96": {player:"Mitch Garver",team:"Twins",note:""},
  "97": {player:"Wil Myers",team:"Padres",note:""},
  "98": {player:"Marcus Semien",team:"Athletics",note:""},
  "99": {player:"Tommy La Stella",team:"Angels",note:""},
  "100": {player:"Nick Markakis",team:"Braves",note:""},
  "101": {player:"Brad Hand",team:"Indians",note:""},
  "102": {player:"Rogelio Armenteros / Abraham Toro / Bryan Abreu",team:"Astros",note:"RC"},
  "103": {player:"Adalberto Mondesi",team:"Royals",note:""},
  "104": {player:"Austin Hedges",team:"Padres",note:""},
  "105": {player:"Josh VanMeter",team:"Reds",note:""},
  "106": {player:"James McCann",team:"White Sox",note:""},
  "107": {player:"Tucker Barnhart",team:"Reds",note:""},
  "108": {player:"Tyler Flowers",team:"Braves",note:""},
  "109": {player:"Joey Lucchesi",team:"Padres",note:""},
  "110": {player:"Pablo Sandoval",team:"Giants",note:""},
  "111": {player:"Domingo Leyba / Josh Rojas",team:"Diamondbacks",note:"RC"},
  "112": {player:"Nick Ahmed",team:"Diamondbacks",note:""},
  "113": {player:"Eduardo Rodriguez",team:"Red Sox",note:""},
  "114": {player:"Caleb Smith",team:"Marlins",note:""},
  "115": {player:"Cal Quantrill",team:"Padres",note:""},
  "116": {player:"Trent Grisham / Mauricio Dubon",team:"Giants",note:"RC"},
  "117": {player:"Marcus Stroman",team:"Mets",note:""},
  "118": {player:"Whit Merrifield",team:"Royals",note:""},
  "119": {player:"Maikel Franco",team:"Phillies",note:""},
  "120": {player:"Willians Astudillo",team:"Twins",note:""},
  "121": {player:"Nico Hoerner / Adbert Alzolay",team:"Cubs",note:"RC"},
  "122": {player:"Brandon Dixon",team:"Tigers",note:""},
  "123": {player:"Sam Hilliard / Dom Nunez",team:"Rockies",note:"RC"},
  "124": {player:"Kolten Wong",team:"Cardinals",note:""},
  "125": {player:"Ross Stripling",team:"Dodgers",note:""},
  "126": {player:"Edwin Encarnacion",team:"Yankees",note:""},
  "127": {player:"Yan Gomes",team:"Nationals",note:""},
  "128": {player:"Josh James",team:"Astros",note:""},
  "129": {player:"Oscar Mercado",team:"Indians",note:""},
  "130": {player:"Clint Frazier",team:"Yankees",note:""},
  "131": {player:"Luke Voit",team:"Yankees",note:""},
  "132": {player:"Jose Martinez",team:"Cardinals",note:""},
  "133": {player:"Buster Posey",team:"Giants",note:""},
  "134": {player:"Willie Calhoun",team:"Rangers",note:""},
  "135": {player:"Raimel Tapia",team:"Rockies",note:""},
  "136": {player:"Cesar Hernandez",team:"Phillies",note:""},
  "137": {player:"Rio Ruiz",team:"Orioles",note:""},
  "138": {player:"Kyle Seager",team:"Mariners",note:""},
  "139": {player:"Kevin Newman",team:"Pirates",note:""},
  "140": {player:"Nathan Eovaldi",team:"Red Sox",note:""},
  "141": {player:"Brandon Belt",team:"Giants",note:""},
  "142": {player:"Javier Baez",team:"Cubs",note:""},
  "143": {player:"Ildemaro Vargas",team:"Diamondbacks",note:""},
  "144": {player:"Miguel Rojas",team:"Marlins",note:""},
  "145": {player:"Rafael Devers",team:"Red Sox",note:""},
  "146": {player:"Mallex Smith",team:"Mariners",note:""},
  "147": {player:"Tyler Naquin",team:"Indians",note:""},
  "148": {player:"Adam Plutko",team:"Indians",note:""},
  "149": {player:"Zack Greinke",team:"Astros",note:""},
  "150": {player:"Shane Greene",team:"Braves",note:""},
  "151": {player:"Jon Gray",team:"Rockies",note:""},
  "152": {player:"Matt Thaiss / Patrick Sandoval",team:"Angels",note:"RC"},
  "153": {player:"Sandy Alcantara",team:"Marlins",note:""},
  "154": {player:"Trea Turner",team:"Nationals",note:""},
  "155": {player:"Jarlin Garcia",team:"Marlins",note:""},
  "156": {player:"Ranger Suarez",team:"Phillies",note:""},
  "157": {player:"Ben Gamel",team:"Brewers",note:""},
  "158": {player:"Daniel Murphy",team:"Rockies",note:""},
  "159": {player:"Garrett Cooper",team:"Marlins",note:""},
  "160": {player:"Domingo Santana",team:"Mariners",note:""},
  "161": {player:"Brendan McKay / Mike Brosseau",team:"Rays",note:"RC"},
  "162": {player:"David Price",team:"Red Sox",note:""},
  "163": {player:"Tyler Beede",team:"Giants",note:""},
  "164": {player:"Sam Coonrod",team:"Giants",note:""},
  "165": {player:"Kurt Suzuki",team:"Nationals",note:""},
  "166": {player:"Joe Panik",team:"Mets",note:""},
  "167": {player:"Max Muncy",team:"Dodgers",note:""},
  "168": {player:"Ken Giles",team:"Blue Jays",note:""},
  "169": {player:"Lance Lynn",team:"Rangers",note:""},
  "170": {player:"Justin Wilson",team:"Mets",note:""},
  "171": {player:"Andrew Stevenson",team:"Nationals",note:""},
  "172": {player:"Pedro Baez",team:"Dodgers",note:""},
  "173": {player:"Trevor Richards",team:"Rays",note:""},
  "174": {player:"Christian Yelich",team:"Brewers",note:""},
  "175": {player:"Danny Santana",team:"Rangers",note:""},
  "176": {player:"Dinelson Lamet",team:"Padres",note:""},
  "177": {player:"Welington Castillo",team:"White Sox",note:""},
  "178": {player:"Brandon Crawford",team:"Giants",note:""},
  "179": {player:"Austin Dean",team:"Marlins",note:""},
  "180": {player:"Byron Buxton",team:"Twins",note:""},
  "181": {player:"Brock Burke / Nick Solak",team:"Rangers",note:"RC"},
  "182": {player:"Chris Paddack",team:"Padres",note:""},
  "183": {player:"Ketel Marte",team:"Diamondbacks",note:""},
  "184": {player:"Manny Margot",team:"Padres",note:""},
  "185": {player:"Luis Severino",team:"Yankees",note:""},
  "186": {player:"Nelson Cruz",team:"Twins",note:""},
  "187": {player:"John Gant",team:"Cardinals",note:""},
  "188": {player:"Gavin Lux / Dustin May",team:"Dodgers",note:"RC"},
  "189": {player:"Leury Garcia",team:"White Sox",note:""},
  "190": {player:"Ronald Guzman",team:"Rangers",note:""},
  "191": {player:"Francisco Mejia",team:"Padres",note:""},
  "192": {player:"Victor Reyes",team:"Tigers",note:""},
  "193": {player:"Brandon Nimmo",team:"Mets",note:""},
  "194": {player:"Craig Kimbrel",team:"Cubs",note:""},
  "195": {player:"Gleyber goes off",team:"Yankees",note:"Highlight"},
  "196": {player:"Correa walks off",team:"Astros",note:"Highlight"},
  "197": {player:"Cole train",team:"Astros",note:"Highlight"},
  "198": {player:"Springer / Correa",team:"Astros",note:"Highlight"},
  "199": {player:"Paxton outduels JV",team:"Yankees",note:"Highlight"},
  "200": {player:"Altuve Walk-off!",team:"Astros",note:"Highlight"},
  "201": {player:"Astros Celebrate!",team:"Astros",note:"Highlight"},
  "202": {player:"Anibal Sanchez near no-no",team:"Nationals",note:"Highlight"},
  "203": {player:"Max's masterpiece",team:"Nationals",note:"Highlight"},
  "204": {player:"Strasburg unstoppable",team:"Nationals",note:"Highlight"},
  "205": {player:"Corbin finishes sweep",team:"Nationals",note:"Highlight"},
  "206": {player:"Nationals Celebrate!",team:"Nationals",note:"Highlight"},
  "207": {player:"Travis d'Arnaud",team:"Rays",note:""},
  "208": {player:"Juan Lagares",team:"Mets",note:""},
  "209": {player:"Austin Slater",team:"Giants",note:""},
  "210": {player:"Ian Kinsler",team:"Padres",note:""},
  "211": {player:"Cam Bedrosian",team:"Angels",note:""},
  "212": {player:"Teoscar Hernandez",team:"Blue Jays",note:""},
  "213": {player:"Ian Kennedy",team:"Royals",note:""},
  "214": {player:"Griffin Canning",team:"Angels",note:""},
  "215": {player:"Justin Upton",team:"Angels",note:""},
  "216": {player:"Junior Fernandez / Randy Arozarena",team:"Cardinals",note:"RC"},
  "217": {player:"Archie Bradley",team:"Diamondbacks",note:""},
  "218": {player:"Lourdes Gurriel Jr.",team:"Blue Jays",note:""},
  "219": {player:"Danny Jansen",team:"Blue Jays",note:""},
  "220": {player:"Nate Lowe",team:"Rays",note:""},
  "221": {player:"Jacob Stallings",team:"Pirates",note:""},
  "222": {player:"Anthony DeSclafani",team:"Reds",note:""},
  "223": {player:"Jordan Hicks",team:"Cardinals",note:""},
  "224": {player:"Joc Pederson",team:"Dodgers",note:""},
  "225": {player:"Zach Davies",team:"Brewers",note:""},
  "226": {player:"Ji-Man Choi",team:"Rays",note:""},
  "227": {player:"Drew VerHagen",team:"Tigers",note:""},
  "228": {player:"Mike Fiers",team:"Athletics",note:""},
  "229": {player:"Dakota Hudson",team:"Cardinals",note:""},
  "230": {player:"Patrick Corbin",team:"Nationals",note:""},
  "231": {player:"Yu Chang / Logan Allen",team:"Indians",note:"RC"},
  "232": {player:"Joe Musgrove",team:"Pirates",note:""},
  "233": {player:"Joey Gallo",team:"Rangers",note:""},
  "234": {player:"Jose Osuna",team:"Pirates",note:""},
  "235": {player:"Mike Freeman",team:"Indians",note:""},
  "236": {player:"Jorge Polanco",team:"Twins",note:""},
  "237": {player:"Mychal Givens",team:"Orioles",note:""},
  "238": {player:"Jose Berrios",team:"Twins",note:""},
  "239": {player:"Jose Peraza",team:"Reds",note:""},
  "240": {player:"Brian Anderson",team:"Marlins",note:""},
  "241": {player:"Willson Contreras",team:"Cubs",note:""},
  "242": {player:"Michael Lorenzen",team:"Reds",note:""},
  "243": {player:"Aaron Sanchez",team:"Astros",note:""},
  "244": {player:"George Springer",team:"Astros",note:""},
  "245": {player:"Mike Soroka",team:"Braves",note:""},
  "246": {player:"Jesus Aguilar",team:"Marlins",note:""},
  "247": {player:"Josh Staumont / Bubba Starling",team:"Royals",note:"RC"},
  "248": {player:"Sean Manaea",team:"Athletics",note:""},
  "249": {player:"Jackie Bradley Jr.",team:"Red Sox",note:""},
  "250": {player:"Erick Fedde",team:"Nationals",note:""},
  "251": {player:"Ryan Zimmerman",team:"Nationals",note:""},
  "252": {player:"Nick Wittgren",team:"Indians",note:""},
  "253": {player:"Joe Jimenez",team:"Tigers",note:""},
  "254": {player:"Zach Plesac",team:"Indians",note:""},
  "255": {player:"Brandon Lowe",team:"Rays",note:""},
  "256": {player:"Brad Peacock",team:"Astros",note:""},
  "257": {player:"Cody Bellinger",team:"Dodgers",note:""},
  "258": {player:"Brad Keller",team:"Royals",note:""},
  "259": {player:"Lewis Brinson",team:"Marlins",note:""},
  "260": {player:"Ryan Pressly",team:"Astros",note:""},
  "261": {player:"Jack Flaherty",team:"Cardinals",note:""},
  "262": {player:"Michel Baez / Andres Munoz",team:"Padres",note:"RC"},
  "263": {player:"Freddie Freeman",team:"Braves",note:""},
  "264": {player:"Jose Altuve",team:"Astros",note:""},
  "265": {player:"Keone Kela",team:"Pirates",note:""},
  "266": {player:"Delino DeShields Jr.",team:"Rangers",note:""},
  "267": {player:"Ryan Yarbrough",team:"Rays",note:""},
  "268": {player:"Tommy Pham",team:"Padres",note:""},
  "269": {player:"John Means",team:"Orioles",note:""},
  "270": {player:"Raisel Iglesias",team:"Reds",note:""},
  "271": {player:"Andrew Cashner",team:"Red Sox",note:""},
  "272": {player:"Eugenio Suarez",team:"Reds",note:""},
  "273": {player:"Gregory Polanco",team:"Pirates",note:""},
  "274": {player:"Wilmer Flores",team:"Diamondbacks",note:""},
  "275": {player:"Franmil Reyes",team:"Indians",note:""},
  "276": {player:"Logan Webb / Tyler Rogers",team:"Giants",note:"RC"},
  "277": {player:"Richie Martin",team:"Orioles",note:""},
  "278": {player:"Wilson Ramos",team:"Mets",note:""},
  "279": {player:"Starlin Castro",team:"Marlins",note:""},
  "280": {player:"Kirby Yates",team:"Padres",note:""},
  "281": {player:"Enrique Hernandez",team:"Dodgers",note:""},
  "282": {player:"Randal Grichuk",team:"Blue Jays",note:""},
  "283": {player:"Eric Hosmer",team:"Padres",note:""},
  "284": {player:"Mike Minor",team:"Rangers",note:""},
  "285": {player:"Will Smith",team:"Dodgers",note:""},
  "286": {player:"Ozzie Albies",team:"Braves",note:""},
  "287": {player:"Jake Arrieta",team:"Phillies",note:""},
  "288": {player:"Miles Mikolas",team:"Cardinals",note:""},
  "289": {player:"Willy Adames",team:"Rays",note:""},
  "290": {player:"Ian Desmond",team:"Rockies",note:""},
  "291": {player:"Kris Bryant",team:"Cubs",note:""},
  "292": {player:"Luis Arraez",team:"Twins",note:""},
  "293": {player:"Mike Leake",team:"Diamondbacks",note:""},
  "294": {player:"Trent Thornton",team:"Blue Jays",note:""},
  "295": {player:"Zach Eflin",team:"Phillies",note:""},
  "296": {player:"Eric Lauer",team:"Padres",note:""},
  "297": {player:"Brandon Workman",team:"Red Sox",note:""},
  "298": {player:"Ryan McMahon",team:"Rockies",note:""},
  "299": {player:"Cam Gallagher",team:"Royals",note:""},
  "300": {player:"Renato Nunez",team:"Orioles",note:""},
  "301": {player:"Freddy Galvis",team:"Reds",note:""},
  "302": {player:"Phil Ervin",team:"Reds",note:""},
  "303": {player:"Masahiro Tanaka",team:"Yankees",note:""},
  "304": {player:"Tommy Edman",team:"Cardinals",note:""},
  "305": {player:"Nicky Lopez",team:"Royals",note:""},
  "306": {player:"Nomar Mazara",team:"Rangers",note:""},
  "307": {player:"Kolby Allard",team:"Rangers",note:""},
  "308": {player:"Manny Machado",team:"Padres",note:""},
  "309": {player:"Martin Perez",team:"Twins",note:""},
  "310": {player:"Michael Conforto",team:"Mets",note:""},
  "311": {player:"Chris Archer",team:"Pirates",note:""},
  "312": {player:"Carlos Correa",team:"Astros",note:""},
  "313": {player:"Thairo Estrada",team:"Yankees",note:""},
  "314": {player:"Kenta Maeda",team:"Dodgers",note:""},
  "315": {player:"Luke Weaver",team:"Diamondbacks",note:""},
  "316": {player:"Nick Anderson",team:"Rays",note:""},
  "317": {player:"Jesus Luzardo / Seth Brown / A.J. Puk",team:"Athletics",note:"RC"},
  "318": {player:"Andrew Heaney",team:"Angels",note:""},
  "319": {player:"Kevin Kiermaier",team:"Rays",note:""},
  "320": {player:"Adam Eaton",team:"Nationals",note:""},
  "321": {player:"Ryan Braun",team:"Brewers",note:""},
  "322": {player:"Nolan Arenado",team:"Rockies",note:""},
  "323": {player:"Edwin Diaz",team:"Mets",note:""},
  "324": {player:"Jose Ramirez",team:"Indians",note:""},
  "325": {player:"Jason Kipnis",team:"Indians",note:""},
  "326": {player:"Austin Hays",team:"Orioles",note:""},
  "327": {player:"Soto blast",team:"Nationals",note:"World Series Highlight"},
  "328": {player:"Kurt Suzuki starts rally",team:"Nationals",note:"World Series Highlight"},
  "329": {player:"Greinke K's 6",team:"Nationals",note:"World Series Highlight"},
  "330": {player:"Bregman grand slam",team:"Astros",note:"World Series Highlight"},
  "331": {player:"Cole comes up huge",team:"Astros",note:"World Series Highlight"},
  "332": {player:"Stephen Strasburg deals",team:"Nationals",note:"World Series Highlight"},
  "333": {player:"Howie Kendrick plays hero",team:"Nationals",note:"World Series Highlight"},
  "334": {player:"Nationals Celebrate!",team:"Nationals",note:"World Series Highlight"},
  "335": {player:"Sean Murphy",team:"Athletics",note:""},
  "336": {player:"Shin-Soo Choo",team:"Rangers",note:""},
  "337": {player:"Jake Marisnick",team:"Astros",note:""},
  "338": {player:"Hector Neris",team:"Phillies",note:""},
  "339": {player:"Sean Doolittle",team:"Nationals",note:""},
  "340": {player:"CC Sabathia",team:"Yankees",note:""},
  "341": {player:"Mike Clevinger",team:"Indians",note:""},
  "342": {player:"Jake Junis",team:"Royals",note:""},
  "343": {player:"Josh Sborz / Tony Gonsolin",team:"Dodgers",note:"RC"},
  "344": {player:"Reynaldo Lopez",team:"White Sox",note:""},
  "345": {player:"Xander Bogaerts",team:"Red Sox",note:""},
  "346": {player:"Trey Mancini",team:"Orioles",note:""},
  "347": {player:"Jurickson Profar",team:"Padres",note:""},
  "348": {player:"Chad Pinder",team:"Athletics",note:""},
  "349": {player:"C.J. Cron",team:"Twins",note:""},
  "350": {player:"Trevor Story",team:"Rockies",note:""},
  "351": {player:"Ty France",team:"Padres",note:""},
  "352": {player:"Mike Tauchman",team:"Yankees",note:""},
  "353": {player:"J.P. Crawford",team:"Mariners",note:""},
  "354": {player:"Yoan Moncada",team:"White Sox",note:""},
  "355": {player:"Amed Rosario",team:"Mets",note:""},
  "356": {player:"Jordan Luplow",team:"Indians",note:""},
  "357": {player:"Chance Sisco",team:"Orioles",note:""},
  "358": {player:"Mike Ford",team:"Yankees",note:""},
  "359": {player:"Roberto Perez",team:"Indians",note:""},
  "360": {player:"Andrelton Simmons",team:"Angels",note:""},
  "361": {player:"Merrill Kelly",team:"Diamondbacks",note:""},
  "362": {player:"Dillon Tate / Hunter Harvey",team:"Orioles",note:"RC"},
  "363": {player:"Josh Naylor",team:"Padres",note:""},
  "364": {player:"Alex Dickerson",team:"Giants",note:""},
  "365": {player:"Tyler Glasnow",team:"Rays",note:""},
  "366": {player:"Jake Lamb",team:"Diamondbacks",note:""},
  "367": {player:"Gerrit Cole",team:"Yankees",note:""},
  "368": {player:"Junior Guerra",team:"Brewers",note:""},
  "369": {player:"Jordan Yamamoto / Isan Diaz",team:"Marlins",note:"RC"},
  "370": {player:"Matt Carpenter",team:"Cardinals",note:""},
  "371": {player:"Adam Haseley",team:"Phillies",note:""},
  "372": {player:"Yolmer Sanchez",team:"White Sox",note:""},
  "373": {player:"Anthony Rizzo",team:"Cubs",note:""},
  "374": {player:"Brandon Woodruff",team:"Brewers",note:""},
  "375": {player:"Hansel Robles",team:"Angels",note:""},
  "376": {player:"T.J. Zeuch / Jordan Romano",team:"Blue Jays",note:"RC"},
  "377": {player:"Alex Colome",team:"White Sox",note:""},
  "378": {player:"Tyler Chatwood",team:"Cubs",note:""},
  "379": {player:"Rowdy Tellez",team:"Blue Jays",note:""},
  "380": {player:"Mark Melancon",team:"Braves",note:""},
  "381": {player:"Darwinzon Hernandez",team:"Red Sox",note:""},
  "382": {player:"Austin Romine",team:"Yankees",note:""},
  "383": {player:"Bryan Reynolds",team:"Pirates",note:""},
  "384": {player:"Chase Anderson",team:"Blue Jays",note:""},
  "385": {player:"Clayton Kershaw",team:"Dodgers",note:""},
  "386": {player:"Dominic Smith",team:"Mets",note:""},
  "387": {player:"Matt Boyd",team:"Tigers",note:""},
  "388": {player:"Niko Goodrum",team:"Tigers",note:""},
  "389": {player:"Ian Happ",team:"Cubs",note:""},
  "390": {player:"Dansby Swanson",team:"Braves",note:""},
  "391": {player:"Justin Dunn / Austin Nola / Kyle Lewis",team:"Mariners",note:"RC"},
  "392": {player:"Freddy Peralta",team:"Brewers",note:""},
  "393": {player:"Anthony Santander",team:"Orioles",note:""},
  "394": {player:"Kevin Pillar",team:"Giants",note:""},
  "395": {player:"Aaron Judge",team:"Yankees",note:""},
  "396": {player:"Hanser Alberto",team:"Orioles",note:""},
  "397": {player:"Eric Thames",team:"Brewers",note:""},
  "398": {player:"Luis Urias",team:"Padres",note:""},
  "399": {player:"Jeff Samardzija",team:"Giants",note:""},
  "400": {player:"Yadier Molina",team:"Cardinals",note:""},
  "401": {player:"Elvis Andrus",team:"Rangers",note:"SP"},
  "402": {player:"Jorge Alfaro",team:"Marlins",note:"SP"},
  "403": {player:"Juan Soto",team:"Nationals",note:"SP"},
  "404": {player:"Marwin Gonzalez",team:"Twins",note:"SP"},
  "405": {player:"Dee Gordon",team:"Mariners",note:"SP"},
  "406": {player:"Jacob deGrom",team:"Mets",note:"SP"},
  "407": {player:"Matt Olson",team:"Athletics",note:"SP"},
  "408": {player:"Yusei Kikuchi",team:"Mariners",note:"SP"},
  "409": {player:"Kyle Schwarber",team:"Cubs",note:"SP"},
  "410": {player:"Corey Seager",team:"Dodgers",note:"SP"},
  "411": {player:"Alex Gordon",team:"Royals",note:"SP"},
  "412": {player:"A.J. Pollock",team:"Dodgers",note:"SP"},
  "413": {player:"Keston Hiura",team:"Brewers",note:"SP"},
  "414": {player:"Vladimir Guerrero Jr.",team:"Blue Jays",note:"SP"},
  "415": {player:"DJ LeMahieu",team:"Yankees",note:"SP"},
  "416": {player:"Lucas Giolito",team:"White Sox",note:"SP"},
  "417": {player:"Blake Snell",team:"Rays",note:"SP"},
  "418": {player:"Justus Sheffield",team:"Mariners",note:"SP"},
  "419": {player:"Andrew Benintendi",team:"Red Sox",note:"SP"},
  "420": {player:"Charlie Blackmon",team:"Rockies",note:"SP"},
  "421": {player:"Stephen Piscotty",team:"Athletics",note:"SP"},
  "422": {player:"Josh Bell",team:"Pirates",note:"SP"},
  "423": {player:"J.D. Martinez",team:"Red Sox",note:"SP"},
  "424": {player:"Yasmani Grandal",team:"White Sox",note:"SP"},
  "425": {player:"Michael Brantley",team:"Astros",note:"SP"},
  "426": {player:"Mike Yastrzemski",team:"Giants",note:"SP"},
  "427": {player:"Jason Heyward",team:"Cubs",note:"SP"},
  "428": {player:"Noah Syndergaard",team:"Mets",note:"SP"},
  "429": {player:"Giovanny Gallegos",team:"Cardinals",note:"SP"},
  "430": {player:"Sean Newcomb",team:"Braves",note:"SP"},
  "431": {player:"Robbie Ray",team:"Diamondbacks",note:"SP"},
  "432": {player:"Eddie Rosario",team:"Twins",note:"SP"},
  "433": {player:"Shohei Ohtani",team:"Angels",note:"SP"},
  "434": {player:"Dwight Smith Jr.",team:"Orioles",note:"SP"},
  "435": {player:"Lorenzo Cain",team:"Brewers",note:"SP"},
  "436": {player:"Tim Anderson",team:"White Sox",note:"SP"},
  "437": {player:"Fernando Tatis Jr.",team:"Padres",note:"SP"},
  "438": {player:"German Marquez",team:"Rockies",note:"SP"},
  "439": {player:"Luis Castillo",team:"Reds",note:"SP"},
  "440": {player:"Jonathan Villar",team:"Marlins",note:"SP"},
  "441": {player:"Miguel Sano",team:"Twins",note:"SP"},
  "442": {player:"Francisco Lindor",team:"Indians",note:"SP"},
  "443": {player:"Giancarlo Stanton",team:"Yankees",note:"SP"},
  "444": {player:"Kyle Hendricks",team:"Cubs",note:"SP"},
  "445": {player:"J.D. Davis",team:"Mets",note:"SP"},
  "446": {player:"Jose Leclerc",team:"Rangers",note:"SP"},
  "447": {player:"Bryce Harper",team:"Phillies",note:"SP"},
  "448": {player:"Amir Garrett",team:"Reds",note:"SP"},
  "449": {player:"Jon Duplantier",team:"Diamondbacks",note:"SP"},
  "450": {player:"Carlos Martinez",team:"Cardinals",note:"SP"},
  "451": {player:"Chris Sale",team:"Red Sox",note:"SP"},
  "452": {player:"David Peralta",team:"Diamondbacks",note:"SP"},
  "453": {player:"Alex Bregman",team:"Astros",note:"SP"},
  "454": {player:"Shane Bieber",team:"Indians",note:"SP"},
  "455": {player:"Sonny Gray",team:"Reds",note:"SP"},
  "456": {player:"Andrew McCutchen",team:"Phillies",note:"SP"},
  "457": {player:"Pete Alonso",team:"Mets",note:"SP"},
  "458": {player:"Jean Segura",team:"Phillies",note:"SP"},
  "459": {player:"Alex Verdugo",team:"Dodgers",note:"SP"},
  "460": {player:"Zack Britton",team:"Yankees",note:"SP"},
  "461": {player:"Daniel Vogelbach",team:"Mariners",note:"SP"},
  "462": {player:"Starling Marte",team:"Pirates",note:"SP"},
  "463": {player:"Kole Calhoun",team:"Angels",note:"SP"},
  "464": {player:"Ronald Acuna Jr.",team:"Braves",note:"SP"},
  "465": {player:"Max Fried",team:"Braves",note:"SP"},
  "466": {player:"Mike Trout",team:"Angels",note:"SP"},
  "467": {player:"Paul Goldschmidt",team:"Cardinals",note:"SP"},
  "468": {player:"Matt Chapman",team:"Athletics",note:"SP"},
  "469": {player:"Julio Urias",team:"Dodgers",note:"SP"},
  "470": {player:"Ryan O'Hearn",team:"Royals",note:"SP"},
  "471": {player:"Christian Vazquez",team:"Red Sox",note:"SP"},
  "472": {player:"Liam Hendriks",team:"Athletics",note:"SP"},
  "473": {player:"Justin Verlander",team:"Astros",note:"SP"},
  "474": {player:"Eduardo Escobar",team:"Diamondbacks",note:"SP"},
  "475": {player:"Yu Darvish",team:"Cubs",note:"SP"},
  "476": {player:"Paul DeJong",team:"Cardinals",note:"SP"},
  "477": {player:"Hunter Renfroe",team:"Rays",note:"SP"},
  "478": {player:"David Dahl",team:"Rockies",note:"SP"},
  "479": {player:"Max Kepler",team:"Twins",note:"SP"},
  "480": {player:"James Paxton",team:"Yankees",note:"SP"},
  "481": {player:"Austin Meadows",team:"Rays",note:"SP"},
  "482": {player:"Nick Senzel",team:"Reds",note:"SP"},
  "483": {player:"Gleyber Torres",team:"Yankees",note:"SP"},
  "484": {player:"Aroldis Chapman",team:"Yankees",note:"SP"},
  "485": {player:"David Fletcher",team:"Angels",note:"SP"},
  "486": {player:"Jon Lester",team:"Cubs",note:"SP"},
  "487": {player:"Hunter Dozier",team:"Royals",note:"SP"},
  "488": {player:"Christian Walker",team:"Diamondbacks",note:"SP"},
  "489": {player:"Aaron Hicks",team:"Yankees",note:"SP"},
  "490": {player:"Rhys Hoskins",team:"Phillies",note:"SP"},
  "491": {player:"Austin Riley",team:"Braves",note:"SP"},
  "492": {player:"Jeff McNeil",team:"Mets",note:"SP"},
  "493": {player:"Mookie Betts",team:"Red Sox",note:"SP"},
  "494": {player:"Eloy Jimenez",team:"White Sox",note:"SP"},
  "495": {player:"Ramon Laureano",team:"Athletics",note:"SP"},
  "496": {player:"Walker Buehler",team:"Dodgers",note:"SP"},
  "497": {player:"Victor Robles",team:"Nationals",note:"SP"},
  "498": {player:"Charlie Morton",team:"Rays",note:"SP"},
  "499": {player:"Roberto Osuna",team:"Astros",note:"SP"},
  "500": {player:"Michael Chavis",team:"Red Sox",note:"SP"}
};
CARD_NAMES["Allen & Ginter"] = {
    "1": {player:"Tom Glavine",team:"Braves",note:""},
    "2": {player:"Randy Johnson",team:"Diamondbacks",note:""},
    "3": {player:"Paul Goldschmidt",team:"Cardinals",note:""},
    "4": {player:"Larry Doby",team:"Indians",note:""},
    "5": {player:"Walker Buehler",team:"Dodgers",note:""},
    "6": {player:"John Smoltz",team:"Braves",note:""},
    "7": {player:"Tim Lincecum",team:"Giants",note:""},
    "8": {player:"Jeff Bagwell",team:"Astros",note:""},
    "9": {player:"Rhys Hoskins",team:"Phillies",note:""},
    "10": {player:"Rod Carew",team:"Angels",note:""},
    "11": {player:"Lou Gehrig",team:"Yankees",note:""},
    "12": {player:"George Springer",team:"Astros",note:""},
    "13": {player:"Aaron Judge",team:"Yankees",note:""},
    "14": {player:"Aaron Nola",team:"Phillies",note:""},
    "15": {player:"Kris Bryant",team:"Cubs",note:""},
    "16": {player:"Bryce Harper",team:"Phillies",note:""},
    "17": {player:"Ken Griffey Jr.",team:"Mariners",note:""},
    "18": {player:"George Brett",team:"Royals",note:""},
    "19": {player:"Keston Hiura",team:"Brewers",note:""},
    "20": {player:"Joe Mauer",team:"Twins",note:""},
    "21": {player:"Ted Williams",team:"Red Sox",note:""},
    "22": {player:"Eddie Mathews",team:"Braves",note:""},
    "23": {player:"Jorge Soler",team:"Royals",note:""},
    "24": {player:"Shohei Ohtani",team:"Angels",note:""},
    "25": {player:"Carl Yastrzemski",team:"Red Sox",note:""},
    "26": {player:"Willie McCovey",team:"Giants",note:""},
    "27": {player:"Joe Morgan",team:"Reds",note:""},
    "28": {player:"Juan Soto",team:"Nationals",note:""},
    "29": {player:"Willie Mays",team:"Giants",note:""},
    "30": {player:"Eloy Jimenez",team:"White Sox",note:""},
    "31": {player:"Babe Ruth",team:"Yankees",note:""},
    "32": {player:"Ichiro",team:"Mariners",note:""},
    "33": {player:"Edgar Martinez",team:"Mariners",note:""},
    "34": {player:"Pete Alonso",team:"Mets",note:""},
    "35": {player:"Rickey Henderson",team:"Athletics",note:""},
    "36": {player:"Alex Bregman",team:"Astros",note:""},
    "37": {player:"Mike Mussina",team:"Orioles",note:""},
    "38": {player:"Miguel Cabrera",team:"Tigers",note:""},
    "39": {player:"Andy Pettitte",team:"Yankees",note:""},
    "40": {player:"Mariano Rivera",team:"Yankees",note:""},
    "41": {player:"David Ortiz",team:"Red Sox",note:""},
    "42": {player:"Jackie Robinson",team:"Dodgers",note:""},
    "43": {player:"Matt Chapman",team:"Athletics",note:""},
    "44": {player:"Rafael Devers",team:"Red Sox",note:""},
    "45": {player:"Yoan Moncada",team:"White Sox",note:""},
    "46": {player:"Pedro Martinez",team:"Expos",note:""},
    "47": {player:"Freddie Freeman",team:"Braves",note:""},
    "48": {player:"Ketel Marte",team:"Diamondbacks",note:""},
    "49": {player:"Roger Clemens",team:"Yankees",note:""},
    "50": {player:"Vladimir Guerrero Jr.",team:"Blue Jays",note:""},
    "51": {player:"Roberto Clemente",team:"Pirates",note:""},
    "52": {player:"Ivan Rodriguez",team:"Rangers",note:""},
    "53": {player:"Mike Soroka",team:"Braves",note:""},
    "54": {player:"Victor Robles",team:"Nationals",note:""},
    "55": {player:"Nick Senzel",team:"Reds",note:""},
    "56": {player:"Ozzie Albies",team:"Braves",note:""},
    "57": {player:"Eddie Murray",team:"Orioles",note:""},
    "58": {player:"Christian Yelich",team:"Brewers",note:""},
    "59": {player:"Duke Snider",team:"Dodgers",note:""},
    "60": {player:"Steve Carlton",team:"Phillies",note:""},
    "61": {player:"Jim Thome",team:"Indians",note:""},
    "62": {player:"Whitey Ford",team:"Yankees",note:""},
    "63": {player:"Marcus Semien",team:"Athletics",note:""},
    "64": {player:"Andre Dawson",team:"Cubs",note:""},
    "65": {player:"Cody Bellinger",team:"Dodgers",note:""},
    "66": {player:"Darryl Strawberry",team:"Mets",note:""},
    "67": {player:"Mookie Betts",team:"Dodgers",note:""},
    "68": {player:"Nomar Garciaparra",team:"Red Sox",note:""},
    "69": {player:"Al Kaline",team:"Tigers",note:""},
    "70": {player:"Don Mattingly",team:"Yankees",note:""},
    "71": {player:"Vladimir Guerrero",team:"Expos",note:""},
    "72": {player:"Johnny Bench",team:"Reds",note:""},
    "73": {player:"Mark McGwire",team:"Athletics",note:""},
    "74": {player:"Ty Cobb",team:"Tigers",note:""},
    "75": {player:"Joey Votto",team:"Reds",note:""},
    "76": {player:"Chipper Jones",team:"Braves",note:""},
    "77": {player:"Javier Baez",team:"Cubs",note:""},
    "78": {player:"Xander Bogaerts",team:"Red Sox",note:""},
    "79": {player:"Sandy Koufax",team:"Dodgers",note:""},
    "80": {player:"DJ LeMahieu",team:"Yankees",note:""},
    "81": {player:"Barry Zito",team:"Athletics",note:""},
    "82": {player:"Andrew Benintendi",team:"Red Sox",note:""},
    "83": {player:"J.D. Martinez",team:"Red Sox",note:""},
    "84": {player:"Clayton Kershaw",team:"Dodgers",note:""},
    "85": {player:"Mike Trout",team:"Angels",note:""},
    "86": {player:"Anthony Rizzo",team:"Cubs",note:""},
    "87": {player:"Trevor Story",team:"Rockies",note:""},
    "88": {player:"Ronald Acuna Jr.",team:"Braves",note:""},
    "89": {player:"Paul Molitor",team:"Blue Jays",note:""},
    "90": {player:"Jack Flaherty",team:"Cardinals",note:""},
    "91": {player:"Dave Winfield",team:"Yankees",note:""},
    "92": {player:"Barry Larkin",team:"Reds",note:""},
    "93": {player:"Francisco Lindor",team:"Indians",note:""},
    "94": {player:"Max Fried",team:"Braves",note:""},
    "95": {player:"Manny Machado",team:"Padres",note:""},
    "96": {player:"Frank Thomas",team:"White Sox",note:""},
    "97": {player:"Aristides Aquino",team:"Reds",note:"Rookie"},
    "98": {player:"Cal Ripken Jr.",team:"Orioles",note:""},
    "99": {player:"Gavin Lux",team:"Dodgers",note:"Rookie"},
    "100": {player:"Max Scherzer",team:"Nationals",note:""},
    "101": {player:"Brooks Robinson",team:"Orioles",note:""},
    "102": {player:"Robin Yount",team:"Brewers",note:""},
    "103": {player:"Tim Anderson",team:"White Sox",note:""},
    "104": {player:"Hank Aaron",team:"Braves",note:""},
    "105": {player:"Todd Helton",team:"Rockies",note:""},
    "106": {player:"Willie Stargell",team:"Pirates",note:""},
    "107": {player:"Roger Maris",team:"Yankees",note:""},
    "108": {player:"Gary Carter",team:"Mets",note:""},
    "109": {player:"Reggie Jackson",team:"Yankees",note:""},
    "110": {player:"Albert Pujols",team:"Angels",note:""},
    "111": {player:"Buster Posey",team:"Giants",note:""},
    "112": {player:"Bo Bichette",team:"Blue Jays",note:"Rookie"},
    "113": {player:"Luis Gonzalez",team:"Diamondbacks",note:""},
    "114": {player:"Gleyber Torres",team:"Yankees",note:""},
    "115": {player:"Fernando Tatis Jr.",team:"Padres",note:""},
    "116": {player:"Honus Wagner",team:"Pirates",note:""},
    "117": {player:"Ernie Banks",team:"Cubs",note:""},
    "118": {player:"Yordan Alvarez",team:"Astros",note:"Rookie"},
    "119": {player:"Giancarlo Stanton",team:"Yankees",note:""},
    "120": {player:"Bob Gibson",team:"Cardinals",note:""},
    "121": {player:"Zack Greinke",team:"Astros",note:""},
    "122": {player:"Trea Turner",team:"Nationals",note:""},
    "123": {player:"Mike Piazza",team:"Mets",note:""},
    "124": {player:"Juan Marichal",team:"Giants",note:""},
    "125": {player:"Craig Biggio",team:"Astros",note:""},
    "126": {player:"Wade Boggs",team:"Rays",note:""},
    "127": {player:"Jose Altuve",team:"Astros",note:""},
    "128": {player:"Tony Gwynn",team:"Padres",note:""},
    "129": {player:"Josh Bell",team:"Pirates",note:""},
    "130": {player:"Nolan Arenado",team:"Rockies",note:""},
    "131": {player:"Stan Musial",team:"Cardinals",note:""},
    "132": {player:"Jim Palmer",team:"Orioles",note:""},
    "133": {player:"Justin Verlander",team:"Astros",note:""},
    "134": {player:"Roberto Alomar",team:"Orioles",note:""},
    "135": {player:"Harmon Killebrew",team:"Twins",note:""},
    "136": {player:"Carlos Correa",team:"Astros",note:""},
    "137": {player:"Yadier Molina",team:"Cardinals",note:""},
    "138": {player:"Tom Seaver",team:"Mets",note:""},
    "139": {player:"Nolan Ryan",team:"Angels",note:""},
    "140": {player:"Joe Torre",team:"Cardinals",note:""},
    "141": {player:"Mike Schmidt",team:"Phillies",note:""},
    "142": {player:"Patrick Corbin",team:"Nationals",note:""},
    "143": {player:"Carlton Fisk",team:"Red Sox",note:""},
    "144": {player:"Warren Spahn",team:"Braves",note:""},
    "145": {player:"Alex Rodriguez",team:"Yankees",note:""},
    "146": {player:"Jacob deGrom",team:"Mets",note:""},
    "147": {player:"Jose Berrios",team:"Twins",note:""},
    "148": {player:"David Wright",team:"Mets",note:""},
    "149": {player:"Ryne Sandberg",team:"Cubs",note:""},
    "150": {player:"Ozzie Smith",team:"Cardinals",note:""},
    "151": {player:"Kenley Jansen",team:"Dodgers",note:""},
    "152": {player:"J.K. Dobbins",team:"Football Player",note:"Non-Baseball"},
    "153": {player:"Starling Marte",team:"Diamondbacks",note:""},
    "154": {player:"Tommy La Stella",team:"Angels",note:""},
    "155": {player:"Chip Gaines",team:"Television Personality",note:"Non-Baseball"},
    "156": {player:"Lourdes Gurriel Jr.",team:"Blue Jays",note:""},
    "157": {player:"Jeff McNeil",team:"Mets",note:""},
    "158": {player:"Kwang-Hyun Kim",team:"Cardinals",note:"Rookie"},
    "159": {player:"Kyle Lewis",team:"Mariners",note:"Rookie"},
    "160": {player:"Lorenzo Cain",team:"Brewers",note:""},
    "161": {player:"Jackie Bradley Jr.",team:"Red Sox",note:""},
    "162": {player:"Kyle Tucker",team:"Astros",note:""},
    "163": {player:"Cole Hamels",team:"Braves",note:""},
    "164": {player:"Kolten Wong",team:"Cardinals",note:""},
    "165": {player:"Hugo Juice Tandron",team:"Baseball Barber",note:"Non-Baseball"},
    "166": {player:"Briana Scurry",team:"Soccer Goalkeeper",note:"Non-Baseball"},
    "167": {player:"Ken Jeong",team:"Actor & Comedian",note:"Non-Baseball"},
    "168": {player:"Willson Contreras",team:"Cubs",note:""},
    "169": {player:"Carter Kieboom",team:"Nationals",note:""},
    "170": {player:"Nick Thune",team:"Actor & Comedian",note:"Non-Baseball"},
    "171": {player:"Hunter Pence",team:"Giants",note:""},
    "172": {player:"Baseball Brit",team:"British Baseball Fan",note:"Non-Baseball"},
    "173": {player:"Evan Longoria",team:"Giants",note:""},
    "174": {player:"Anthony Kay",team:"Blue Jays",note:"Rookie"},
    "175": {player:"Kirby Yates",team:"Padres",note:""},
    "176": {player:"Justin Dunn",team:"Mariners",note:"Rookie"},
    "177": {player:"Hunter Harvey",team:"Orioles",note:"Rookie"},
    "178": {player:"Marcell Ozuna",team:"Braves",note:""},
    "179": {player:"Dallas Keuchel",team:"White Sox",note:""},
    "180": {player:"Khris Davis",team:"Athletics",note:""},
    "181": {player:"Adbert Alzolay",team:"Cubs",note:"Rookie"},
    "182": {player:"Kelsey Cook",team:"Comedian & Foosball",note:"Non-Baseball"},
    "183": {player:"Lucas Giolito",team:"White Sox",note:""},
    "184": {player:"Joc Pederson",team:"Dodgers",note:""},
    "185": {player:"Austin Meadows",team:"Rays",note:""},
    "186": {player:"Bryan Reynolds",team:"Pirates",note:""},
    "187": {player:"Masahiro Tanaka",team:"Yankees",note:""},
    "188": {player:"Eugenio Suarez",team:"Reds",note:""},
    "189": {player:"Brandon Lowe",team:"Rays",note:""},
    "190": {player:"Yuli Gurriel",team:"Astros",note:""},
    "191": {player:"Nelson Cruz",team:"Twins",note:""},
    "192": {player:"Jose Abreu",team:"White Sox",note:""},
    "193": {player:"Nyjah Huston",team:"Skateboarder",note:"Non-Baseball"},
    "194": {player:"Mike Doc Emrick",team:"Sports Broadcaster",note:"Non-Baseball"},
    "195": {player:"Robinson Cano",team:"Mets",note:""},
    "196": {player:"Noah Syndergaard",team:"Mets",note:""},
    "197": {player:"Matt Thaiss",team:"Angels",note:"Rookie"},
    "198": {player:"Will Smith",team:"Dodgers",note:""},
    "199": {player:"Nico Hoerner",team:"Cubs",note:"Rookie"},
    "200": {player:"Jim Abbott",team:"Angels",note:""},
    "201": {player:"Sakura Kokumai",team:"Karate Athlete",note:"Non-Baseball"},
    "202": {player:"Tino Martinez",team:"Yankees",note:""},
    "203": {player:"Tony Dunst",team:"Poker Player",note:"Non-Baseball"},
    "204": {player:"Jared Carrabis",team:"Baseball Writer",note:"Non-Baseball"},
    "205": {player:"Salvador Perez",team:"Royals",note:""},
    "206": {player:"C.J. Cron",team:"Tigers",note:""},
    "207": {player:"Brendan McKay",team:"Rays",note:"Rookie"},
    "208": {player:"Mike Moustakas",team:"Reds",note:""},
    "209": {player:"Johnny Bananas",team:"Reality Show Host",note:"Non-Baseball"},
    "210": {player:"Jose Ramirez",team:"Indians",note:""},
    "211": {player:"Ryan Braun",team:"Brewers",note:""},
    "212": {player:"Chris Paddack",team:"Padres",note:""},
    "213": {player:"Oscar Mercado",team:"Indians",note:""},
    "214": {player:"Ryan McMahon",team:"Rockies",note:""},
    "215": {player:"Paul DeJong",team:"Cardinals",note:""},
    "216": {player:"Shun Yamaguchi",team:"Blue Jays",note:"Rookie"},
    "217": {player:"Aaron Wheelz Fotheringham",team:"Wheelchair Motocross",note:"Non-Baseball"},
    "218": {player:"Andrelton Simmons",team:"Angels",note:""},
    "219": {player:"Josh Hader",team:"Brewers",note:""},
    "220": {player:"Eric Hosmer",team:"Padres",note:""},
    "221": {player:"Mike Foltynewicz",team:"Braves",note:""},
    "222": {player:"Isan Diaz",team:"Marlins",note:"Rookie"},
    "223": {player:"Shane Bieber",team:"Indians",note:""},
    "224": {player:"Kole Calhoun",team:"Diamondbacks",note:""},
    "225": {player:"Austin Riley",team:"Braves",note:""},
    "226": {player:"A.J. Puk",team:"Athletics",note:"Rookie"},
    "227": {player:"Max Muncy",team:"Dodgers",note:""},
    "228": {player:"Justine Siegal",team:"Baseball Coach",note:"Non-Baseball"},
    "229": {player:"Jordan Yamamoto",team:"Marlins",note:"Rookie"},
    "230": {player:"Matt Olson",team:"Athletics",note:""},
    "231": {player:"Bucky Lasek",team:"Skateboarder",note:"Non-Baseball"},
    "232": {player:"Dakota Hudson",team:"Cardinals",note:""},
    "233": {player:"Howie Kendrick",team:"Nationals",note:""},
    "234": {player:"Jorge Alfaro",team:"Marlins",note:""},
    "235": {player:"Jesus Luzardo",team:"Athletics",note:"Rookie"},
    "236": {player:"Alex Verdugo",team:"Red Sox",note:""},
    "237": {player:"Nick Ahmed",team:"Diamondbacks",note:""},
    "238": {player:"Gerrit Cole",team:"Yankees",note:""},
    "239": {player:"Kyle Schwarber",team:"Cubs",note:""},
    "240": {player:"Luis Arraez",team:"Twins",note:""},
    "241": {player:"Michael Brantley",team:"Astros",note:""},
    "242": {player:"Andy Cohen",team:"TV & Radio Host",note:"Non-Baseball"},
    "243": {player:"Max Kepler",team:"Twins",note:""},
    "244": {player:"Brandon Woodruff",team:"Brewers",note:""},
    "245": {player:"Josh Donaldson",team:"Twins",note:""},
    "246": {player:"Mike Clevinger",team:"Indians",note:""},
    "247": {player:"Yusei Kikuchi",team:"Mariners",note:""},
    "248": {player:"Rob Friedman",team:"Pitching Analyst",note:"Non-Baseball"},
    "249": {player:"Stephen Strasburg",team:"Nationals",note:""},
    "250": {player:"Charlie Blackmon",team:"Rockies",note:""},
    "251": {player:"Corey Kluber",team:"Rangers",note:""},
    "252": {player:"Steve Byrne",team:"Actor & Comedian",note:"Non-Baseball"},
    "253": {player:"David Price",team:"Dodgers",note:""},
    "254": {player:"Ryan Nyquist",team:"BMX Legend",note:"Non-Baseball"},
    "255": {player:"David Dahl",team:"Rockies",note:""},
    "256": {player:"Luis Robert",team:"White Sox",note:"Rookie"},
    "257": {player:"Corey Seager",team:"Dodgers",note:""},
    "258": {player:"Cavan Biggio",team:"Blue Jays",note:""},
    "259": {player:"Whit Merrifield",team:"Royals",note:""},
    "260": {player:"J.T. Realmuto",team:"Phillies",note:""},
    "261": {player:"Joey Gallo",team:"Rangers",note:""},
    "262": {player:"Zac Gallen",team:"Diamondbacks",note:"Rookie"},
    "263": {player:"Dansby Swanson",team:"Braves",note:""},
    "264": {player:"Abraham Toro",team:"Astros",note:"Rookie"},
    "265": {player:"Tommy Edman",team:"Cardinals",note:""},
    "266": {player:"Didi Gregorius",team:"Phillies",note:""},
    "267": {player:"Elvis Andrus",team:"Rangers",note:""},
    "268": {player:"Eduardo Escobar",team:"Diamondbacks",note:""},
    "269": {player:"Miguel Sano",team:"Twins",note:""},
    "270": {player:"Luis Castillo",team:"Reds",note:""},
    "271": {player:"Michael Conforto",team:"Mets",note:""},
    "272": {player:"Jon Lester",team:"Cubs",note:""},
    "273": {player:"Gregory Polanco",team:"Pirates",note:""},
    "274": {player:"Steven Tefft",team:"Tattoo Artist",note:"Non-Baseball"},
    "275": {player:"Jeff Dye",team:"Actor & Comedian",note:"Non-Baseball"},
    "276": {player:"Jose Urquidy",team:"Astros",note:"Rookie"},
    "277": {player:"John Means",team:"Orioles",note:""},
    "278": {player:"Nick Castellanos",team:"Reds",note:""},
    "279": {player:"Maikel Franco",team:"Royals",note:""},
    "280": {player:"Jean Segura",team:"Phillies",note:""},
    "281": {player:"Derrick Goold",team:"Baseball Writer",note:"Non-Baseball"},
    "282": {player:"Matthew Boyd",team:"Tigers",note:""},
    "283": {player:"Nomar Mazara",team:"White Sox",note:""},
    "284": {player:"Julian Edwards",team:"Actor",note:"Non-Baseball"},
    "285": {player:"Orlando Arcia",team:"Brewers",note:""},
    "286": {player:"Trey Mancini",team:"Orioles",note:""},
    "287": {player:"Aroldis Chapman",team:"Yankees",note:""},
    "288": {player:"Courtney Hansen",team:"Television Host",note:"Non-Baseball"},
    "289": {player:"Anthony Rendon",team:"Angels",note:""},
    "290": {player:"Ramon Laureano",team:"Athletics",note:""},
    "291": {player:"Sonny Gray",team:"Reds",note:""},
    "292": {player:"Hyun-Jin Ryu",team:"Blue Jays",note:""},
    "293": {player:"Daniel Vogelbach",team:"Mariners",note:""},
    "294": {player:"Mauricio Dubon",team:"Giants",note:"Rookie"},
    "295": {player:"Zack Wheeler",team:"Phillies",note:""},
    "296": {player:"Trevor Bauer",team:"Reds",note:""},
    "297": {player:"R.L. Stine",team:"Author",note:"Non-Baseball"},
    "298": {player:"Adalberto Mondesi",team:"Royals",note:""},
    "299": {player:"Blake Snell",team:"Rays",note:""},
    "300": {player:"Andres Munoz",team:"Padres",note:"Rookie"},
    "301": {player:"Tim Raines",team:"Expos",note:"SP"},
    "302": {player:"Thurman Munson",team:"Yankees",note:"SP"},
    "303": {player:"Earl Weaver",team:"Orioles",note:"SP"},
    "304": {player:"Darin Erstad",team:"Angels",note:"SP"},
    "305": {player:"Bill Mazeroski",team:"Pirates",note:"SP"},
    "306": {player:"Moises Alou",team:"Astros",note:"SP"},
    "307": {player:"Miguel Tejada",team:"Orioles",note:"SP"},
    "308": {player:"Phil Rizzuto",team:"Yankees",note:"SP"},
    "309": {player:"Alan Trammell",team:"Tigers",note:"SP"},
    "310": {player:"Sean Casey",team:"Reds",note:"SP"},
    "311": {player:"Bert Blyleven",team:"Twins",note:"SP"},
    "312": {player:"Dennis Eckersley",team:"Athletics",note:"SP"},
    "313": {player:"Fred McGriff",team:"Blue Jays",note:"SP"},
    "314": {player:"Dwight Gooden",team:"Mets",note:"SP"},
    "315": {player:"Juan Gonzalez",team:"Rangers",note:"SP"},
    "316": {player:"Billy Williams",team:"Cubs",note:"SP"},
    "317": {player:"Cecil Fielder",team:"Tigers",note:"SP"},
    "318": {player:"Andruw Jones",team:"Braves",note:"SP"},
    "319": {player:"Tony LaRussa",team:"Athletics",note:"SP"},
    "320": {player:"Orlando Cepeda",team:"Giants",note:"SP"},
    "321": {player:"Trevor Hoffman",team:"Padres",note:"SP"},
    "322": {player:"Catfish Hunter",team:"Athletics",note:"SP"},
    "323": {player:"Bernie Williams",team:"Yankees",note:"SP"},
    "324": {player:"Lou Brock",team:"Cardinals",note:"SP"},
    "325": {player:"Mark Grace",team:"Diamondbacks",note:"SP"},
    "326": {player:"Monte Irvin",team:"Giants",note:"SP"},
    "327": {player:"Jose Canseco",team:"Rays",note:"SP"},
    "328": {player:"Bobby Doerr",team:"Red Sox",note:"SP"},
    "329": {player:"Ryan Howard",team:"Phillies",note:"SP"},
    "330": {player:"Bob Feller",team:"Indians",note:"SP"},
    "331": {player:"Gary Sheffield",team:"Marlins",note:"SP"},
    "332": {player:"Shawn Green",team:"Dodgers",note:"SP"},
    "333": {player:"Kenny Lofton",team:"Indians",note:"SP"},
    "334": {player:"Rollie Fingers",team:"Brewers",note:"SP"},
    "335": {player:"Tony Perez",team:"Reds",note:"SP"},
    "336": {player:"Jermaine Dye",team:"Royals",note:"SP"},
    "337": {player:"Ralph Kiner",team:"Pirates",note:"SP"},
    "338": {player:"Fergie Jenkins",team:"Cubs",note:"SP"},
    "339": {player:"Kerry Wood",team:"Cubs",note:"SP"},
    "340": {player:"Magglio Ordonez",team:"White Sox",note:"SP"},
    "341": {player:"Jim Bunning",team:"Tigers",note:"SP"},
    "342": {player:"Mo Vaughn",team:"Red Sox",note:"SP"},
    "343": {player:"Jack Morris",team:"Tigers",note:"SP"},
    "344": {player:"Phil Niekro",team:"Braves",note:"SP"},
    "345": {player:"Larry Walker",team:"Rockies",note:"SP"},
    "346": {player:"Sparky Anderson",team:"Reds",note:"SP"},
    "347": {player:"Tommy Lasorda",team:"Dodgers",note:"SP"},
    "348": {player:"Luis Aparicio",team:"White Sox",note:"SP"},
    "349": {player:"Jay Buhner",team:"Mariners",note:"SP"},
    "350": {player:"Goose Gossage",team:"Yankees",note:"SP"}
};
CARD_NAMES["Gypsy Queen"] = {
  "1": {player:"Mookie Betts",team:"Red Sox",note:""},
  "2": {player:"J.T. Realmuto",team:"Phillies",note:""},
  "3": {player:"Ramon Laureano",team:"Athletics",note:""},
  "4": {player:"Matt Olson",team:"Athletics",note:""},
  "5": {player:"Dom Nunez",team:"Rockies",note:"Rookie"},
  "6": {player:"Brandon Woodruff",team:"Brewers",note:""},
  "7": {player:"Zack Greinke",team:"Astros",note:""},
  "8": {player:"Garrett Hampson",team:"Rockies",note:""},
  "9": {player:"Harold Ramirez",team:"Marlins",note:""},
  "10": {player:"Rangel Ravelo",team:"Cardinals",note:"Rookie"},
  "11": {player:"Cedric Mullins",team:"Orioles",note:""},
  "12": {player:"Max Kepler",team:"Twins",note:""},
  "13": {player:"Howie Kendrick",team:"Nationals",note:""},
  "14": {player:"John Means",team:"Orioles",note:""},
  "15": {player:"Justin Smoak",team:"Brewers",note:""},
  "16": {player:"Michael Brantley",team:"Astros",note:""},
  "17": {player:"Bo Bichette",team:"Blue Jays",note:"Rookie"},
  "18": {player:"Asdrubal Cabrera",team:"Nationals",note:""},
  "19": {player:"Brock Holt",team:"Red Sox",note:""},
  "20": {player:"Yusei Kikuchi",team:"Mariners",note:""},
  "21": {player:"Clayton Kershaw",team:"Dodgers",note:""},
  "22": {player:"Victor Robles",team:"Nationals",note:""},
  "23": {player:"Trent Grisham",team:"Padres",note:"Rookie"},
  "24": {player:"Michael Conforto",team:"Mets",note:""},
  "25": {player:"Christian Yelich",team:"Brewers",note:""},
  "26": {player:"Adrian Morejon",team:"Padres",note:"Rookie"},
  "27": {player:"Joey Votto",team:"Reds",note:""},
  "28": {player:"Brock Burke",team:"Rangers",note:"Rookie"},
  "29": {player:"Willson Contreras",team:"Cubs",note:""},
  "30": {player:"Carter Kieboom",team:"Nationals",note:""},
  "31": {player:"Carlos Santana",team:"Indians",note:""},
  "32": {player:"Dawel Lugo",team:"Tigers",note:""},
  "33": {player:"Tom Eshelman",team:"Orioles",note:"Rookie"},
  "34": {player:"Adbert Alzolay",team:"Cubs",note:"Rookie"},
  "35": {player:"Aristides Aquino",team:"Reds",note:"Rookie"},
  "36": {player:"Hanser Alberto",team:"Orioles",note:""},
  "37": {player:"Dario Agrazal",team:"Tigers",note:"Rookie"},
  "38": {player:"Kris Bryant",team:"Cubs",note:""},
  "39": {player:"Yolmer Sanchez",team:"White Sox",note:""},
  "40": {player:"Danny Jansen",team:"Blue Jays",note:""},
  "41": {player:"Blake Snell",team:"Rays",note:""},
  "42": {player:"Gio Urshela",team:"Yankees",note:""},
  "43": {player:"Jacob deGrom",team:"Mets",note:""},
  "44": {player:"Alex Colome",team:"White Sox",note:""},
  "45": {player:"Didi Gregorius",team:"Phillies",note:""},
  "46": {player:"Willians Astudillo",team:"Twins",note:""},
  "47": {player:"Paul Goldschmidt",team:"Cardinals",note:""},
  "48": {player:"Vladimir Guerrero Jr.",team:"Blue Jays",note:""},
  "49": {player:"Brandon Crawford",team:"Giants",note:""},
  "50": {player:"Aaron Judge",team:"Yankees",note:""},
  "51": {player:"Austin Dean",team:"Cardinals",note:""},
  "52": {player:"Brendan McKay",team:"Rays",note:"Rookie"},
  "53": {player:"Harrison Bader",team:"Cardinals",note:""},
  "54": {player:"Jeff McNeil",team:"Mets",note:""},
  "55": {player:"Trea Turner",team:"Nationals",note:""},
  "56": {player:"Giancarlo Stanton",team:"Yankees",note:""},
  "57": {player:"Jose Altuve",team:"Astros",note:""},
  "58": {player:"Ty France",team:"Padres",note:""},
  "59": {player:"Willie Calhoun",team:"Rangers",note:""},
  "60": {player:"Joe Jimenez",team:"Tigers",note:""},
  "61": {player:"Josh Bell",team:"Pirates",note:""},
  "62": {player:"Dylan Cease",team:"White Sox",note:"Rookie"},
  "63": {player:"Austin Nola",team:"Mariners",note:"Rookie"},
  "64": {player:"Mitch Haniger",team:"Mariners",note:""},
  "65": {player:"Pete Alonso",team:"Mets",note:""},
  "66": {player:"Kirby Yates",team:"Padres",note:""},
  "67": {player:"David Price",team:"Red Sox",note:""},
  "68": {player:"Randy Arozarena",team:"Rays",note:"Rookie"},
  "69": {player:"Max Fried",team:"Braves",note:""},
  "70": {player:"Bobby Bradley",team:"Indians",note:"Rookie"},
  "71": {player:"Jose Berrios",team:"Twins",note:""},
  "72": {player:"Kyle Hendricks",team:"Cubs",note:""},
  "73": {player:"Jorge Alfaro",team:"Marlins",note:""},
  "74": {player:"T.J. Zeuch",team:"Blue Jays",note:"Rookie"},
  "75": {player:"David Dahl",team:"Rockies",note:""},
  "76": {player:"Bryce Harper",team:"Phillies",note:""},
  "77": {player:"Josh Staumont",team:"Royals",note:"Rookie"},
  "78": {player:"A.J. Minter",team:"Braves",note:""},
  "79": {player:"Jack Flaherty",team:"Cardinals",note:""},
  "80": {player:"Tim Lopes",team:"Mariners",note:"Rookie"},
  "81": {player:"David Peralta",team:"Diamondbacks",note:""},
  "82": {player:"Matt Thaiss",team:"Angels",note:"Rookie"},
  "83": {player:"Noah Syndergaard",team:"Mets",note:""},
  "84": {player:"Eric Hosmer",team:"Padres",note:""},
  "85": {player:"Eduardo Rodriguez",team:"Red Sox",note:""},
  "86": {player:"Anthony Rizzo",team:"Cubs",note:""},
  "87": {player:"Junior Fernandez",team:"Cardinals",note:"Rookie"},
  "88": {player:"Wilson Ramos",team:"Mets",note:""},
  "89": {player:"Jake Arrieta",team:"Phillies",note:""},
  "90": {player:"Brandon Belt",team:"Giants",note:""},
  "91": {player:"Seth Brown",team:"Athletics",note:"Rookie"},
  "92": {player:"Justin Turner",team:"Dodgers",note:""},
  "93": {player:"Gerrit Cole",team:"Yankees",note:""},
  "94": {player:"Eloy Jimenez",team:"White Sox",note:""},
  "95": {player:"Jorge Polanco",team:"Twins",note:""},
  "96": {player:"Xander Bogaerts",team:"Red Sox",note:""},
  "97": {player:"Kyle Seager",team:"Mariners",note:""},
  "98": {player:"Nick Solak",team:"Rangers",note:"Rookie"},
  "99": {player:"Matthew Boyd",team:"Tigers",note:""},
  "100": {player:"Gleyber Torres",team:"Yankees",note:""},
  "101": {player:"Sean Murphy",team:"Athletics",note:"Rookie"},
  "102": {player:"Mike Soroka",team:"Braves",note:""},
  "103": {player:"Charlie Blackmon",team:"Rockies",note:""},
  "104": {player:"Fernando Tatis Jr.",team:"Padres",note:""},
  "105": {player:"Eugenio Suarez",team:"Reds",note:""},
  "106": {player:"Meibrys Viloria",team:"Royals",note:""},
  "107": {player:"Nelson Cruz",team:"Twins",note:""},
  "108": {player:"Logan Webb",team:"Giants",note:"Rookie"},
  "109": {player:"Andrelton Simmons",team:"Angels",note:""},
  "110": {player:"Brian Anderson",team:"Marlins",note:""},
  "111": {player:"Trevor Story",team:"Rockies",note:""},
  "112": {player:"Jonathan Hernandez",team:"Rangers",note:"Rookie"},
  "113": {player:"A.J. Puk",team:"Athletics",note:"Rookie"},
  "114": {player:"David Fletcher",team:"Angels",note:""},
  "115": {player:"Rhys Hoskins",team:"Phillies",note:""},
  "116": {player:"Brendan Rodgers",team:"Rockies",note:""},
  "117": {player:"Andrew Benintendi",team:"Red Sox",note:""},
  "118": {player:"Ender Inciarte",team:"Braves",note:""},
  "119": {player:"Robbie Ray",team:"Diamondbacks",note:""},
  "120": {player:"Lourdes Gurriel Jr.",team:"Blue Jays",note:""},
  "121": {player:"Chance Sisco",team:"Orioles",note:""},
  "122": {player:"Luis Robert",team:"White Sox",note:"Rookie"},
  "123": {player:"Logan Allen",team:"Indians",note:"Rookie"},
  "124": {player:"Mark Melancon",team:"Braves",note:""},
  "125": {player:"Tyler Alexander",team:"Tigers",note:""},
  "126": {player:"Amed Rosario",team:"Mets",note:""},
  "127": {player:"Jose Rodriguez",team:"Angels",note:"Rookie"},
  "128": {player:"Zac Gallen",team:"Diamondbacks",note:"Rookie"},
  "129": {player:"Tommy Pham",team:"Padres",note:""},
  "130": {player:"Kevin Newman",team:"Pirates",note:""},
  "131": {player:"Colin Moran",team:"Pirates",note:""},
  "132": {player:"Yoan Moncada",team:"White Sox",note:""},
  "133": {player:"Kole Calhoun",team:"Diamondbacks",note:""},
  "134": {player:"Tim Anderson",team:"White Sox",note:""},
  "135": {player:"Corey Seager",team:"Dodgers",note:""},
  "136": {player:"Rafael Devers",team:"Red Sox",note:""},
  "137": {player:"Yordan Alvarez",team:"Astros",note:"Rookie"},
  "138": {player:"Jose Urena",team:"Marlins",note:""},
  "139": {player:"Eduardo Escobar",team:"Diamondbacks",note:""},
  "140": {player:"Eric Thames",team:"Nationals",note:""},
  "141": {player:"Lorenzo Cain",team:"Brewers",note:""},
  "142": {player:"Luis Severino",team:"Yankees",note:""},
  "143": {player:"Robert Dugger",team:"Marlins",note:"Rookie"},
  "144": {player:"Justin Dunn",team:"Mariners",note:"Rookie"},
  "145": {player:"Mitch Garver",team:"Twins",note:""},
  "146": {player:"Anthony Santander",team:"Orioles",note:""},
  "147": {player:"Bubba Starling",team:"Royals",note:"Rookie"},
  "148": {player:"Nomar Mazara",team:"White Sox",note:""},
  "149": {player:"Shin-Soo Choo",team:"Rangers",note:""},
  "150": {player:"Cody Bellinger",team:"Dodgers",note:""},
  "151": {player:"Michael Lorenzen",team:"Reds",note:""},
  "152": {player:"Gary Sanchez",team:"Yankees",note:""},
  "153": {player:"Austin Hays",team:"Orioles",note:""},
  "154": {player:"Nick Williams",team:"Phillies",note:""},
  "155": {player:"Dustin May",team:"Dodgers",note:"Rookie"},
  "156": {player:"Rougned Odor",team:"Rangers",note:""},
  "157": {player:"Yuli Gurriel",team:"Astros",note:""},
  "158": {player:"Walker Buehler",team:"Dodgers",note:""},
  "159": {player:"Carlos Correa",team:"Astros",note:""},
  "160": {player:"Mike Minor",team:"Rangers",note:""},
  "161": {player:"Kean Wong",team:"Giants",note:"Rookie"},
  "162": {player:"Anthony Kay",team:"Blue Jays",note:"Rookie"},
  "163": {player:"Patrick Corbin",team:"Nationals",note:""},
  "164": {player:"Shane Bieber",team:"Indians",note:""},
  "165": {player:"Jose Abreu",team:"White Sox",note:""},
  "166": {player:"Max Scherzer",team:"Nationals",note:""},
  "167": {player:"Bryan Reynolds",team:"Pirates",note:""},
  "168": {player:"Jake Fraley",team:"Mariners",note:"Rookie"},
  "169": {player:"Adam Ottavino",team:"Yankees",note:""},
  "170": {player:"Kyle Schwarber",team:"Cubs",note:""},
  "171": {player:"Yu Chang",team:"Indians",note:"Rookie"},
  "172": {player:"Jon Lester",team:"Cubs",note:""},
  "173": {player:"Jordan Yamamoto",team:"Marlins",note:"Rookie"},
  "174": {player:"Gavin Lux",team:"Dodgers",note:"Rookie"},
  "175": {player:"Hyun-Jin Ryu",team:"Blue Jays",note:""},
  "176": {player:"Kevin Kiermaier",team:"Rays",note:""},
  "177": {player:"James Paxton",team:"Yankees",note:""},
  "178": {player:"Juan Soto",team:"Nationals",note:""},
  "179": {player:"Nicky Lopez",team:"Royals",note:""},
  "180": {player:"Keston Hiura",team:"Brewers",note:""},
  "181": {player:"Jean Segura",team:"Phillies",note:""},
  "182": {player:"Brandon Dixon",team:"Tigers",note:""},
  "183": {player:"Yasmani Grandal",team:"White Sox",note:""},
  "184": {player:"Miles Mikolas",team:"Cardinals",note:""},
  "185": {player:"Jose Iglesias",team:"Orioles",note:""},
  "186": {player:"Evan Longoria",team:"Giants",note:""},
  "187": {player:"Ronald Acuna Jr.",team:"Braves",note:""},
  "188": {player:"Matt Chapman",team:"Athletics",note:""},
  "189": {player:"Tyler Glasnow",team:"Rays",note:""},
  "190": {player:"Eddie Rosario",team:"Twins",note:""},
  "191": {player:"Victor Reyes",team:"Tigers",note:""},
  "192": {player:"Ryan O'Hearn",team:"Royals",note:""},
  "193": {player:"Trevor Williams",team:"Pirates",note:""},
  "194": {player:"Jaylin Davis",team:"Giants",note:"Rookie"},
  "195": {player:"J.D. Martinez",team:"Red Sox",note:""},
  "196": {player:"Mitch Keller",team:"Pirates",note:""},
  "197": {player:"Hunter Harvey",team:"Orioles",note:"Rookie"},
  "198": {player:"Alex Young",team:"Diamondbacks",note:"Rookie"},
  "199": {player:"Adam Haseley",team:"Phillies",note:""},
  "200": {player:"Alex Bregman",team:"Astros",note:""},
  "201": {player:"Nico Hoerner",team:"Cubs",note:"Rookie"},
  "202": {player:"Max Muncy",team:"Dodgers",note:""},
  "203": {player:"Luis Arraez",team:"Twins",note:""},
  "204": {player:"Albert Pujols",team:"Angels",note:""},
  "205": {player:"Austin Meadows",team:"Rays",note:""},
  "206": {player:"Christian Vazquez",team:"Red Sox",note:""},
  "207": {player:"Paul DeJong",team:"Cardinals",note:""},
  "208": {player:"Adalberto Mondesi",team:"Royals",note:""},
  "209": {player:"J.D. Davis",team:"Mets",note:""},
  "210": {player:"Khris Davis",team:"Athletics",note:""},
  "211": {player:"Austin Riley",team:"Braves",note:""},
  "212": {player:"Marcus Semien",team:"Athletics",note:""},
  "213": {player:"Aroldis Chapman",team:"Yankees",note:""},
  "214": {player:"Danny Duffy",team:"Royals",note:""},
  "215": {player:"Anthony Rendon",team:"Angels",note:""},
  "216": {player:"Willy Adames",team:"Rays",note:""},
  "217": {player:"Sheldon Neuse",team:"Athletics",note:"Rookie"},
  "218": {player:"Starling Marte",team:"Pirates",note:""},
  "219": {player:"Will Smith",team:"Dodgers",note:""},
  "220": {player:"James Marvel",team:"Pirates",note:"Rookie"},
  "221": {player:"Dansby Swanson",team:"Braves",note:""},
  "222": {player:"Michael Chavis",team:"Red Sox",note:""},
  "223": {player:"Cavan Biggio",team:"Blue Jays",note:""},
  "224": {player:"Trey Mancini",team:"Orioles",note:""},
  "225": {player:"Jake Rogers",team:"Tigers",note:"Rookie"},
  "226": {player:"Kyle Lewis",team:"Mariners",note:"Rookie"},
  "227": {player:"Oscar Mercado",team:"Indians",note:""},
  "228": {player:"Francisco Lindor",team:"Indians",note:""},
  "229": {player:"Emmanuel Clase",team:"Indians",note:"Rookie"},
  "230": {player:"Francisco Mejia",team:"Padres",note:""},
  "231": {player:"Aaron Nola",team:"Phillies",note:""},
  "232": {player:"Aaron Civale",team:"Indians",note:"Rookie"},
  "233": {player:"Javier Baez",team:"Cubs",note:""},
  "234": {player:"Michel Baez",team:"Padres",note:"Rookie"},
  "235": {player:"Ryan McMahon",team:"Rockies",note:""},
  "236": {player:"Derek Dietrich",team:"Reds",note:""},
  "237": {player:"Sandy Alcantara",team:"Marlins",note:""},
  "238": {player:"Ozzie Albies",team:"Braves",note:""},
  "239": {player:"Nick Senzel",team:"Reds",note:""},
  "240": {player:"Scott Kingery",team:"Phillies",note:""},
  "241": {player:"Ryan Braun",team:"Brewers",note:""},
  "242": {player:"Hunter Dozier",team:"Royals",note:""},
  "243": {player:"Buster Posey",team:"Giants",note:""},
  "244": {player:"Shed Long",team:"Mariners",note:""},
  "245": {player:"Marcus Stroman",team:"Mets",note:""},
  "246": {player:"Brusdar Graterol",team:"Twins",note:"Rookie"},
  "247": {player:"Ronald Guzman",team:"Rangers",note:""},
  "248": {player:"Steven Matz",team:"Mets",note:""},
  "249": {player:"Luis Castillo",team:"Reds",note:""},
  "250": {player:"Justin Verlander",team:"Astros",note:""},
  "251": {player:"Jose Ramirez",team:"Indians",note:""},
  "252": {player:"Will Smith",team:"Braves",note:""},
  "253": {player:"Rowdy Tellez",team:"Blue Jays",note:""},
  "254": {player:"Chris Archer",team:"Pirates",note:""},
  "255": {player:"Luke Weaver",team:"Diamondbacks",note:""},
  "256": {player:"Christian Walker",team:"Diamondbacks",note:""},
  "257": {player:"Willi Castro",team:"Tigers",note:""},
  "258": {player:"Mike Yastrzemski",team:"Giants",note:""},
  "259": {player:"Starlin Castro",team:"Nationals",note:""},
  "260": {player:"Zack Collins",team:"White Sox",note:"Rookie"},
  "261": {player:"Shohei Ohtani",team:"Angels",note:""},
  "262": {player:"Andres Munoz",team:"Padres",note:"Rookie"},
  "263": {player:"Dwight Smith Jr.",team:"Orioles",note:""},
  "264": {player:"Trevor Bauer",team:"Reds",note:""},
  "265": {player:"Sam Hilliard",team:"Rockies",note:"Rookie"},
  "266": {player:"Miguel Cabrera",team:"Tigers",note:""},
  "267": {player:"Peter Lambert",team:"Rockies",note:""},
  "268": {player:"Mauricio Dubon",team:"Giants",note:"Rookie"},
  "269": {player:"Jorge Soler",team:"Royals",note:""},
  "270": {player:"Franmil Reyes",team:"Indians",note:""},
  "271": {player:"Michael Brosseau",team:"Rays",note:"Rookie"},
  "272": {player:"Raisel Iglesias",team:"Reds",note:""},
  "273": {player:"Yadier Molina",team:"Cardinals",note:""},
  "274": {player:"Andrew Heaney",team:"Angels",note:""},
  "275": {player:"Jeff Samardzija",team:"Giants",note:""},
  "276": {player:"George Springer",team:"Astros",note:""},
  "277": {player:"Lucas Giolito",team:"White Sox",note:""},
  "278": {player:"DJ LeMahieu",team:"Yankees",note:""},
  "279": {player:"Randal Grichuk",team:"Blue Jays",note:""},
  "280": {player:"Travis d'Arnaud",team:"Braves",note:""},
  "281": {player:"Whit Merrifield",team:"Royals",note:""},
  "282": {player:"Aaron Nola",team:"Phillies",note:""},
  "283": {player:"Zach Davies",team:"Padres",note:""},
  "284": {player:"Robel Garcia",team:"Cubs",note:"Rookie"},
  "285": {player:"Stephen Strasburg",team:"Nationals",note:""},
  "286": {player:"Domingo Leyba",team:"Diamondbacks",note:"Rookie"},
  "287": {player:"Jesus Luzardo",team:"Athletics",note:"Rookie"},
  "288": {player:"Josh Hader",team:"Brewers",note:""},
  "289": {player:"Byron Buxton",team:"Twins",note:""},
  "290": {player:"Tommy La Stella",team:"Angels",note:""},
  "291": {player:"Tommy Edman",team:"Cardinals",note:""},
  "292": {player:"Manny Machado",team:"Padres",note:""},
  "293": {player:"Isan Diaz",team:"Marlins",note:"Rookie"},
  "294": {player:"Nolan Arenado",team:"Rockies",note:""},
  "295": {player:"Ketel Marte",team:"Diamondbacks",note:""},
  "296": {player:"Archie Bradley",team:"Diamondbacks",note:""},
  "297": {player:"Travis Demeritte",team:"Tigers",note:"Rookie"},
  "298": {player:"Freddie Freeman",team:"Braves",note:""},
  "299": {player:"Sonny Gray",team:"Reds",note:""},
  "300": {player:"Mike Trout",team:"Angels",note:""},
  "301": {player:"Babe Ruth",team:"Yankees",note:"SP Extended"},
  "302": {player:"Mariano Rivera",team:"Yankees",note:"SP Extended"},
  "303": {player:"Deion Sanders",team:"Reds",note:"SP Extended"},
  "304": {player:"Reggie Jackson",team:"Athletics",note:"SP Extended"},
  "305": {player:"Tony Gwynn",team:"Padres",note:"SP Extended"},
  "306": {player:"Carl Yastrzemski",team:"Red Sox",note:"SP Extended"},
  "307": {player:"Mike Schmidt",team:"Phillies",note:"SP Extended"},
  "308": {player:"Roberto Clemente",team:"Pirates",note:"SP Extended"},
  "309": {player:"Johnny Bench",team:"Reds",note:"SP Extended"},
  "310": {player:"Vladimir Guerrero",team:"Expos",note:"SP Extended"},
  "311": {player:"Chipper Jones",team:"Braves",note:"SP Extended"},
  "312": {player:"Sammy Sosa",team:"Cubs",note:"SP Extended"},
  "313": {player:"Pedro Martinez",team:"Red Sox",note:"SP Extended"},
  "314": {player:"Ted Williams",team:"Red Sox",note:"SP Extended"},
  "315": {player:"Sandy Koufax",team:"Dodgers",note:"SP Extended"},
  "316": {player:"Rickey Henderson",team:"Athletics",note:"SP Extended"},
  "317": {player:"Cal Ripken Jr.",team:"Orioles",note:"SP Extended"},
  "318": {player:"Ken Griffey Jr.",team:"Mariners",note:"SP Extended"},
  "319": {player:"Honus Wagner",team:"Pirates",note:"SP Extended"},
  "320": {player:"Jackie Robinson",team:"Dodgers",note:"SP Extended"}
};
CARD_NAMES["Archives"] = {
  "1": {player:"Babe Ruth",team:"Yankees",note:"1955 Design"},
  "2": {player:"Paul Goldschmidt",team:"Cardinals",note:"1955 Design"},
  "3": {player:"Charlie Blackmon",team:"Rockies",note:"1955 Design"},
  "4": {player:"Nick Senzel",team:"Reds",note:"1955 Design"},
  "5": {player:"Steve Carlton",team:"Phillies",note:"1955 Design"},
  "6": {player:"Aristides Aquino",team:"Reds",note:"Rookie 1955 Design"},
  "7": {player:"Shohei Ohtani",team:"Angels",note:"1955 Design"},
  "8": {player:"Kyle Schwarber",team:"Cubs",note:"1955 Design"},
  "9": {player:"Joey Gallo",team:"Rangers",note:"1955 Design"},
  "10": {player:"Mariano Rivera",team:"Yankees",note:"1955 Design"},
  "11": {player:"Rickey Henderson",team:"Athletics",note:"1955 Design"},
  "12": {player:"Marcus Stroman",team:"Mets",note:"1955 Design"},
  "13": {player:"Seth Brown",team:"Athletics",note:"Rookie 1955 Design"},
  "14": {player:"Harmon Killebrew",team:"Twins",note:"1955 Design"},
  "15": {player:"Albert Pujols",team:"Angels",note:"1955 Design"},
  "16": {player:"Willi Castro",team:"Tigers",note:"Rookie 1955 Design"},
  "17": {player:"Jorge Soler",team:"Royals",note:"1955 Design"},
  "18": {player:"Dylan Cease",team:"White Sox",note:"Rookie 1955 Design"},
  "19": {player:"Pete Alonso",team:"Mets",note:"1955 Design"},
  "20": {player:"Whit Merrifield",team:"Royals",note:"1955 Design"},
  "21": {player:"Gary Sanchez",team:"Yankees",note:"1955 Design"},
  "22": {player:"Marcus Semien",team:"Athletics",note:"1955 Design"},
  "23": {player:"Francisco Lindor",team:"Indians",note:"1955 Design"},
  "24": {player:"Xander Bogaerts",team:"Red Sox",note:"1955 Design"},
  "25": {player:"Jackie Robinson",team:"Dodgers",note:"1955 Design"},
  "26": {player:"Keston Hiura",team:"Brewers",note:"1955 Design"},
  "27": {player:"Mookie Betts",team:"Dodgers",note:"1955 Design"},
  "28": {player:"Aaron Hicks",team:"Yankees",note:"1955 Design"},
  "29": {player:"Robin Yount",team:"Brewers",note:"1955 Design"},
  "30": {player:"George Brett",team:"Royals",note:"1955 Design"},
  "31": {player:"Alex Bregman",team:"Astros",note:"1955 Design"},
  "32": {player:"Al Kaline",team:"Tigers",note:"1955 Design"},
  "33": {player:"Will Smith",team:"Dodgers",note:"1955 Design"},
  "34": {player:"Brusdar Graterol",team:"Dodgers",note:"Rookie 1955 Design"},
  "35": {player:"Tim Lincecum",team:"Giants",note:"1955 Design"},
  "36": {player:"Shane Bieber",team:"Indians",note:"1955 Design"},
  "37": {player:"Kyle Lewis",team:"Mariners",note:"Rookie 1955 Design"},
  "38": {player:"Jose Altuve",team:"Astros",note:"1955 Design"},
  "39": {player:"Michael Brantley",team:"Astros",note:"1955 Design"},
  "40": {player:"Sam Hilliard",team:"Rockies",note:"Rookie 1955 Design"},
  "41": {player:"Deion Sanders",team:"Braves",note:"1955 Design"},
  "42": {player:"Jeff McNeil",team:"Mets",note:"1955 Design"},
  "43": {player:"Aaron Civale",team:"Indians",note:"Rookie 1955 Design"},
  "44": {player:"Lucas Giolito",team:"White Sox",note:"1955 Design"},
  "45": {player:"Bo Bichette",team:"Blue Jays",note:"Rookie 1955 Design"},
  "46": {player:"Gary Carter",team:"Mets",note:"1955 Design"},
  "47": {player:"Goose Gossage",team:"Yankees",note:"1955 Design"},
  "48": {player:"J.D. Martinez",team:"Red Sox",note:"1955 Design"},
  "49": {player:"George Kell",team:"Tigers",note:"1955 Design"},
  "50": {player:"Mike Trout",team:"Angels",note:"1955 Design"},
  "51": {player:"Brock Burke",team:"Rangers",note:"Rookie 1955 Design"},
  "52": {player:"Catfish Hunter",team:"Athletics",note:"1955 Design"},
  "53": {player:"Lou Boudreau",team:"Indians",note:"1955 Design"},
  "54": {player:"Max Muncy",team:"Dodgers",note:"1955 Design"},
  "55": {player:"Jose Berrios",team:"Twins",note:"1955 Design"},
  "56": {player:"Vladimir Guerrero Jr.",team:"Blue Jays",note:"1955 Design"},
  "57": {player:"Ozzie Albies",team:"Braves",note:"1955 Design"},
  "58": {player:"Tim Anderson",team:"White Sox",note:"1955 Design"},
  "59": {player:"Will Clark",team:"Giants",note:"1955 Design"},
  "60": {player:"Carl Yastrzemski",team:"Red Sox",note:"1955 Design"},
  "61": {player:"Alex Young",team:"Diamondbacks",note:"Rookie 1955 Design"},
  "62": {player:"Nomar Garciaparra",team:"Red Sox",note:"1955 Design"},
  "63": {player:"Bryan Reynolds",team:"Pirates",note:"1955 Design"},
  "64": {player:"Joey Votto",team:"Reds",note:"1955 Design"},
  "65": {player:"Sean Murphy",team:"Athletics",note:"1955 Design"},
  "66": {player:"J.T. Realmuto",team:"Phillies",note:"1955 Design"},
  "67": {player:"Kenta Maeda",team:"Twins",note:"1955 Design"},
  "68": {player:"Jack Flaherty",team:"Cardinals",note:"1955 Design"},
  "69": {player:"Trevor Bauer",team:"Reds",note:"1955 Design"},
  "70": {player:"Jim Thome",team:"Indians",note:"1955 Design"},
  "71": {player:"Zack Greinke",team:"Astros",note:"1955 Design"},
  "72": {player:"Isan Diaz",team:"Marlins",note:"Rookie 1955 Design"},
  "73": {player:"Ryne Sandberg",team:"Cubs",note:"1955 Design"},
  "74": {player:"Ralph Kiner",team:"Pirates",note:"1955 Design"},
  "75": {player:"Mike Mussina",team:"Yankees",note:"1955 Design"},
  "76": {player:"Larry Doby",team:"Indians",note:"1955 Design"},
  "77": {player:"Paul DeJong",team:"Cardinals",note:"1955 Design"},
  "78": {player:"Gavin Lux",team:"Dodgers",note:"Rookie 1955 Design"},
  "79": {player:"Matt Chapman",team:"Athletics",note:"1955 Design"},
  "80": {player:"Ramon Laureano",team:"Athletics",note:"1955 Design"},
  "81": {player:"Corey Seager",team:"Dodgers",note:"1955 Design"},
  "82": {player:"Luis Aparicio",team:"White Sox",note:"1955 Design"},
  "83": {player:"Tom Glavine",team:"Braves",note:"1955 Design"},
  "84": {player:"Amed Rosario",team:"Mets",note:"1955 Design"},
  "85": {player:"Jake Fraley",team:"Mariners",note:"Rookie 1955 Design"},
  "86": {player:"Raisel Iglesias",team:"Reds",note:"1955 Design"},
  "87": {player:"Juan Soto",team:"Nationals",note:"1955 Design"},
  "88": {player:"Derek Jeter",team:"Yankees",note:"1955 Design"},
  "89": {player:"Nolan Arenado",team:"Rockies",note:"1955 Design"},
  "90": {player:"Nolan Ryan",team:"Astros",note:"1955 Design"},
  "91": {player:"Jordan Yamamoto",team:"Marlins",note:"Rookie 1955 Design"},
  "92": {player:"Matt Carpenter",team:"Cardinals",note:"1955 Design"},
  "93": {player:"Mallex Smith",team:"Mariners",note:"1955 Design"},
  "94": {player:"Charlie Morton",team:"Rays",note:"1955 Design"},
  "95": {player:"A.J. Puk",team:"Athletics",note:"Rookie 1955 Design"},
  "96": {player:"DJ LeMahieu",team:"Yankees",note:"1955 Design"},
  "97": {player:"Monte Irvin",team:"Giants",note:"1955 Design"},
  "98": {player:"Wade Boggs",team:"Red Sox",note:"1955 Design"},
  "99": {player:"Shin-Soo Choo",team:"Rangers",note:"1955 Design"},
  "100": {player:"Hank Aaron",team:"Braves",note:"1955 Design"},
  "101": {player:"Ted Williams",team:"Red Sox",note:"1974 Design"},
  "102": {player:"Bob Gibson",team:"Cardinals",note:"1974 Design"},
  "103": {player:"Mike Clevinger",team:"Indians",note:"1974 Design"},
  "104": {player:"Christian Walker",team:"Diamondbacks",note:"1974 Design"},
  "105": {player:"Chris Paddack",team:"Padres",note:"1974 Design"},
  "106": {player:"Tony Gwynn",team:"Padres",note:"1974 Design"},
  "107": {player:"Kerry Wood",team:"Cubs",note:"1974 Design"},
  "108": {player:"Mike Piazza",team:"Mets",note:"1974 Design"},
  "109": {player:"Randy Johnson",team:"Diamondbacks",note:"1974 Design"},
  "110": {player:"Abraham Toro",team:"Astros",note:"Rookie 1974 Design"},
  "111": {player:"Nick Solak",team:"Rangers",note:"Rookie 1974 Design"},
  "112": {player:"Stephen Piscotty",team:"Athletics",note:"1974 Design"},
  "113": {player:"Hunter Dozier",team:"Royals",note:"1974 Design"},
  "114": {player:"Bob Feller",team:"Indians",note:"1974 Design"},
  "115": {player:"Mike Moustakas",team:"Reds",note:"1974 Design"},
  "116": {player:"Jacob deGrom",team:"Mets",note:"1974 Design"},
  "117": {player:"Shogo Akiyama",team:"Reds",note:"Rookie 1974 Design"},
  "118": {player:"Ernie Banks",team:"Cubs",note:"1974 Design"},
  "119": {player:"Eloy Jimenez",team:"White Sox",note:"1974 Design"},
  "120": {player:"Carlos Correa",team:"Astros",note:"1974 Design"},
  "121": {player:"Frank Robinson",team:"Reds",note:"1974 Design"},
  "122": {player:"Sandy Koufax",team:"Dodgers",note:"1974 Design"},
  "123": {player:"Jason Heyward",team:"Cubs",note:"1974 Design"},
  "124": {player:"Trevor Story",team:"Rockies",note:"1974 Design"},
  "125": {player:"Mike Schmidt",team:"Phillies",note:"1974 Design"},
  "126": {player:"Bobby Bradley",team:"Indians",note:"Rookie 1974 Design"},
  "127": {player:"Roberto Alomar",team:"Blue Jays",note:"1974 Design"},
  "128": {player:"Fred McGriff",team:"Braves",note:"1974 Design"},
  "129": {player:"DJ LeMahieu",team:"Yankees",note:"1974 Design"},
  "130": {player:"Larry Walker",team:"Rockies",note:"1974 Design"},
  "131": {player:"Eric Hosmer",team:"Padres",note:"1974 Design"},
  "132": {player:"Buster Posey",team:"Giants",note:"1974 Design"},
  "133": {player:"Tony Gonsolin",team:"Dodgers",note:"Rookie 1974 Design"},
  "134": {player:"Jon Lester",team:"Cubs",note:"1974 Design"},
  "135": {player:"Yoshi Tsutsugo",team:"Rays",note:"Rookie 1974 Design"},
  "136": {player:"Ty Cobb",team:"Tigers",note:"1974 Design"},
  "137": {player:"Eduardo Escobar",team:"Diamondbacks",note:"1974 Design"},
  "138": {player:"Blake Snell",team:"Rays",note:"1974 Design"},
  "139": {player:"Mike Soroka",team:"Braves",note:"1974 Design"},
  "140": {player:"Zack Collins",team:"White Sox",note:"Rookie 1974 Design"},
  "141": {player:"Dustin May",team:"Dodgers",note:"Rookie 1974 Design"},
  "142": {player:"Cal Ripken Jr.",team:"Orioles",note:"1974 Design"},
  "143": {player:"Brandon Crawford",team:"Giants",note:"1974 Design"},
  "144": {player:"Bo Jackson",team:"Royals",note:"1974 Design"},
  "145": {player:"Paul Molitor",team:"Brewers",note:"1974 Design"},
  "146": {player:"Ketel Marte",team:"Diamondbacks",note:"1974 Design"},
  "147": {player:"Jesus Luzardo",team:"Athletics",note:"Rookie 1974 Design"},
  "148": {player:"Josh Hader",team:"Brewers",note:"1974 Design"},
  "149": {player:"Roberto Clemente",team:"Pirates",note:"1974 Design"},
  "150": {player:"Mo Vaughn",team:"Red Sox",note:"1974 Design"},
  "151": {player:"Jeff Bagwell",team:"Astros",note:"1974 Design"},
  "152": {player:"Corey Kluber",team:"Rangers",note:"1974 Design"},
  "153": {player:"Ken Griffey Jr.",team:"Mariners",note:"1974 Design"},
  "154": {player:"George Springer",team:"Astros",note:"1974 Design"},
  "155": {player:"Justin Dunn",team:"Mariners",note:"Rookie 1974 Design"},
  "156": {player:"Clayton Kershaw",team:"Dodgers",note:"1974 Design"},
  "157": {player:"Daniel Vogelbach",team:"Mariners",note:"1974 Design"},
  "158": {player:"Brooks Robinson",team:"Orioles",note:"1974 Design"},
  "159": {player:"Luis Robert",team:"White Sox",note:"Rookie 1974 Design"},
  "160": {player:"Mauricio Dubon",team:"Giants",note:"Rookie 1974 Design"},
  "161": {player:"Justin Upton",team:"Angels",note:"1974 Design"},
  "162": {player:"Javier Baez",team:"Cubs",note:"1974 Design"},
  "163": {player:"Max Scherzer",team:"Nationals",note:"1974 Design"},
  "164": {player:"David Ortiz",team:"Red Sox",note:"1974 Design"},
  "165": {player:"John Smoltz",team:"Braves",note:"1974 Design"},
  "166": {player:"Dave Winfield",team:"Padres",note:"1974 Design"},
  "167": {player:"Justin Turner",team:"Dodgers",note:"1974 Design"},
  "168": {player:"Nelson Cruz",team:"Twins",note:"1974 Design"},
  "169": {player:"Khris Davis",team:"Athletics",note:"1974 Design"},
  "170": {player:"Rowdy Tellez",team:"Blue Jays",note:"1974 Design"},
  "171": {player:"Adbert Alzolay",team:"Cubs",note:"Rookie 1974 Design"},
  "172": {player:"Zac Gallen",team:"Diamondbacks",note:"Rookie 1974 Design"},
  "173": {player:"Lou Brock",team:"Cardinals",note:"1974 Design"},
  "174": {player:"Trey Mancini",team:"Orioles",note:"1974 Design"},
  "175": {player:"Sammy Sosa",team:"Cubs",note:"1974 Design"},
  "176": {player:"Duke Snider",team:"Dodgers",note:"1974 Design"},
  "177": {player:"Hyun-Jin Ryu",team:"Blue Jays",note:"1974 Design"},
  "178": {player:"Thurman Munson",team:"Yankees",note:"1974 Design"},
  "179": {player:"Sandy Alcantara",team:"Marlins",note:"1974 Design"},
  "180": {player:"Gleyber Torres",team:"Yankees",note:"1974 Design"},
  "181": {player:"Matthew Boyd",team:"Tigers",note:"1974 Design"},
  "182": {player:"Willie Stargell",team:"Pirates",note:"1974 Design"},
  "183": {player:"Walker Buehler",team:"Dodgers",note:"1974 Design"},
  "184": {player:"Trent Grisham",team:"Padres",note:"Rookie 1974 Design"},
  "185": {player:"Fernando Tatis Jr.",team:"Padres",note:"1974 Design"},
  "186": {player:"Willie McCovey",team:"Giants",note:"1974 Design"},
  "187": {player:"Sheldon Neuse",team:"Athletics",note:"Rookie 1974 Design"},
  "188": {player:"Josh Bell",team:"Pirates",note:"1974 Design"},
  "189": {player:"Ivan Rodriguez",team:"Rangers",note:"1974 Design"},
  "190": {player:"Billy Williams",team:"Cubs",note:"1974 Design"},
  "191": {player:"Andrew Benintendi",team:"Red Sox",note:"1974 Design"},
  "192": {player:"Shun Yamaguchi",team:"Blue Jays",note:"Rookie 1974 Design"},
  "193": {player:"Anthony Rizzo",team:"Cubs",note:"1974 Design"},
  "194": {player:"Victor Robles",team:"Nationals",note:"1974 Design"},
  "195": {player:"Tom Seaver",team:"Mets",note:"1974 Design"},
  "196": {player:"Rhys Hoskins",team:"Phillies",note:"1974 Design"},
  "197": {player:"Danny Jansen",team:"Blue Jays",note:"1974 Design"},
  "198": {player:"Dansby Swanson",team:"Braves",note:"1974 Design"},
  "199": {player:"Giancarlo Stanton",team:"Yankees",note:"1974 Design"},
  "200": {player:"Marco Gonzales",team:"Mariners",note:"1974 Design"},
  "201": {player:"Manny Machado",team:"Padres",note:"2002 Design"},
  "202": {player:"Anthony Kay",team:"Blue Jays",note:"Rookie 2002 Design"},
  "203": {player:"Anthony Rendon",team:"Angels",note:"2002 Design"},
  "204": {player:"Michel Baez",team:"Padres",note:"Rookie 2002 Design"},
  "205": {player:"Kyle Seager",team:"Mariners",note:"2002 Design"},
  "206": {player:"Juan Gonzalez",team:"Rangers",note:"2002 Design"},
  "207": {player:"Carter Kieboom",team:"Nationals",note:"2002 Design"},
  "208": {player:"Chris Sale",team:"Red Sox",note:"2002 Design"},
  "209": {player:"Kenley Jansen",team:"Dodgers",note:"2002 Design"},
  "210": {player:"Ralph Kiner",team:"Pirates",note:"2002 Design"},
  "211": {player:"Starling Marte",team:"Diamondbacks",note:"2002 Design"},
  "212": {player:"Orlando Cepeda",team:"Giants",note:"2002 Design"},
  "213": {player:"Randy Arozarena",team:"Rays",note:"Rookie 2002 Design"},
  "214": {player:"Austin Meadows",team:"Rays",note:"2002 Design"},
  "215": {player:"Frank Thomas",team:"White Sox",note:"2002 Design"},
  "216": {player:"Robel Garcia",team:"Cubs",note:"Rookie 2002 Design"},
  "217": {player:"Cody Bellinger",team:"Dodgers",note:"2002 Design"},
  "218": {player:"Reggie Jackson",team:"Athletics",note:"2002 Design"},
  "219": {player:"Rollie Fingers",team:"Athletics",note:"2002 Design"},
  "220": {player:"Chipper Jones",team:"Braves",note:"2002 Design"},
  "221": {player:"John Means",team:"Orioles",note:"2002 Design"},
  "222": {player:"Yordan Alvarez",team:"Astros",note:"Rookie 2002 Design"},
  "223": {player:"Brad Keller",team:"Royals",note:"2002 Design"},
  "224": {player:"Andrelton Simmons",team:"Angels",note:"2002 Design"},
  "225": {player:"Evan Longoria",team:"Giants",note:"2002 Design"},
  "226": {player:"David Wright",team:"Mets",note:"2002 Design"},
  "227": {player:"Ryan Howard",team:"Phillies",note:"2002 Design"},
  "228": {player:"Gerrit Cole",team:"Yankees",note:"2002 Design"},
  "229": {player:"Eugenio Suarez",team:"Reds",note:"2002 Design"},
  "230": {player:"Michael Chavis",team:"Red Sox",note:"2002 Design"},
  "231": {player:"Whitey Ford",team:"Yankees",note:"2002 Design"},
  "232": {player:"Willson Contreras",team:"Cubs",note:"2002 Design"},
  "233": {player:"Rod Carew",team:"Twins",note:"2002 Design"},
  "234": {player:"Yadier Molina",team:"Cardinals",note:"2002 Design"},
  "235": {player:"Ichiro",team:"Mariners",note:"2002 Design"},
  "236": {player:"Bryce Harper",team:"Phillies",note:"2002 Design"},
  "237": {player:"Trevor Hoffman",team:"Padres",note:"2002 Design"},
  "238": {player:"Jorge Alfaro",team:"Marlins",note:"2002 Design"},
  "239": {player:"Alan Trammell",team:"Tigers",note:"2002 Design"},
  "240": {player:"Nico Hoerner",team:"Cubs",note:"Rookie 2002 Design"},
  "241": {player:"Ronald Acuna Jr.",team:"Braves",note:"2002 Design"},
  "242": {player:"Matt Olson",team:"Athletics",note:"2002 Design"},
  "243": {player:"Edgar Martinez",team:"Mariners",note:"2002 Design"},
  "244": {player:"Brendan McKay",team:"Rays",note:"Rookie 2002 Design"},
  "245": {player:"Yuli Gurriel",team:"Astros",note:"2002 Design"},
  "246": {player:"Kole Calhoun",team:"Diamondbacks",note:"2002 Design"},
  "247": {player:"Craig Biggio",team:"Astros",note:"2002 Design"},
  "248": {player:"Christian Yelich",team:"Brewers",note:"2002 Design"},
  "249": {player:"Vladimir Guerrero",team:"Expos",note:"2002 Design"},
  "250": {player:"Carlton Fisk",team:"Red Sox",note:"2002 Design"},
  "251": {player:"Logan Allen",team:"Indians",note:"Rookie 2002 Design"},
  "252": {player:"Noah Syndergaard",team:"Mets",note:"2002 Design"},
  "253": {player:"Aaron Nola",team:"Phillies",note:"2002 Design"},
  "254": {player:"Rougned Odor",team:"Rangers",note:"2002 Design"},
  "255": {player:"Dennis Eckersley",team:"Athletics",note:"2002 Design"},
  "256": {player:"Jorge Polanco",team:"Twins",note:"2002 Design"},
  "257": {player:"Aroldis Chapman",team:"Yankees",note:"2002 Design"},
  "258": {player:"Roger Clemens",team:"Yankees",note:"2002 Design"},
  "259": {player:"Anthony Santander",team:"Orioles",note:"2002 Design"},
  "260": {player:"Yu Darvish",team:"Cubs",note:"2002 Design"},
  "261": {player:"Harrison Bader",team:"Cardinals",note:"2002 Design"},
  "262": {player:"Honus Wagner",team:"Pirates",note:"2002 Design"},
  "263": {player:"Michael Conforto",team:"Mets",note:"2002 Design"},
  "264": {player:"Alex Rodriguez",team:"Yankees",note:"2002 Design"},
  "265": {player:"Ryan McMahon",team:"Rockies",note:"2002 Design"},
  "266": {player:"Barry Larkin",team:"Reds",note:"2002 Design"},
  "267": {player:"Rafael Devers",team:"Red Sox",note:"2002 Design"},
  "268": {player:"Eddie Rosario",team:"Twins",note:"2002 Design"},
  "269": {player:"Andres Munoz",team:"Padres",note:"Rookie 2002 Design"},
  "270": {player:"Jose Abreu",team:"White Sox",note:"2002 Design"},
  "271": {player:"Jose Ramirez",team:"Indians",note:"2002 Design"},
  "272": {player:"Tim Hudson",team:"Athletics",note:"2002 Design"},
  "273": {player:"Adrian Morejon",team:"Padres",note:"Rookie 2002 Design"},
  "274": {player:"Johnny Bench",team:"Reds",note:"2002 Design"},
  "275": {player:"Juan Marichal",team:"Giants",note:"2002 Design"},
  "276": {player:"Kevin Newman",team:"Pirates",note:"2002 Design"},
  "277": {player:"Joe Morgan",team:"Reds",note:"2002 Design"},
  "278": {player:"Lourdes Gurriel Jr.",team:"Blue Jays",note:"2002 Design"},
  "279": {player:"Miguel Cabrera",team:"Tigers",note:"2002 Design"},
  "280": {player:"Ryan Braun",team:"Brewers",note:"2002 Design"},
  "281": {player:"Lou Gehrig",team:"Yankees",note:"2002 Design"},
  "282": {player:"Brandon Woodruff",team:"Brewers",note:"2002 Design"},
  "283": {player:"Johnny Cueto",team:"Giants",note:"2002 Design"},
  "284": {player:"Wil Myers",team:"Padres",note:"2002 Design"},
  "285": {player:"Andruw Jones",team:"Braves",note:"2002 Design"},
  "286": {player:"Cavan Biggio",team:"Blue Jays",note:"2002 Design"},
  "287": {player:"Jonathan Villar",team:"Marlins",note:"2002 Design"},
  "288": {player:"Justin Verlander",team:"Astros",note:"2002 Design"},
  "289": {player:"Pedro Martinez",team:"Red Sox",note:"2002 Design"},
  "290": {player:"Jose Urquidy",team:"Astros",note:"Rookie 2002 Design"},
  "291": {player:"Andy Pettitte",team:"Yankees",note:"2002 Design"},
  "292": {player:"Yu Chang",team:"Indians",note:"Rookie 2002 Design"},
  "293": {player:"Aaron Judge",team:"Yankees",note:"2002 Design"},
  "294": {player:"Elvis Andrus",team:"Rangers",note:"2002 Design"},
  "295": {player:"Andre Dawson",team:"Expos",note:"2002 Design"},
  "296": {player:"Carlos Santana",team:"Indians",note:"2002 Design"},
  "297": {player:"Willie Mays",team:"Giants",note:"2002 Design"},
  "298": {player:"Stephen Strasburg",team:"Nationals",note:"2002 Design"},
  "299": {player:"Kris Bryant",team:"Cubs",note:"2002 Design"},
  "300": {player:"Freddie Freeman",team:"Braves",note:"2002 Design"}
};
CARD_NAMES["Opening Day"] = {
  "1": {player:"Brendan McKay",team:"Rays",note:"Rookie"},
  "2": {player:"Jonathan Villar",team:"Orioles",note:""},
  "3": {player:"Garrett Cooper",team:"Marlins",note:""},
  "4": {player:"Brandon Woodruff",team:"Brewers",note:""},
  "5": {player:"Mike Moustakas",team:"Reds",note:""},
  "6": {player:"Sean Doolittle",team:"Nationals",note:""},
  "7": {player:"James Paxton",team:"Yankees",note:""},
  "8": {player:"Domingo Santana",team:"Mariners",note:""},
  "9": {player:"Joc Pederson",team:"Dodgers",note:""},
  "10": {player:"Yasmani Grandal",team:"White Sox",note:""},
  "11": {player:"Luis Arraez",team:"Twins",note:""},
  "12": {player:"Nico Hoerner",team:"Cubs",note:"Rookie"},
  "13": {player:"Brian Anderson",team:"Marlins",note:""},
  "14": {player:"Alex Verdugo",team:"Red Sox",note:""},
  "15": {player:"J.T. Realmuto",team:"Phillies",note:""},
  "16": {player:"Zac Gallen",team:"Diamondbacks",note:"Rookie"},
  "17": {player:"Kyle Lewis",team:"Mariners",note:"Rookie"},
  "18": {player:"Lance Lynn",team:"Rangers",note:""},
  "19": {player:"Tim Anderson",team:"White Sox",note:""},
  "20": {player:"Max Scherzer",team:"Nationals",note:""},
  "21": {player:"Gerrit Cole",team:"Yankees",note:""},
  "22": {player:"Anthony Rizzo",team:"Cubs",note:""},
  "23": {player:"Eduardo Rodriguez",team:"Red Sox",note:""},
  "24": {player:"Willson Contreras",team:"Cubs",note:""},
  "25": {player:"Omar Narvaez",team:"Brewers",note:""},
  "26": {player:"Sean Murphy",team:"Athletics",note:"Rookie"},
  "27": {player:"Juan Soto",team:"Nationals",note:""},
  "28": {player:"Mookie Betts",team:"Dodgers",note:""},
  "29": {player:"Jordan Yamamoto",team:"Marlins",note:"Rookie"},
  "30": {player:"Nick Solak",team:"Rangers",note:"Rookie"},
  "31": {player:"Aaron Judge",team:"Yankees",note:""},
  "32": {player:"J.D. Martinez",team:"Red Sox",note:""},
  "33": {player:"Vladimir Guerrero Jr.",team:"Blue Jays",note:""},
  "34": {player:"Jeff McNeil",team:"Mets",note:""},
  "35": {player:"Trea Turner",team:"Nationals",note:""},
  "36": {player:"Ken Giles",team:"Blue Jays",note:""},
  "37": {player:"Justin Turner",team:"Dodgers",note:""},
  "38": {player:"Nolan Arenado",team:"Rockies",note:""},
  "39": {player:"Carter Kieboom",team:"Nationals",note:""},
  "40": {player:"Mitch Garver",team:"Twins",note:""},
  "41": {player:"Patrick Corbin",team:"Nationals",note:""},
  "42": {player:"Max Fried",team:"Braves",note:""},
  "43": {player:"Shohei Ohtani",team:"Angels",note:""},
  "44": {player:"Albert Pujols",team:"Angels",note:""},
  "45": {player:"Dakota Hudson",team:"Cardinals",note:""},
  "46": {player:"Franmil Reyes",team:"Indians",note:""},
  "47": {player:"Jose Ramirez",team:"Indians",note:""},
  "48": {player:"Francisco Lindor",team:"Indians",note:""},
  "49": {player:"Sandy Alcantara",team:"Marlins",note:""},
  "50": {player:"Kenta Maeda",team:"Twins",note:""},
  "51": {player:"Ramon Laureano",team:"Athletics",note:""},
  "52": {player:"David Dahl",team:"Rockies",note:""},
  "53": {player:"Jon Lester",team:"Cubs",note:""},
  "54": {player:"Adalberto Mondesi",team:"Royals",note:""},
  "55": {player:"Abraham Toro",team:"Astros",note:"Rookie"},
  "56": {player:"Mike Soroka",team:"Braves",note:""},
  "57": {player:"Dustin May",team:"Dodgers",note:"Rookie"},
  "58": {player:"Mike Fiers",team:"Athletics",note:""},
  "59": {player:"Gary Sanchez",team:"Yankees",note:""},
  "60": {player:"Lourdes Gurriel Jr.",team:"Blue Jays",note:""},
  "61": {player:"Keston Hiura",team:"Brewers",note:""},
  "62": {player:"Michel Baez",team:"Padres",note:"Rookie"},
  "63": {player:"Yordan Alvarez",team:"Astros",note:"Rookie"},
  "64": {player:"Mike Yastrzemski",team:"Giants",note:""},
  "65": {player:"Justin Verlander",team:"Astros",note:""},
  "66": {player:"Paul Goldschmidt",team:"Cardinals",note:""},
  "67": {player:"Ronald Acuna Jr.",team:"Braves",note:""},
  "68": {player:"Dominic Smith",team:"Mets",note:""},
  "69": {player:"Tommy La Stella",team:"Angels",note:""},
  "70": {player:"Gavin Lux",team:"Dodgers",note:"Rookie"},
  "71": {player:"Ozzie Albies",team:"Braves",note:""},
  "72": {player:"Jorge Soler",team:"Royals",note:""},
  "73": {player:"Amed Rosario",team:"Mets",note:""},
  "74": {player:"Tommy Pham",team:"Padres",note:""},
  "75": {player:"Craig Kimbrel",team:"Cubs",note:""},
  "76": {player:"Jack Flaherty",team:"Cardinals",note:""},
  "77": {player:"Bryan Reynolds",team:"Pirates",note:""},
  "78": {player:"Matt Chapman",team:"Athletics",note:""},
  "79": {player:"DJ LeMahieu",team:"Yankees",note:""},
  "80": {player:"Michael Conforto",team:"Mets",note:""},
  "81": {player:"Evan Longoria",team:"Giants",note:""},
  "82": {player:"Orlando Arcia",team:"Brewers",note:""},
  "83": {player:"Eric Hosmer",team:"Padres",note:""},
  "84": {player:"Kyle Seager",team:"Mariners",note:""},
  "85": {player:"Elvis Andrus",team:"Rangers",note:""},
  "86": {player:"Anthony Rendon",team:"Angels",note:""},
  "87": {player:"Giancarlo Stanton",team:"Yankees",note:""},
  "88": {player:"Matt Carpenter",team:"Cardinals",note:""},
  "89": {player:"Jose Altuve",team:"Astros",note:""},
  "90": {player:"Mike Trout",team:"Angels",note:""},
  "91": {player:"Marco Gonzales",team:"Mariners",note:""},
  "92": {player:"Zach Plesac",team:"Indians",note:""},
  "93": {player:"Nelson Cruz",team:"Twins",note:""},
  "94": {player:"Liam Hendriks",team:"Athletics",note:""},
  "95": {player:"Eduardo Escobar",team:"Diamondbacks",note:""},
  "96": {player:"Aroldis Chapman",team:"Yankees",note:""},
  "97": {player:"Eugenio Suarez",team:"Reds",note:""},
  "98": {player:"Oscar Mercado",team:"Indians",note:""},
  "99": {player:"Nick Senzel",team:"Reds",note:""},
  "100": {player:"John Means",team:"Orioles",note:""},
  "101": {player:"Kenley Jansen",team:"Dodgers",note:""},
  "102": {player:"Scott Kingery",team:"Phillies",note:""},
  "103": {player:"Hanser Alberto",team:"Orioles",note:""},
  "104": {player:"Matthew Boyd",team:"Tigers",note:""},
  "105": {player:"Jesus Luzardo",team:"Athletics",note:"Rookie"},
  "106": {player:"Tyler Glasnow",team:"Rays",note:""},
  "107": {player:"Max Muncy",team:"Dodgers",note:""},
  "108": {player:"Corey Seager",team:"Dodgers",note:""},
  "109": {player:"Trevor Story",team:"Rockies",note:""},
  "110": {player:"Merrill Kelly",team:"Diamondbacks",note:""},
  "111": {player:"Miguel Cabrera",team:"Tigers",note:""},
  "112": {player:"Victor Robles",team:"Nationals",note:""},
  "113": {player:"Charlie Morton",team:"Rays",note:""},
  "114": {player:"Randal Grichuk",team:"Blue Jays",note:""},
  "115": {player:"Yusei Kikuchi",team:"Mariners",note:""},
  "116": {player:"Dansby Swanson",team:"Braves",note:""},
  "117": {player:"Kris Bryant",team:"Cubs",note:""},
  "118": {player:"Yoan Moncada",team:"White Sox",note:""},
  "119": {player:"Joey Lucchesi",team:"Padres",note:""},
  "120": {player:"Hunter Dozier",team:"Royals",note:""},
  "121": {player:"Zack Greinke",team:"Astros",note:""},
  "122": {player:"Jorge Alfaro",team:"Marlins",note:""},
  "123": {player:"Trey Mancini",team:"Orioles",note:""},
  "124": {player:"Carlos Correa",team:"Astros",note:""},
  "125": {player:"Luis Castillo",team:"Reds",note:""},
  "126": {player:"Andres Munoz",team:"Padres",note:"Rookie"},
  "127": {player:"Kirby Yates",team:"Padres",note:""},
  "128": {player:"Javier Baez",team:"Cubs",note:""},
  "129": {player:"Cody Bellinger",team:"Dodgers",note:""},
  "130": {player:"Yadier Molina",team:"Cardinals",note:""},
  "131": {player:"Eddie Rosario",team:"Twins",note:""},
  "132": {player:"Clayton Kershaw",team:"Dodgers",note:""},
  "133": {player:"Christian Walker",team:"Diamondbacks",note:""},
  "134": {player:"Michael Brantley",team:"Astros",note:""},
  "135": {player:"Tommy Edman",team:"Cardinals",note:""},
  "136": {player:"Shane Bieber",team:"Indians",note:""},
  "137": {player:"Gregory Polanco",team:"Pirates",note:""},
  "138": {player:"Eloy Jimenez",team:"White Sox",note:""},
  "139": {player:"Paul DeJong",team:"Cardinals",note:""},
  "140": {player:"Michael Chavis",team:"Red Sox",note:""},
  "141": {player:"Lucas Giolito",team:"White Sox",note:""},
  "142": {player:"Carlos Santana",team:"Indians",note:""},
  "143": {player:"Kyle Schwarber",team:"Cubs",note:""},
  "144": {player:"Buster Posey",team:"Giants",note:""},
  "145": {player:"Freddie Freeman",team:"Braves",note:""},
  "146": {player:"George Springer",team:"Astros",note:""},
  "147": {player:"Aristides Aquino",team:"Reds",note:"Rookie"},
  "148": {player:"Jorge Polanco",team:"Twins",note:""},
  "149": {player:"Charlie Blackmon",team:"Rockies",note:""},
  "150": {player:"Will Smith",team:"Dodgers",note:""},
  "151": {player:"Ian Kennedy",team:"Royals",note:""},
  "152": {player:"Marcus Stroman",team:"Mets",note:""},
  "153": {player:"Josh Hader",team:"Brewers",note:""},
  "154": {player:"Whit Merrifield",team:"Royals",note:""},
  "155": {player:"J.D. Davis",team:"Mets",note:""},
  "156": {player:"Rhys Hoskins",team:"Phillies",note:""},
  "157": {player:"Pete Alonso",team:"Mets",note:""},
  "158": {player:"Mike Clevinger",team:"Indians",note:""},
  "159": {player:"Luke Voit",team:"Yankees",note:""},
  "160": {player:"Ryan Braun",team:"Brewers",note:""},
  "161": {player:"Ketel Marte",team:"Diamondbacks",note:""},
  "162": {player:"Max Kepler",team:"Twins",note:""},
  "163": {player:"Christian Yelich",team:"Brewers",note:""},
  "164": {player:"Alex Bregman",team:"Astros",note:""},
  "165": {player:"Brandon Lowe",team:"Rays",note:""},
  "166": {player:"Andrew Benintendi",team:"Red Sox",note:""},
  "167": {player:"Adbert Alzolay",team:"Cubs",note:"Rookie"},
  "168": {player:"A.J. Puk",team:"Athletics",note:"Rookie"},
  "169": {player:"Rafael Devers",team:"Red Sox",note:""},
  "170": {player:"Starling Marte",team:"Diamondbacks",note:""},
  "171": {player:"Joey Votto",team:"Reds",note:""},
  "172": {player:"Walker Buehler",team:"Dodgers",note:""},
  "173": {player:"Bo Bichette",team:"Blue Jays",note:"Rookie"},
  "174": {player:"Sonny Gray",team:"Reds",note:""},
  "175": {player:"Austin Meadows",team:"Rays",note:""},
  "176": {player:"Jean Segura",team:"Phillies",note:""},
  "177": {player:"Masahiro Tanaka",team:"Yankees",note:""},
  "178": {player:"Marcus Semien",team:"Athletics",note:""},
  "179": {player:"Niko Goodrum",team:"Tigers",note:""},
  "180": {player:"Austin Riley",team:"Braves",note:""},
  "181": {player:"Starlin Castro",team:"Nationals",note:""},
  "182": {player:"Jameson Taillon",team:"Pirates",note:""},
  "183": {player:"Yuli Gurriel",team:"Astros",note:""},
  "184": {player:"Matt Olson",team:"Athletics",note:""},
  "185": {player:"Aaron Nola",team:"Phillies",note:""},
  "186": {player:"Gleyber Torres",team:"Yankees",note:""},
  "187": {player:"Jacob deGrom",team:"Mets",note:""},
  "188": {player:"Bryce Harper",team:"Phillies",note:""},
  "189": {player:"Fernando Tatis Jr.",team:"Padres",note:""},
  "190": {player:"Trent Grisham",team:"Padres",note:"Rookie"},
  "191": {player:"Hunter Renfroe",team:"Rays",note:""},
  "192": {player:"Dee Gordon",team:"Mariners",note:""},
  "193": {player:"Cavan Biggio",team:"Blue Jays",note:""},
  "194": {player:"Emilio Pagan",team:"Padres",note:""},
  "195": {player:"Brad Hand",team:"Indians",note:""},
  "196": {player:"Chris Paddack",team:"Padres",note:""},
  "197": {player:"Josh Bell",team:"Pirates",note:""},
  "198": {player:"Dan Vogelbach",team:"Mariners",note:""},
  "199": {player:"Jose Berrios",team:"Twins",note:""},
  "200": {player:"Manny Machado",team:"Padres",note:""},
  "201": {player:"Luis Robert",team:"White Sox",note:"Rookie SP"}
};
CARD_NAMES["Stadium Club"] = {
  "1": {player:"Mike Trout",team:"Angels",note:""},
  "2": {player:"Nelson Cruz",team:"Twins",note:""},
  "3": {player:"Babe Ruth",team:"Yankees",note:""},
  "4": {player:"Justus Sheffield",team:"Mariners",note:""},
  "5": {player:"Bobby Bradley",team:"Indians",note:"Rookie"},
  "6": {player:"Abraham Toro",team:"Astros",note:"Rookie"},
  "7": {player:"Michel Baez",team:"Padres",note:"Rookie"},
  "8": {player:"Michael Conforto",team:"Mets",note:""},
  "9": {player:"Jameson Taillon",team:"Pirates",note:""},
  "10": {player:"Chris Sale",team:"Red Sox",note:""},
  "11": {player:"Matt Olson",team:"Athletics",note:""},
  "12": {player:"David Dahl",team:"Rockies",note:""},
  "13": {player:"Yadier Molina",team:"Cardinals",note:""},
  "14": {player:"Anthony Rizzo",team:"Cubs",note:""},
  "15": {player:"DJ LeMahieu",team:"Yankees",note:""},
  "16": {player:"Michael Chavis",team:"Red Sox",note:""},
  "17": {player:"J.T. Realmuto",team:"Phillies",note:""},
  "18": {player:"Giancarlo Stanton",team:"Yankees",note:""},
  "19": {player:"Eddie Rosario",team:"Twins",note:""},
  "20": {player:"Mitch Garver",team:"Twins",note:""},
  "21": {player:"Xander Bogaerts",team:"Red Sox",note:""},
  "22": {player:"Jose Ramirez",team:"Indians",note:""},
  "23": {player:"Dylan Cease",team:"White Sox",note:"Rookie"},
  "24": {player:"Walker Buehler",team:"Dodgers",note:""},
  "25": {player:"Yasmani Grandal",team:"White Sox",note:""},
  "26": {player:"Sean Murphy",team:"Athletics",note:"Rookie"},
  "27": {player:"Mike Clevinger",team:"Indians",note:""},
  "28": {player:"Max Muncy",team:"Dodgers",note:""},
  "29": {player:"Lorenzo Cain",team:"Brewers",note:""},
  "30": {player:"Bryce Harper",team:"Phillies",note:""},
  "31": {player:"John Means",team:"Orioles",note:""},
  "32": {player:"Yuli Gurriel",team:"Astros",note:""},
  "33": {player:"Albert Pujols",team:"Angels",note:""},
  "34": {player:"Anthony Kay",team:"Blue Jays",note:"Rookie"},
  "35": {player:"Lou Gehrig",team:"Yankees",note:""},
  "36": {player:"Aristides Aquino",team:"Reds",note:"Rookie"},
  "37": {player:"Mark Canha",team:"Athletics",note:""},
  "38": {player:"Eugenio Suarez",team:"Reds",note:""},
  "39": {player:"Ryan Zimmerman",team:"Nationals",note:""},
  "40": {player:"Blake Snell",team:"Rays",note:""},
  "41": {player:"Jonathan Villar",team:"Marlins",note:""},
  "42": {player:"Michael Brantley",team:"Astros",note:""},
  "43": {player:"Byron Buxton",team:"Twins",note:""},
  "44": {player:"Tommy Edman",team:"Cardinals",note:""},
  "45": {player:"Justin Turner",team:"Dodgers",note:""},
  "46": {player:"Joey Gallo",team:"Rangers",note:""},
  "47": {player:"Robel Garcia",team:"Cubs",note:"Rookie"},
  "48": {player:"George Springer",team:"Astros",note:""},
  "49": {player:"Josh VanMeter",team:"Reds",note:""},
  "50": {player:"Mike Moustakas",team:"Reds",note:""},
  "51": {player:"Adbert Alzolay",team:"Cubs",note:"Rookie"},
  "52": {player:"Mike Schmidt",team:"Phillies",note:""},
  "53": {player:"Brusdar Graterol",team:"Dodgers",note:"Rookie"},
  "54": {player:"David Wright",team:"Mets",note:""},
  "55": {player:"Lucas Giolito",team:"White Sox",note:""},
  "56": {player:"Robinson Cano",team:"Mets",note:""},
  "57": {player:"Shun Yamaguchi",team:"Blue Jays",note:"Rookie"},
  "58": {player:"Jason Varitek",team:"Red Sox",note:""},
  "59": {player:"Sean Doolittle",team:"Nationals",note:""},
  "60": {player:"Josh Donaldson",team:"Twins",note:""},
  "61": {player:"Dale Murphy",team:"Braves",note:""},
  "62": {player:"Austin Meadows",team:"Rays",note:""},
  "63": {player:"Yoan Moncada",team:"White Sox",note:""},
  "64": {player:"Yoshi Tsutsugo",team:"Rays",note:"Rookie"},
  "65": {player:"Dario Agrazal",team:"Tigers",note:"Rookie"},
  "66": {player:"Aaron Hicks",team:"Yankees",note:""},
  "67": {player:"Ted Williams",team:"Red Sox",note:""},
  "68": {player:"Paul Goldschmidt",team:"Cardinals",note:""},
  "69": {player:"Yordan Alvarez",team:"Astros",note:"Rookie"},
  "70": {player:"Bob Feller",team:"Indians",note:""},
  "71": {player:"Carl Yastrzemski",team:"Red Sox",note:""},
  "72": {player:"Zack Collins",team:"White Sox",note:"Rookie"},
  "73": {player:"Ketel Marte",team:"Diamondbacks",note:""},
  "74": {player:"Brandon Woodruff",team:"Brewers",note:""},
  "75": {player:"Nolan Ryan",team:"Astros",note:""},
  "76": {player:"Mike Soroka",team:"Braves",note:""},
  "77": {player:"Andrew McCutchen",team:"Phillies",note:""},
  "78": {player:"Sean Manaea",team:"Athletics",note:""},
  "79": {player:"Jose Abreu",team:"White Sox",note:""},
  "80": {player:"Mike Brosseau",team:"Rays",note:"Rookie"},
  "81": {player:"Randal Grichuk",team:"Blue Jays",note:""},
  "82": {player:"Kirby Yates",team:"Padres",note:""},
  "83": {player:"Max Kepler",team:"Twins",note:""},
  "84": {player:"Adrian Morejon",team:"Padres",note:"Rookie"},
  "85": {player:"Kyle Hendricks",team:"Cubs",note:""},
  "86": {player:"Yu Chang",team:"Indians",note:"Rookie"},
  "87": {player:"Clayton Kershaw",team:"Dodgers",note:""},
  "88": {player:"Starling Marte",team:"Diamondbacks",note:""},
  "89": {player:"Adalberto Mondesi",team:"Royals",note:""},
  "90": {player:"Tommy La Stella",team:"Angels",note:""},
  "91": {player:"Max Scherzer",team:"Nationals",note:""},
  "92": {player:"Luke Voit",team:"Yankees",note:""},
  "93": {player:"Kwang-Hyun Kim",team:"Cardinals",note:"Rookie"},
  "94": {player:"Masahiro Tanaka",team:"Yankees",note:""},
  "95": {player:"Jesus Luzardo",team:"Athletics",note:"Rookie"},
  "96": {player:"Mark McGwire",team:"Athletics",note:""},
  "97": {player:"Brendan Rodgers",team:"Rockies",note:""},
  "98": {player:"Sam Hilliard",team:"Rockies",note:"Rookie"},
  "99": {player:"Nomar Garciaparra",team:"Red Sox",note:""},
  "100": {player:"Javier Baez",team:"Cubs",note:""},
  "101": {player:"James Marvel",team:"Pirates",note:"Rookie"},
  "102": {player:"Barry Larkin",team:"Reds",note:""},
  "103": {player:"Hideki Matsui",team:"Yankees",note:""},
  "104": {player:"Juan Soto",team:"Nationals",note:""},
  "105": {player:"Junior Fernandez",team:"Cardinals",note:"Rookie"},
  "106": {player:"Cal Ripken Jr.",team:"Orioles",note:""},
  "107": {player:"Kris Bryant",team:"Cubs",note:""},
  "108": {player:"Yusei Kikuchi",team:"Mariners",note:""},
  "109": {player:"Trey Mancini",team:"Orioles",note:""},
  "110": {player:"Ernie Banks",team:"Cubs",note:""},
  "111": {player:"Luis Severino",team:"Yankees",note:""},
  "112": {player:"Bo Bichette",team:"Blue Jays",note:"Rookie"},
  "113": {player:"Darryl Strawberry",team:"Mets",note:""},
  "114": {player:"Robbie Ray",team:"Diamondbacks",note:""},
  "115": {player:"Ramon Laureano",team:"Athletics",note:""},
  "116": {player:"Ronald Acuna Jr.",team:"Braves",note:""},
  "117": {player:"Miguel Cabrera",team:"Tigers",note:""},
  "118": {player:"Jacob deGrom",team:"Mets",note:""},
  "119": {player:"Derek Dietrich",team:"Reds",note:""},
  "120": {player:"Nolan Arenado",team:"Rockies",note:""},
  "121": {player:"Nick Markakis",team:"Braves",note:""},
  "122": {player:"Carter Kieboom",team:"Nationals",note:""},
  "123": {player:"Carlos Correa",team:"Astros",note:""},
  "124": {player:"Keston Hiura",team:"Brewers",note:""},
  "125": {player:"Sonny Gray",team:"Reds",note:""},
  "126": {player:"Travis Demeritte",team:"Tigers",note:"Rookie"},
  "127": {player:"Miguel Sano",team:"Twins",note:""},
  "128": {player:"Lourdes Gurriel Jr.",team:"Blue Jays",note:""},
  "129": {player:"Alex Young",team:"Diamondbacks",note:"Rookie"},
  "130": {player:"Cody Bellinger",team:"Dodgers",note:""},
  "131": {player:"Joey Votto",team:"Reds",note:""},
  "132": {player:"Jeff McNeil",team:"Mets",note:""},
  "133": {player:"Victor Robles",team:"Nationals",note:""},
  "134": {player:"Didi Gregorius",team:"Phillies",note:""},
  "135": {player:"J.D. Martinez",team:"Red Sox",note:""},
  "136": {player:"Zack Greinke",team:"Astros",note:""},
  "137": {player:"Hyun-Jin Ryu",team:"Blue Jays",note:""},
  "138": {player:"Aaron Judge",team:"Yankees",note:""},
  "139": {player:"Trevor Story",team:"Rockies",note:""},
  "140": {player:"Willie Mays",team:"Giants",note:""},
  "141": {player:"Danny Jansen",team:"Blue Jays",note:""},
  "142": {player:"Adam Wainwright",team:"Cardinals",note:""},
  "143": {player:"Will Smith",team:"Dodgers",note:""},
  "144": {player:"Lewis Thorpe",team:"Twins",note:"Rookie"},
  "145": {player:"Shohei Ohtani",team:"Angels",note:""},
  "146": {player:"Jose Canseco",team:"Athletics",note:""},
  "147": {player:"Gleyber Torres",team:"Yankees",note:""},
  "148": {player:"Honus Wagner",team:"Pirates",note:""},
  "149": {player:"Jose Urquidy",team:"Astros",note:"Rookie"},
  "150": {player:"Rod Carew",team:"Angels",note:""},
  "151": {player:"Nick Solak",team:"Rangers",note:"Rookie"},
  "152": {player:"Trent Grisham",team:"Padres",note:"Rookie"},
  "153": {player:"Roberto Alomar",team:"Blue Jays",note:""},
  "154": {player:"Brian Anderson",team:"Marlins",note:""},
  "155": {player:"Joey Lucchesi",team:"Padres",note:""},
  "156": {player:"Matt Thaiss",team:"Angels",note:"Rookie"},
  "157": {player:"Marcell Ozuna",team:"Braves",note:""},
  "158": {player:"Noah Syndergaard",team:"Mets",note:""},
  "159": {player:"Roberto Clemente",team:"Pirates",note:""},
  "160": {player:"Tony Gwynn",team:"Padres",note:""},
  "161": {player:"Manny Machado",team:"Padres",note:""},
  "162": {player:"Jaylin Davis",team:"Giants",note:"Rookie"},
  "163": {player:"Nomar Mazara",team:"White Sox",note:""},
  "164": {player:"Pete Alonso",team:"Mets",note:""},
  "165": {player:"Stephen Strasburg",team:"Nationals",note:""},
  "166": {player:"Ozzie Smith",team:"Cardinals",note:""},
  "167": {player:"Trevor Bauer",team:"Reds",note:""},
  "168": {player:"Ryne Sandberg",team:"Cubs",note:""},
  "169": {player:"Chris Paddack",team:"Padres",note:""},
  "170": {player:"Seth Brown",team:"Athletics",note:"Rookie"},
  "171": {player:"Tim Lincecum",team:"Giants",note:""},
  "172": {player:"Jeff Bagwell",team:"Astros",note:""},
  "173": {player:"Freddie Freeman",team:"Braves",note:""},
  "174": {player:"Gio Urshela",team:"Yankees",note:""},
  "175": {player:"Justin Dunn",team:"Mariners",note:"Rookie"},
  "176": {player:"Dallas Keuchel",team:"White Sox",note:""},
  "177": {player:"Yasiel Puig",team:"Indians",note:""},
  "178": {player:"Barry Zito",team:"Athletics",note:""},
  "179": {player:"Marcus Semien",team:"Athletics",note:""},
  "180": {player:"Josh Bell",team:"Pirates",note:""},
  "181": {player:"Josh Hader",team:"Brewers",note:""},
  "182": {player:"Aroldis Chapman",team:"Yankees",note:""},
  "183": {player:"Andres Munoz",team:"Padres",note:"Rookie"},
  "184": {player:"Brandon Lowe",team:"Rays",note:""},
  "185": {player:"Buster Posey",team:"Giants",note:""},
  "186": {player:"Austin Nola",team:"Mariners",note:"Rookie"},
  "187": {player:"Stan Musial",team:"Cardinals",note:""},
  "188": {player:"Fernando Tatis Jr.",team:"Padres",note:""},
  "189": {player:"Jorge Posada",team:"Yankees",note:""},
  "190": {player:"Dakota Hudson",team:"Cardinals",note:""},
  "191": {player:"Francisco Lindor",team:"Indians",note:""},
  "192": {player:"Hank Aaron",team:"Braves",note:""},
  "193": {player:"Jack Flaherty",team:"Cardinals",note:""},
  "194": {player:"Matt Chapman",team:"Athletics",note:""},
  "195": {player:"Andrew Benintendi",team:"Red Sox",note:""},
  "196": {player:"Marcus Stroman",team:"Mets",note:""},
  "197": {player:"Mike Yastrzemski",team:"Giants",note:""},
  "198": {player:"Shed Long",team:"Mariners",note:""},
  "199": {player:"David Ortiz",team:"Red Sox",note:""},
  "200": {player:"Will Clark",team:"Giants",note:""},
  "201": {player:"Kerry Wood",team:"Cubs",note:""},
  "202": {player:"Patrick Corbin",team:"Nationals",note:""},
  "203": {player:"Chipper Jones",team:"Braves",note:""},
  "204": {player:"Patrick Sandoval",team:"Angels",note:"Rookie"},
  "205": {player:"Corey Kluber",team:"Rangers",note:""},
  "206": {player:"Salvador Perez",team:"Royals",note:""},
  "207": {player:"Shane Bieber",team:"Indians",note:""},
  "208": {player:"Domingo Leyba",team:"Diamondbacks",note:"Rookie"},
  "209": {player:"Charlie Morton",team:"Rays",note:""},
  "210": {player:"Eduardo Escobar",team:"Diamondbacks",note:""},
  "211": {player:"Lance McCullers Jr.",team:"Astros",note:""},
  "212": {player:"Jorge Soler",team:"Royals",note:""},
  "213": {player:"Josh Rojas",team:"Diamondbacks",note:"Rookie"},
  "214": {player:"Ty Cobb",team:"Tigers",note:""},
  "215": {player:"Gary Sanchez",team:"Yankees",note:""},
  "216": {player:"Rhys Hoskins",team:"Phillies",note:""},
  "217": {player:"Logan Webb",team:"Giants",note:"Rookie"},
  "218": {player:"Mookie Betts",team:"Dodgers",note:""},
  "219": {player:"Hunter Harvey",team:"Orioles",note:"Rookie"},
  "220": {player:"Paul DeJong",team:"Cardinals",note:""},
  "221": {player:"Dan Vogelbach",team:"Mariners",note:""},
  "222": {player:"Elvis Andrus",team:"Rangers",note:""},
  "223": {player:"Matthew Boyd",team:"Tigers",note:""},
  "224": {player:"Edgar Martinez",team:"Mariners",note:""},
  "225": {player:"Nick Senzel",team:"Reds",note:""},
  "226": {player:"Hunter Dozier",team:"Royals",note:""},
  "227": {player:"Justin Verlander",team:"Astros",note:""},
  "228": {player:"Khris Davis",team:"Athletics",note:""},
  "229": {player:"Tim Anderson",team:"White Sox",note:""},
  "230": {player:"Jordan Yamamoto",team:"Marlins",note:"Rookie"},
  "231": {player:"Al Kaline",team:"Tigers",note:""},
  "232": {player:"Jake Fraley",team:"Mariners",note:"Rookie"},
  "233": {player:"Nick Castellanos",team:"Reds",note:""},
  "234": {player:"Rafael Devers",team:"Red Sox",note:""},
  "235": {player:"Carlos Santana",team:"Indians",note:""},
  "236": {player:"Alex Bregman",team:"Astros",note:""},
  "237": {player:"Brendan McKay",team:"Rays",note:"Rookie"},
  "238": {player:"Amed Rosario",team:"Mets",note:""},
  "239": {player:"Austin Hays",team:"Orioles",note:""},
  "240": {player:"A.J. Puk",team:"Athletics",note:"Rookie"},
  "241": {player:"Kyle Tucker",team:"Astros",note:""},
  "242": {player:"George Brett",team:"Royals",note:""},
  "243": {player:"Aaron Nola",team:"Phillies",note:""},
  "244": {player:"Ichiro",team:"Mariners",note:""},
  "245": {player:"Willi Castro",team:"Tigers",note:"Rookie"},
  "246": {player:"Trea Turner",team:"Nationals",note:""},
  "247": {player:"Gerrit Cole",team:"Yankees",note:""},
  "248": {player:"Yu Darvish",team:"Cubs",note:""},
  "249": {player:"Kyle Lewis",team:"Mariners",note:"Rookie"},
  "250": {player:"Tyler Glasnow",team:"Rays",note:""},
  "251": {player:"Luis Arraez",team:"Twins",note:""},
  "252": {player:"Brock Burke",team:"Rangers",note:"Rookie"},
  "253": {player:"Nico Hoerner",team:"Cubs",note:"Rookie"},
  "254": {player:"Jose Berrios",team:"Twins",note:""},
  "255": {player:"Dustin May",team:"Dodgers",note:"Rookie"},
  "256": {player:"Bryan Reynolds",team:"Pirates",note:""},
  "257": {player:"Frank Thomas",team:"White Sox",note:""},
  "258": {player:"Isan Diaz",team:"Marlins",note:"Rookie"},
  "259": {player:"Joc Pederson",team:"Dodgers",note:""},
  "260": {player:"Willie Calhoun",team:"Rangers",note:""},
  "261": {player:"Charlie Blackmon",team:"Rockies",note:""},
  "262": {player:"Zac Gallen",team:"Diamondbacks",note:"Rookie"},
  "263": {player:"Corey Seager",team:"Dodgers",note:""},
  "264": {player:"Cavan Biggio",team:"Blue Jays",note:""},
  "265": {player:"Christian Walker",team:"Diamondbacks",note:""},
  "266": {player:"Kolten Wong",team:"Cardinals",note:""},
  "267": {player:"Mitch Keller",team:"Pirates",note:""},
  "268": {player:"Luis Castillo",team:"Reds",note:""},
  "269": {player:"Aaron Civale",team:"Indians",note:"Rookie"},
  "270": {player:"Ken Griffey Jr.",team:"Mariners",note:""},
  "271": {player:"Logan Allen",team:"Indians",note:"Rookie"},
  "272": {player:"Don Mattingly",team:"Yankees",note:""},
  "273": {player:"Austin Riley",team:"Braves",note:""},
  "274": {player:"Felix Hernandez",team:"Braves",note:""},
  "275": {player:"Bubba Starling",team:"Royals",note:"Rookie"},
  "276": {player:"Kyle Schwarber",team:"Cubs",note:""},
  "277": {player:"Johnny Bench",team:"Reds",note:""},
  "278": {player:"Jose Altuve",team:"Astros",note:""},
  "279": {player:"Mitch Haniger",team:"Mariners",note:""},
  "280": {player:"Dansby Swanson",team:"Braves",note:""},
  "281": {player:"Josh Staumont",team:"Royals",note:"Rookie"},
  "282": {player:"Sheldon Neuse",team:"Athletics",note:"Rookie"},
  "283": {player:"Anthony Rendon",team:"Angels",note:""},
  "284": {player:"James Karinchak",team:"Indians",note:"Rookie"},
  "285": {player:"Shogo Akiyama",team:"Reds",note:""},
  "286": {player:"Ozzie Albies",team:"Braves",note:""},
  "287": {player:"Tommy Pham",team:"Padres",note:""},
  "288": {player:"Vladimir Guerrero Jr.",team:"Blue Jays",note:""},
  "289": {player:"Luis Robert",team:"White Sox",note:"Rookie"},
  "290": {player:"Sandy Koufax",team:"Dodgers",note:""},
  "291": {player:"Willson Contreras",team:"Cubs",note:""},
  "292": {player:"Christian Yelich",team:"Brewers",note:""},
  "293": {player:"Randy Johnson",team:"Diamondbacks",note:""},
  "294": {player:"T.J. Zeuch",team:"Blue Jays",note:"Rookie"},
  "295": {player:"Jake Rogers",team:"Tigers",note:"Rookie"},
  "296": {player:"Eduardo Rodriguez",team:"Red Sox",note:""},
  "297": {player:"Mauricio Dubon",team:"Giants",note:"Rookie"},
  "298": {player:"Gavin Lux",team:"Dodgers",note:"Rookie"},
  "299": {player:"Randy Arozarena",team:"Rays",note:"Rookie"},
  "300": {player:"Eloy Jimenez",team:"White Sox",note:""}
};
CARD_NAMES["Big League"] = {
    "1": {player:"Salvador Perez",team:"Royals",note:""},
    "2": {player:"Elvis Andrus",team:"Rangers",note:""},
    "3": {player:"Patrick Corbin",team:"Nationals",note:""},
    "4": {player:"Nelson Cruz",team:"Twins",note:""},
    "5": {player:"George Springer",team:"Astros",note:""},
    "6": {player:"Eric Hosmer",team:"Padres",note:""},
    "7": {player:"Jonathan Schoop",team:"Tigers",note:""},
    "8": {player:"Jose Urquidy",team:"Astros",note:"Rookie"},
    "9": {player:"Willson Contreras",team:"Cubs",note:""},
    "10": {player:"DJ LeMahieu",team:"Yankees",note:""},
    "11": {player:"Mike Moustakas",team:"Reds",note:""},
    "12": {player:"Tommy La Stella",team:"Angels",note:""},
    "13": {player:"Dee Gordon",team:"Mariners",note:""},
    "14": {player:"Joey Votto",team:"Reds",note:""},
    "15": {player:"Miguel Sano",team:"Twins",note:""},
    "16": {player:"Yusei Kikuchi",team:"Mariners",note:""},
    "17": {player:"Roberto Perez",team:"Indians",note:""},
    "18": {player:"Niko Goodrum",team:"Tigers",note:""},
    "19": {player:"Lorenzo Cain",team:"Brewers",note:""},
    "20": {player:"Griffin Canning",team:"Angels",note:""},
    "21": {player:"Cole Hamels",team:"Braves",note:""},
    "22": {player:"Eduardo Escobar",team:"Diamondbacks",note:""},
    "23": {player:"Walker Buehler",team:"Dodgers",note:""},
    "24": {player:"Alex Young",team:"Diamondbacks",note:"Rookie"},
    "25": {player:"Brian Anderson",team:"Marlins",note:""},
    "26": {player:"Matthew Boyd",team:"Tigers",note:""},
    "27": {player:"Bryan Reynolds",team:"Pirates",note:""},
    "28": {player:"Shohei Ohtani",team:"Angels",note:""},
    "29": {player:"Pete Alonso",team:"Mets",note:""},
    "30": {player:"Kole Calhoun",team:"Diamondbacks",note:""},
    "31": {player:"Bryce Harper",team:"Phillies",note:""},
    "32": {player:"Jorge Soler",team:"Royals",note:""},
    "33": {player:"Tommy Edman",team:"Cardinals",note:""},
    "34": {player:"Zack Collins",team:"White Sox",note:"Rookie"},
    "35": {player:"Joey Lucchesi",team:"Padres",note:""},
    "36": {player:"Noah Syndergaard",team:"Mets",note:""},
    "37": {player:"Jesus Aguilar",team:"Marlins",note:""},
    "38": {player:"Ryan McMahon",team:"Rockies",note:""},
    "39": {player:"Nolan Arenado",team:"Rockies",note:""},
    "40": {player:"Nomar Mazara",team:"White Sox",note:""},
    "41": {player:"Michael Chavis",team:"Red Sox",note:""},
    "42": {player:"Jeff McNeil",team:"Mets",note:""},
    "43": {player:"Cody Bellinger",team:"Dodgers",note:""},
    "44": {player:"C.J. Cron",team:"Tigers",note:""},
    "45": {player:"Whit Merrifield",team:"Royals",note:""},
    "46": {player:"Nick Senzel",team:"Reds",note:""},
    "47": {player:"Aaron Nola",team:"Phillies",note:""},
    "48": {player:"Keston Hiura",team:"Brewers",note:""},
    "49": {player:"David Price",team:"Dodgers",note:""},
    "50": {player:"Austin Riley",team:"Braves",note:""},
    "51": {player:"Ramon Laureano",team:"Athletics",note:""},
    "52": {player:"J.T. Realmuto",team:"Phillies",note:""},
    "53": {player:"Marcus Stroman",team:"Mets",note:""},
    "54": {player:"Ozzie Albies",team:"Braves",note:""},
    "55": {player:"Sonny Gray",team:"Reds",note:""},
    "56": {player:"Sean Murphy",team:"Athletics",note:"Rookie"},
    "57": {player:"Christian Yelich",team:"Brewers",note:""},
    "58": {player:"A.J. Puk",team:"Athletics",note:"Rookie"},
    "59": {player:"Kolten Wong",team:"Cardinals",note:""},
    "60": {player:"Dustin May",team:"Dodgers",note:"Rookie"},
    "61": {player:"Jesus Luzardo",team:"Athletics",note:"Rookie"},
    "62": {player:"Hunter Harvey",team:"Orioles",note:"Rookie"},
    "63": {player:"Max Kepler",team:"Twins",note:""},
    "64": {player:"Evan Longoria",team:"Giants",note:""},
    "65": {player:"Blake Snell",team:"Rays",note:""},
    "66": {player:"Luis Castillo",team:"Reds",note:""},
    "67": {player:"Aaron Civale",team:"Indians",note:"Rookie"},
    "68": {player:"Mike Trout",team:"Angels",note:""},
    "69": {player:"Eloy Jimenez",team:"White Sox",note:""},
    "70": {player:"Adalberto Mondesi",team:"Royals",note:""},
    "71": {player:"Aroldis Chapman",team:"Yankees",note:""},
    "72": {player:"Anthony Rizzo",team:"Cubs",note:""},
    "73": {player:"Charlie Morton",team:"Rays",note:""},
    "74": {player:"Amed Rosario",team:"Mets",note:""},
    "75": {player:"Jon Lester",team:"Cubs",note:""},
    "76": {player:"Mike Minor",team:"Rangers",note:""},
    "77": {player:"Charlie Blackmon",team:"Rockies",note:""},
    "78": {player:"Alex Bregman",team:"Astros",note:""},
    "79": {player:"Jordan Yamamoto",team:"Marlins",note:"Rookie"},
    "80": {player:"Ian Desmond",team:"Rockies",note:""},
    "81": {player:"Yasmani Grandal",team:"White Sox",note:""},
    "82": {player:"Ronald Acuna Jr.",team:"Braves",note:""},
    "83": {player:"Trent Grisham",team:"Padres",note:"Rookie"},
    "84": {player:"Gerrit Cole",team:"Yankees",note:""},
    "85": {player:"Rafael Devers",team:"Red Sox",note:""},
    "86": {player:"Trea Turner",team:"Nationals",note:""},
    "87": {player:"Willy Adames",team:"Rays",note:""},
    "88": {player:"Dallas Keuchel",team:"White Sox",note:""},
    "89": {player:"Paul Goldschmidt",team:"Cardinals",note:""},
    "90": {player:"Xander Bogaerts",team:"Red Sox",note:""},
    "91": {player:"Shin-Soo Choo",team:"Rangers",note:""},
    "92": {player:"Gleyber Torres",team:"Yankees",note:""},
    "93": {player:"Javier Baez",team:"Cubs",note:""},
    "94": {player:"Stephen Strasburg",team:"Nationals",note:""},
    "95": {player:"Robinson Cano",team:"Mets",note:""},
    "96": {player:"Hunter Dozier",team:"Royals",note:""},
    "97": {player:"Trevor Story",team:"Rockies",note:""},
    "98": {player:"Max Fried",team:"Braves",note:""},
    "99": {player:"Nicky Lopez",team:"Royals",note:""},
    "100": {player:"Michael Conforto",team:"Mets",note:""},
    "101": {player:"Joe Musgrove",team:"Pirates",note:""},
    "102": {player:"Fernando Tatis Jr.",team:"Padres",note:""},
    "103": {player:"Eugenio Suarez",team:"Reds",note:""},
    "104": {player:"Mitch Keller",team:"Pirates",note:""},
    "105": {player:"Miguel Cabrera",team:"Tigers",note:""},
    "106": {player:"Starling Marte",team:"Diamondbacks",note:""},
    "107": {player:"Aristides Aquino",team:"Reds",note:"Rookie"},
    "108": {player:"Bo Bichette",team:"Blue Jays",note:"Rookie"},
    "109": {player:"Matt Olson",team:"Athletics",note:""},
    "110": {player:"Andres Munoz",team:"Padres",note:"Rookie"},
    "111": {player:"Juan Soto",team:"Nationals",note:""},
    "112": {player:"Buster Posey",team:"Giants",note:""},
    "113": {player:"Albert Pujols",team:"Angels",note:""},
    "114": {player:"Jorge Polanco",team:"Twins",note:""},
    "115": {player:"Ryan Braun",team:"Brewers",note:""},
    "116": {player:"Freddie Freeman",team:"Braves",note:""},
    "117": {player:"Austin Meadows",team:"Rays",note:""},
    "118": {player:"Jorge Alfaro",team:"Marlins",note:""},
    "119": {player:"Andrew Benintendi",team:"Red Sox",note:""},
    "120": {player:"Jean Segura",team:"Phillies",note:""},
    "121": {player:"Jacob deGrom",team:"Mets",note:""},
    "122": {player:"Brendan McKay",team:"Rays",note:"Rookie"},
    "123": {player:"Yordan Alvarez",team:"Astros",note:"Rookie"},
    "124": {player:"Wil Myers",team:"Padres",note:""},
    "125": {player:"Luis Arraez",team:"Twins",note:""},
    "126": {player:"Jack Flaherty",team:"Cardinals",note:""},
    "127": {player:"Yadier Molina",team:"Cardinals",note:""},
    "128": {player:"Lourdes Gurriel Jr.",team:"Blue Jays",note:""},
    "129": {player:"Dansby Swanson",team:"Braves",note:""},
    "130": {player:"Andrelton Simmons",team:"Angels",note:""},
    "131": {player:"German Marquez",team:"Rockies",note:""},
    "132": {player:"Jeff Samardzija",team:"Giants",note:""},
    "133": {player:"Trey Mancini",team:"Orioles",note:""},
    "134": {player:"Max Scherzer",team:"Nationals",note:""},
    "135": {player:"Jordan Montgomery",team:"Yankees",note:""},
    "136": {player:"David Peralta",team:"Diamondbacks",note:""},
    "137": {player:"Chris Archer",team:"Pirates",note:""},
    "138": {player:"Brandon Crawford",team:"Giants",note:""},
    "139": {player:"Nico Hoerner",team:"Cubs",note:"Rookie"},
    "140": {player:"Kevin Newman",team:"Pirates",note:""},
    "141": {player:"Vladimir Guerrero Jr.",team:"Blue Jays",note:""},
    "142": {player:"Eddie Rosario",team:"Twins",note:""},
    "143": {player:"Harold Ramirez",team:"Marlins",note:""},
    "144": {player:"Will Smith",team:"Dodgers",note:""},
    "145": {player:"Marcus Semien",team:"Athletics",note:""},
    "146": {player:"Danny Santana",team:"Rangers",note:""},
    "147": {player:"John Means",team:"Orioles",note:""},
    "148": {player:"Maikel Franco",team:"Royals",note:""},
    "149": {player:"Chris Sale",team:"Red Sox",note:""},
    "150": {player:"Hyun-Jin Ryu",team:"Blue Jays",note:""},
    "151": {player:"Michel Baez",team:"Padres",note:"Rookie"},
    "152": {player:"Christian Walker",team:"Diamondbacks",note:""},
    "153": {player:"Gary Sanchez",team:"Yankees",note:""},
    "154": {player:"Shane Bieber",team:"Indians",note:""},
    "155": {player:"Mitch Garver",team:"Twins",note:""},
    "156": {player:"Nick Solak",team:"Rangers",note:"Rookie"},
    "157": {player:"Brandon Lowe",team:"Rays",note:""},
    "158": {player:"Gavin Lux",team:"Dodgers",note:"Rookie"},
    "159": {player:"Paul DeJong",team:"Cardinals",note:""},
    "160": {player:"Kris Bryant",team:"Cubs",note:""},
    "161": {player:"Jose Berrios",team:"Twins",note:""},
    "162": {player:"Carter Kieboom",team:"Nationals",note:""},
    "163": {player:"Mitch Haniger",team:"Mariners",note:""},
    "164": {player:"Orlando Arcia",team:"Brewers",note:""},
    "165": {player:"Daniel Murphy",team:"Rockies",note:""},
    "166": {player:"Giancarlo Stanton",team:"Yankees",note:""},
    "167": {player:"Josh Donaldson",team:"Twins",note:""},
    "168": {player:"Brendan Rodgers",team:"Rockies",note:""},
    "169": {player:"Isan Diaz",team:"Marlins",note:"Rookie"},
    "170": {player:"Eduardo Rodriguez",team:"Red Sox",note:""},
    "171": {player:"Corey Kluber",team:"Rangers",note:""},
    "172": {player:"Chris Paddack",team:"Padres",note:""},
    "173": {player:"Hanser Alberto",team:"Orioles",note:""},
    "174": {player:"Victor Robles",team:"Nationals",note:""},
    "175": {player:"Dawel Lugo",team:"Tigers",note:""},
    "176": {player:"Mallex Smith",team:"Mariners",note:""},
    "177": {player:"Mike Clevinger",team:"Indians",note:""},
    "178": {player:"Lucas Giolito",team:"White Sox",note:""},
    "179": {player:"Jose Abreu",team:"White Sox",note:""},
    "180": {player:"Kyle Lewis",team:"Mariners",note:"Rookie"},
    "181": {player:"Chance Sisco",team:"Orioles",note:""},
    "182": {player:"Jose Ramirez",team:"Indians",note:""},
    "183": {player:"Zack Wheeler",team:"Phillies",note:""},
    "184": {player:"Manny Machado",team:"Padres",note:""},
    "185": {player:"Randal Grichuk",team:"Blue Jays",note:""},
    "186": {player:"Mike Yastrzemski",team:"Giants",note:""},
    "187": {player:"Howie Kendrick",team:"Nationals",note:""},
    "188": {player:"Rhys Hoskins",team:"Phillies",note:""},
    "189": {player:"Carlos Correa",team:"Astros",note:""},
    "190": {player:"Brandon Woodruff",team:"Brewers",note:""},
    "191": {player:"Gio Urshela",team:"Yankees",note:""},
    "192": {player:"Jonathan Villar",team:"Marlins",note:""},
    "193": {player:"Cavan Biggio",team:"Blue Jays",note:""},
    "194": {player:"Josh Hader",team:"Brewers",note:""},
    "195": {player:"Andrew McCutchen",team:"Phillies",note:""},
    "196": {player:"J.D. Martinez",team:"Red Sox",note:""},
    "197": {player:"Kyle Seager",team:"Mariners",note:""},
    "198": {player:"Corey Seager",team:"Dodgers",note:""},
    "199": {player:"Jake Rogers",team:"Tigers",note:"Rookie"},
    "200": {player:"Renato Nunez",team:"Orioles",note:""},
    "201": {player:"Trevor Bauer",team:"Reds",note:""},
    "202": {player:"Carlos Santana",team:"Indians",note:""},
    "203": {player:"Aaron Judge",team:"Yankees",note:""},
    "204": {player:"Josh Bell",team:"Pirates",note:""},
    "205": {player:"Matt Chapman",team:"Athletics",note:""},
    "206": {player:"Khris Davis",team:"Athletics",note:""},
    "207": {player:"Mike Soroka",team:"Braves",note:""},
    "208": {player:"Robbie Ray",team:"Diamondbacks",note:""},
    "209": {player:"Daniel Vogelbach",team:"Mariners",note:""},
    "210": {player:"Ketel Marte",team:"Diamondbacks",note:""},
    "211": {player:"Tim Anderson",team:"White Sox",note:""},
    "212": {player:"Kyle Schwarber",team:"Cubs",note:""},
    "213": {player:"Rowdy Tellez",team:"Blue Jays",note:""},
    "214": {player:"Anthony Rendon",team:"Angels",note:""},
    "215": {player:"Francisco Lindor",team:"Indians",note:""},
    "216": {player:"Joey Gallo",team:"Rangers",note:""},
    "217": {player:"Zack Greinke",team:"Astros",note:""},
    "218": {player:"Max Muncy",team:"Dodgers",note:""},
    "219": {player:"Oscar Mercado",team:"Indians",note:""},
    "220": {player:"Jose Altuve",team:"Astros",note:""},
    "221": {player:"Didi Gregorius",team:"Phillies",note:""},
    "222": {player:"Joc Pederson",team:"Dodgers",note:""},
    "223": {player:"Hunter Renfroe",team:"Rays",note:""},
    "224": {player:"Gregory Polanco",team:"Pirates",note:""},
    "225": {player:"Yoan Moncada",team:"White Sox",note:""},
    "226": {player:"Brandon Belt",team:"Giants",note:""},
    "227": {player:"Dakota Hudson",team:"Cardinals",note:""},
    "228": {player:"Kevin Kiermaier",team:"Rays",note:""},
    "229": {player:"Zac Gallen",team:"Diamondbacks",note:"Rookie"},
    "230": {player:"Clayton Kershaw",team:"Dodgers",note:""},
    "231": {player:"Freddy Galvis",team:"Reds",note:""},
    "232": {player:"Luis Robert",team:"White Sox",note:"Rookie"},
    "233": {player:"Mookie Betts",team:"Dodgers",note:""},
    "234": {player:"Scott Kingery",team:"Phillies",note:""},
    "235": {player:"Justin Verlander",team:"Astros",note:""},
    "236": {player:"Pete Alonso / Cody Bellinger / Eugenio Suarez",team:"Mets",note:"NL HR Leaders"},
    "237": {player:"Alex Bregman / Mike Trout / Jorge Soler",team:"Astros",note:"AL HR Leaders"},
    "238": {player:"Anthony Rendon / Cody Bellinger / Ronald Acuna Jr.",team:"Nationals",note:"NL Runs Leaders"},
    "239": {player:"Marcus Semien / Rafael Devers / Mookie Betts",team:"Athletics",note:"AL Runs Leaders"},
    "240": {player:"Nolan Arenado / Ketel Marte / Ozzie Albies",team:"Rockies",note:"NL Hits Leaders"},
    "241": {player:"DJ LeMahieu / Rafael Devers / Whit Merrifield",team:"Yankees",note:"AL Hits Leaders"},
    "242": {player:"Ozzie Albies / Corey Seager / Anthony Rendon",team:"Braves",note:"NL Doubles Leaders"},
    "243": {player:"Marcus Semien / Rafael Devers / Xander Bogaerts",team:"Athletics",note:"AL Doubles Leaders"},
    "244": {player:"Freddie Freeman / Pete Alonso / Anthony Rendon",team:"Braves",note:"NL RBI Leaders"},
    "245": {player:"Jorge Soler / Xander Bogaerts / Jose Abreu",team:"Royals",note:"AL RBI Leaders"},
    "246": {player:"Yasmani Grandal / Juan Soto / Rhys Hoskins",team:"Brewers",note:"NL Walks Leaders"},
    "247": {player:"Carlos Santana / Mike Trout / Alex Bregman",team:"Indians",note:"AL Walks Leaders"},
    "248": {player:"Christian Yelich / Trea Turner / Ronald Acuna Jr.",team:"Brewers",note:"NL SB Leaders"},
    "249": {player:"Jonathan Villar / Adalberto Mondesi / Mallex Smith",team:"Orioles",note:"AL SB Leaders"},
    "250": {player:"Ketel Marte / Anthony Rendon / Christian Yelich",team:"Diamondbacks",note:"NL AVG Leaders"},
    "251": {player:"Yoan Moncada / DJ LeMahieu / Tim Anderson",team:"White Sox",note:"AL AVG Leaders"},
    "252": {player:"Anthony Rendon / Cody Bellinger / Christian Yelich",team:"Nationals",note:"NL SLG Leaders"},
    "253": {player:"Alex Bregman / Nelson Cruz / Mike Trout",team:"Astros",note:"AL SLG Leaders"},
    "254": {player:"Mike Soroka / Jacob deGrom / Hyun-Jin Ryu",team:"Braves",note:"NL ERA Leaders"},
    "255": {player:"Charlie Morton / Justin Verlander / Gerrit Cole",team:"Rays",note:"AL ERA Leaders"},
    "256": {player:"Clayton Kershaw / Max Fried / Stephen Strasburg",team:"Dodgers",note:"NL Wins Leaders"},
    "257": {player:"Eduardo Rodriguez / Gerrit Cole / Justin Verlander",team:"Red Sox",note:"AL Wins Leaders"},
    "258": {player:"Max Scherzer / Jacob deGrom / Stephen Strasburg",team:"Nationals",note:"NL SO Leaders"},
    "259": {player:"Shane Bieber / Justin Verlander / Gerrit Cole",team:"Indians",note:"AL SO Leaders"},
    "260": {player:"Will Smith / Josh Hader / Kirby Yates",team:"Giants",note:"NL Saves Leaders"},
    "261": {player:"Brad Hand / Aroldis Chapman / Roberto Osuna",team:"Indians",note:"AL Saves Leaders"},
    "262": {player:"Aaron Nola / Stephen Strasburg / Jacob deGrom",team:"Phillies",note:"NL IP Leaders"},
    "263": {player:"Gerrit Cole / Shane Bieber / Justin Verlander",team:"Astros",note:"AL IP Leaders"},
    "264": {player:"Hyun-Jin Ryu / Jack Flaherty / Jacob deGrom",team:"Dodgers",note:"NL WHIP Leaders"},
    "265": {player:"Shane Bieber / Justin Verlander / Gerrit Cole",team:"Indians",note:"AL WHIP Leaders"},
    "266": {player:"Mike Trout",team:"Angels",note:"AL MVP Award"},
    "267": {player:"Cody Bellinger",team:"Dodgers",note:"NL MVP Award"},
    "268": {player:"Justin Verlander",team:"Astros",note:"AL Cy Young Award"},
    "269": {player:"Jacob deGrom",team:"Mets",note:"NL Cy Young Award"},
    "270": {player:"Yordan Alvarez",team:"Astros",note:"AL ROY Award"},
    "271": {player:"Pete Alonso",team:"Mets",note:"NL ROY Award"},
    "272": {player:"Stephen Strasburg",team:"Nationals",note:"WS MVP Award"},
    "273": {player:"Shane Bieber",team:"Indians",note:"ASG MVP Award"},
    "274": {player:"Mike Trout",team:"Angels",note:"AL Hank Aaron Award"},
    "275": {player:"Christian Yelich",team:"Brewers",note:"NL Hank Aaron Award"},
    "276": {player:"Carlos Carrasco",team:"Indians",note:"AL Comeback Award"},
    "277": {player:"Josh Donaldson",team:"Braves",note:"NL Comeback Award"},
    "278": {player:"Aroldis Chapman",team:"Yankees",note:"AL Reliever of Year Award"},
    "279": {player:"Josh Hader",team:"Brewers",note:"NL Reliever of Year Award"},
    "280": {player:"Nelson Cruz",team:"Twins",note:"DH Award"},
    "281": {player:"Carlos Carrasco",team:"Indians",note:"Roberto Clemente Award"},
    "282": {player:"Curtis Granderson",team:"Marlins",note:"Marvin Miller Award"},
    "283": {player:"Mike Trout",team:"Angels",note:"Players Choice AL Outstanding Award"},
    "284": {player:"Anthony Rendon",team:"Nationals",note:"Players Choice NL Outstanding Award"},
    "285": {player:"Mike Trout",team:"Angels",note:"Players Choice Player of Year Award"},
    "286": {player:"Ichiro",team:"Mariners",note:"Highlights"},
    "287": {player:"Pete Alonso",team:"Mets",note:"Highlights"},
    "288": {player:"CC Sabathia",team:"Yankees",note:"Highlights"},
    "289": {player:"Albert Pujols",team:"Angels",note:"Highlights"},
    "290": {player:"Bryce Harper",team:"Phillies",note:"Highlights"},
    "291": {player:"Justin Verlander",team:"Astros",note:"Highlights"},
    "292": {player:"Bo Bichette",team:"Blue Jays",note:"Rookie Highlights"},
    "293": {player:"Mike Trout",team:"Angels",note:"Highlights"},
    "294": {player:"Shohei Ohtani",team:"Angels",note:"Highlights"},
    "295": {player:"Vladimir Guerrero Jr.",team:"Blue Jays",note:"Highlights"},
    "296": {player:"Yordan Alvarez",team:"Astros",note:"Rookie Highlights"},
    "297": {player:"Mike Fiers",team:"Athletics",note:"Highlights"},
    "298": {player:"Aristides Aquino",team:"Reds",note:"Rookie Highlights"},
    "299": {player:"Angels",team:"Angels",note:"Highlights Team"},
    "300": {player:"Ronald Acuna Jr.",team:"Braves",note:"Highlights"}
};
const TEAM_SHORT_TO_FULL: Record<string,string> = {"Angels":"Los Angeles Angels","Astros":"Houston Astros","Royals":"Kansas City Royals","Mets":"New York Mets","Tigers":"Detroit Tigers","Nationals":"Washington Nationals","Yankees":"New York Yankees","Orioles":"Baltimore Orioles","Brewers":"Milwaukee Brewers","Rays":"Tampa Bay Rays","Cardinals":"St. Louis Cardinals","Padres":"San Diego Padres","Indians":"Cleveland Guardians","Twins":"Minnesota Twins","Reds":"Cincinnati Reds","Braves":"Atlanta Braves","Dodgers":"Los Angeles Dodgers","Cubs":"Chicago Cubs","White Sox":"Chicago White Sox","Marlins":"Miami Marlins","Mariners":"Seattle Mariners","Phillies":"Philadelphia Phillies","Giants":"San Francisco Giants","Blue Jays":"Toronto Blue Jays","Red Sox":"Boston Red Sox","Athletics":"Oakland Athletics","Diamondbacks":"Arizona Diamondbacks","Rangers":"Texas Rangers","Pirates":"Pittsburgh Pirates","Rockies":"Colorado Rockies","AL":"Other","NL":"Other","League Leaders":"Other"};
function normalizeCardNumber(setId:string, cardNumber:string): string {
  const raw = String(cardNumber||"").trim();
  if(setId==="update"){
    const m = raw.toUpperCase().match(/^U?-?(\d+)$/);
    return m ? `U-${parseInt(m[1],10)}` : cardNumber;
  }
  if(setId==="bowman-prospects"){
    const m = raw.toUpperCase().match(/^(?:BP|BPP)-?(\d+)$/);
    if(m) return `BP-${parseInt(m[1],10)}`;
    const n = raw.toUpperCase().match(/^(\d+)$/);
    if(n) return `BP-${parseInt(n[1],10)}`;
    return cardNumber;
  }
  if(setId==="bowman"){
    const b90 = raw.toUpperCase().match(/^90B-?([A-Z]+)$/);
    if(b90) return `90B-${b90[1]}`;
    const m = raw.toUpperCase().match(/^(?:BP|BPP)-?(\d+)$/);
    if(m) return `BP-${parseInt(m[1],10)}`;
    const c = raw.toUpperCase().match(/^BCP-?(\d+)$/);
    if(c) return `BCP-${parseInt(c[1],10)}`;
    return cardNumber;
  }
  if(setId==="bowman-chrome"){
    const m = raw.toUpperCase().match(/^(?:BCP|BP|BPP)-?(\d+)$/);
    if(m) return `BCP-${parseInt(m[1],10)}`;
    return cardNumber;
  }
  if(setId==="bowman-draft"){
    const m = raw.toUpperCase().match(/^(?:BD)-?(\d+)$/);
    if(m) return `BD-${parseInt(m[1],10)}`;
    const n = raw.toUpperCase().match(/^(\d+)$/);
    if(n) return `BD-${parseInt(n[1],10)}`;
    return cardNumber;
  }
  return cardNumber;
}
function lookupCardName(setId:string, cardNumber:string, parallel?:string): CardNameEntry | undefined {
  const raw = String(cardNumber||"").trim();
  if(setId==="s1"){ const ins = getS1InsertEntry(raw); if(ins) return ins; }
  if(setId==="s2"){ const ins = getS2InsertEntry(raw); if(ins) return ins; }
  if(setId==="update"){ if(parallel){ const v = updVariationEntry(raw, parallel); if(v) return v; } const ins = getUpdateInsertEntry(raw); if(ins) return ins; }
  if(setId==="chrome"){ if(parallel){ const v = chromeVariationEntry(raw, parallel); if(v) return v; } const ins = getChromeInsertEntry(raw); if(ins) return ins; }
  const upper = raw.toUpperCase();
  if(setId==="bowman-prospects"){
    const m = upper.match(/^(?:BP|BPP)-?(\d+)$/) || upper.match(/^(\d+)$/);
    if(!m) return undefined;
    return CARD_NAMES["Bowman Prospects"]?.[`BP-${parseInt(m[1],10)}`];
  }
  if(setId==="bowman"){
    const bowIns = getBowmanInsertEntry(raw);
    if(bowIns) return bowIns;
    if(/^(?:BP|BPP)-?(\d+)$/.test(upper)){
      const n = parseInt(upper.replace(/^(?:BP|BPP)-?/,""),10);
      return CARD_NAMES["Bowman Prospects"]?.[`BP-${n}`];
    }
    if(/^BCP-?(\d+)$/.test(upper)){
      const n = parseInt(upper.replace(/^BCP-?/,""),10);
      return CARD_NAMES["Bowman Chrome Prospects"]?.[`BCP-${n}`];
    }
    const n = parseInt(raw,10);
    if(!Number.isFinite(n)) return undefined;
    return CARD_NAMES["Bowman"]?.[String(n)];
  }
  if(setId==="bowman-chrome"){
    if(/^(?:BCP|BP|BPP)-?(\d+)$/.test(upper)){
      const n = parseInt(upper.replace(/^(?:BCP|BP|BPP)-?/,""),10);
      return CARD_NAMES["Bowman Chrome Prospects"]?.[`BCP-${n}`];
    }
    return undefined;
  }
  if(setId==="bowman-draft"){
    const m = upper.match(/^(?:BD)-?(\d+)$/) || upper.match(/^(\d+)$/);
    if(!m) return undefined;
    return CARD_NAMES["Bowman Draft"]?.[`BD-${parseInt(m[1],10)}`];
  }
  const key = setId==="s1" ? "Series 1" : setId==="s2" ? "Series 2" : setId==="update" ? "Update" : setId==="chrome" ? "Chrome" : setId==="heritage" ? "Heritage" : setId==="ag" ? "Allen & Ginter" : setId==="gypsy" ? "Gypsy Queen" : setId==="opening-day" ? "Opening Day" : setId==="stadium" ? "Stadium Club" : setId==="big-league" ? "Big League" : setId==="archives" ? "Archives" : null;
  if(!key) return undefined;
  const n = parseInt(String(cardNumber||"").trim().replace(/^U-/i,""),10);
  if(!Number.isFinite(n)) return undefined;
  return CARD_NAMES[key][key==="Update" ? `U-${n}` : String(n)];
}
function fullTeamName(short:string){ return TEAM_SHORT_TO_FULL[short] || short; }
const TEAMS = ["Arizona Diamondbacks","Atlanta Braves","Baltimore Orioles","Boston Red Sox","Chicago Cubs","Chicago White Sox","Cincinnati Reds","Cleveland Guardians","Colorado Rockies","Detroit Tigers","Houston Astros","Kansas City Royals","Los Angeles Angels","Los Angeles Dodgers","Miami Marlins","Milwaukee Brewers","Minnesota Twins","New York Mets","New York Yankees","Oakland Athletics","Philadelphia Phillies","Pittsburgh Pirates","San Diego Padres","San Francisco Giants","Seattle Mariners","St. Louis Cardinals","Tampa Bay Rays","Texas Rangers","Toronto Blue Jays","Washington Nationals","Expos","Football Player","Television Personality","Baseball Barber","Soccer Goalkeeper","Actor & Comedian","British Baseball Fan","Comedian & Foosball","Skateboarder","Sports Broadcaster","Karate Athlete","Poker Player","Baseball Writer","Reality Show Host","Wheelchair Motocross","Baseball Coach","BMX Legend","TV & Radio Host","Pitching Analyst","Actor","Tattoo Artist","Television Host","Author","Other"];
const PARALLELS = ["Base","Yellow (Retail)","Purple (Retail)","Rainbow Foil","Gold Foil (Jumbo)","Gold /2020","Advanced Stat /300","Vintage Stock /99","Independence Day /76","Black /69 (Hobby/Jumbo)","Black /69","Mother's Day Hot Pink /50","Father's Day Blue /50","Father's Day Powder Blue /50","Memorial Day Camo /25","Platinum 1/1","Cyan Printing Plate 1/1","Magenta Printing Plate 1/1","Yellow Printing Plate 1/1","Black Printing Plate 1/1","Purple (Meijer)","Royal Blue (Walmart Blaster)","Yellow (Walgreens Hanger)","Clear Variation","SP Variation","SSP Variation","SSSP Variation","Refractor","Orange","Red","Black","SP","SSP","Auto","Relic","Auto Relic","Chrome","Sapphire","Prism","Pink","Blue","Green","Purple","Gold Foil","Silver","Bronze","Holo","Insert","Printing Plate","Gold Foil 1/1","Clear /10","Printing Plate 1/1","Purple /175","Silver /99","Red /75","Blue /25","Sepia","Negative","Blue /150","Green /99","Gold /50","Orange /25","Red /5","SuperFractor 1/1","Pink (Value Pack)","Sepia (Value Box)","X-Fractor (Monster Box)","Purple /299","Green Wave /99","Blue Wave /75","Gold Wave /50","Orange Wave /25","Red Wave /5","Green Wave /99 (Hobby/Jumbo)","Blue Wave /75 (Hobby/Jumbo)","Gold Wave /50 (Hobby/Jumbo)","Orange Wave /25 (Hobby/Jumbo)","Red Wave /5 (Hobby/Jumbo)","Orange /25 (Hobby)","Rainbow Foil / Parallel","Gold Parallel","Red Parallel","Blue Parallel","Black 1/1","Sky Blue /499","Purple /250","Green /99 Retail","Yellow /75","Orange /25 Hobby","Printing Plates 1/1","Camo Value Pack","Atomic Hobby","Atomic /150","Refractor /499","Speckle /299","Blue Shimmer /150","Aqua /125","Aqua Shimmer /125","Green Shimmer /99 Retail","Gold Shimmer /50","Orange Shimmer /25 Hobby","Red Shimmer /5"];
type ParallelDef = {name:string; rarity:string; notes:string};
const PARALLEL_DEFS: Record<string, ParallelDef[]> = {
  "s1": [...S1_BASE_PARALLELS, {name:"Clear Variation",rarity:"Variation",notes:"Clear Variation — 100 base card numbers, see Checklists"} ],
  "s2": [...S2_BASE_PARALLELS, {name:"Clear Variation",rarity:"Variation",notes:"Clear Variation — 100 base card numbers, see Checklists"} ],
  "update": [{name:"Base",rarity:"Base",notes:"Standard base card"}, ...UPD_BASE_PARALLELS, {name:"Clear Variation",rarity:"Variation",notes:"Clear Variation — Hobby /10. Checklist is SP-based; no full 100 list invented."}, {name:"SP Variation",rarity:"Variation",notes:"SP Variation — 50 cards. CMP code ends #631."}, {name:"SSP Variation",rarity:"Variation",notes:"SSP Variation — 25 cards. CMP code ends #632."}, {name:"SSSP Variation",rarity:"Variation",notes:"SSSP Variation — 5 cards. CMP code ends #633."} ],
  "archives": [
    {name:"Base",rarity:"Base",notes:"Standard base card"},
    {name:"Purple /175",rarity:"/175",notes:"Numbered to 175"},
    {name:"Silver /99",rarity:"/99",notes:"Numbered to 99"},
    {name:"Red /75",rarity:"/75",notes:"Numbered to 75"},
    {name:"Blue /25",rarity:"/25",notes:"Numbered to 25"},
    {name:"Gold Foil 1/1",rarity:"1/1",notes:"One of one"},
  ],
  "bowman": [
    {name:"Base",rarity:"Base",notes:"Standard Bowman base paper card"},
    {name:"Sky Blue /499",rarity:"/499",notes:"Bowman Part 1 — Base Paper parallel, numbered to 499"},
    {name:"Purple /250",rarity:"/250",notes:"Bowman Part 1 — Base Paper parallel, numbered to 250"},
    {name:"Blue /150",rarity:"/150",notes:"Bowman Part 1 — Base Paper parallel, numbered to 150"},
    {name:"Green /99 Retail",rarity:"/99",notes:"Bowman Part 1 — Base Paper parallel, Retail, numbered to 99"},
    {name:"Yellow /75",rarity:"/75",notes:"Bowman Part 1 — Base Paper parallel, numbered to 75"},
    {name:"Gold /50",rarity:"/50",notes:"Bowman Part 1 — Base Paper parallel, numbered to 50"},
    {name:"Orange /25 Hobby",rarity:"/25",notes:"Bowman Part 1 — Base Paper parallel, Hobby, numbered to 25"},
    {name:"Red /5",rarity:"/5",notes:"Bowman Part 1 — Base Paper parallel, numbered to 5"},
    {name:"Platinum 1/1",rarity:"1/1",notes:"Bowman Part 1 — Base Paper parallel, one of one"},
    {name:"Printing Plates 1/1",rarity:"1/1",notes:"Bowman Part 1 — Base Paper parallel, printing plate, one of one"},
    {name:"1990 Bowman Insert — Base",rarity:"Base",notes:"1990 Bowman Insert base card (90B-*)"},
    {name:"1990 Bowman Insert — Atomic /150",rarity:"/150",notes:"1990 Bowman Insert parallel, numbered to 150"},
    {name:"1990 Bowman Insert — Green /99 Retail",rarity:"/99",notes:"1990 Bowman Insert parallel, Retail, numbered to 99"},
    {name:"1990 Bowman Insert — Gold /50",rarity:"/50",notes:"1990 Bowman Insert parallel, numbered to 50"},
    {name:"1990 Bowman Insert — Orange /25 Hobby",rarity:"/25",notes:"1990 Bowman Insert parallel, Hobby, numbered to 25"},
    {name:"1990 Bowman Insert — Red /5",rarity:"/5",notes:"1990 Bowman Insert parallel, numbered to 5"},
    {name:"1990 Bowman Insert — SuperFractor 1/1",rarity:"1/1",notes:"1990 Bowman Insert parallel, one of one"},
    {name:"Bowman Hidden Finds — Refractor /99",rarity:"/99",notes:"Bowman Hidden Finds parallel, numbered to 99"},
    {name:"Bowman Hidden Finds — Orange /25",rarity:"/25",notes:"Bowman Hidden Finds parallel, numbered to 25"},
    {name:"Bowman Hidden Finds — Red /5",rarity:"/5",notes:"Bowman Hidden Finds parallel, numbered to 5"},
    {name:"Bowman Hidden Finds — SuperFractor 1/1",rarity:"1/1",notes:"Bowman Hidden Finds parallel, one of one"},
    {name:"Hidden Finds Autographs — Refractor /99",rarity:"/99",notes:"Hidden Finds Autograph Variation parallel, numbered to 99"},
    {name:"Hidden Finds Autographs — Orange /25",rarity:"/25",notes:"Hidden Finds Autograph Variation parallel, numbered to 25"},
    {name:"Hidden Finds Autographs — Red /5",rarity:"/5",notes:"Hidden Finds Autograph Variation parallel, numbered to 5"},
    {name:"Hidden Finds Autographs — SuperFractor 1/1",rarity:"1/1",notes:"Hidden Finds Autograph Variation parallel, one of one"},
  ],
  "bowman-prospects": [
    {name:"Base",rarity:"Base",notes:"Standard Bowman paper prospect card"},
    {name:"Camo Value Pack",rarity:"Retail",notes:"Bowman Part 1 — Paper Prospect parallel, Value Pack"},
    {name:"Sky Blue /499",rarity:"/499",notes:"Bowman Part 1 — Paper Prospect parallel, numbered to 499"},
    {name:"Purple /250",rarity:"/250",notes:"Bowman Part 1 — Paper Prospect parallel, numbered to 250"},
    {name:"Blue /150",rarity:"/150",notes:"Bowman Part 1 — Paper Prospect parallel, numbered to 150"},
    {name:"Green /99 Retail",rarity:"/99",notes:"Bowman Part 1 — Paper Prospect parallel, Retail, numbered to 99"},
    {name:"Yellow /75",rarity:"/75",notes:"Bowman Part 1 — Paper Prospect parallel, numbered to 75"},
    {name:"Gold /50",rarity:"/50",notes:"Bowman Part 1 — Paper Prospect parallel, numbered to 50"},
    {name:"Orange /25 Hobby",rarity:"/25",notes:"Bowman Part 1 — Paper Prospect parallel, Hobby, numbered to 25"},
    {name:"Red /5",rarity:"/5",notes:"Bowman Part 1 — Paper Prospect parallel, numbered to 5"},
    {name:"Platinum 1/1",rarity:"1/1",notes:"Bowman Part 1 — Paper Prospect parallel, one of one"},
    {name:"Printing Plates 1/1",rarity:"1/1",notes:"Bowman Part 1 — Paper Prospect parallel, printing plate, one of one"},
  ],
  "bowman-chrome": [
    {name:"Base",rarity:"Base",notes:"Standard Bowman Chrome card"},
    {name:"Atomic Hobby",rarity:"Hobby",notes:"Bowman Part 1 — Chrome Prospect parallel, Hobby"},
    {name:"Refractor /499",rarity:"/499",notes:"Bowman Part 1 — Chrome Prospect parallel, numbered to 499"},
    {name:"Speckle /299",rarity:"/299",notes:"Bowman Part 1 — Chrome Prospect parallel, numbered to 299"},
    {name:"Purple /250",rarity:"/250",notes:"Bowman Part 1 — Chrome Prospect parallel, numbered to 250"},
    {name:"Blue /150",rarity:"/150",notes:"Bowman Part 1 — Chrome Prospect parallel, numbered to 150"},
    {name:"Blue Shimmer /150",rarity:"/150",notes:"Bowman Part 1 — Chrome Prospect parallel, numbered to 150"},
    {name:"Aqua /125",rarity:"/125",notes:"Bowman Part 1 — Chrome Prospect parallel, numbered to 125"},
    {name:"Aqua Shimmer /125",rarity:"/125",notes:"Bowman Part 1 — Chrome Prospect parallel, numbered to 125"},
    {name:"Green /99 Retail",rarity:"/99",notes:"Bowman Part 1 — Chrome Prospect parallel, Retail, numbered to 99"},
    {name:"Green Shimmer /99 Retail",rarity:"/99",notes:"Bowman Part 1 — Chrome Prospect parallel, Retail, numbered to 99"},
    {name:"Yellow /75",rarity:"/75",notes:"Bowman Part 1 — Chrome Prospect parallel, numbered to 75"},
    {name:"Gold /50",rarity:"/50",notes:"Bowman Part 1 — Chrome Prospect parallel, numbered to 50"},
    {name:"Gold Shimmer /50",rarity:"/50",notes:"Bowman Part 1 — Chrome Prospect parallel, numbered to 50"},
    {name:"Orange /25 Hobby",rarity:"/25",notes:"Bowman Part 1 — Chrome Prospect parallel, Hobby, numbered to 25"},
    {name:"Orange Shimmer /25 Hobby",rarity:"/25",notes:"Bowman Part 1 — Chrome Prospect parallel, Hobby, numbered to 25"},
    {name:"Red /5",rarity:"/5",notes:"Bowman Part 1 — Chrome Prospect parallel, numbered to 5"},
    {name:"Red Shimmer /5",rarity:"/5",notes:"Bowman Part 1 — Chrome Prospect parallel, numbered to 5"},
    {name:"SuperFractor 1/1",rarity:"1/1",notes:"Bowman Part 1 — Chrome Prospect parallel, one of one"},
    {name:"Printing Plates 1/1",rarity:"1/1",notes:"Bowman Part 1 — Chrome Prospect parallel, printing plate, one of one"},
  ],
  "chrome": [
    {name:"Base",rarity:"Base",notes:"Standard Chrome base card"},
    ...CHROME_BASE_PARALLELS,
    {name:"SP Variation",rarity:"Variation",notes:"SP Variation — 20 cards. CMP code ends 635."},
    {name:"SSP Variation",rarity:"Variation",notes:"SSP Variation — 5 cards. CMP code ends 641."},
  ],
};
const GENERIC_PARALLELS: ParallelDef[] = [
  {name:"Base",rarity:"Base",notes:"Standard base card"},
  {name:"Rainbow Foil / Parallel",rarity:"Foil / Parallel",notes:"Rainbow foil / parallel version"},
  {name:"Gold Parallel",rarity:"Gold",notes:"Gold parallel"},
  {name:"Red Parallel",rarity:"Red",notes:"Red parallel"},
  {name:"Blue Parallel",rarity:"Blue",notes:"Blue parallel"},
  {name:"Black 1/1",rarity:"1/1",notes:"One of one"},
];
function variantsForSet(setId:string): string[] { return (PARALLEL_DEFS[setId] || GENERIC_PARALLELS).map(p=>p.name); }
function parallelDefsForSet(setId:string): ParallelDef[] { return PARALLEL_DEFS[setId] || GENERIC_PARALLELS; }
const CONDITIONS = ["Mint","NM-MT","NM","EX-MT","EX","VG","Good"];
const SUBSET_TYPES: SubsetType[] = ["Base Card","Base Subset","Insert","Parallel","Auto","Relic"];
const SAMPLE: CardValue[] = [
  {setId:"s1",cardNumber:"1",player:"Mike Trout",team:"Los Angeles Angels",parallel:"Base",condition:"NM-MT",gradedCompany:"Raw",grade:"",owned:true,wantlist:false,forTrade:false,purchasePrice:3,currentValue:5,notes:"Series 1 opener",dateAdded:"2020-02-05",subsetName:"",subsetType:"Base Card",qtyOwned:1,qtyForTrade:0,qtyGraded:0,location:""},
  {setId:"s1",cardNumber:"58",player:"Yordan Alvarez",team:"Houston Astros",parallel:"Base",condition:"NM-MT",gradedCompany:"Raw",grade:"",owned:true,wantlist:false,forTrade:false,purchasePrice:8,currentValue:12,notes:"RC",dateAdded:"2020-02-05",subsetName:"Rookies",subsetType:"Base Subset",qtyOwned:1,qtyForTrade:0,qtyGraded:0,location:""},
  {setId:"update",cardNumber:"U-100",player:"Luis Robert",team:"Chicago White Sox",parallel:"Base",condition:"Mint",gradedCompany:"Raw",grade:"",owned:true,wantlist:false,forTrade:false,purchasePrice:6,currentValue:10,notes:"RC",dateAdded:"2020-11-06",subsetName:"",subsetType:"Base Card",qtyOwned:1,qtyForTrade:0,qtyGraded:0,location:""},
  {setId:"chrome",cardNumber:"1",player:"Mike Trout",team:"Los Angeles Angels",parallel:"Refractor",condition:"NM-MT",gradedCompany:"Raw",grade:"",owned:true,wantlist:false,forTrade:true,purchasePrice:10,currentValue:18,notes:"",dateAdded:"2020-08-07",subsetName:"",subsetType:"Base Card",qtyOwned:1,qtyForTrade:1,qtyGraded:0,location:""},
  {setId:"heritage",cardNumber:"1",player:"Mike Trout",team:"Los Angeles Angels",parallel:"Base",condition:"NM",gradedCompany:"Raw",grade:"",owned:true,wantlist:false,forTrade:false,purchasePrice:2,currentValue:4,notes:"1971 design",dateAdded:"2020-02-26",subsetName:"",subsetType:"Base Card",qtyOwned:1,qtyForTrade:0,qtyGraded:0,location:""},
  {setId:"ag",cardNumber:"1",player:"Mike Trout",team:"Los Angeles Angels",parallel:"Base",condition:"NM-MT",gradedCompany:"Raw",grade:"",owned:false,wantlist:true,forTrade:false,purchasePrice:0,currentValue:3,notes:"Want for A&G run",dateAdded:"2020-09-16",subsetName:"",subsetType:"Base Card",qtyOwned:0,qtyForTrade:0,qtyGraded:0,location:""},
  {id:"x",} as never,
].filter((x:any)=>x.setId) as CardValue[];
const SAMPLE2: CardValue[] = [
  ...SAMPLE,
  {setId:"s2",cardNumber:"400",player:"Fernando Tatis Jr.",team:"San Diego Padres",parallel:"Base",condition:"NM-MT",gradedCompany:"PSA",grade:"10",owned:true,wantlist:false,forTrade:false,purchasePrice:15,currentValue:35,notes:"Graded gem",dateAdded:"2020-06-26",subsetName:"",subsetType:"Base Card",qtyOwned:1,qtyForTrade:0,qtyGraded:1,location:""},
  {setId:"finest",cardNumber:"10",player:"Bo Bichette",team:"Toronto Blue Jays",parallel:"Refractor",condition:"Mint",gradedCompany:"Raw",grade:"",owned:true,wantlist:false,forTrade:false,purchasePrice:9,currentValue:14,notes:"RC",dateAdded:"2020-06-19",subsetName:"",subsetType:"Base Card",qtyOwned:1,qtyForTrade:0,qtyGraded:0,location:""},
  {setId:"museum",cardNumber:"25",player:"Mookie Betts",team:"Los Angeles Dodgers",parallel:"Auto",condition:"NM-MT",gradedCompany:"Raw",grade:"",owned:true,wantlist:false,forTrade:false,purchasePrice:120,currentValue:180,notes:"On-card auto",dateAdded:"2020-07-29",subsetName:"",subsetType:"Auto",qtyOwned:1,qtyForTrade:0,qtyGraded:0,location:""},
  {setId:"now",cardNumber:"12",player:"Fernando Tatis Jr.",team:"San Diego Padres",parallel:"Base",condition:"NM-MT",gradedCompany:"Raw",grade:"",owned:false,wantlist:true,forTrade:false,purchasePrice:0,currentValue:6,notes:"Moment card",dateAdded:"2020-01-01",subsetName:"",subsetType:"Base Card",qtyOwned:0,qtyForTrade:0,qtyGraded:0,location:""},
  {setId:"stadium",cardNumber:"88",player:"Ronald Acuña Jr.",team:"Atlanta Braves",parallel:"Base",condition:"NM",gradedCompany:"Raw",grade:"",owned:true,wantlist:false,forTrade:true,purchasePrice:4,currentValue:7,notes:"",dateAdded:"2020-09-02",subsetName:"",subsetType:"Base Card",qtyOwned:1,qtyForTrade:1,qtyGraded:0,location:""},
  {setId:"tier-one",cardNumber:"T1-7",player:"Juan Soto",team:"Washington Nationals",parallel:"Auto Relic",condition:"Mint",gradedCompany:"Raw",grade:"",owned:true,wantlist:false,forTrade:false,purchasePrice:85,currentValue:120,notes:"Hit",dateAdded:"2020-06-05",subsetName:"",subsetType:"Auto",qtyOwned:1,qtyForTrade:0,qtyGraded:0,location:""},
  {setId:"total",cardNumber:"101",player:"Jacob deGrom",team:"New York Mets",parallel:"Base",condition:"EX-MT",gradedCompany:"Raw",grade:"",owned:false,wantlist:true,forTrade:false,purchasePrice:0,currentValue:2,notes:"",dateAdded:"2020-03-13",subsetName:"",subsetType:"Base Card",qtyOwned:0,qtyForTrade:0,qtyGraded:0,location:""},
];
const emptyForm: CardValue = {setId:"s1",cardNumber:"",player:"",team:"Los Angeles Angels",parallel:"Base",condition:"NM-MT",gradedCompany:"Raw",grade:"",owned:true,wantlist:false,forTrade:false,purchasePrice:0,currentValue:0,notes:"",dateAdded:new Date().toISOString().slice(0,10),subsetName:"",subsetType:"Base Card",qtyOwned:1,qtyForTrade:0,qtyGraded:0,location:""};

function qtyOwnedOf(v: CardValue){ return typeof v.qtyOwned === "number" ? v.qtyOwned : (v.owned ? 1 : 0); }
function qtyForTradeOf(v: CardValue){ return typeof v.qtyForTrade === "number" ? v.qtyForTrade : 0; }
function qtyGradedOf(v: CardValue){ return typeof v.qtyGraded === "number" ? v.qtyGraded : 0; }
function locationOf(v: CardValue){ return v.location || ""; }
function effectiveOwned(v: CardValue){ return v.owned || qtyOwnedOf(v) > 0; }
function isBaseCard(v: CardValue){ const t = v.subsetType || "Base Card"; return t==="Base Card" || t==="Base Subset"; }
function isInsertParallel(v: CardValue){ return !isBaseCard(v); }
function subsetTypeForDef(d: SubsetDef): SubsetType { if(d.type==="Base Subset") return "Base Subset"; if(d.type==="Parallel") return "Parallel"; if(d.type==="Auto") return "Auto"; if(d.type==="Relic") return "Relic"; return "Insert"; }
function slotNumbersForSet(s: SetDef): string[] {
  if(s.id==="update") return Array.from({length:300},(_,i)=>`U-${i+1}`);
  if(s.id==="bowman-draft") return Array.from({length:200},(_,i)=>`BD-${i+1}`);
  if(s.id==="bowman") return Array.from({length:100},(_,i)=>String(i+1));
  if(s.id==="bowman-prospects") return Array.from({length:150},(_,i)=>`BP-${i+1}`);
  if(s.id==="bowman-chrome") return [...Array.from({length:100},(_,i)=>String(i+1)), ...Array.from({length:150},(_,i)=>`BCP-${i+1}`)];
  return Array.from({length:s.baseCards},(_,i)=>String(i+1));
}
function slotMetaForNumber(n: string): {subsetName:string; subsetType:SubsetType} {
  if(n.startsWith("BP-") || n.startsWith("BPP-")) return {subsetName:"Bowman Prospects (Paper + Chrome)", subsetType:"Base Subset"};
  if(n.startsWith("BCP-")) return {subsetName:"Bowman Chrome Prospects", subsetType:"Base Subset"};
  return {subsetName:"", subsetType:"Base Card"};
}

async function api(action:string, args:any){
  const r = await fetch("actions",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({action,args})});
  const j = await r.json().catch(()=>({error:"Invalid response"}));
  if(!r.ok || j.error) throw new Error(j.error || `Request failed (${r.status})`);
  return j.data;
}
function money(n:number){ return `$${(Number(n)||0).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2})}`; }
function fmtDate(s:string){ try{return new Date(s+"T12:00:00").toLocaleDateString(undefined,{month:"short",day:"numeric",year:"numeric"})}catch{return s} }
function Banner(){ return <p style={{background:"#fff4d6",border:"1px solid #e5c24f",borderRadius:8,padding:"13px 15px",margin:"0 0 14px",fontSize:14,lineHeight:1.6}}><strong>Series 1 names added (350/350). Series 2 names added (350/350). Update names added (300/300). Chrome names added (200/200). Bowman — In Progress / Part 1 Done + 1990 Bowman Insert (90B, 50 cards) added: names added (100/100 base + 150/150 paper prospects + 150/150 Chrome Prospects). Other inserts / autos come in Part 2 / Part 3 — not added yet. Bowman Draft names added (200/200). Heritage names added (500/500). Allen & Ginter names added (350/350). Gypsy Queen names added (320/320). Opening Day names added (201/201). Stadium Club names added (300/300). Big League names added (300/300). Archives names added (300/300).</strong> Flagship named: 1000 / 1000 (Series 1 350 + Series 2 350 + Update 300). Chrome named: 200 / 200. Bowman named: 250 / 250 + 1990 Bowman Insert 50 / 50. Bowman Draft named: 200 / 200. Heritage named: 500 / 500 (1–400 base, 401–500 short prints). Allen & Ginter named: 350 / 350 (1–300 base, 301–350 short prints). Gypsy Queen named: 320 / 320 (1–300 base, 301–320 Extended Base SPs). Opening Day named: 201 / 201 (1–200 base, 201 short print). Stadium Club named: 300 / 300. Big League named: 300 / 300. Archives named: 300 / 300 (1–100 1955 Design, 101–200 1974 Design, 201–300 2002 Design; 301–325 extended Nickname Posters / 1976 Topps Traded). Total named: 3971 / 3971. Every SET (52), every SUBSET / INSERT definition (28+), and every CARD NUMBER SLOT for every base set (e.g. Series 1 #1–350, Series 2 #351–700, Update U-1–U-300, Chrome #1–200, Bowman #1–100, Bowman Prospects BP-1–BP-150, Bowman Draft BD-1 to BD-200, Heritage #1–500, Allen & Ginter #1–350, Gypsy Queen #1–320, Opening Day #1–201, Stadium Club #1–300, Big League #1–300). Series 1, Series 2, Update, Chrome, Bowman, Bowman Prospects, Bowman Draft, Heritage, Allen & Ginter, Gypsy Queen, Opening Day, Stadium Club and Big League now show the player + team for every slot. For other sets, you fill Player when you add a card, or use <strong>Generate Checklist</strong> below to create blank slots and fill them in. Use <strong>Quantity</strong> to track duplicates.</p>; }

type HitType = "Auto" | "Relic" | "Auto-Relic" | "Cut";
type HitRow = { setId: string; type: HitType; subset: string; code: string; player: string; team: string; note: string; parallels: string };
const HIT_ROWS: HitRow[] = [];
function hit(setId: string, type: HitType, subset: string, rows: string, parallels = "") { for (const line of rows.split(";")) { if (!line.trim()) continue; const p = line.split("|"); HIT_ROWS.push({ setId, type, subset, code: (p[0] || "").trim(), player: (p[1] || "").trim(), team: (p[2] || "").trim(), note: (p[3] || "").trim(), parallels }); } }
function hitRange(setId: string, type: HitType, subset: string, prefix: string, count: number, player: string, team: string, note = "", parallels = "") { for (let i = 1; i <= count; i++) HIT_ROWS.push({ setId, type, subset, code: `${prefix}-${i}`, player, team, note, parallels }); }
// ---- SERIES 1 AUTOGRAPHS ----
hit("s1","Auto","Decades Best Autograph Parallel","BD70-BB|Bert Blyleven|Minnesota Twins|;BD70-BG|Bob Gibson|St. Louis Cardinals|;BD70-DS|Don Sutton|Los Angeles Dodgers|;BD70-NR|Nolan Ryan|California Angels|;BD70-PN|Phil Niekro|Atlanta Braves|;BD70-SC|Steve Carlton|Philadelphia Phillies|;BD80-AD|Andre Dawson|Montreal Expos|;BD80-CRJ|Cal Ripken Jr.|Baltimore Orioles|;BD80-DM|Don Mattingly|New York Yankees|;BD80-DMU|Dale Murphy|Atlanta Braves|;BD80-DS|Darryl Strawberry|New York Mets|;BD80-RS|Ryne Sandberg|Chicago Cubs|;BD80-RY|Robin Yount|Milwaukee Brewers|;BD80-WB|Wade Boggs|Boston Red Sox|;DB90-BL|Barry Larkin|Cincinnati Reds|;DB90-BL1|Barry Larkin|Cincinnati Reds|;DB90-CJ|Chipper Jones|Atlanta Braves|;DB90-CRJ|Cal Ripken Jr.|Baltimore Orioles|;DB90-EM|Edgar Martinez|Seattle Mariners|;DB90-FT1|Frank Thomas|Chicago White Sox|;DB90-JB|Jeff Bagwell|Houston Astros|;DB90-JBA|Jeff Bagwell|Houston Astros|;DB90-KGJ|Ken Griffey Jr.|Seattle Mariners|;DB90-MM|Mark McGwire|Oakland Athletics|;DB90-PM|Pedro Martinez|Boston Red Sox|;DB90-RA|Roberto Alomar|Toronto Blue Jays|;DB90-RH|Rickey Henderson|Oakland Athletics|;DB90-SS|Sammy Sosa|Chicago Cubs|;DB00-AP|Andy Pettitte|New York Yankees|;DB00-CC|CC Sabathia|Cleveland Indians|;DB00-JS|John Smoltz|Atlanta Braves|;DB00-MM|Mike Mussina|New York Yankees|;DB00-MR|Mariano Rivera|New York Yankees|;DB00-PM|Pedro Martinez|Boston Red Sox|;DB00-RC|Roger Clemens|New York Yankees|;DB00-RJ|Randy Johnson|Arizona Diamondbacks|;DB00-TG|Tom Glavine|Atlanta Braves|;DB10-AJ|Aaron Judge|New York Yankees|;DB10-JD|Jacob deGrom|New York Mets|;DB10-KB|Kris Bryant|Chicago Cubs|;DB10-MC|Miguel Cabrera|Detroit Tigers|;DB10-MS|Max Scherzer|Detroit Tigers|;DB10-MT|Mike Trout|Angels|;DB10-SO|Shohei Ohtani|Angels|");
hit("s1","Auto","Topps Choice Autographs","TCA-AJ|Aaron Judge|Yankees|;TCA-CK|Clayton Kershaw|Dodgers|;TCA-CRJ|Cal Ripken Jr.|Orioles|;TCA-CY|Christian Yelich|Brewers|;TCA-DMA|Don Mattingly|Yankees|;TCA-FTJ|Fernando Tatis Jr.|Padres|;TCA-GL|Gavin Lux|Dodgers|;TCA-I|Ichiro|Mariners|;TCA-JA|Jose Altuve|Astros|;TCA-KB|Kris Bryant|Cubs|;TCA-KGJ|Ken Griffey Jr.|Mariners|;TCA-MT|Mike Trout|Angels|;TCA-PA|Pete Alonso|Mets|;TCA-RAJ|Ronald Acuna Jr.|Braves|;TCA-SO|Shohei Ohtani|Angels|;TCA-VGJ|Vladimir Guerrero Jr.|Blue Jays|;TCA-YA|Yordan Alvarez|Astros|");
hit("s1","Auto","Decades Next Autographs","DNA-AR|Austin Riley|Braves|;DNA-BBI|Bo Bichette|Blue Jays|;DNA-BMK|Brendan McKay|Rays|;DNA-CP|Chris Paddack|Padres|;DNA-EJ|Eloy Jimenez|White Sox|;DNA-FTJ|Fernando Tatis Jr.|Padres|;DNA-GL|Gavin Lux|Dodgers|;DNA-GT|Gleyber Torres|Yankees|;DNA-JR|Julio Urias|Dodgers|;DNA-JS|Juan Soto|Nationals|;DNA-JSL|Jesus Luzardo|Athletics|;DNA-KH|Keston Hiura|Brewers|;DNA-KT|Kyle Tucker|Astros|;DNA-LG|Lucas Giolito|White Sox|;DNA-MS|Mike Soroka|Braves|;DNA-NH|Nico Hoerner|Cubs|;DNA-OAL|Ozzie Albies|Braves|;DNA-PAL|Pete Alonso|Mets|;DNA-RAJ|Ronald Acuna Jr.|Braves|;DNA-RD|Rafael Devers|Red Sox|;DNA-RL|Ramon Laureano|Athletics|;DNA-SOH|Shohei Ohtani|Angels|;DNA-VGJ|Vladimir Guerrero Jr.|Blue Jays|;DNA-VR|Victor Robles|Nationals|;DNA-YA|Yordan Alvarez|Astros|");
hit("s1","Auto","Decade of Dominance Die-Cut Autographs","DOD-I|Ichiro|Mariners|;DOD-JB|Johnny Bench|Reds|;DOD-KGJ|Ken Griffey Jr.|Mariners|;DOD-MM|Mark McGwire|Cardinals|;DOD-MR|Mariano Rivera|Yankees|;DOD-MT|Mike Trout|Angels|;DOD-NR|Nolan Ryan|Rangers|;DOD-RC|Roger Clemens|Red Sox|;DOD-RH|Rickey Henderson|Athletics|;DOD-RJ|Randy Johnson|Diamondbacks|");
hitRange("s1","Auto","Walmart Player Highlight Autographs","RHA",30,"Rhys Hoskins","Philadelphia Phillies");
hitRange("s1","Auto","Target Player Highlight Autographs","VGJA",30,"Vladimir Guerrero Jr.","Toronto Blue Jays");
hit("s1","Auto","Baseball Stars Autographs","BSA-AA|Adbert Alzolay|Cubs|Rookie;BSA-AAQ|Aristides Aquino|Reds|Rookie;BSA-AC|Aaron Civale|Indians|Rookie;BSA-AR|Austin Riley|Braves|;BSA-ARI|Anthony Rizzo|Cubs|;BSA-AT|Abraham Toro|Astros|Rookie;BSA-BB|Bobby Bradley|Indians|Rookie;BSA-BBU|Brock Burke|Rangers|Rookie;BSA-BO|Bo Bichette|Blue Jays|Rookie;BSA-BR|Bryan Reynolds|Pirates|;BSA-CD|Corey Dickerson|Phillies|;BSA-CF|Cecil Fielder|Tigers|;BSA-CH|Cesar Hernandez|Phillies|;BSA-CKE|Clayton Kershaw|Dodgers|;BSA-CP|Chris Paddack|Padres|;BSA-CW|Christian Walker|Diamondbacks|;BSA-DM|Dustin May|Dodgers|Rookie;BSA-DPD|Daniel Ponce de Leon|Cardinals|;BSA-EE|Eduardo Escobar|Diamondbacks|;BSA-FT|Frank Thomas|White Sox|;BSA-GH|Garrett Hampson|Rockies|;BSA-GL|Gavin Lux|Dodgers|Rookie;BSA-GS|George Springer|Astros|;BSA-GU|Gio Urshela|Yankees|;BSA-HR|Harold Ramirez|Marlins|;BSA-ID|Isan Diaz|Marlins|Rookie;BSA-JB|Jake Bauers|Indians|;BSA-JF|Jack Flaherty|Cardinals|;BSA-JFR|Jake Fraley|Mariners|Rookie;BSA-JJ|Josh James|Astros|;BSA-JL|Jesus Luzardo|Athletics|Rookie;BSA-JY|Jordan Yamamoto|Marlins|Rookie;BSA-KB|Kris Bryant|Cubs|;BSA-KGJ|Ken Griffey Jr.|Mariners|;BSA-KH|Keston Hiura|Brewers|;BSA-KL|Kyle Lewis|Mariners|Rookie;BSA-LA|Logan Allen|Indians|Rookie;BSA-LAR|Luis Arraez|Twins|;BSA-LGJ|Lourdes Gurriel Jr.|Blue Jays|;BSA-LMJ|Lance McCullers Jr.|Astros|;BSA-MC|Michael Chavis|Red Sox|;BSA-MO|Matt Olson|Athletics|;BSA-MS|Max Scherzer|Nationals|;BSA-MT|Mike Trout|Angels|;BSA-NA|Nolan Arenado|Rockies|;BSA-NH|Nico Hoerner|Cubs|Rookie;BSA-NL|Nate Lowe|Rays|;BSA-NLA|Aaron Nola|Phillies|;BSA-NSO|Nick Solak|Rangers|Rookie;BSA-RF|Rollie Fingers|Athletics|;BSA-RH|Rhys Hoskins|Phillies|;BSA-RMC|Ryan McMahon|Rockies|;BSA-SMU|Sean Murphy|Athletics|Rookie;BSA-SO|Shohei Ohtani|Angels|;BSA-SSC|Shin-Soo Choo|Rangers|;BSA-TA|Tim Anderson|White Sox|;BSA-TG|Trent Grisham|Brewers|Rookie;BSA-TM|Tino Martinez|Yankees|;BSA-VR|Victor Robles|Nationals|;BSA-WA|Willians Astudillo|Twins|;BSA-WC|Willson Contreras|Cubs|;BSA-WM|Whit Merrifield|Royals|;BSA-WS|Will Smith|Dodgers|;BSA-YA|Yordan Alvarez|Astros|Rookie","Black /199, Gold /50, Red /25, Platinum 1/1");
hit("s1","Auto","Baseball Stars Dual Autographs","BSDA-AJ|Chipper Jones + Ronald Acuna Jr.|Braves / Braves|;BSDA-AS|George Springer + Yordan Alvarez|Astros / Astros|;BSDA-GB|Vladimir Guerrero Jr. + Bo Bichette|Blue Jays / Blue Jays|;BSDA-GG|Vladimir Guerrero + Vladimir Guerrero Jr.|Expos / Blue Jays|;BSDA-GT|Mike Trout + Ken Griffey Jr.|Angels / Mariners|;BSDA-JJ|Aaron Judge + Reggie Jackson|Yankees / Yankees|;BSDA-MO|David Ortiz + J.D. Martinez|Red Sox / Red Sox|;BSDA-MS|Pedro Martinez + Chris Sale|Red Sox / Red Sox|;BSDA-MTJ|Fernando Tatis Jr. + Manny Machado|Padres / Padres|;BSDA-NC|Aaron Nola + Steve Carlton|Phillies / Phillies|;BSDA-SB|Ryne Sandberg + Kris Bryant|Cubs / Cubs|;BSDA-SJ|Max Scherzer + Randy Johnson|Nationals / Diamondbacks|;BSDA-SS|Juan Soto + Max Scherzer|Nationals / Nationals|;BSDA-TO|Shohei Ohtani + Mike Trout|Angels / Angels|","Dual Autos /5 or less");
hit("s1","Auto","World Champion Autographs","WCA-FR|Fernando Rodney|Nationals|;WCA-HK|Howie Kendrick|Nationals|;WCA-JR|Joe Ross|Nationals|;WCA-JS|Juan Soto|Nationals|;WCA-MS|Max Scherzer|Nationals|;WCA-PC|Patrick Corbin|Nationals|;WCA-SD|Sean Doolittle|Nationals|;WCA-VR|Victor Robles|Nationals|");
hit("s1","Auto","Postseason Performance Autographs","PPA-AJ|Aaron Judge|Yankees|;PPA-BS|Blake Snell|Rays|;PPA-DS|Dansby Swanson|Braves|;PPA-GL|Gavin Lux|Dodgers|;PPA-GS|George Springer|Astros|;PPA-GT|Gleyber Torres|Yankees|;PPA-JA|Jose Altuve|Astros|;PPA-JF|Jack Flaherty|Cardinals|;PPA-JP|Joc Pederson|Dodgers|;PPA-JS|Juan Soto|Nationals|;PPA-MM|Max Muncy|Dodgers|;PPA-MS|Max Scherzer|Nationals|;PPA-MSO|Mike Soroka|Braves|;PPA-OA|Ozzie Albies|Braves|;PPA-PC|Patrick Corbin|Nationals|;PPA-PG|Paul Goldschmidt|Cardinals|;PPA-RA|Ronald Acuna Jr.|Braves|;PPA-SD|Sean Doolittle|Nationals|");
hit("s1","Auto","1985 Topps Baseball Autographs","85A-AAQ|Aristides Aquino|Reds|Rookie;85A-AC|Aaron Civale|Indians|Rookie;85A-AD|Andre Dawson|Cubs|;85A-AJ|Aaron Judge|Yankees|;85A-AN|Aaron Nola|Phillies|;85A-AP|A.J. Puk|Athletics|Rookie;85A-ARI|Austin Riley|Braves|;85A-AT|Abraham Toro|Astros|Rookie;85A-AY|Alex Young|Diamondbacks|Rookie;85A-BB|Bo Bichette|Blue Jays|Rookie;85A-BBE|Brock Burke|Rangers|Rookie;85A-BHA|Bryce Harper|Phillies|;85A-BO|Bobby Bradley|Indians|Rookie;85A-CB|Cavan Biggio|Blue Jays|;85A-CF|Carlton Fisk|White Sox|;85A-CK|Carter Kieboom|Nationals|;85A-CKE|Clayton Kershaw|Dodgers|;85A-CR|Cal Ripken Jr.|Orioles|;85A-DC|Dylan Cease|White Sox|Rookie;85A-DE|Dennis Eckersley|Athletics|;85A-DL|DJ LeMahieu|Yankees|;85A-DM|Don Mattingly|Yankees|;85A-DMA|Dustin May|Dodgers|Rookie;85A-DO|David Ortiz|Red Sox|;85A-DPD|Dustin Pedroia|Red Sox|;85A-DS|Dansby Swanson|Braves|;85A-DST|Darryl Strawberry|Mets|;85A-EJ|Eloy Jimenez|White Sox|;85A-FT|Fernando Tatis Jr.|Padres|;85A-FTH|Frank Thomas|White Sox|;85A-GC|Gerrit Cole|Astros|;85A-GL|Gavin Lux|Dodgers|Rookie;85A-HA|Hank Aaron|Braves|;85A-HH|Hunter Harvey|Orioles|Rookie;85A-HM|Hideki Matsui|Yankees|;85A-ID|Isan Diaz|Marlins|Rookie;85A-JAA|Jose Altuve|Astros|;85A-JBN|Johnny Bench|Reds|;85A-JFE|Junior Fernandez|Cardinals|Rookie;85A-JR|Jake Rogers|Tigers|Rookie;85A-JS|Juan Soto|Nationals|;85A-JSM|John Smoltz|Braves|;85A-JV|Joey Votto|Reds|;85A-JVA|Jason Varitek|Red Sox|;85A-JY|Jordan Yamamoto|Marlins|Rookie;85A-KHI|Keston Hiura|Brewers|;85A-KL|Kyle Lewis|Mariners|Rookie;85A-KW|Kerry Wood|Cubs|;85A-LA|Logan Allen|Indians|Rookie;85A-LM|Lance McCullers Jr.|Astros|;85A-LW|Logan Webb|Giants|Rookie;85A-MCL|Mike Clevinger|Indians|;85A-MMU|Max Muncy|Dodgers|;85A-MR|Mariano Rivera|Yankees|;85A-MSO|Mike Soroka|Braves|;85A-MT|Mike Trout|Angels|;85A-MU|Andres Munoz|Padres|Rookie;85A-NGA|Nomar Garciaparra|Red Sox|;85A-NH|Nico Hoerner|Cubs|Rookie;85A-NR|Nolan Ryan|Astros|;85A-NSO|Nick Solak|Rangers|Rookie;85A-OS|Ozzie Smith|Cardinals|;85A-PAL|Pete Alonso|Mets|;85A-PS|Patrick Sandoval|Angels|Rookie;85A-RAC|Ronald Acuna Jr.|Braves|;85A-RAL|Roberto Alomar|Blue Jays|;85A-RCL|Roger Clemens|Red Sox|;85A-RG|Robel Garcia|Cubs|Rookie;85A-SB|Seth Brown|Athletics|Rookie;85A-SH|Sam Hilliard|Rockies|Rookie;85A-SM|Sean Murphy|Athletics|Rookie;85A-SO|Shohei Ohtani|Angels|;85A-TA|Tim Anderson|White Sox|;85A-TD|Travis Demeritte|Tigers|Rookie;85A-TG|Tom Glavine|Braves|;85A-VG|Vladimir Guerrero Jr.|Blue Jays|;85A-WB|Wade Boggs|Red Sox|;85A-WCO|Willson Contreras|Cubs|;85A-XB|Xander Bogaerts|Red Sox|;85A-YA|Yordan Alvarez|Astros|Rookie");
hit("s1","Auto","1985 Topps Baseball Chrome Variation Autograph Parallel","85C-1|Mike Trout|Angels|;85C-2|Shohei Ohtani|Angels|;85C-3|Ronald Acuna Jr.|Braves|;85C-4|Cal Ripken Jr.|Orioles|;85C-5|Rafael Devers|Red Sox|;85C-6|Nico Hoerner|Cubs|Rookie;85C-8|Kris Bryant|Cubs|;85C-9|Ryne Sandberg|Cubs|;85C-10|Dylan Cease|White Sox|Rookie;85C-11|Frank Thomas|White Sox|;85C-13|Nolan Arenado|Rockies|;85C-14|Jose Altuve|Astros|;85C-15|Nolan Ryan|Astros|;85C-16|Yordan Alvarez|Astros|Rookie;85C-17|Whit Merrifield|Royals|;85C-18|Clayton Kershaw|Dodgers|;85C-19|Dustin May|Dodgers|Rookie;85C-20|Jordan Yamamoto|Marlins|Rookie;85C-21|Christian Yelich|Brewers|;85C-22|Keston Hiura|Brewers|;85C-23|Max Kepler|Twins|;85C-24|Darryl Strawberry|Mets|;85C-25|Jacob deGrom|Mets|;85C-26|Pete Alonso|Mets|;85C-27|Aaron Judge|Yankees|;85C-28|Don Mattingly|Yankees|;85C-29|Gleyber Torres|Yankees|;85C-30|Mark McGwire|Athletics|;85C-32|Manny Machado|Padres|;85C-33|Fernando Tatis Jr.|Padres|;85C-34|Sean Murphy|Athletics|Rookie;85C-35|Will Clark|Giants|;85C-36|Ichiro|Mariners|;85C-37|Ken Griffey Jr.|Mariners|;85C-38|Paul Goldschmidt|Cardinals|;85C-39|Kyle Lewis|Mariners|Rookie;85C-40|Brendan McKay|Rays|Rookie;85C-41|Bo Bichette|Blue Jays|Rookie;85C-42|Vladimir Guerrero Jr.|Blue Jays|;85C-43|Juan Soto|Nationals|;85C-44|Matt Thaiss|Angels|Rookie;85C-46|Aristides Aquino|Reds|Rookie;85C-47|Robel Garcia|Cubs|Rookie;85C-48|Gavin Lux|Dodgers|Rookie;85C-49|Jesus Luzardo|Athletics|Rookie;85C-50|Trent Grisham|Brewers|Rookie");

// ---- SERIES 1 RELICS ----
hit("s1","Relic","Jumbo Jersey Sleeve Patch","JJSP-AA|Aristides Aquino|Reds|Rookie;JJSP-ABR|Alex Bregman|Astros|;JJSP-AM|Adalberto Mondesi|Royals|;JJSP-AP|Albert Pujols|Angels|;JJSP-ARI|Anthony Rizzo|Cubs|;JJSP-BH|Bryce Harper|Phillies|;JJSP-BM|Brendan McKay|Rays|Rookie;JJSP-BP|Buster Posey|Giants|;JJSP-BS|Blake Snell|Rays|;JJSP-CB|Cody Bellinger|Dodgers|;JJSP-CK|Clayton Kershaw|Dodgers|;JJSP-DV|Daniel Vogelbach|Mariners|;JJSP-EA|Elvis Andrus|Rangers|;JJSP-EJ|Eloy Jimenez|White Sox|;JJSP-FF|Freddie Freeman|Braves|;JJSP-JB|Javier Baez|Cubs|;JJSP-JBE|Josh Bell|Pirates|;JJSP-JD|Jacob deGrom|Mets|;JJSP-JG|Joey Gallo|Rangers|;JJSP-JL|Jesus Luzardo|Athletics|;JJSP-JS|Juan Soto|Nationals|;JJSP-JV|Justin Verlander|Astros|;JJSP-JVO|Joey Votto|Reds|;JJSP-JY|Jordan Yamamoto|Marlins|Rookie;JJSP-KB|Kris Bryant|Cubs|;JJSP-KL|Kyle Lewis|Mariners|Rookie;JJSP-KM|Ketel Marte|Diamondbacks|;JJSP-MB|Mookie Betts|Red Sox|;JJSP-MC|Matt Chapman|Athletics|;JJSP-MK|Max Kepler|Twins|;JJSP-MS|Max Scherzer|Nationals|;JJSP-MT|Mike Trout|Angels|;JJSP-NA|Nolan Arenado|Rockies|;JJSP-OA|Ozzie Albies|Braves|;JJSP-PA|Pete Alonso|Mets|;JJSP-RA|Ronald Acuna Jr.|Braves|;JJSP-RD|Rafael Devers|Red Sox|;JJSP-RH|Rhys Hoskins|Phillies|;JJSP-SO|Shohei Ohtani|Angels|;JJSP-TM|Trey Mancini|Orioles|;JJSP-TS|Trevor Story|Rockies|;JJSP-WB|Walker Buehler|Dodgers|;JJSP-WM|Whit Merrifield|Royals|;JJSP-XB|Xander Bogaerts|Red Sox|;JJSP-YA|Yordan Alvarez|Astros|Rookie;JJSP-ZG|Zac Gallen|Diamondbacks|Rookie");
hit("s1","Relic","Global Game Medallion","GGM-AB|Alex Bregman|Astros|;GGM-AC|Aroldis Chapman|Yankees|;GGM-AJ|Aaron Judge|Yankees|;GGM-AP|Albert Pujols|Angels|;GGM-AV|Alex Verdugo|Dodgers|;GGM-BH|Bryce Harper|Phillies|;GGM-BP|Buster Posey|Giants|;GGM-CB|Cody Bellinger|Dodgers|;GGM-CC|Carlos Correa|Astros|;GGM-CK|Clayton Kershaw|Dodgers|;GGM-CY|Christian Yelich|Brewers|;GGM-DG|Didi Gregorius|Yankees|;GGM-DO|David Ortiz|Red Sox|;GGM-EJ|Eloy Jimenez|White Sox|;GGM-FF|Freddie Freeman|Braves|;GGM-FL|Francisco Lindor|Indians|;GGM-GS|Gary Sanchez|Yankees|;GGM-GT|Gleyber Torres|Yankees|;GGM-HM|Hideki Matsui|Yankees|;GGM-I|Ichiro|Mariners|;GGM-JA|Jose Altuve|Astros|;GGM-JB|Javier Baez|Cubs|;GGM-JS|Juan Soto|Nationals|;GGM-JT|Jameson Taillon|Pirates|;GGM-JU|Julio Urias|Dodgers|;GGM-JV|Joey Votto|Reds|;GGM-KB|Kris Bryant|Cubs|;GGM-KD|Khris Davis|Athletics|;GGM-KG|Ken Griffey Jr.|Mariners|;GGM-LU|Luis Urias|Padres|;GGM-MA|Masahiro Tanaka|Yankees|;GGM-MB|Mookie Betts|Red Sox|;GGM-MC|Miguel Cabrera|Tigers|;GGM-MM|Manny Machado|Padres|;GGM-MT|Mike Trout|Angels|;GGM-OA|Ozzie Albies|Braves|;GGM-RA|Ronald Acuna Jr.|Braves|;GGM-RC|Roberto Clemente|Pirates|;GGM-RD|Rafael Devers|Red Sox|;GGM-RO|Robinson Cano|Mets|;GGM-SO|Shohei Ohtani|Angels|;GGM-VG|Vladimir Guerrero Jr.|Blue Jays|;GGM-WC|Willson Contreras|Cubs|;GGM-XB|Xander Bogaerts|Red Sox|;GGM-YA|Yordan Alvarez|Astros|;GGM-YD|Yu Darvish|Cubs|;GGM-YG|Yasmani Grandal|Brewers|;GGM-YM|Yadier Molina|Cardinals|;GGM-YO|Yoan Moncada|White Sox|;GGM-YP|Yasiel Puig|Indians|");
hit("s1","Relic","Rookie Card Retrospective RC Logo Medallion","RCR-AJ|Aaron Judge|Yankees|;RCR-AK|Al Kaline|Tigers|;RCR-AP|Albert Pujols|Cardinals|;RCR-BG|Bob Gibson|Cardinals|;RCR-BH|Bryce Harper|Nationals|;RCR-BJ|Bo Jackson|Royals|;RCR-BP|Buster Posey|Giants|;RCR-BR|Brooks Robinson|Orioles|;RCR-CA|Jose Canseco|Athletics|;RCR-CB|Cody Bellinger|Dodgers|;RCR-CC|Carlos Correa|Astros|;RCR-CJ|Chipper Jones|Braves|;RCR-CK|Clayton Kershaw|Dodgers|;RCR-CR|Cal Ripken Jr.|Orioles|;RCR-CY|Christian Yelich|Marlins|;RCR-DG|Dwight Gooden|Mets|;RCR-DM|Don Mattingly|Yankees|;RCR-DS|Darryl Strawberry|Mets|;RCR-DY|Dennis Eckersley|Indians|;RCR-EB|Ernie Banks|Cubs|;RCR-EM|Eddie Murray|Orioles|;RCR-FA|Frank Thomas|White Sox|;RCR-FR|Frank Robinson|Reds|;RCR-FT|Fernando Tatis Jr.|Padres|;RCR-HA|Hank Aaron|Braves|;RCR-IS|Ichiro|Mariners|;RCR-JA|Jose Altuve|Astros|;RCR-JB|Jeff Bagwell|Astros|;RCR-JS|John Smoltz|Braves|;RCR-KB|Kris Bryant|Cubs|;RCR-KG|Ken Griffey Jr.|Mariners|;RCR-MC|Miguel Cabrera|Marlins|;RCR-MS|Giancarlo Stanton|Marlins|;RCR-MT|Mike Trout|Angels|;RCR-OS|Ozzie Smith|Padres|;RCR-PA|Pete Alonso|Mets|;RCR-RC|Roger Clemens|Red Sox|;RCR-RH|Rickey Henderson|Athletics|;RCR-RJ|Reggie Jackson|Athletics|;RCR-RO|Roberto Clemente|Pirates|;RCR-RS|Ryne Sandberg|Cubs|;RCR-RY|Rhys Hoskins|Phillies|;RCR-SA|Sandy Alomar Jr.|Padres|;RCR-SK|Sandy Koufax|Dodgers|;RCR-SO|Shohei Ohtani|Angels|;RCR-SS|Sammy Sosa|White Sox|;RCR-ST|Stephen Strasburg|Nationals|;RCR-TG|Tony Gwynn|Padres|;RCR-TR|Tim Raines|Expos|;RCR-VG|Vladimir Guerrero Jr.|Blue Jays|");
hit("s1","Relic","Major League Material","MLM-AB|Andrew Benintendi|Red Sox|;MLM-AJ|Aaron Judge|Yankees|;MLM-AM|Austin Meadows|Rays|;MLM-AR|Anthony Rizzo|Cubs|;MLM-ARI|Austin Riley|Braves|;MLM-ARO|Amed Rosario|Mets|;MLM-BB|Byron Buxton|Twins|;MLM-BP|Buster Posey|Giants|;MLM-BS|Blake Snell|Rays|;MLM-CB|Charlie Blackmon|Rockies|;MLM-CBE|Cody Bellinger|Dodgers|;MLM-CS|Corey Seager|Dodgers|;MLM-CSA|Carlos Santana|Indians|;MLM-DD|David Dahl|Rockies|;MLM-DG|Didi Gregorius|Yankees|;MLM-DS|Dansby Swanson|Braves|;MLM-DV|Daniel Vogelbach|Mariners|;MLM-ET|Eric Thames|Brewers|;MLM-FF|Freddie Freeman|Braves|;MLM-FL|Francisco Lindor|Indians|;MLM-GS|George Springer|Astros|;MLM-GSA|Gary Sanchez|Yankees|;MLM-JA|Jose Altuve|Astros|;MLM-JB|Jose Berrios|Twins|;MLM-JG|Joey Gallo|Rangers|;MLM-JH|Josh Hader|Brewers|;MLM-JR|J.T. Realmuto|Phillies|;MLM-LC|Lorenzo Cain|Brewers|;MLM-LG|Lourdes Gurriel Jr.|Blue Jays|;MLM-LV|Luke Voit|Yankees|;MLM-MB|Matthew Boyd|Tigers|;MLM-MCO|Michael Conforto|Mets|;MLM-MSA|Miguel Sano|Twins|;MLM-MT|Mike Trout|Angels|;MLM-NS|Nick Senzel|Reds|;MLM-NSY|Noah Syndergaard|Mets|;MLM-OA|Ozzie Albies|Braves|;MLM-PA|Pete Alonso|Mets|;MLM-PD|Paul DeJong|Cardinals|;MLM-SG|Sonny Gray|Reds|;MLM-SS|Stephen Strasburg|Nationals|;MLM-TA|Tim Anderson|White Sox|;MLM-TM|Trey Mancini|Orioles|;MLM-TS|Trevor Story|Rockies|;MLM-TT|Trea Turner|Nationals|;MLM-WB|Walker Buehler|Dodgers|;MLM-WC|Willson Contreras|Cubs|;MLM-WM|Whit Merrifield|Royals|;MLM-XB|Xander Bogaerts|Red Sox|;MLM-YM|Yoan Moncada|White Sox|","Black, Gold, Red, Platinum");
hit("s1","Relic","1985 Topps Baseball Relics","85R-AB|Alex Bregman|Astros|;85R-AJ|Aaron Judge|Yankees|;85R-AP|Albert Pujols|Angels|;85R-BH|Bryce Harper|Phillies|;85R-BL|Barry Larkin|Reds|;85R-BP|Buster Posey|Giants|;85R-CB|Charlie Blackmon|Rockies|;85R-CBE|Cody Bellinger|Dodgers|;85R-CR|Cal Ripken Jr.|Orioles|;85R-DM|Don Mattingly|Yankees|;85R-EM|Eddie Murray|Orioles|;85R-FF|Freddie Freeman|Braves|;85R-FL|Francisco Lindor|Indians|;85R-FT|Fernando Tatis Jr.|Padres|;85R-FTH|Frank Thomas|White Sox|;85R-GB|George Brett|Royals|;85R-GS|George Springer|Astros|;85R-GT|Gleyber Torres|Yankees|;85R-HR|Hyun-Jin Ryu|Dodgers|;85R-JBZ|Javier Baez|Cubs|;85R-JS|Juan Soto|Nationals|;85R-KB|Kris Bryant|Cubs|;85R-KG|Ken Griffey Jr.|Mariners|;85R-KH|Keston Hiura|Brewers|;85R-MB|Mookie Betts|Red Sox|;85R-MC|Miguel Cabrera|Tigers|;85R-MK|Max Kepler|Twins|;85R-MM|Manny Machado|Padres|;85R-MMG|Mark McGwire|Athletics|;85R-MS|Max Scherzer|Nationals|;85R-MT|Mike Trout|Angels|;85R-NA|Nolan Arenado|Rockies|;85R-NR|Nolan Ryan|Astros|;85R-OS|Ozzie Smith|Cardinals|;85R-PA|Pete Alonso|Mets|;85R-PG|Paul Goldschmidt|Cardinals|;85R-RA|Ronald Acuna Jr.|Braves|;85R-RC|Roger Clemens|Red Sox|;85R-RD|Rafael Devers|Red Sox|;85R-RH|Rickey Henderson|Athletics|;85R-RHO|Rhys Hoskins|Phillies|;85R-RJ|Reggie Jackson|Angels|;85R-RS|Ryne Sandberg|Cubs|;85R-RY|Robin Yount|Brewers|;85R-TG|Tony Gwynn|Padres|;85R-VG|Vladimir Guerrero Jr.|Blue Jays|;85R-WB|Wade Boggs|Red Sox|;85R-WC|Will Clark|Giants|;85R-WM|Whit Merrifield|Royals|;85R-XB|Xander Bogaerts|Red Sox|");
hit("s1","Relic","World Champion Relics","WCR-AC|Asdrubal Cabrera|Nationals|;WCR-AR|Anthony Rendon|Nationals|;WCR-AS|Anibal Sanchez|Nationals|;WCR-BD|Brian Dozier|Nationals|;WCR-JS|Juan Soto|Nationals|;WCR-KS|Kurt Suzuki|Nationals|;WCR-MS|Max Scherzer|Nationals|;WCR-MT|Michael Taylor|Nationals|;WCR-PC|Patrick Corbin|Nationals|;WCR-RZ|Ryan Zimmerman|Nationals|;WCR-SD|Sean Doolittle|Nationals|;WCR-SS|Stephen Strasburg|Nationals|;WCR-TT|Trea Turner|Nationals|;WCR-VR|Victor Robles|Nationals|;WCR-YG|Yan Gomes|Nationals|");
hit("s1","Relic","Postseason Performance Relics","PPR-AB|Alex Bregman|Astros|;PPR-AJ|Aaron Judge|Yankees|;PPR-AR|Anthony Rendon|Nationals|;PPR-CB|Cody Bellinger|Dodgers|;PPR-CC|Carlos Correa|Astros|;PPR-DS|Dansby Swanson|Braves|;PPR-FF|Freddie Freeman|Braves|;PPR-GC|Gerrit Cole|Astros|;PPR-GS|Giancarlo Stanton|Yankees|;PPR-GSP|George Springer|Astros|;PPR-JA|Jose Altuve|Astros|;PPR-JF|Jack Flaherty|Cardinals|;PPR-JP|Joc Pederson|Dodgers|;PPR-JS|Juan Soto|Nationals|;PPR-JV|Justin Verlander|Astros|;PPR-MS|Max Scherzer|Nationals|;PPR-MSO|Mike Soroka|Braves|;PPR-OA|Ozzie Albies|Braves|;PPR-PC|Patrick Corbin|Nationals|;PPR-PG|Paul Goldschmidt|Cardinals|;PPR-RA|Ronald Acuna Jr.|Braves|;PPR-RZ|Ryan Zimmerman|Nationals|;PPR-SD|Sean Doolittle|Nationals|;PPR-SS|Stephen Strasburg|Nationals|;PPR-TG|Tyler Glasnow|Rays|;PPR-TT|Trea Turner|Nationals|;PPR-WB|Walker Buehler|Dodgers|;PPR-YM|Yadier Molina|Cardinals|");
hit("s1","Relic","In The Name Relics","ITN-AB|Alex Bregman|Astros|;ITN-AC|Aroldis Chapman|Yankees|;ITN-AM|Austin Meadows|Rays|;ITN-CB|Charlie Blackmon|Rockies|;ITN-CBE|Cody Bellinger|Dodgers|;ITN-CK|Clayton Kershaw|Dodgers|;ITN-CM|Charlie Morton|Rays|;ITN-CS|Carlos Santana|Indians|;ITN-CY|Christian Yelich|Brewers|;ITN-DD|David Dahl|Rockies|;ITN-DL|DJ LeMahieu|Yankees|;ITN-DV|Daniel Vogelbach|Mariners|;ITN-FF|Freddie Freeman|Braves|;ITN-FL|Francisco Lindor|Indians|;ITN-GC|Gerrit Cole|Astros|;ITN-GS|George Springer|Astros|;ITN-GSA|Gary Sanchez|Yankees|;ITN-GT|Gleyber Torres|Yankees|;ITN-HP|Hunter Pence|Rangers|;ITN-HR|Hyun-Jin Ryu|Dodgers|;ITN-JA|Jose Abreu|White Sox|;ITN-JBE|Josh Bell|Pirates|;ITN-JBZ|Javier Baez|Cubs|;ITN-JD|Jacob deGrom|Mets|;ITN-JG|Joey Gallo|Rangers|;ITN-JH|Josh Hader|Brewers|;ITN-JM|James McCann|White Sox|;ITN-JMA|J.D. Martinez|Red Sox|;ITN-JMC|Jeff McNeil|Mets|;ITN-JME|John Means|Orioles|;ITN-JO|Jake Odorizzi|Twins|;ITN-JP|Jorge Polanco|Twins|;ITN-JR|J.T. Realmuto|Phillies|;ITN-JV|Justin Verlander|Astros|;ITN-KB|Kris Bryant|Cubs|;ITN-KM|Ketel Marte|Diamondbacks|;ITN-KY|Kirby Yates|Padres|;ITN-LG|Lucas Giolito|White Sox|;ITN-LH|Liam Hendriks|Athletics|;ITN-MB|Mookie Betts|Red Sox|;ITN-MBR|Michael Brantley|Astros|;ITN-MC|Matt Chapman|Athletics|;ITN-MM|Mike Minor|Rangers|;ITN-MMO|Mike Moustakas|Brewers|;ITN-MMU|Max Muncy|Dodgers|;ITN-MS|Mike Soroka|Braves|;ITN-MSC|Max Scherzer|Nationals|;ITN-MT|Masahiro Tanaka|Yankees|;ITN-MTR|Mike Trout|Angels|;ITN-PA|Pete Alonso|Mets|;ITN-PD|Paul DeJong|Cardinals|;ITN-RA|Ronald Acuna Jr.|Braves|;ITN-SA|Sandy Alcantara|Marlins|;ITN-SGR|Sonny Gray|Reds|;ITN-TS|Trevor Story|Rockies|;ITN-WB|Walker Buehler|Dodgers|;ITN-WC|Willson Contreras|Cubs|;ITN-WM|Whit Merrifield|Royals|;ITN-WS|Will Smith|Giants|;ITN-YG|Yasmani Grandal|Brewers|");
// ---- SERIES 1 CUT SIGNATURES ----
hit("s1","Cut","Cut Signatures","CS-BD|Bill Dickey|Yankees|;CS-BF|Bob Feller|Indians|;CS-BG|Burleigh Grimes|Dodgers|;CS-BH|Billy Herman|Cubs|;CS-CG|Charlie Gehringer|Tigers|;CS-CM|Connie Mack|Athletics|;CS-CS|Casey Stengel|Yankees|;CS-CY|Cy Young|Red Sox|;CS-DD|Don Drysdale|Dodgers|;CS-DDE|Dizzy Dean|Cardinals|;CS-DL|Don Larsen|Yankees|;CS-DS|Duke Snider|Dodgers|;CS-EB|Ernie Banks|Cubs|;CS-EM|Eddie Mathews|Braves|;CS-FF|Frankie Frisch|Cardinals|;CS-GH|Gil Hodges|Dodgers|;CS-GK|George Kell|Tigers|;CS-GKP|George Kelly|Giants|;CS-HG|Hank Greenberg|Tigers|;CS-HW|Hoyt Wilhelm|White Sox|;CS-JD|Joe DiMaggio|Yankees|;CS-JH|Jim Hunter|Athletics|;CS-JR|Jackie Robinson|Dodgers|;CS-LD|Larry Doby|Indians|;CS-LG|Lefty Grove|Athletics|;CS-MI|Monte Irvin|Giants|;CS-NF|Nellie Fox|White Sox|;CS-PR|Phil Rizzuto|Yankees|;CS-PRE|Pee Wee Reese|Dodgers|;CS-RC|Roberto Clemente|Pirates|;CS-RK|Ralph Kiner|Pirates|;CS-RM|Roger Maris|Yankees|;CS-SC|Stan Coveleski|Indians|;CS-SM|Stan Musial|Cardinals|;CS-SP|Satchel Paige|Indians|;CS-TC|Ty Cobb|Tigers|;CS-TG|Tony Gwynn|Padres|;CS-TW|Ted Williams|Red Sox|;CS-WH|Waite Hoyt|Yankees|;CS-WS|Warren Spahn|Braves|");
// ---- SERIES 1 AUTO-RELICS ----
hit("s1","Auto-Relic","Global Game Medallion Autograph","GGMA-AJ|Aaron Judge|Yankees|;GGMA-AV|Alex Verdugo|Dodgers|;GGMA-CK|Clayton Kershaw|Dodgers|;GGMA-CY|Christian Yelich|Brewers|;GGMA-DG|Didi Gregorius|Yankees|;GGMA-EJ|Eloy Jimenez|White Sox|;GGMA-GS|Gary Sanchez|Yankees|;GGMA-GT|Gleyber Torres|Yankees|;GGMA-HM|Hideki Matsui|Yankees|;GGMA-I|Ichiro|Mariners|;GGMA-JA|Jose Altuve|Astros|;GGMA-JS|Juan Soto|Nationals|;GGMA-JU|Julio Urias|Dodgers|;GGMA-JV|Joey Votto|Reds|;GGMA-KB|Kris Bryant|Cubs|;GGMA-KG|Ken Griffey Jr.|Mariners|;GGMA-LU|Luis Urias|Padres|;GGMA-MC|Miguel Cabrera|Tigers|;GGMA-MM|Manny Machado|Padres|;GGMA-MT|Mike Trout|Angels|;GGMA-OA|Ozzie Albies|Braves|;GGMA-RA|Ronald Acuna Jr.|Braves|;GGMA-RD|Rafael Devers|Red Sox|;GGMA-SO|Shohei Ohtani|Angels|;GGMA-VG|Vladimir Guerrero Jr.|Blue Jays|;GGMA-WC|Willson Contreras|Cubs|;GGMA-XB|Xander Bogaerts|Red Sox|;GGMA-YA|Yordan Alvarez|Astros|Rookie;GGMA-YG|Yasmani Grandal|Brewers|");
hit("s1","Auto-Relic","Jumbo Jersey Sleeve Patch Autograph","JJSA-AA|Aristides Aquino|Reds|Rookie;JJSA-AR|Anthony Rizzo|Cubs|;JJSA-BM|Brendan McKay|Rays|Rookie;JJSA-BS|Blake Snell|Rays|;JJSA-DV|Daniel Vogelbach|Mariners|;JJSA-JL|Jesus Luzardo|Athletics|Rookie;JJSA-JS|Juan Soto|Nationals|;JJSA-JVO|Joey Votto|Reds|;JJSA-JY|Jordan Yamamoto|Marlins|Rookie;JJSA-Jd|Jacob deGrom|Mets|;JJSA-KL|Kyle Lewis|Mariners|Rookie;JJSA-KM|Ketel Marte|Diamondbacks|;JJSA-MC|Matt Chapman|Athletics|;JJSA-MK|Max Kepler|Twins|;JJSA-MS|Max Scherzer|Nationals|;JJSA-MT|Mike Trout|Angels|;JJSA-NA|Nolan Arenado|Rockies|;JJSA-OA|Ozzie Albies|Braves|;JJSA-PA|Pete Alonso|Mets|;JJSA-RA|Ronald Acuna Jr.|Braves|;JJSA-RD|Rafael Devers|Red Sox|;JJSA-RH|Rhys Hoskins|Phillies|;JJSA-TM|Trey Mancini|Orioles|;JJSA-WM|Whit Merrifield|Royals|;JJSA-YA|Yordan Alvarez|Astros|Rookie");
hit("s1","Auto-Relic","Rookie Card Retrospective Medallion Autograph","RRMA-AK|Al Kaline|Tigers|;RRMA-BG|Bob Gibson|Cardinals|;RRMA-BJ|Bo Jackson|Royals|;RRMA-BP|Buster Posey|Giants|;RRMA-CJ|Chipper Jones|Braves|;RRMA-CK|Clayton Kershaw|Dodgers|;RRMA-CR|Cal Ripken Jr.|Orioles|;RRMA-DE|Dennis Eckersley|Indians|;RRMA-DG|Dwight Gooden|Mets|;RRMA-DM|Don Mattingly|Yankees|;RRMA-DS|Darryl Strawberry|Mets|;RRMA-FR|Frank Robinson|Reds|;RRMA-FT|Fernando Tatis Jr.|Padres|;RRMA-FTH|Frank Thomas|White Sox|;RRMA-IS|Ichiro|Mariners|;RRMA-JA|Jose Altuve|Astros|;RRMA-JB|Jeff Bagwell|Astros|;RRMA-JC|Jose Canseco|Athletics|;RRMA-JS|John Smoltz|Braves|;RRMA-KG|Ken Griffey Jr.|Mariners|;RRMA-MC|Miguel Cabrera|Marlins|;RRMA-MT|Mike Trout|Angels|;RRMA-OS|Ozzie Smith|Padres|;RRMA-PA|Pete Alonso|Mets|;RRMA-RH|Rhys Hoskins|Phillies|;RRMA-RHE|Rickey Henderson|Athletics|;RRMA-RJ|Reggie Jackson|Athletics|;RRMA-RS|Ryne Sandberg|Cubs|;RRMA-TR|Tim Raines|Expos|;RRMA-VG|Vladimir Guerrero Jr.|Blue Jays|");
hit("s1","Auto-Relic","Topps Reverence Autograph Patch","TRAP-AB|Andrew Benintendi|Red Sox|;TRAP-AJ|Aaron Judge|Yankees|;TRAP-AN|Aaron Nola|Phillies|;TRAP-AP|Andy Pettitte|Yankees|;TRAP-ARI|Austin Riley|Braves|;TRAP-BB|Bo Bichette|Blue Jays|Rookie;TRAP-BH|Bryce Harper|Phillies|;TRAP-BL|Brandon Lowe|Rays|;TRAP-BR|Brendan Rodgers|Rockies|;TRAP-CJ|Chipper Jones|Braves|;TRAP-CKS|Clayton Kershaw|Dodgers|;TRAP-CS|CC Sabathia|Yankees|;TRAP-DO|David Ortiz|Red Sox|;TRAP-DP|Dustin Pedroia|Red Sox|;TRAP-DS|Dansby Swanson|Braves|;TRAP-FT|Fernando Tatis Jr.|Padres|;TRAP-GC|Gerrit Cole|Astros|;TRAP-JAL|Jose Altuve|Astros|;TRAP-JR|Jose Ramirez|Indians|;TRAP-JS|John Smoltz|Braves|;TRAP-JSO|Juan Soto|Nationals|;TRAP-JV|Joey Votto|Reds|;TRAP-KH|Keston Hiura|Brewers|;TRAP-KW|Kerry Wood|Cubs|;TRAP-LG|Lourdes Gurriel Jr.|Blue Jays|;TRAP-LS|Luis Severino|Yankees|;TRAP-MTR|Mike Trout|Angels|;TRAP-NA|Nolan Arenado|Rockies|;TRAP-NSE|Nick Senzel|Reds|;TRAP-PA|Pete Alonso|Mets|;TRAP-RA|Roberto Alomar|Orioles|;TRAP-RH|Rickey Henderson|Mets|;TRAP-TG|Tom Glavine|Mets|;TRAP-VG|Vladimir Guerrero Jr.|Blue Jays|;TRAP-WB|Wade Boggs|Devil Rays|;TRAP-WC|Willson Contreras|Cubs|;TRAP-WM|Whit Merrifield|Royals|;TRAP-XB|Xander Bogaerts|Red Sox|;TRAP-YA|Yordan Alvarez|Astros|Rookie");
hit("s1","Auto-Relic","Major League Material Autograph","MLMA-AJ|Aaron Judge|Yankees|;MLMA-AN|Aaron Nola|Phillies|;MLMA-AR|Austin Riley|Braves|;MLMA-BL|Brandon Lowe|Rays|;MLMA-BM|Brendan McKay|Rays|Rookie;MLMA-BR|Brendan Rodgers|Rockies|;MLMA-CCS|CC Sabathia|Yankees|;MLMA-CP|Chris Paddack|Padres|;MLMA-CY|Christian Yelich|Brewers|;MLMA-FR|Franmil Reyes|Padres|;MLMA-FTJ|Fernando Tatis Jr.|Padres|;MLMA-GT|Gleyber Torres|Yankees|;MLMA-GU|Gio Urshela|Yankees|;MLMA-JA|Jose Altuve|Astros|;MLMA-JB|Jose Berrios|Twins|;MLMA-JDM|J.D. Martinez|Red Sox|;MLMA-JF|Jack Flaherty|Cardinals|;MLMA-JS|Juan Soto|Nationals|;MLMA-JSH|Justus Sheffield|Mariners|;MLMA-KB|Kris Bryant|Cubs|;MLMA-KGJ|Ken Griffey Jr.|Mariners|;MLMA-KH|Keston Hiura|Brewers|;MLMA-KS|Kyle Schwarber|Cubs|;MLMA-LGJ|Lourdes Gurriel Jr.|Blue Jays|;MLMA-LV|Luke Voit|Yankees|;MLMA-MCH|Matt Chapman|Athletics|;MLMA-MCL|Mike Clevinger|Indians|;MLMA-MK|Max Kepler|Twins|;MLMA-MS|Max Scherzer|Nationals|;MLMA-MSO|Mike Soroka|Braves|;MLMA-MT|Mike Trout|Angels|;MLMA-NA|Nolan Arenado|Rockies|;MLMA-PA|Pete Alonso|Mets|;MLMA-RAJ|Ronald Acuna Jr.|Braves|;MLMA-RH|Rhys Hoskins|Phillies|;MLMA-VGJ|Vladimir Guerrero Jr.|Blue Jays|;MLMA-VR|Victor Robles|Nationals|;MLMA-WA|Willians Astudillo|Twins|;MLMA-YA|Yordan Alvarez|Astros|Rookie","Black, Gold, Red, Platinum");
hit("s1","Auto-Relic","World Champion Autograph Relic","WCAR-JS|Juan Soto|Nationals|;WCAR-KS|Kurt Suzuki|Nationals|;WCAR-MS|Max Scherzer|Nationals|;WCAR-PC|Patrick Corbin|Nationals|;WCAR-RZ|Ryan Zimmerman|Nationals|;WCAR-SD|Sean Doolittle|Nationals|;WCAR-VR|Victor Robles|Nationals|;WCAR-YG|Yan Gomes|Nationals|");
hit("s1","Auto-Relic","Postseason Performance Autograph Relic","PPAR-AJ|Aaron Judge|Yankees|;PPAR-BS|Blake Snell|Rays|;PPAR-CK|Clayton Kershaw|Dodgers|;PPAR-DS|Dansby Swanson|Braves|;PPAR-GC|Gerrit Cole|Astros|;PPAR-GS|George Springer|Astros|;PPAR-JA|Jose Altuve|Astros|;PPAR-JF|Jack Flaherty|Cardinals|;PPAR-JP|Joc Pederson|Dodgers|;PPAR-JS|Juan Soto|Nationals|;PPAR-MM|Max Muncy|Dodgers|;PPAR-MS|Max Scherzer|Nationals|;PPAR-MSO|Mike Soroka|Braves|;PPAR-OA|Ozzie Albies|Braves|;PPAR-PC|Patrick Corbin|Nationals|;PPAR-PG|Paul Goldschmidt|Cardinals|;PPAR-RA|Ronald Acuna Jr.|Braves|;PPAR-SD|Sean Doolittle|Nationals|");

export default function App(){
  const [tab,setTab]=useState<"dashboard"|"sets"|"subsets"|"collection"|"wantlist"|"add"|"inventory"|"checklists"|"parallels">("dashboard");
  const [parSearch,setParSearch]=useState(""); const [parSet,setParSet]=useState("All");
  const [s1InsertId,setS1InsertId]=useState("s1-85"); const [s1InsertSearch,setS1InsertSearch]=useState("");
  const [s2InsertId,setS2InsertId]=useState("s2-db"); const [s2InsertSearch,setS2InsertSearch]=useState("");
  const [updInsertId,setUpdInsertId]=useState("upd-db"); const [updInsertSearch,setUpdInsertSearch]=useState(""); const [updVarSearch,setUpdVarSearch]=useState(""); const [updVarId,setUpdVarId]=useState<"SP Variation"|"SSP Variation"|"SSSP Variation">("SP Variation");
  const [chrInsertId,setChrInsertId]=useState("chr-85tc"); const [chrInsertSearch,setChrInsertSearch]=useState(""); const [chrVarSearch,setChrVarSearch]=useState(""); const [chrVarId,setChrVarId]=useState<"SP Variation"|"SSP Variation">("SP Variation");
  const [bowInsertSearch,setBowInsertSearch]=useState("");
  const [bowHfSearch,setBowHfSearch]=useState("");
  const [bowHfAutoSearch,setBowHfAutoSearch]=useState("");
  const [checkSearch,setCheckSearch]=useState(""); const [checkTeam,setCheckTeam]=useState("All"); const [checkNote,setCheckNote]=useState("All"); const [checkOwned,setCheckOwned]=useState("All");
  const [cards,setCards]=useState<Rec[]>([]);
  const [overrides,setOverrides]=useState<OverrideRec[]>([]);
  const [loading,setLoading]=useState(true);
  const [busy,setBusy]=useState(false);
  const [message,setMessage]=useState("");
  const [form,setForm]=useState<CardValue>(emptyForm);
  const [editingId,setEditingId]=useState<string|null>(null);
  const [detailId,setDetailId]=useState<string|null>(null);
  const [editingSize,setEditingSize]=useState<string|null>(null);
  const [sizeDraft,setSizeDraft]=useState("");
  const [search,setSearch]=useState(""); const [cat,setCat]=useState("All"); const [sortSet,setSortSet]=useState("name");
  const [colSearch,setColSearch]=useState(""); const [colSet,setColSet]=useState("All"); const [colOwned,setColOwned]=useState("All"); const [colParallel,setColParallel]=useState("All"); const [colSort,setColSort]=useState("player");
  const [colSubsetType,setColSubsetType]=useState("All"); const [colSubsetName,setColSubsetName]=useState("All");
  const [subSearch,setSubSearch]=useState(""); const [subSet,setSubSet]=useState("All"); const [subType,setSubType]=useState("All");
  const [selected,setSelected]=useState<Set<string>>(new Set());
  const [confirmClear,setConfirmClear]=useState(false);
  const [invSearch,setInvSearch]=useState(""); const [invSet,setInvSet]=useState("All"); const [invSort,setInvSort]=useState("player");
  const [invSelected,setInvSelected]=useState<Set<string>>(new Set());
  const [invBulkQty,setInvBulkQty]=useState("1"); const [showSetQty,setShowSetQty]=useState(false); const [invConfirmDelete,setInvConfirmDelete]=useState(false);
  const [duplicate,setDuplicate]=useState<{existing:Rec; pending:CardValue}|null>(null);
  const fileRef=useRef<HTMLInputElement>(null);

  const overrideMap = useMemo(()=>{ const m=new Map<string,number>(); overrides.forEach(o=>m.set(o.value.setId,o.value.baseCards)); return m; },[overrides]);
  const sets = useMemo(()=>SETS.map(s=>({...s, baseCards: overrideMap.has(s.id)? overrideMap.get(s.id)! : s.baseCards})),[overrideMap]);
  const setById = useMemo(()=>new Map(sets.map(s=>[s.id,s])),[sets]);

  async function reloadRecords(){
    const [c,o]=await Promise.all([api("records.list",{collection:"topps_cards"}), api("records.list",{collection:"topps_set_overrides"})]);
    setCards(c.records||[]); setOverrides(o.records||[]);
  }
  useEffect(()=>{ reloadRecords().catch((e)=>setMessage("Database unavailable in preview — your saved cards will load after publishing. "+e.message)).finally(()=>setLoading(false)); },[]);

  async function createRow(row:CardValue){
    return api("records.create",{collection:"topps_cards",value:row,idempotency_key:`card-${row.setId}-${row.cardNumber}-${row.player.replace(/[^a-z0-9]/gi,"-")}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`});
  }

  const totalBase = useMemo(()=>sets.reduce((a,s)=>a+(s.baseCards>0?s.baseCards:0),0),[sets]);
  const baseOwnedCards = cards.filter(c=>effectiveOwned(c.value) && isBaseCard(c.value));
  const ownedCards = baseOwnedCards;
  const insertCards = cards.filter(c=>isInsertParallel(c.value));
  const insertOwned = insertCards.filter(c=>effectiveOwned(c.value));
  const wantCards = cards.filter(c=>c.value.wantlist && !effectiveOwned(c.value));
  const totalValue = cards.reduce((a,c)=>a + qtyOwnedOf(c.value)*(c.value.currentValue||0),0);
  const completion = totalBase? Math.min(100, ownedCards.length/totalBase*100):0;
  const ownedBySet = useMemo(()=>{ const m=new Map<string,number>(); cards.forEach(c=>{ if(effectiveOwned(c.value) && isBaseCard(c.value)){ let sid=c.value.setId; const cn=String(c.value.cardNumber||"").toUpperCase(); if(sid==="bowman" && /^(BP|BPP)-/.test(cn)) sid="bowman-prospects"; if(sid==="bowman" && /^BCP-/.test(cn)) sid="bowman-chrome"; m.set(sid,(m.get(sid)||0)+1)} }); return m; },[cards]);
  const insertsBySet = useMemo(()=>{ const m=new Map<string,number>(); cards.forEach(c=>{ if(isInsertParallel(c.value)) m.set(c.value.setId,(m.get(c.value.setId)||0)+1)}); return m; },[cards]);

  // Inventory grouping: Set + Card # + Player + Parallel
  type InvGroup = {key:string; setId:string; cardNumber:string; player:string; parallel:string; qtyOwned:number; qtyForTrade:number; qtyGraded:number; totalQty:number; unitValue:number; totalValue:number; locations:string; condition:string; subsetName:string; subsetType:string; ids:string[]; rep:Rec};
  const invGroups = useMemo(()=>{
    const map = new Map<string, InvGroup>();
    cards.forEach(c=>{
      const v=c.value; const key=`${v.setId}|${v.cardNumber.toLowerCase()}|${(v.player||"").toLowerCase()}|${v.parallel}|${v.subsetName||""}`;
      const qo=qtyOwnedOf(v), qft=qtyForTradeOf(v), qg=qtyGradedOf(v);
      const existing = map.get(key);
      if(existing){
        existing.qtyOwned+=qo; existing.qtyForTrade+=qft; existing.qtyGraded+=qg; existing.totalQty+=qo+qft; existing.totalValue+=qo*(v.currentValue||0); existing.ids.push(c.id);
        const loc=locationOf(v); if(loc && !existing.locations.includes(loc)) existing.locations = existing.locations ? `${existing.locations}, ${loc}` : loc;
      } else {
        map.set(key,{key,setId:v.setId,cardNumber:v.cardNumber,player:v.player,parallel:v.parallel,qtyOwned:qo,qtyForTrade:qft,qtyGraded:qg,totalQty:qo+qft,unitValue:v.currentValue||0,totalValue:qo*(v.currentValue||0),locations:locationOf(v),condition:v.condition,subsetName:v.subsetName||"",subsetType:v.subsetType||"Base Card",ids:[c.id],rep:c});
      }
    });
    return Array.from(map.values());
  },[cards]);
  const invOwnedGroups = invGroups.filter(g=>g.qtyOwned>0);
  const invUnique = invOwnedGroups.length;
  const invTotalOwned = invGroups.reduce((a,g)=>a+g.qtyOwned,0);
  const invDuplicates = Math.max(0, invTotalOwned - invUnique);
  const invTotalForTrade = invGroups.reduce((a,g)=>a+g.qtyForTrade,0);
  const invTotalValue = invGroups.reduce((a,g)=>a+g.totalValue,0);

  function applyLookupToForm(base:CardValue): CardValue { const e = lookupCardName(base.setId, base.cardNumber, base.parallel); if(!e) return base; return {...base, player:e.player, team:fullTeamName(e.team), notes: base.notes || e.note}; }
  function startAdd(prefill?:Partial<CardValue>){ let next: CardValue = {...emptyForm, ...prefill, dateAdded:new Date().toISOString().slice(0,10), subsetName:prefill?.subsetName ?? "", subsetType:prefill?.subsetType ?? "Base Card", qtyOwned: prefill?.qtyOwned ?? 1, qtyForTrade: prefill?.qtyForTrade ?? 0, qtyGraded: prefill?.qtyGraded ?? 0, location: prefill?.location ?? ""}; if(next.setId==="bowman" && (next.subsetName||"").startsWith("Bowman Prospects")) next = {...next, setId:"bowman-prospects"}; if(prefill?.cardNumber){ const norm = normalizeCardNumber(next.setId, prefill.cardNumber); if(next.setId==="bowman" && /^(BP|BPP)-/.test(norm.toUpperCase())) next = {...next, setId:"bowman-prospects"}; next = {...next, cardNumber: norm}; } if(!prefill?.player && prefill?.cardNumber) next = applyLookupToForm(next); setForm(next); setEditingId(null); setTab("add"); }
  function handleCardNumberChange(cardNumber:string){ const normalized = normalizeCardNumber(form.setId, cardNumber); let effectiveSetId = form.setId; if(form.setId==="bowman" && /^(BP|BPP)-/.test(normalized.toUpperCase())) effectiveSetId="bowman-prospects"; const base = {...form, setId: effectiveSetId, cardNumber: normalized}; const e = lookupCardName(base.setId, normalized, base.parallel); const next = e ? {...applyLookupToForm(base), notes: e.note} : base; setForm(next); }
  function lookupName(){ const normNum = normalizeCardNumber(form.setId, form.cardNumber); let sid = form.setId; if(sid==="bowman" && /^(BP|BPP)-/.test(normNum.toUpperCase())) sid="bowman-prospects"; const normalized = {...form, setId: sid, cardNumber: normNum}; const next = applyLookupToForm(normalized); if(next===normalized){ setForm(normalized); setMessage("No Series 1, Series 2, Update, Chrome, Bowman, Bowman Prospects, Bowman Draft, Heritage, Allen & Ginter, Gypsy Queen, Opening Day, Stadium Club, Big League, or Archives name found for that Set + Card #."); } else { setForm(next); setMessage(`Looked up #${next.cardNumber}: ${next.player} — ${next.team}. You can still edit Player / Team manually.`); } }
  function handleSubsetNameChange(name:string){
    if(name===""){
      setForm({...form, subsetName:"", subsetType:"Base Card"});
    } else if(name==="Other"){
      setForm({...form, subsetName:"Other"});
    } else {
      const def = SUBSETS.find(s=>s.setId===form.setId && s.name===name);
      setForm({...form, subsetName:name, subsetType: def ? subsetTypeForDef(def) : form.subsetType});
    }
  }
  function handleFormSetChange(setId:string){
    const base = {...form, setId, subsetName:"", subsetType:"Base Card", cardNumber: normalizeCardNumber(setId, form.cardNumber)};
    setForm(lookupCardName(setId, base.cardNumber) ? applyLookupToForm(base) : base);
  }
  async function saveCard(e:React.FormEvent){
    e.preventDefault();
    if(!form.cardNumber.trim()){ setMessage("Card # is required."); return; }
    if(!form.player.trim() && editingId===null && !duplicate){ /* allow blank only via generated slots; normal add needs player */ }
    if(!form.player.trim()){ setMessage("Player is required. For a blank checklist slot, use Generate Checklist in the set detail instead."); return; }
    const normalized: CardValue = {...form, cardNumber: normalizeCardNumber(form.setId, form.cardNumber), qtyOwned: Math.max(0, Number(form.qtyOwned)||0), qtyForTrade: Math.max(0, Number(form.qtyForTrade)||0), qtyGraded: Math.max(0, Number(form.qtyGraded)||0), location: (form.location||"").trim(), owned: (Number(form.qtyOwned)||0)>0 || form.owned, forTrade: (Number(form.qtyForTrade)||0)>0 || form.forTrade};
    if(!editingId){
      const existing = cards.find(c=>c.value.setId===normalized.setId && c.value.cardNumber.toLowerCase()===normalized.cardNumber.toLowerCase() && c.value.parallel===normalized.parallel && (c.value.subsetName||"")===(normalized.subsetName||""));
      if(existing){ setDuplicate({existing, pending: normalized}); return; }
    }
    setBusy(true); setMessage("");
    try{
      if(editingId){ await api("records.replace",{collection:"topps_cards",id:editingId,value:normalized}); setMessage("Card updated."); }
      else { await createRow(normalized); setMessage("Card saved to your collection."); }
      await reloadRecords(); setEditingId(null); setForm({...emptyForm,dateAdded:new Date().toISOString().slice(0,10)}); setTab("collection");
    }catch(err:any){ setMessage(err.message||"Save failed."); } finally{ setBusy(false); }
  }
  async function addToExisting(){
    if(!duplicate) return;
    setBusy(true);
    try{
      const ex=duplicate.existing; const cur=qtyOwnedOf(ex.value);
      await api("records.replace",{collection:"topps_cards",id:ex.id,value:{...ex.value, qtyOwned:cur+1, owned:true, qtyForTrade: qtyForTradeOf(ex.value), qtyGraded: qtyGradedOf(ex.value), location: locationOf(ex.value)}});
      await reloadRecords(); setDuplicate(null); setMessage(`Added +1 to existing ${ex.value.player || "card"} — now ${cur+1} owned.`); setTab("inventory");
    }catch(err:any){ setMessage(err.message||"Could not add to existing."); } finally{ setBusy(false); }
  }
  async function createSeparateEntry(){
    if(!duplicate) return;
    setBusy(true);
    try{ await createRow(duplicate.pending); await reloadRecords(); setDuplicate(null); setMessage("Created a separate entry."); setTab("collection"); }catch(err:any){ setMessage(err.message||"Save failed."); } finally{ setBusy(false); }
  }
  function editCard(r:Rec){ setForm({...r.value, subsetName:r.value.subsetName||"", subsetType:r.value.subsetType||"Base Card", qtyOwned: qtyOwnedOf(r.value), qtyForTrade: qtyForTradeOf(r.value), qtyGraded: qtyGradedOf(r.value), location: locationOf(r.value)}); setEditingId(r.id); setTab("add"); window.scrollTo({top:0,behavior:"smooth"}); }
  async function deleteCard(id:string){ setBusy(true); try{ await api("records.delete",{collection:"topps_cards",id}); await reloadRecords(); setMessage("Card deleted."); }catch(e:any){ setMessage(e.message);} finally{setBusy(false);} }
  async function toggleOwned(r:Rec, owned:boolean){ try{ const cur=qtyOwnedOf(r.value); await api("records.replace",{collection:"topps_cards",id:r.id,value:{...r.value,owned, wantlist: owned? false : r.value.wantlist, qtyOwned: owned ? Math.max(1,cur) : 0, qtyForTrade: qtyForTradeOf(r.value), qtyGraded: qtyGradedOf(r.value), location: locationOf(r.value)}}); await reloadRecords(); }catch(e:any){ setMessage(e.message);} }
  async function adjustQty(r:Rec, delta:number){
    const next = Math.max(0, qtyOwnedOf(r.value)+delta);
    try{ await api("records.replace",{collection:"topps_cards",id:r.id,value:{...r.value, qtyOwned:next, owned: next>0, wantlist: next>0 ? false : r.value.wantlist, qtyForTrade: qtyForTradeOf(r.value), qtyGraded: qtyGradedOf(r.value), location: locationOf(r.value)}}); await reloadRecords(); }catch(e:any){ setMessage(e.message); }
  }
  async function adjustGroupQty(g:InvGroup, delta:number){ await adjustQty(g.rep, delta); }
  async function moveToOwned(r:Rec){ await toggleOwned(r,true); setMessage(`${r.value.player} moved to Owned.`); }
  async function bulkOwned(){ setBusy(true); try{ for(const id of selected){ const r=cards.find(x=>x.id===id); if(r) await api("records.replace",{collection:"topps_cards",id,value:{...r.value,owned:true,wantlist:false, qtyOwned: Math.max(1, qtyOwnedOf(r.value)), qtyForTrade: qtyForTradeOf(r.value), qtyGraded: qtyGradedOf(r.value), location: locationOf(r.value)}});} await reloadRecords(); setSelected(new Set()); setMessage("Selected cards marked owned."); }catch(e:any){setMessage(e.message)} finally{setBusy(false);} }
  async function bulkDelete(){ setBusy(true); try{ for(const id of [...selected]) await api("records.delete",{collection:"topps_cards",id}); await reloadRecords(); setSelected(new Set()); setMessage("Selected cards deleted."); }catch(e:any){setMessage(e.message)} finally{setBusy(false);} }
  async function markSetComplete(s:SetDef){
    if(s.baseCards===0){ setMessage("This is a hit-driven set — add hits manually."); return; }
    const numbers = slotNumbersForSet(s);
    const existing = new Set(cards.filter(c=>c.value.setId===s.id && effectiveOwned(c.value) && isBaseCard(c.value)).map(c=>normalizeCardNumber(s.id, c.value.cardNumber)));
    if(s.id==="bowman-prospects") cards.filter(c=>c.value.setId==="bowman" && effectiveOwned(c.value) && isBaseCard(c.value)).forEach(c=>existing.add(normalizeCardNumber("bowman", c.value.cardNumber)));
    const rows:CardValue[] = [];
    for(const num of numbers){ if(!existing.has(num)) { const e=lookupCardName(s.id,num); const meta = slotMetaForNumber(num); rows.push({...emptyForm,setId:s.id,cardNumber:num,player:e?e.player:"— Base Card —",team:e?fullTeamName(e.team):"Other",owned:true,subsetName:meta.subsetName,subsetType:meta.subsetType,qtyOwned:1,qtyForTrade:0,qtyGraded:0,location:"",notes:e?e.note:""}); } }
    if(!rows.length){ setMessage(`${s.name} is already marked complete.`); return; }
    setBusy(true); let saved=0; let error:string|null=null;
    try{ for(const row of rows){ await createRow(row); saved++; } }catch(e){ error=e instanceof Error?e.message:String(e); }
    let reloadError:string|null=null; try{ await reloadRecords(); }catch(e){ reloadError=e instanceof Error?e.message:String(e); }
    setMessage(`Marked complete: saved ${saved} of ${rows.length}. Remaining ${rows.length-saved}.${error?` Error: ${error}`:""}${reloadError?` Reload: ${reloadError}`:""}`); setBusy(false);
  }
  async function generateSlots(s:SetDef){
    if(s.baseCards===0){ setMessage("This is a hit-driven set — add hits manually. No base slots to generate."); return; }
    const numbers = slotNumbersForSet(s);
    const existing = new Set(cards.filter(c=>c.value.setId===s.id).map(c=>c.value.cardNumber.toLowerCase()));
    if(s.id==="bowman-prospects") cards.filter(c=>c.value.setId==="bowman").forEach(c=>existing.add(normalizeCardNumber("bowman", c.value.cardNumber).toLowerCase()));
    const toCreate = numbers.filter(n=>!existing.has(n.toLowerCase()));
    if(!toCreate.length){ setMessage(`${s.name} already has all ${numbers.length} slots — no duplicates generated.`); return; }
    setBusy(true); let saved=0; let error:string|null=null;
    try{ for(const n of toCreate){ const meta=slotMetaForNumber(n); const e=lookupCardName(s.id,n); await createRow({...emptyForm,setId:s.id,cardNumber:n,player:e?e.player:"",team:e?fullTeamName(e.team):"Other",parallel:"Base",owned:false,wantlist:false,forTrade:false,purchasePrice:0,currentValue:0,notes:e?e.note:"",subsetName:meta.subsetName,subsetType:meta.subsetType,qtyOwned:0,qtyForTrade:0,qtyGraded:0,location:""}); saved++; } }catch(e){ error=e instanceof Error?e.message:String(e); }
    let reloadError:string|null=null; try{ await reloadRecords(); }catch(e){ reloadError=e instanceof Error?e.message:String(e); }
    setMessage(`Generate Checklist: saved ${saved} of ${toCreate.length} slots. Remaining ${toCreate.length-saved}. Skipped ${numbers.length-toCreate.length} existing slots.${error?` Error: ${error}`:""}${reloadError?` Reload: ${reloadError}`:""}`); setBusy(false);
  }
  async function clearZeroQtySlots(s:SetDef){
    const targets = cards.filter(c=>c.value.setId===s.id && qtyOwnedOf(c.value)===0 && qtyForTradeOf(c.value)===0 && !(c.value.player||"").trim());
    if(!targets.length){ setMessage(`No zero-qty blank slots to clear in ${s.name}.`); return; }
    setBusy(true); try{ for(const c of targets) await api("records.delete",{collection:"topps_cards",id:c.id}); await reloadRecords(); setMessage(`Cleared ${targets.length} zero-qty blank slots from ${s.name}.`); }catch(e:any){ setMessage(e.message); } finally{ setBusy(false); }
  }
  async function loadSample(){
    const existing = new Set(cards.map(c=>`${c.value.setId}|${c.value.cardNumber}|${c.value.player}`));
    const rows = SAMPLE2.filter(c=>!existing.has(`${c.setId}|${c.cardNumber}|${c.player}`));
    if(!rows.length){ setMessage("Sample cards are already in your collection."); return; }
    setBusy(true); let saved=0; let error:string|null=null;
    try{ for(const row of rows){ await createRow(row); saved++; } }catch(e){ error=e instanceof Error?e.message:String(e); }
    let reloadError:string|null=null; try{ await reloadRecords(); }catch(e){ reloadError=e instanceof Error?e.message:String(e); }
    setMessage(`Sample data: saved ${saved}, remaining ${rows.length-saved}.${error?` ${error}`:""}${reloadError?` Reload: ${reloadError}`:""}`); setBusy(false);
  }
  async function clearAll(){
    setBusy(true); try{ for(const c of cards) await api("records.delete",{collection:"topps_cards",id:c.id}); await reloadRecords(); setMessage("Collection cleared. Sets Library remains intact."); }catch(e:any){setMessage(e.message)} finally{setBusy(false); setConfirmClear(false);}
  }
  async function saveSize(s:SetDef){
    const n = Number(sizeDraft); if(!Number.isInteger(n)||n<0||n>5000){ setMessage("Enter a whole number from 0 to 5,000."); return; }
    setBusy(true); try{ const ex=overrides.find(o=>o.value.setId===s.id); if(ex) await api("records.replace",{collection:"topps_set_overrides",id:ex.id,value:{setId:s.id,baseCards:n}}); else await api("records.create",{collection:"topps_set_overrides",value:{setId:s.id,baseCards:n},idempotency_key:`override-${s.id}`}); await reloadRecords(); setEditingSize(null); setMessage(`${s.name} base size updated to ${n}.`);}catch(e:any){setMessage(e.message)} finally{setBusy(false);}
  }
  async function bulkInvAdjust(delta:number){
    if(!invSelected.size) return;
    setBusy(true);
    try{
      for(const key of [...invSelected]){ const g=invGroups.find(x=>x.key===key); if(!g) continue; const next=Math.max(0, qtyOwnedOf(g.rep.value)+delta); await api("records.replace",{collection:"topps_cards",id:g.rep.id,value:{...g.rep.value, qtyOwned:next, owned: next>0, wantlist: next>0?false:g.rep.value.wantlist, qtyForTrade: qtyForTradeOf(g.rep.value), qtyGraded: qtyGradedOf(g.rep.value), location: locationOf(g.rep.value)}}); }
      await reloadRecords(); setInvSelected(new Set()); setMessage(`Bulk ${delta>0?"+1":"-1"} Qty applied to ${invSelected.size} group${invSelected.size===1?"":"s"}.`);
    }catch(e:any){ setMessage(e.message); } finally{ setBusy(false); }
  }
  async function bulkInvSetQty(){
    const n=Number(invBulkQty); if(!Number.isInteger(n)||n<0||n>999){ setMessage("Enter a whole Qty from 0 to 999 for Set Qty."); return; }
    setBusy(true);
    try{
      for(const key of [...invSelected]){ const g=invGroups.find(x=>x.key===key); if(!g) continue; for(const id of g.ids){ const r=cards.find(x=>x.id===id); if(!r) continue; const isRep = id===g.rep.id; await api("records.replace",{collection:"topps_cards",id,value:{...r.value, qtyOwned: isRep?n:0, owned: isRep ? n>0 : false, wantlist: isRep ? (n>0?false:r.value.wantlist) : r.value.wantlist, qtyForTrade: qtyForTradeOf(r.value), qtyGraded: qtyGradedOf(r.value), location: locationOf(r.value)}}); } }
      await reloadRecords(); setInvSelected(new Set()); setShowSetQty(false); setMessage(`Bulk Set Qty: set ${invSelected.size} group${invSelected.size===1?"":"s"} to ${n}.`);
    }catch(e:any){ setMessage(e.message); } finally{ setBusy(false); }
  }
  async function bulkInvWantlist(){
    setBusy(true);
    try{ for(const key of [...invSelected]){ const g=invGroups.find(x=>x.key===key); if(!g) continue; for(const id of g.ids){ const r=cards.find(x=>x.id===id); if(r) await api("records.replace",{collection:"topps_cards",id,value:{...r.value, owned:false, wantlist:true, qtyOwned:0, qtyForTrade: qtyForTradeOf(r.value), qtyGraded: qtyGradedOf(r.value), location: locationOf(r.value)}}); } } await reloadRecords(); setInvSelected(new Set()); setMessage("Selected groups moved to Wantlist."); }catch(e:any){ setMessage(e.message); } finally{ setBusy(false); }
  }
  async function bulkInvDelete(){
    setBusy(true);
    try{ const ids:number=0; let count=0; for(const key of [...invSelected]){ const g=invGroups.find(x=>x.key===key); if(!g) continue; for(const id of g.ids){ await api("records.delete",{collection:"topps_cards",id}); count++; } } void ids; await reloadRecords(); setInvSelected(new Set()); setInvConfirmDelete(false); setMessage(`Deleted ${count} card record${count===1?"":"s"} in ${invSelected.size} group${invSelected.size===1?"":"s"}.`); }catch(e:any){ setMessage(e.message); } finally{ setBusy(false); }
  }
  function exportJSON(){
    const blob=new Blob([JSON.stringify({exportedAt:new Date().toISOString(),cards:cards.map(c=>c.value)},null,2)],{type:"application/json"}); const url=URL.createObjectURL(blob); const a=document.createElement("a"); a.href=url; a.download="2020-topps-collection.json"; a.click(); URL.revokeObjectURL(url);
  }
  function exportCSV(){
    const head=["Set","Card #","Player","Team","Parallel","Subset / Insert","Subset Type","Condition","Graded","Grade","Owned","Wantlist","For Trade","Qty Owned","Qty For Trade","Qty Graded","Location","Purchase Price","Current Value","Notes","Date Added"];
    const rows=cards.map(c=>{const v=c.value; return [setById.get(v.setId)?.name||v.setId,v.cardNumber,v.player,v.team,v.parallel,v.subsetName||"",v.subsetType||"Base Card",v.condition,v.gradedCompany,v.grade,v.owned?"Yes":"No",v.wantlist?"Yes":"No",v.forTrade?"Yes":"No",qtyOwnedOf(v),qtyForTradeOf(v),qtyGradedOf(v),locationOf(v),v.purchasePrice,v.currentValue,v.notes,v.dateAdded];});
    const esc=(x:any)=>`"${String(x??"").replace(/"/g,'""')}"`;
    const blob=new Blob([[head,...rows].map(r=>r.map(esc).join(",")).join("\n")],{type:"text/csv"}); const url=URL.createObjectURL(blob); const a=document.createElement("a"); a.href=url; a.download="2020-topps-collection.csv"; a.click(); URL.revokeObjectURL(url);
  }
  async function importJSON(file:File){
    try{
      const text=await file.text(); const data=JSON.parse(text); const list=Array.isArray(data)?data:(Array.isArray(data.cards)?data.cards:[]);
      if(!list.length){ setMessage("No cards found in that JSON file."); return; }
      const rows:CardValue[] = list.filter((v:any)=>v && v.setId && v.cardNumber).map((v:any)=>({...emptyForm,...v,purchasePrice:Number(v.purchasePrice)||0,currentValue:Number(v.currentValue)||0,owned:!!v.owned,wantlist:!!v.wantlist,forTrade:!!v.forTrade,subsetName:v.subsetName||"",subsetType:(v.subsetType||"Base Card") as SubsetType, qtyOwned: typeof v.qtyOwned==="number"?v.qtyOwned:(v.owned?1:0), qtyForTrade: Number(v.qtyForTrade)||0, qtyGraded: Number(v.qtyGraded)||0, location: v.location||""}));
      if(!rows.length){ setMessage("No valid cards found. Each card needs setId and cardNumber."); return; }
      setBusy(true); let saved=0; let error:string|null=null;
      try{ for(const row of rows){ await createRow(row); saved++; } }catch(e){ error=e instanceof Error?e.message:String(e); }
      let reloadError:string|null=null; try{ await reloadRecords(); }catch(e){ reloadError=e instanceof Error?e.message:String(e); }
      setMessage(`Import: saved ${saved}, remaining ${rows.length-saved}.${error?` ${error}`:""}${reloadError?` Reload: ${reloadError}`:""}`); setBusy(false);
    }catch{ setMessage("That file could not be read as JSON."); }
  }

  const filteredSets = useMemo(()=>{ let list=sets.filter(s=>(cat==="All"||s.category===cat) && (s.name.toLowerCase().includes(search.toLowerCase())||s.notes.toLowerCase().includes(search.toLowerCase())));
    if(sortSet==="name") list.sort((a,b)=>a.name.localeCompare(b.name));
    if(sortSet==="date") list.sort((a,b)=>a.releaseDate.localeCompare(b.releaseDate));
    if(sortSet==="base") list.sort((a,b)=>b.baseCards-a.baseCards);
    if(sortSet==="completion") list.sort((a,b)=>{ const ap=a.baseCards?(ownedBySet.get(a.id)||0)/a.baseCards:0; const bp=b.baseCards?(ownedBySet.get(b.id)||0)/b.baseCards:0; return bp-ap; });
    return list; },[sets,cat,search,sortSet,ownedBySet]);

  const filteredSubsets = useMemo(()=>{
    const q = subSearch.toLowerCase();
    return SUBSETS.filter(s=>{
      const okSet = subSet==="All" || s.setId===subSet;
      const okType = subType==="All" || s.type===subType;
      const okQ = !q || s.name.toLowerCase().includes(q) || s.notes.toLowerCase().includes(q) || (setById.get(s.setId)?.name||"").toLowerCase().includes(q);
      return okSet && okType && okQ;
    });
  },[subSearch,subSet,subType,setById]);

  const filteredCards = useMemo(()=>{ let list=cards.filter(c=>{ const v=c.value; const q=colSearch.toLowerCase(); const okQ=!q||v.player.toLowerCase().includes(q)||(setById.get(v.setId)?.name||"").toLowerCase().includes(q)||v.cardNumber.toLowerCase().includes(q)||(v.subsetName||"").toLowerCase().includes(q); const okSet=colSet==="All"||v.setId===colSet; const okOwned=colOwned==="All"||(colOwned==="Owned"&&effectiveOwned(v))||(colOwned==="Wantlist"&&v.wantlist&&!effectiveOwned(v)); const okPar=colParallel==="All"||v.parallel===colParallel; const okSubType=colSubsetType==="All"||(v.subsetType||"Base Card")===colSubsetType; const okSubName=colSubsetName==="All"||(colSubsetName==="None - Base Card"?(v.subsetName||"")==="" : (v.subsetName||"")===colSubsetName); return okQ&&okSet&&okOwned&&okPar&&okSubType&&okSubName; });
    const get=(c:Rec)=>c.value; list.sort((a,b)=>{ const va=get(a),vb=get(b); if(colSort==="player")return va.player.localeCompare(vb.player); if(colSort==="set")return (setById.get(va.setId)?.name||"").localeCompare(setById.get(vb.setId)?.name||""); if(colSort==="value")return vb.currentValue-va.currentValue; if(colSort==="date")return vb.dateAdded.localeCompare(va.dateAdded); if(colSort==="number")return va.cardNumber.localeCompare(vb.cardNumber,undefined,{numeric:true}); return 0; }); return list; },[cards,colSearch,colSet,colOwned,colParallel,colSubsetType,colSubsetName,colSort,setById]);

  const filteredInv = useMemo(()=>{
    let list = invGroups.filter(g=>{
      const q=invSearch.toLowerCase(); const okQ=!q||g.player.toLowerCase().includes(q)||(setById.get(g.setId)?.name||"").toLowerCase().includes(q)||g.cardNumber.toLowerCase().includes(q)||g.parallel.toLowerCase().includes(q)||g.locations.toLowerCase().includes(q);
      const okSet=invSet==="All"||g.setId===invSet; return okQ&&okSet;
    });
    list.sort((a,b)=>{ if(invSort==="player") return a.player.localeCompare(b.player); if(invSort==="set") return (setById.get(a.setId)?.name||"").localeCompare(setById.get(b.setId)?.name||""); if(invSort==="qty") return b.qtyOwned-a.qtyOwned; if(invSort==="value") return b.totalValue-a.totalValue; if(invSort==="number") return a.cardNumber.localeCompare(b.cardNumber,undefined,{numeric:true}); return 0; });
    return list;
  },[invGroups,invSearch,invSet,invSort,setById]);

  const checklistRows = useMemo(()=> Object.entries(CARD_NAMES["Series 1"]).map(([num, e])=>{ const found = cards.find(c=>c.value.setId==="s1" && c.value.cardNumber===num && isBaseCard(c.value)); const qty = cards.filter(c=>c.value.setId==="s1" && c.value.cardNumber===num).reduce((a,c)=>a+qtyOwnedOf(c.value),0); return {num:Number(num), entry:e, qty, owned: qty>0 || (found ? effectiveOwned(found.value) : false), found}; }).sort((a,b)=>a.num-b.num),[cards]);
  const checklistTeams = useMemo(()=> ["All", ...Array.from(new Set([...Object.values(CARD_NAMES["Series 1"]), ...Object.values(CARD_NAMES["Series 2"]), ...Object.values(CARD_NAMES["Update"]), ...Object.values(CARD_NAMES["Chrome"]), ...Object.values(CARD_NAMES["Bowman"]||{}), ...Object.values(CARD_NAMES["Bowman Prospects"]||{}), ...Object.values(CARD_NAMES["Bowman Draft"]||{}), ...Object.values(CARD_NAMES["Heritage"]||{}), ...Object.values(CARD_NAMES["Allen & Ginter"]||{}), ...Object.values(CARD_NAMES["Gypsy Queen"]||{}), ...Object.values(CARD_NAMES["Opening Day"]||{}), ...Object.values(CARD_NAMES["Stadium Club"]||{}), ...Object.values(CARD_NAMES["Big League"]||{}), ...Object.values(CARD_NAMES["Archives"]||{})].map(e=>e.team)))],[]);
  const checklistNotes = ["All","Rookie","RC","RC Debut","AS","Active Leaders","HR Derby","Combo","Future Stars","Team Card","League Leaders","Leaders","Award","World Series Highlights","Rookie Cup","Prospect","SP","SP Extended","LL","Highlight","World Series Highlight","Non-Baseball","1955 Design","1974 Design","2002 Design","Rookie 1955 Design","Rookie 1974 Design","Rookie 2002 Design"];
  const filteredChecklist = useMemo(()=>{ const q=checkSearch.trim().toLowerCase(); return checklistRows.filter(r=>{ const okQ=!q || r.entry.player.toLowerCase().includes(q) || String(r.num).includes(q) || r.entry.team.toLowerCase().includes(q); const okTeam=checkTeam==="All" || r.entry.team===checkTeam; const okNote=checkNote==="All" || r.entry.note===checkNote; const okOwned=checkOwned==="All" || (checkOwned==="Owned" && r.owned) || (checkOwned==="Not Owned" && !r.owned); return okQ&&okTeam&&okNote&&okOwned; }); },[checklistRows,checkSearch,checkTeam,checkNote,checkOwned]);
  const checklistRows2 = useMemo(()=> Object.entries(CARD_NAMES["Series 2"]).map(([num, e])=>{ const found = cards.find(c=>c.value.setId==="s2" && c.value.cardNumber===num && isBaseCard(c.value)); const qty = cards.filter(c=>c.value.setId==="s2" && c.value.cardNumber===num).reduce((a,c)=>a+qtyOwnedOf(c.value),0); return {num:Number(num), entry:e, qty, owned: qty>0 || (found ? effectiveOwned(found.value) : false), found}; }).sort((a,b)=>a.num-b.num),[cards]);
  const filteredChecklist2 = useMemo(()=>{ const q=checkSearch.trim().toLowerCase(); return checklistRows2.filter(r=>{ const okQ=!q || r.entry.player.toLowerCase().includes(q) || String(r.num).includes(q) || r.entry.team.toLowerCase().includes(q); const okTeam=checkTeam==="All" || r.entry.team===checkTeam; const okNote=checkNote==="All" || r.entry.note===checkNote; const okOwned=checkOwned==="All" || (checkOwned==="Owned" && r.owned) || (checkOwned==="Not Owned" && !r.owned); return okQ&&okTeam&&okNote&&okOwned; }); },[checklistRows2,checkSearch,checkTeam,checkNote,checkOwned]);
  const checklistRowsUpdate = useMemo(()=> Object.entries(CARD_NAMES["Update"]).map(([num, e])=>{ const n = parseInt(num.replace(/^U-/i,""),10); const found = cards.find(c=>c.value.setId==="update" && normalizeCardNumber("update", c.value.cardNumber)===num && isBaseCard(c.value)); const qty = cards.filter(c=>c.value.setId==="update" && normalizeCardNumber("update", c.value.cardNumber)===num).reduce((a,c)=>a+qtyOwnedOf(c.value),0); return {num:n, numLabel:num, entry:e, qty, owned: qty>0 || (found ? effectiveOwned(found.value) : false), found}; }).sort((a,b)=>a.num-b.num),[cards]);
  const filteredChecklistUpdate = useMemo(()=>{ const q=checkSearch.trim().toLowerCase(); return checklistRowsUpdate.filter(r=>{ const okQ=!q || r.entry.player.toLowerCase().includes(q) || r.numLabel.toLowerCase().includes(q) || String(r.num).includes(q) || r.entry.team.toLowerCase().includes(q); const okTeam=checkTeam==="All" || r.entry.team===checkTeam; const okNote=checkNote==="All" || r.entry.note===checkNote; const okOwned=checkOwned==="All" || (checkOwned==="Owned" && r.owned) || (checkOwned==="Not Owned" && !r.owned); return okQ&&okTeam&&okNote&&okOwned; }); },[checklistRowsUpdate,checkSearch,checkTeam,checkNote,checkOwned]);
  const checklistRowsChrome = useMemo(()=> Object.entries(CARD_NAMES["Chrome"]).map(([num, e])=>{ const found = cards.find(c=>c.value.setId==="chrome" && c.value.cardNumber===num && isBaseCard(c.value)); const qty = cards.filter(c=>c.value.setId==="chrome" && c.value.cardNumber===num).reduce((a,c)=>a+qtyOwnedOf(c.value),0); return {num:Number(num), entry:e, qty, owned: qty>0 || (found ? effectiveOwned(found.value) : false), found}; }).sort((a,b)=>a.num-b.num),[cards]);
  const filteredChecklistChrome = useMemo(()=>{ const q=checkSearch.trim().toLowerCase(); return checklistRowsChrome.filter(r=>{ const okQ=!q || r.entry.player.toLowerCase().includes(q) || String(r.num).includes(q) || r.entry.team.toLowerCase().includes(q); const okTeam=checkTeam==="All" || r.entry.team===checkTeam; const okNote=checkNote==="All" || r.entry.note===checkNote; const okOwned=checkOwned==="All" || (checkOwned==="Owned" && r.owned) || (checkOwned==="Not Owned" && !r.owned); return okQ&&okTeam&&okNote&&okOwned; }); },[checklistRowsChrome,checkSearch,checkTeam,checkNote,checkOwned]);
  const checklistRowsBowman = useMemo(()=> Object.entries(CARD_NAMES["Bowman"]||{}).map(([num, e])=>{ const found = cards.find(c=>c.value.setId==="bowman" && normalizeCardNumber("bowman", c.value.cardNumber)===num && isBaseCard(c.value)); const qty = cards.filter(c=>c.value.setId==="bowman" && normalizeCardNumber("bowman", c.value.cardNumber)===num).reduce((a,c)=>a+qtyOwnedOf(c.value),0); return {num:Number(num), numLabel:num, entry:e, qty, owned: qty>0 || (found ? effectiveOwned(found.value) : false), found}; }).sort((a,b)=>a.num-b.num),[cards]);
  const filteredChecklistBowman = useMemo(()=>{ const q=checkSearch.trim().toLowerCase(); return checklistRowsBowman.filter(r=>{ const okQ=!q || r.entry.player.toLowerCase().includes(q) || String(r.num).includes(q) || r.entry.team.toLowerCase().includes(q); const okTeam=checkTeam==="All" || r.entry.team===checkTeam; const okNote=checkNote==="All" || r.entry.note===checkNote; const okOwned=checkOwned==="All" || (checkOwned==="Owned" && r.owned) || (checkOwned==="Not Owned" && !r.owned); return okQ&&okTeam&&okNote&&okOwned; }); },[checklistRowsBowman,checkSearch,checkTeam,checkNote,checkOwned]);
  const checklistRowsBowmanProspects = useMemo(()=> Object.entries(CARD_NAMES["Bowman Prospects"]||{}).map(([num, e])=>{ const n = parseInt(num.replace(/^BP-/i,""),10); const matches = (c:Rec)=> ((c.value.setId==="bowman-prospects" && normalizeCardNumber("bowman-prospects", c.value.cardNumber)===num) || (c.value.setId==="bowman" && normalizeCardNumber("bowman", c.value.cardNumber)===num)) && isBaseCard(c.value); const found = cards.find(matches); const qty = cards.filter(matches).reduce((a,c)=>a+qtyOwnedOf(c.value),0); return {num:n, numLabel:num, entry:e, qty, owned: qty>0 || (found ? effectiveOwned(found.value) : false), found}; }).sort((a,b)=>a.num-b.num),[cards]);
  const filteredChecklistBowmanProspects = useMemo(()=>{ const q=checkSearch.trim().toLowerCase(); return checklistRowsBowmanProspects.filter(r=>{ const okQ=!q || r.entry.player.toLowerCase().includes(q) || r.numLabel.toLowerCase().includes(q) || String(r.num).includes(q) || r.entry.team.toLowerCase().includes(q); const okTeam=checkTeam==="All" || r.entry.team===checkTeam; const okNote=checkNote==="All" || r.entry.note===checkNote; const okOwned=checkOwned==="All" || (checkOwned==="Owned" && r.owned) || (checkOwned==="Not Owned" && !r.owned); return okQ&&okTeam&&okNote&&okOwned; }); },[checklistRowsBowmanProspects,checkSearch,checkTeam,checkNote,checkOwned]);
  const checklistRowsBowmanDraft = useMemo(()=> Object.entries(CARD_NAMES["Bowman Draft"]||{}).map(([num, e])=>{ const n = parseInt(num.replace(/^BD-/i,""),10); const matches = (c:Rec)=> c.value.setId==="bowman-draft" && normalizeCardNumber("bowman-draft", c.value.cardNumber)===num && isBaseCard(c.value); const found = cards.find(matches); const qty = cards.filter(matches).reduce((a,c)=>a+qtyOwnedOf(c.value),0); return {num:n, numLabel:num, entry:e, qty, owned: qty>0 || (found ? effectiveOwned(found.value) : false), found}; }).sort((a,b)=>a.num-b.num),[cards]);
  const filteredChecklistBowmanDraft = useMemo(()=>{ const q=checkSearch.trim().toLowerCase(); return checklistRowsBowmanDraft.filter(r=>{ const okQ=!q || r.entry.player.toLowerCase().includes(q) || r.numLabel.toLowerCase().includes(q) || String(r.num).includes(q) || r.entry.team.toLowerCase().includes(q); const okTeam=checkTeam==="All" || r.entry.team===checkTeam; const okNote=checkNote==="All" || r.entry.note===checkNote; const okOwned=checkOwned==="All" || (checkOwned==="Owned" && r.owned) || (checkOwned==="Not Owned" && !r.owned); return okQ&&okTeam&&okNote&&okOwned; }); },[checklistRowsBowmanDraft,checkSearch,checkTeam,checkNote,checkOwned]);
  const checklistRowsHeritage = useMemo(()=> Object.entries(CARD_NAMES["Heritage"]||{}).map(([num, e])=>{ const found = cards.find(c=>c.value.setId==="heritage" && c.value.cardNumber===num && isBaseCard(c.value)); const qty = cards.filter(c=>c.value.setId==="heritage" && c.value.cardNumber===num).reduce((a,c)=>a+qtyOwnedOf(c.value),0); return {num:Number(num), entry:e, qty, owned: qty>0 || (found ? effectiveOwned(found.value) : false), found}; }).sort((a,b)=>a.num-b.num),[cards]);
  const filteredChecklistHeritage = useMemo(()=>{ const q=checkSearch.trim().toLowerCase(); return checklistRowsHeritage.filter(r=>{ const okQ=!q || r.entry.player.toLowerCase().includes(q) || String(r.num).includes(q) || r.entry.team.toLowerCase().includes(q); const okTeam=checkTeam==="All" || r.entry.team===checkTeam; const okNote=checkNote==="All" || r.entry.note===checkNote; const okOwned=checkOwned==="All" || (checkOwned==="Owned" && r.owned) || (checkOwned==="Not Owned" && !r.owned); return okQ&&okTeam&&okNote&&okOwned; }); },[checklistRowsHeritage,checkSearch,checkTeam,checkNote,checkOwned]);
  const checklistRowsAG = useMemo(()=> Object.entries(CARD_NAMES["Allen & Ginter"]||{}).map(([num, e])=>{ const found = cards.find(c=>c.value.setId==="ag" && c.value.cardNumber===num && isBaseCard(c.value)); const qty = cards.filter(c=>c.value.setId==="ag" && c.value.cardNumber===num).reduce((a,c)=>a+qtyOwnedOf(c.value),0); return {num:Number(num), entry:e, qty, owned: qty>0 || (found ? effectiveOwned(found.value) : false), found}; }).sort((a,b)=>a.num-b.num),[cards]);
  const filteredChecklistAG = useMemo(()=>{ const q=checkSearch.trim().toLowerCase(); return checklistRowsAG.filter(r=>{ const okQ=!q || r.entry.player.toLowerCase().includes(q) || String(r.num).includes(q) || r.entry.team.toLowerCase().includes(q); const okTeam=checkTeam==="All" || r.entry.team===checkTeam; const okNote=checkNote==="All" || r.entry.note===checkNote; const okOwned=checkOwned==="All" || (checkOwned==="Owned" && r.owned) || (checkOwned==="Not Owned" && !r.owned); return okQ&&okTeam&&okNote&&okOwned; }); },[checklistRowsAG,checkSearch,checkTeam,checkNote,checkOwned]);
  const checklistRowsGypsy = useMemo(()=> Object.entries(CARD_NAMES["Gypsy Queen"]||{}).map(([num, e])=>{ const found = cards.find(c=>c.value.setId==="gypsy" && c.value.cardNumber===num && isBaseCard(c.value)); const qty = cards.filter(c=>c.value.setId==="gypsy" && c.value.cardNumber===num).reduce((a,c)=>a+qtyOwnedOf(c.value),0); return {num:Number(num), entry:e, qty, owned: qty>0 || (found ? effectiveOwned(found.value) : false), found}; }).sort((a,b)=>a.num-b.num),[cards]);
  const filteredChecklistGypsy = useMemo(()=>{ const q=checkSearch.trim().toLowerCase(); return checklistRowsGypsy.filter(r=>{ const okQ=!q || r.entry.player.toLowerCase().includes(q) || String(r.num).includes(q) || r.entry.team.toLowerCase().includes(q); const okTeam=checkTeam==="All" || r.entry.team===checkTeam; const okNote=checkNote==="All" || r.entry.note===checkNote || (checkNote==="SP" && r.entry.note==="SP Extended"); const okOwned=checkOwned==="All" || (checkOwned==="Owned" && r.owned) || (checkOwned==="Not Owned" && !r.owned); return okQ&&okTeam&&okNote&&okOwned; }); },[checklistRowsGypsy,checkSearch,checkTeam,checkNote,checkOwned]);
  const checklistRowsOpeningDay = useMemo(()=> Object.entries(CARD_NAMES["Opening Day"]||{}).map(([num, e])=>{ const found = cards.find(c=>c.value.setId==="opening-day" && c.value.cardNumber===num && isBaseCard(c.value)); const qty = cards.filter(c=>c.value.setId==="opening-day" && c.value.cardNumber===num).reduce((a,c)=>a+qtyOwnedOf(c.value),0); return {num:Number(num), entry:e, qty, owned: qty>0 || (found ? effectiveOwned(found.value) : false), found}; }).sort((a,b)=>a.num-b.num),[cards]);
  const filteredChecklistOpeningDay = useMemo(()=>{ const q=checkSearch.trim().toLowerCase(); return checklistRowsOpeningDay.filter(r=>{ const okQ=!q || r.entry.player.toLowerCase().includes(q) || String(r.num).includes(q) || r.entry.team.toLowerCase().includes(q); const okTeam=checkTeam==="All" || r.entry.team===checkTeam; const okNote=checkNote==="All" || r.entry.note===checkNote || (checkNote==="SP" && r.entry.note.includes("SP")) || (checkNote==="Rookie" && r.entry.note.includes("Rookie")); const okOwned=checkOwned==="All" || (checkOwned==="Owned" && r.owned) || (checkOwned==="Not Owned" && !r.owned); return okQ&&okTeam&&okNote&&okOwned; }); },[checklistRowsOpeningDay,checkSearch,checkTeam,checkNote,checkOwned]);
  const checklistRowsStadium = useMemo(()=> Object.entries(CARD_NAMES["Stadium Club"]||{}).map(([num, e])=>{ const found = cards.find(c=>c.value.setId==="stadium" && c.value.cardNumber===num && isBaseCard(c.value)); const qty = cards.filter(c=>c.value.setId==="stadium" && c.value.cardNumber===num).reduce((a,c)=>a+qtyOwnedOf(c.value),0); return {num:Number(num), entry:e, qty, owned: qty>0 || (found ? effectiveOwned(found.value) : false), found}; }).sort((a,b)=>a.num-b.num),[cards]);
  const filteredChecklistStadium = useMemo(()=>{ const q=checkSearch.trim().toLowerCase(); return checklistRowsStadium.filter(r=>{ const okQ=!q || r.entry.player.toLowerCase().includes(q) || String(r.num).includes(q) || r.entry.team.toLowerCase().includes(q); const okTeam=checkTeam==="All" || r.entry.team===checkTeam; const okNote=checkNote==="All" || r.entry.note===checkNote || (checkNote==="Rookie" && r.entry.note.includes("Rookie")); const okOwned=checkOwned==="All" || (checkOwned==="Owned" && r.owned) || (checkOwned==="Not Owned" && !r.owned); return okQ&&okTeam&&okNote&&okOwned; }); },[checklistRowsStadium,checkSearch,checkTeam,checkNote,checkOwned]);
  const checklistRowsBigLeague = useMemo(()=> Object.entries(CARD_NAMES["Big League"]||{}).map(([num, e])=>{ const found = cards.find(c=>c.value.setId==="big-league" && c.value.cardNumber===num && isBaseCard(c.value)); const qty = cards.filter(c=>c.value.setId==="big-league" && c.value.cardNumber===num).reduce((a,c)=>a+qtyOwnedOf(c.value),0); return {num:Number(num), entry:e, qty, owned: qty>0 || (found ? effectiveOwned(found.value) : false), found}; }).sort((a,b)=>a.num-b.num),[cards]);
  const filteredChecklistBigLeague = useMemo(()=>{ const q=checkSearch.trim().toLowerCase(); return checklistRowsBigLeague.filter(r=>{ const okQ=!q || r.entry.player.toLowerCase().includes(q) || String(r.num).includes(q) || r.entry.team.toLowerCase().includes(q); const okTeam=checkTeam==="All" || r.entry.team===checkTeam; const okNote=checkNote==="All" || r.entry.note===checkNote || (checkNote==="Rookie" && r.entry.note.includes("Rookie")) || (checkNote==="Leaders" && r.entry.note.includes("Leaders")) || (checkNote==="Award" && r.entry.note.includes("Award")) || (checkNote==="Highlight" && r.entry.note.includes("Highlight")) || (checkNote==="Highlights" && r.entry.note.includes("Highlights")); const okOwned=checkOwned==="All" || (checkOwned==="Owned" && r.owned) || (checkOwned==="Not Owned" && !r.owned); return okQ&&okTeam&&okNote&&okOwned; }); },[checklistRowsBigLeague,checkSearch,checkTeam,checkNote,checkOwned]);
  async function toggleChecklist(r:{num:number; entry:CardNameEntry; found?:Rec; numLabel?:string}, setId:string="s1"){ try{ if(r.found){ await toggleOwned(r.found, !effectiveOwned(r.found.value) || qtyOwnedOf(r.found.value)===0); } else { const cardNumber = (setId==="update" || setId==="bowman-prospects" || setId==="bowman" || setId==="bowman-draft") && r.numLabel ? r.numLabel : setId==="update" ? `U-${r.num}` : String(r.num); const meta = slotMetaForNumber(cardNumber); await createRow({...emptyForm,setId,cardNumber,player:r.entry.player,team:fullTeamName(r.entry.team),parallel:"Base",owned:true,wantlist:false,forTrade:false,notes:r.entry.note,subsetName:meta.subsetName,subsetType:meta.subsetType,qtyOwned:1,qtyForTrade:0,qtyGraded:0,location:""}); await reloadRecords(); setMessage(`${r.entry.player} (#${cardNumber}) marked owned.`); } }catch(e:any){ setMessage(e.message); } }
  const activeS1InsertDef = S1_INSERT_DEFS.find(d=>d.id===s1InsertId) || S1_INSERT_DEFS[0];
  const s1InsertRows = useMemo(()=> s1InsertRowsFor(activeS1InsertDef).map(row=>{ const found = cards.find(c=>c.value.setId==="s1" && c.value.cardNumber.toUpperCase()===row.code && (c.value.subsetName||"")===activeS1InsertDef.name); const qty = cards.filter(c=>c.value.setId==="s1" && c.value.cardNumber.toUpperCase()===row.code && (c.value.subsetName||"")===activeS1InsertDef.name).reduce((a,c)=>a+qtyOwnedOf(c.value),0); return {...row, qty, owned: qty>0 || (found ? effectiveOwned(found.value) : false), found}; }),[cards,activeS1InsertDef]);
  const filteredS1InsertRows = useMemo(()=>{ const q=s1InsertSearch.trim().toLowerCase(); return s1InsertRows.filter(r=>!q || r.player.toLowerCase().includes(q) || r.code.toLowerCase().includes(q) || r.team.toLowerCase().includes(q)); },[s1InsertRows,s1InsertSearch]);
  const clearVariationRows = useMemo(()=> CLEAR_VARIATION_NUMBERS.map(n=>{ const entry = CARD_NAMES["Series 1"][String(n)]; const found = cards.find(c=>c.value.setId==="s1" && c.value.cardNumber===String(n) && c.value.parallel==="Clear Variation"); const qty = cards.filter(c=>c.value.setId==="s1" && c.value.cardNumber===String(n) && c.value.parallel==="Clear Variation").reduce((a,c)=>a+qtyOwnedOf(c.value),0); return {num:n, entry, qty, owned: qty>0 || (found ? effectiveOwned(found.value) : false), found}; }),[cards]);
  const filteredClearRows = useMemo(()=>{ const q=checkSearch.trim().toLowerCase(); return clearVariationRows.filter(r=>!q || r.entry.player.toLowerCase().includes(q) || String(r.num).includes(q) || r.entry.team.toLowerCase().includes(q)); },[clearVariationRows,checkSearch]);
  async function toggleClearVariation(r:{num:number; entry:CardNameEntry; found?:Rec}){ try{ if(r.found){ await toggleOwned(r.found, !effectiveOwned(r.found.value) || qtyOwnedOf(r.found.value)===0); } else { await createRow({...emptyForm,setId:"s1",cardNumber:String(r.num),player:r.entry.player,team:fullTeamName(r.entry.team),parallel:"Clear Variation",owned:true,wantlist:false,forTrade:false,notes:"Clear Variation",subsetName:"Clear Variation",subsetType:"Parallel",qtyOwned:1,qtyForTrade:0,qtyGraded:0,location:""}); await reloadRecords(); setMessage(`${r.entry.player} (#${r.num} Clear Variation) marked owned.`); } }catch(e:any){ setMessage(e.message); } }
  async function toggleS1Insert(r:{code:string; player:string; team:string; found?:Rec}){ try{ if(r.found){ await toggleOwned(r.found, !effectiveOwned(r.found.value) || qtyOwnedOf(r.found.value)===0); } else { await createRow({...emptyForm,setId:"s1",cardNumber:r.code,player:r.player,team:fullTeamName(r.team)==="—" ? "Other" : fullTeamName(r.team),parallel:"Base",owned:true,wantlist:false,forTrade:false,notes:activeS1InsertDef.notes,subsetName:activeS1InsertDef.name,subsetType:activeS1InsertDef.type,qtyOwned:1,qtyForTrade:0,qtyGraded:0,location:""}); await reloadRecords(); setMessage(`${r.player} (${r.code}) marked owned.`); } }catch(e:any){ setMessage(e.message); } }
  const s1ParallelsFiltered = useMemo(()=>{ const q=parSearch.trim().toLowerCase(); const defs = parSet==="All" ? (["s1","s2","update","chrome","archives"] as const).flatMap(k=>parallelDefsForSet(k).map(d=>({...d,setName: k==="s1"?"Series 1":k==="s2"?"Series 2":k==="update"?"Update Series":k==="chrome"?"Chrome":"Archives"}))) : parallelDefsForSet(parSet).map(d=>({...d,setName: setById.get(parSet)?.name||parSet})); return defs.filter(d=>!q || d.name.toLowerCase().includes(q) || d.notes.toLowerCase().includes(q) || d.setName.toLowerCase().includes(q)); },[parSearch,parSet,setById]);
  const activeS2InsertDef = S2_HUB_DEFS.find(d=>d.id===s2InsertId) || S2_HUB_DEFS[0];
  const s2InsertRows = useMemo(()=> s2InsertRowsFor(activeS2InsertDef).map(row=>{ const found = cards.find(c=>c.value.setId==="s2" && c.value.cardNumber.toUpperCase()===row.code && (c.value.subsetName||"")===activeS2InsertDef.name); const qty = cards.filter(c=>c.value.setId==="s2" && c.value.cardNumber.toUpperCase()===row.code && (c.value.subsetName||"")===activeS2InsertDef.name).reduce((a,c)=>a+qtyOwnedOf(c.value),0); return {...row, qty, owned: qty>0 || (found ? effectiveOwned(found.value) : false), found}; }),[cards,activeS2InsertDef]);
  const filteredS2InsertRows = useMemo(()=>{ const q=s2InsertSearch.trim().toLowerCase(); return s2InsertRows.filter(r=>!q || r.player.toLowerCase().includes(q) || r.code.toLowerCase().includes(q) || r.team.toLowerCase().includes(q)); },[s2InsertRows,s2InsertSearch]);
  const clearVariationRowsS2 = useMemo(()=> CLEAR_VARIATION_NUMBERS_S2.map(n=>{ const entry = CARD_NAMES["Series 2"][String(n)]; const found = cards.find(c=>c.value.setId==="s2" && c.value.cardNumber===String(n) && c.value.parallel==="Clear Variation"); const qty = cards.filter(c=>c.value.setId==="s2" && c.value.cardNumber===String(n) && c.value.parallel==="Clear Variation").reduce((a,c)=>a+qtyOwnedOf(c.value),0); return {num:n, entry, qty, owned: qty>0 || (found ? effectiveOwned(found.value) : false), found}; }),[cards]);
  const filteredClearRowsS2 = useMemo(()=>{ const q=checkSearch.trim().toLowerCase(); return clearVariationRowsS2.filter(r=>r.entry && (!q || r.entry.player.toLowerCase().includes(q) || String(r.num).includes(q) || r.entry.team.toLowerCase().includes(q))); },[clearVariationRowsS2,checkSearch]);
  async function toggleClearVariationS2(r:{num:number; entry:CardNameEntry; found?:Rec}){ try{ if(r.found){ await toggleOwned(r.found, !effectiveOwned(r.found.value) || qtyOwnedOf(r.found.value)===0); } else { await createRow({...emptyForm,setId:"s2",cardNumber:String(r.num),player:r.entry.player,team:fullTeamName(r.entry.team),parallel:"Clear Variation",owned:true,wantlist:false,forTrade:false,notes:"Clear Variation",subsetName:"Clear Variation",subsetType:"Parallel",qtyOwned:1,qtyForTrade:0,qtyGraded:0,location:""}); await reloadRecords(); setMessage(`${r.entry.player} (#${r.num} Clear Variation) marked owned.`); } }catch(e:any){ setMessage(e.message); } }
  async function toggleS2Insert(r:{code:string; player:string; team:string; found?:Rec}){ try{ if(r.found){ await toggleOwned(r.found, !effectiveOwned(r.found.value) || qtyOwnedOf(r.found.value)===0); } else { await createRow({...emptyForm,setId:"s2",cardNumber:r.code,player:r.player,team:fullTeamName(r.team)==="—" ? "Other" : fullTeamName(r.team),parallel:"Base",owned:true,wantlist:false,forTrade:false,notes:activeS2InsertDef.notes,subsetName:activeS2InsertDef.name,subsetType:activeS2InsertDef.type,qtyOwned:1,qtyForTrade:0,qtyGraded:0,location:""}); await reloadRecords(); setMessage(`${r.player} (${r.code}) marked owned.`); } }catch(e:any){ setMessage(e.message); } }
  const activeUpdInsertDef = UPD_HUB_DEFS.find(d=>d.id===updInsertId) || UPD_HUB_DEFS[0];
  const updInsertRows = useMemo(()=> updInsertRowsFor(activeUpdInsertDef).map(row=>{ const found = cards.find(c=>c.value.setId==="update" && c.value.cardNumber.toUpperCase()===row.code && (c.value.subsetName||"")===activeUpdInsertDef.name); const qty = cards.filter(c=>c.value.setId==="update" && c.value.cardNumber.toUpperCase()===row.code && (c.value.subsetName||"")===activeUpdInsertDef.name).reduce((a,c)=>a+qtyOwnedOf(c.value),0); return {...row, qty, owned: qty>0 || (found ? effectiveOwned(found.value) : false), found}; }),[cards,activeUpdInsertDef]);
  const filteredUpdInsertRows = useMemo(()=>{ const q=updInsertSearch.trim().toLowerCase(); return updInsertRows.filter(r=>!q || r.player.toLowerCase().includes(q) || r.code.toLowerCase().includes(q) || r.team.toLowerCase().includes(q)); },[updInsertRows,updInsertSearch]);
  async function toggleUpdInsert(r:{code:string; player:string; team:string; found?:Rec}){ try{ if(r.found){ await toggleOwned(r.found, !effectiveOwned(r.found.value) || qtyOwnedOf(r.found.value)===0); } else { await createRow({...emptyForm,setId:"update",cardNumber:r.code,player:r.player,team:fullTeamName(r.team)==="—" ? "Other" : fullTeamName(r.team),parallel:"Base",owned:true,wantlist:false,forTrade:false,notes:activeUpdInsertDef.notes,subsetName:activeUpdInsertDef.name,subsetType:activeUpdInsertDef.type,qtyOwned:1,qtyForTrade:0,qtyGraded:0,location:""}); await reloadRecords(); setMessage(`${r.player} (${r.code}) marked owned.`); } }catch(e:any){ setMessage(e.message); } }
  const updVarRows = useMemo(()=> updVariationRowsFor(updVarId).map(row=>{ const found = cards.find(c=>c.value.setId==="update" && c.value.cardNumber.toUpperCase()===row.code && c.value.parallel===updVarId); const qty = cards.filter(c=>c.value.setId==="update" && c.value.cardNumber.toUpperCase()===row.code && c.value.parallel===updVarId).reduce((a,c)=>a+qtyOwnedOf(c.value),0); return {...row, qty, owned: qty>0 || (found ? effectiveOwned(found.value) : false), found}; }),[cards,updVarId]);
  const filteredUpdVarRows = useMemo(()=>{ const q=updVarSearch.trim().toLowerCase(); return updVarRows.filter(r=>!q || r.player.toLowerCase().includes(q) || r.code.toLowerCase().includes(q) || r.team.toLowerCase().includes(q)); },[updVarRows,updVarSearch]);
  async function toggleUpdVariation(r:{code:string; player:string; team:string; note:string; found?:Rec}){ try{ if(r.found){ await toggleOwned(r.found, !effectiveOwned(r.found.value) || qtyOwnedOf(r.found.value)===0); } else { await createRow({...emptyForm,setId:"update",cardNumber:r.code,player:r.player,team:fullTeamName(r.team)==="—" ? "Other" : fullTeamName(r.team),parallel:updVarId,owned:true,wantlist:false,forTrade:false,notes:r.note||updVarId,subsetName:updVarId,subsetType:"Parallel",qtyOwned:1,qtyForTrade:0,qtyGraded:0,location:""}); await reloadRecords(); setMessage(`${r.player} (${r.code} ${updVarId}) marked owned.`); } }catch(e:any){ setMessage(e.message); } }

  const activeBowInsertDef = BOWMAN_INSERT_DEFS[0];
  const bowInsertRows = useMemo(()=> bowmanInsertRowsFor(activeBowInsertDef).map(row=>{ const found = cards.find(c=>c.value.setId==="bowman" && c.value.cardNumber.toUpperCase()===row.code && (c.value.subsetName||"")===activeBowInsertDef.name); const qty = cards.filter(c=>c.value.setId==="bowman" && c.value.cardNumber.toUpperCase()===row.code && (c.value.subsetName||"")===activeBowInsertDef.name).reduce((a,c)=>a+qtyOwnedOf(c.value),0); return {...row, qty, owned: qty>0 || (found ? effectiveOwned(found.value) : false), found}; }),[cards,activeBowInsertDef]);
  const filteredBowInsertRows = useMemo(()=>{ const q=bowInsertSearch.trim().toLowerCase(); return bowInsertRows.filter(r=>!q || r.player.toLowerCase().includes(q) || r.code.toLowerCase().includes(q) || r.team.toLowerCase().includes(q)); },[bowInsertRows,bowInsertSearch]);
  async function toggleBowInsert(r:{code:string; player:string; team:string; found?:Rec}){ try{ if(r.found){ await toggleOwned(r.found, !effectiveOwned(r.found.value) || qtyOwnedOf(r.found.value)===0); } else { await createRow({...emptyForm,setId:"bowman",cardNumber:r.code,player:r.player,team:fullTeamName(r.team)==="—" ? "Other" : fullTeamName(r.team),parallel:"Base",owned:true,wantlist:false,forTrade:false,notes:activeBowInsertDef.notes,subsetName:activeBowInsertDef.name,subsetType:activeBowInsertDef.type,qtyOwned:1,qtyForTrade:0,qtyGraded:0,location:""}); await reloadRecords(); setMessage(`${r.player} (${r.code}) marked owned.`); } }catch(e:any){ setMessage(e.message); } }
  const bowHfDef = BOWMAN_INSERT_DEFS.find(d=>d.id==="bow-hf") || BOWMAN_INSERT_DEFS[0];
  const bowHfAutoDef = BOWMAN_INSERT_DEFS.find(d=>d.id==="bow-hf-auto") || BOWMAN_INSERT_DEFS[0];
  const bowHfRows = useMemo(()=> bowmanInsertRowsFor(bowHfDef).map(row=>{ const found = cards.find(c=>c.value.setId==="bowman" && c.value.cardNumber.toUpperCase()===row.code && (c.value.subsetName||"")===bowHfDef.name); const qty = cards.filter(c=>c.value.setId==="bowman" && c.value.cardNumber.toUpperCase()===row.code && (c.value.subsetName||"")===bowHfDef.name).reduce((a,c)=>a+qtyOwnedOf(c.value),0); return {...row, qty, owned: qty>0 || (found ? effectiveOwned(found.value) : false), found}; }),[cards,bowHfDef]);
  const filteredBowHfRows = useMemo(()=>{ const q=bowHfSearch.trim().toLowerCase(); return bowHfRows.filter(r=>!q || r.player.toLowerCase().includes(q) || r.code.toLowerCase().includes(q) || r.team.toLowerCase().includes(q)); },[bowHfRows,bowHfSearch]);
  const bowHfAutoRows = useMemo(()=> bowmanInsertRowsFor(bowHfAutoDef).map(row=>{ const found = cards.find(c=>c.value.setId==="bowman" && c.value.cardNumber.toUpperCase()===row.code && (c.value.subsetName||"")===bowHfAutoDef.name); const qty = cards.filter(c=>c.value.setId==="bowman" && c.value.cardNumber.toUpperCase()===row.code && (c.value.subsetName||"")===bowHfAutoDef.name).reduce((a,c)=>a+qtyOwnedOf(c.value),0); return {...row, qty, owned: qty>0 || (found ? effectiveOwned(found.value) : false), found}; }),[cards,bowHfAutoDef]);
  const filteredBowHfAutoRows = useMemo(()=>{ const q=bowHfAutoSearch.trim().toLowerCase(); return bowHfAutoRows.filter(r=>!q || r.player.toLowerCase().includes(q) || r.code.toLowerCase().includes(q) || r.team.toLowerCase().includes(q)); },[bowHfAutoRows,bowHfAutoSearch]);
  async function toggleBowHf(r:{code:string; player:string; team:string; found?:Rec}, def:S1InsertDef){ try{ if(r.found){ await toggleOwned(r.found, !effectiveOwned(r.found.value) || qtyOwnedOf(r.found.value)===0); } else { await createRow({...emptyForm,setId:"bowman",cardNumber:r.code,player:r.player,team:fullTeamName(r.team)==="—" ? "Other" : fullTeamName(r.team),parallel:"Base",owned:true,wantlist:false,forTrade:false,notes:def.notes,subsetName:def.name,subsetType:def.type,qtyOwned:1,qtyForTrade:0,qtyGraded:0,location:""}); await reloadRecords(); setMessage(`${r.player} (${r.code}) marked owned.`); } }catch(e:any){ setMessage(e.message); } }

  const detail = detailId? setById.get(detailId):undefined;
  const detailSubsets = detail ? SUBSETS.filter(s=>s.setId===detail.id) : [];
  const detailBaseOwned = detail ? (ownedBySet.get(detail.id)||0) : 0;
  const detailInserts = detail ? (insertsBySet.get(detail.id)||0) : 0;
  const categories = ["All",...Array.from(new Set(SETS.map(s=>s.category)))];
  const formSubsets = SUBSETS.filter(s=>s.setId===form.setId);
  const subsetNameOptions = useMemo(()=>{
    const names = new Set<string>();
    SUBSETS.forEach(s=>names.add(s.name));
    return Array.from(names).sort();
  },[]);

  return (
    <div data-safe-area-inset-root style={{boxSizing:"border-box",paddingTop:"var(--safe-area-inset-top)",minHeight:"100vh",background:"var(--surface)"}}>
      <header style={{background:"var(--navy)",color:"white",position:"sticky",top:"var(--safe-area-inset-top)",zIndex:20}} data-safe-area-sticky-top>
        <div style={{maxWidth:1240,margin:"0 auto",padding:"14px 16px 12px"}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:12,flexWrap:"wrap"}}>
            <div>
              <div style={{fontSize:11,fontWeight:800,letterSpacing:".18em",color:"#ff5c66"}}>TOPPS • BOWMAN • 2020 SEASON</div>
              <h1 style={{margin:"3px 0 0",fontSize:"clamp(30px,5vw,48px)",lineHeight:.9}}>2020 TOPPS <span style={{color:"#ff3b46"}}>MASTER</span> DATABASE</h1>
              <p style={{margin:"6px 0 0",color:"#c7d2e5",fontSize:14}}>Every 2020 Topps + Bowman set. Your cards. Your wantlist. One working record.</p>
            </div>
            <button className="btn btn-red" onClick={()=>startAdd()}><Plus size={18}/> Add Card</button>
          </div>
          <nav style={{display:"flex",gap:6,marginTop:14,flexWrap:"wrap"}} aria-label="Main">
            {([["dashboard","Dashboard"],["sets","Sets Library"],["subsets","Subsets & Inserts"],["collection","My Collection"],["inventory","Inventory"],["wantlist","Wantlist"],["checklists","Checklists"],["parallels","Parallels"],["add","Add Card"]] as const).map(([k,label])=>(
              <button key={k} onClick={()=>setTab(k)} style={{border:0,borderRadius:999,padding:"9px 15px",fontWeight:700,fontSize:14,background:tab===k?"var(--red)":"rgba(255,255,255,.12)",color:"white"}}>{label}{k==="wantlist" && wantCards.length?` (${wantCards.length})`:""}{k==="inventory" ? ` (${invTotalOwned})` : ""}</button>
            ))}
          </nav>
        </div>
      </header>

      <main style={{maxWidth:1240,margin:"0 auto",padding:"18px 16px 30px"}}>
        {message && <div role="status" style={{background:"#fff4d6",border:"1px solid #e5c24f",borderRadius:8,padding:"11px 13px",display:"flex",justifyContent:"space-between",gap:10,marginBottom:14}}><span>{message}</span><button className="btn btn-light" style={{padding:"5px 9px"}} onClick={()=>setMessage("")}><X size={16}/></button></div>}
        {loading && <p>Loading your saved collection…</p>}

        {tab==="dashboard" && (
          <section>
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(170px,1fr))",gap:12}}>
              {[
                {icon:<Database size={20}/>,label:"Total Sets",val:`${sets.length}`,sub:"All 2020 Topps + Bowman sets"},
                {icon:<Layers size={20}/>,label:"Total Base Cards",val:`${totalBase.toLocaleString()}+`,sub:"Base set only"},
                {icon:<Check size={20}/>,label:"Cards Owned",val:String(invTotalOwned),sub:`Unique Cards: ${invUnique} | Total Cards (with qty): ${invTotalOwned}`},
                {icon:<Trophy size={20}/>,label:"Completion",val:`${completion.toFixed(1)}%`,sub:"Base owned ÷ base cards — Unique only"},
                {icon:<DollarSign size={20}/>,label:"Total Est. Value",val:money(totalValue),sub:"Owned qty × unit value"},
                {icon:<ListChecks size={20}/>,label:"Wantlist Count",val:String(wantCards.length),sub:"Wantlist, not owned"},
              ].map(x=><div key={x.label} style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10,padding:16}}><div style={{color:"var(--red)",display:"flex",alignItems:"center",gap:7,fontSize:12,fontWeight:800,textTransform:"uppercase",letterSpacing:".07em"}}>{x.icon}{x.label}</div><div className="display" style={{fontSize:38,lineHeight:1,marginTop:8}}>{x.val}</div><div style={{color:"var(--muted)",fontSize:13,marginTop:5}}>{x.sub}</div></div>)}
            </div>
            <div style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10,padding:18,marginTop:14}}>
              <div style={{display:"flex",justifyContent:"space-between",flexWrap:"wrap",gap:8}}><h2 style={{margin:0,fontSize:26}}>OVERALL COMPLETION</h2><strong>{ownedCards.length.toLocaleString()} / {totalBase.toLocaleString()} base cards</strong></div>
              <div style={{height:16,background:"var(--surface-2)",borderRadius:999,overflow:"hidden",marginTop:12}}><div style={{height:"100%",width:`${completion}%`,background:"var(--red)",transition:"width .3s"}}/></div>
              <p style={{margin:"12px 0 0",fontSize:16}}><strong>Flagship named: 1000 / 1000 (Series 1 350 + Series 2 350 + Update 300)</strong></p>
              <p style={{margin:"6px 0 0",fontSize:16}}><strong>Chrome named: 200 / 200</strong></p>
              <p style={{margin:"6px 0 0",fontSize:16}}><strong>Bowman named: 250 / 250</strong></p>
              <p style={{margin:"6px 0 0",fontSize:16}}><strong>Bowman Draft named: 200 / 200</strong></p>
              <p style={{margin:"6px 0 0",fontSize:16}}><strong>Heritage named: 500 / 500</strong></p>
              <p style={{margin:"6px 0 0",fontSize:16}}><strong>Allen &amp; Ginter named: 350 / 350</strong></p>
              <p style={{margin:"6px 0 0",fontSize:16}}><strong>Gypsy Queen named: 320 / 320</strong></p>
              <p style={{margin:"6px 0 0",fontSize:16}}><strong>Opening Day named: 201 / 201</strong></p>
              <p style={{margin:"6px 0 0",fontSize:16}}><strong>Stadium Club named: 300 / 300</strong></p>
              <p style={{margin:"6px 0 0",fontSize:16}}><strong>Big League named: 300 / 300</strong></p>
              <p style={{margin:"6px 0 0",fontSize:16}}><strong>Series 1 Inserts tracked: 1985 (100) + Decades Best (100) + Decade's Next (30) + DOD (20) + Topps Choice (25) + Turkey Red (100) + Chrome Turkey Red (100) + Topps Now Review (10) + HR Challenge (30) = 515 insert cards</strong> — plus Decades Best Chrome (100, same order as Decades Best) and the other Series 1 insert hub sets below.</p>
              <p style={{margin:"6px 0 0",fontSize:16}}><strong>Series 1 Parallels: 17 + Clear Variation (100)</strong> — Series 1 Base Parallels: 17 (Base plus the 17 parallels in the Parallels tab).</p>
              <p style={{margin:"6px 0 0",fontSize:16}}><strong>Series 2 Inserts tracked: Decades Best 100 + Decades Best Chrome 100 + Warriors 50 + Player of Decade 25 + Significant Stats 25 + Topps 2030 20 + 1985 TB 50 + 1985 All Stars 50 + Empire State 30 + Tatis Highlights 30 + Turkey Red S2 100 + Chrome Turkey Red S2 100 + HR Challenge 30 + 1985 Chrome Promo 50 + Best of Topps Now 10 = 770 insert cards</strong> — plus Player of the Decade Auto (25), Empire State Auto (30) and Tatis Highlights Auto (30) parallels, and the other Series 2 code-based insert sets below.</p>
              <p style={{margin:"6px 0 0",fontSize:16}}><strong>Series 2 Parallels: 17 + Clear Variation (100)</strong> — Series 2 Base Parallels: 17 (Base plus the 17 parallels in the Parallels tab).</p>
              <p style={{margin:"6px 0 0",fontSize:16}}><strong>Series 2 Total: Base 350 + Clear Variation 100 + Inserts 770 = 1,220 checklist entries</strong></p>
              <p style={{margin:"6px 0 0",fontSize:16}}><strong>Series 1 Total 965 + Series 2 Total 1,220 = 2,185 for Series 1+2 alone.</strong></p>
              <p style={{margin:"6px 0 0",fontSize:16}}><strong>Update Inserts tracked: Decades Best Update 80 + Prospects 30 + A Numbers Game 25 + 1985 TB Update 50 + 20 Years of the Captain 20 + Acuna Highlights 20 + Turkey Red Update 50 + Chrome Turkey Red Update 50 + Chrome Promo Update 50 = 375 insert cards</strong></p>
              <p style={{margin:"6px 0 0",fontSize:16}}><strong>Update Base Parallels: 18</strong> — Purple (Meijer), Royal Blue (Walmart Blaster), Yellow (Walgreens Hanger), Rainbow Foil, Gold Foil (Jumbo), Gold /2020, Advanced Stat /300, Vintage Stock /99, Independence Day /76, Black /69, Mother&apos;s Day Hot Pink /50, Father&apos;s Day Powder Blue /50, Memorial Day Camo /25, Platinum 1/1, Cyan / Magenta / Yellow / Black Printing Plate 1/1 — plus Base, SP Variation (50), SSP Variation (25), SSSP Variation (5) and Clear Variation (Hobby /10). CMP codes: Base ends #588, SP ends #631, SSP ends #632, SSSP ends #633, Advanced Stat ends #634.</p>
              <p style={{margin:"6px 0 0",fontSize:16}}><strong>Update Total: Base 300 + SP 50 + SSP 25 + SSSP 5 + Inserts 375 = 755 checklist entries (plus Clear /10 variant)</strong></p>
              <p style={{margin:"6px 0 0",fontSize:16}}><strong>Flagship Trilogy Totals: Series 1 Total 965 + Series 2 Total 1,220 + Update Total 755 = 2,940 for Series 1 + Series 2 + Update flagship.</strong></p>
              <p style={{margin:"6px 0 0",fontSize:16}}><strong>Total named: 3621 / 3621</strong></p>
              <p style={{color:"var(--muted)",margin:"10px 0 0"}}>Hit-driven sets with no traditional base set are tracked by hits, not base-card completion. Progress bars use <strong>Unique</strong> cards only — 3 copies of #1 Trout still counts as 1 / 350.</p>
              <div style={{display:"flex",gap:14,flexWrap:"wrap",marginTop:12,fontSize:15}}><span><strong>Base:</strong> {ownedCards.length.toLocaleString()} / {totalBase.toLocaleString()} · {completion.toFixed(1)}%</span><span><strong>Unique Cards: {invUnique} | Total Cards (with qty): {invTotalOwned}</strong></span><span><strong>Duplicates:</strong> {invDuplicates}</span><span><strong>Inserts / Parallels:</strong> {insertCards.length} tracked · {insertOwned.length} owned</span><span><strong>Subsets defined:</strong> {SUBSETS.length}</span></div>
              <p style={{color:"var(--muted)",margin:"8px 0 0",fontSize:13}}>Inserts and Parallels do NOT count toward base completion. They are tracked separately in Subsets &amp; Inserts.</p>
              <div style={{display:"flex",gap:8,flexWrap:"wrap",marginTop:16}}>
                <button className="btn btn-navy" onClick={()=>setTab("sets")}>Browse Sets Library</button>
                <button className="btn btn-outline" onClick={()=>setTab("inventory")}><Boxes size={16}/> Open Inventory</button>
                <button className="btn btn-outline" onClick={()=>setTab("subsets")}>Browse Subsets &amp; Inserts</button>
                <button className="btn btn-outline" onClick={()=>setTab("collection")}>Open My Collection</button>
                <button className="btn btn-outline" onClick={loadSample} disabled={busy}>Load 12 Sample Cards</button>
                <button className="btn btn-outline" onClick={exportCSV}><Download size={16}/> Export CSV</button>
                <button className="btn btn-outline" onClick={exportJSON}><Download size={16}/> Export JSON</button>
              </div>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(280px,1fr))",gap:12,marginTop:14}}>
              <div style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10,padding:16}}><h3 style={{margin:"0 0 10px",fontSize:22}}>RECENTLY ADDED</h3>{cards.slice(-4).reverse().map(c=><div key={c.id} style={{display:"flex",justifyContent:"space-between",padding:"9px 0",borderBottom:"1px solid var(--line)"}}><span><strong>{c.value.player || "— Unfilled Slot —"}</strong> <span style={{color:"var(--muted)"}}>· {setById.get(c.value.setId)?.name} #{c.value.cardNumber}{c.value.subsetName?` · ${c.value.subsetName}`:""}</span></span><strong>Qty {qtyOwnedOf(c.value)} · {money(c.value.currentValue)}</strong></div>)}{!cards.length && <p style={{color:"var(--muted)"}}>No cards yet. Add one, or load the 12 sample cards.</p>}</div>
              <article style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10,padding:16}}><h3 style={{margin:"0 0 10px",fontSize:22}}><a href="https://cloutsnchara.com/checklist/2020-bowman-baseball-checklist/" target="_blank" rel="noopener">2020 Bowman Baseball Checklist</a></h3><p style={{color:"var(--muted)",fontSize:13,margin:"0 0 8px"}}>Reference checklist · CloutsnChara</p><p style={{fontSize:14,margin:"0 0 10px"}}>Full 2020 Bowman checklist reference, including Bowman Hidden Finds.</p><a href="https://cloutsnchara.com/checklist/2020-bowman-baseball-checklist/" target="_blank" rel="noopener" className="btn btn-outline">View Checklist →</a></article>
              <div style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10,padding:16}}><h3 style={{margin:"0 0 10px",fontSize:22}}>CATEGORY PROGRESS</h3>{categories.filter(c=>c!=="All").map(catName=>{ const ss=sets.filter(s=>s.category===catName); const base=ss.reduce((a,s)=>a+(s.baseCards>0?s.baseCards:0),0); const owned=ss.reduce((a,s)=>a+(ownedBySet.get(s.id)||0),0); const pct=base?Math.min(100,owned/base*100):0; return <div key={catName} style={{marginBottom:10}}><div style={{display:"flex",justifyContent:"space-between",fontSize:13}}><span><strong>{catName}</strong> · {ss.length} sets</span><span>{owned} / {base.toLocaleString()}</span></div><div style={{height:8,background:"var(--surface-2)",borderRadius:999,overflow:"hidden",marginTop:4}}><div style={{height:"100%",width:`${pct}%`,background:"var(--navy)"}}/></div></div>})}</div>
            </div>
          </section>
        )}

        {tab==="sets" && (
          <section>
            <Banner />
            <p style={{background:"#fff4d6",border:"1px solid #e5c24f",borderRadius:8,padding:"11px 13px",margin:"0 0 14px",fontSize:14}}><strong>Bowman Prospects (BP-1 to BP-150) are tracked as their own set</strong> — see Bowman Prospects in this library, or Subsets tab. Bowman (100 base) + Bowman Prospects (150) = 250 Bowman cards. Bowman Chrome Prospects (BCP-1 to BCP-100) use the same prospect names.</p>
            <div style={{display:"flex",gap:10,flexWrap:"wrap",alignItems:"end",marginBottom:14}}>
              <div style={{flex:"1 1 260px"}}><label className="label">Search sets</label><div style={{position:"relative"}}><Search size={18} style={{position:"absolute",left:10,top:12,color:"var(--muted)"}}/><input className="field" style={{paddingLeft:36}} value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search name or notes…"/></div></div>
              <div><label className="label">Category</label><select className="field" value={cat} onChange={e=>setCat(e.target.value)}>{categories.map(c=><option key={c}>{c}</option>)}</select></div>
              <div><label className="label">Sort</label><select className="field" value={sortSet} onChange={e=>setSortSet(e.target.value)}><option value="name">Name</option><option value="date">Release Date</option><option value="base">Base Cards</option><option value="completion">Completion</option></select></div>
              <div style={{fontSize:13,color:"var(--muted)"}}><ArrowDownWideNarrow size={16}/> Showing <strong style={{color:"var(--ink)"}}>{filteredSets.length}</strong> of {sets.length} sets</div>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(300px,1fr))",gap:12}}>
              {filteredSets.map(s=>{ const owned=ownedBySet.get(s.id)||0; const pct=s.baseCards?Math.min(100,owned/s.baseCards*100):(owned?100:0); return (
                <article key={s.id} style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10,padding:16,display:"flex",flexDirection:"column"}}>
                  <div style={{display:"flex",justifyContent:"space-between",gap:8}}><h3 style={{margin:0,fontSize:26,lineHeight:1}}>{s.name}</h3><span className="chip" style={{background:"var(--navy)",color:"white",whiteSpace:"nowrap"}}>{s.category}</span></div>
                  <p style={{color:"var(--muted)",fontSize:13,margin:"8px 0"}}>Released {fmtDate(s.releaseDate)} · {s.config}</p>
                  <p style={{fontSize:14,margin:"0 0 12px",flex:1}}>{s.notes}</p>
                  <div style={{fontSize:13,display:"flex",justifyContent:"space-between"}}><span>Base size: {editingSize===s.id? <><input className="field" style={{width:90,minHeight:32,display:"inline-block"}} value={sizeDraft} onChange={e=>setSizeDraft(e.target.value)} inputMode="numeric"/> <button className="btn btn-red" style={{padding:"6px 9px"}} onClick={()=>saveSize(s)}>Save</button> <button className="btn btn-light" style={{padding:"6px 9px"}} onClick={()=>setEditingSize(null)}>Cancel</button></> : <><strong>{s.baseCards===0?"Hit-driven":s.baseCards.toLocaleString()}</strong> <button onClick={()=>{setEditingSize(s.id);setSizeDraft(String(s.baseCards))}} style={{border:0,background:"none",color:"var(--red)",fontWeight:700}}>Edit size</button></>}</span><span>Owned: <strong>{owned}</strong></span></div>
                  <div style={{height:9,background:"var(--surface-2)",borderRadius:999,overflow:"hidden",margin:"10px 0"}}><div style={{height:"100%",width:`${pct}%`,background:"var(--red)"}}/></div>
                  <div style={{fontSize:13,color:"var(--muted)",marginBottom:8}}>Base: {owned} / {s.baseCards} · Inserts/Parallels: {insertsBySet.get(s.id)||0} tracked</div>
                  <div style={{display:"flex",gap:7,flexWrap:"wrap"}}><button className="btn btn-navy" style={{flex:1}} onClick={()=>{setDetailId(s.id); setColSet(s.id);}}>View Cards</button><button className="btn btn-outline" onClick={()=>startAdd({setId:s.id})}>Quick Add</button><button className="btn btn-outline" onClick={()=>markSetComplete(s)} disabled={busy}>Mark Set Complete</button></div>
                </article>)})}
            </div>
            {detail && (
              <div style={{background:"var(--paper)",border:"2px solid var(--navy)",borderRadius:12,padding:18,marginTop:16}}>
                <div style={{display:"flex",justifyContent:"space-between",gap:10,flexWrap:"wrap"}}><div><h2 style={{margin:0,fontSize:32}}>{detail.name} — CHECKLIST</h2><p style={{color:"var(--muted)",margin:"6px 0"}}>{detail.notes} · {fmtDate(detail.releaseDate)} · {detail.config}</p></div><button className="btn btn-light" onClick={()=>setDetailId(null)}><X size={18}/> Close</button></div>
                <div style={{display:"flex",gap:14,flexWrap:"wrap",fontSize:15,margin:"8px 0"}}><span><strong>Base:</strong> {detailBaseOwned} / {detail.baseCards}{detail.baseCards?` · ${((detailBaseOwned/detail.baseCards)*100).toFixed(1)}%`:""}</span><span><strong>Inserts/Parallels:</strong> {detailInserts} tracked</span></div>
                <div style={{display:"flex",gap:8,flexWrap:"wrap",margin:"10px 0"}}><button className="btn btn-red" onClick={()=>generateSlots(detail)} disabled={busy}>Generate All Card Slots for This Set</button><button className="btn btn-outline" onClick={()=>clearZeroQtySlots(detail)} disabled={busy}>Clear Zero-Qty Slots</button></div>
                <p style={{fontSize:13,color:"var(--muted)",margin:"0 0 10px"}}>Generate creates blank slots (#1 to baseCards, Qty Owned = 0, Player blank, Parallel = Base) so you can click + in Inventory to add. It skips slots you already have — no duplicates. <strong>Bowman numbering:</strong> Bowman generates 1–100 Base. Bowman Prospects generates BP-1 to BP-150. Bowman Draft generates BD-1 to BD-200. Bowman Chrome generates 1–100 + BCP-1 to BCP-150 (same prospect names as BP-1 to BP-150). Bowman — In Progress / Part 1 Done + 1990 Bowman Insert (90B, 50 cards); other inserts / autos come in Part 2 / Part 3. Allen &amp; Ginter generates 1–350 (1–300 base + 301–350 SP). Gypsy Queen generates 1–320 (1–300 base + 301–320 Extended Base SPs). Opening Day generates 1–201 (1–200 base + 201 SP). Stadium Club generates 1–300. Big League generates 1–300.</p>
                {detailSubsets.length>0 && <div style={{margin:"10px 0 16px"}}><h3 style={{margin:"0 0 8px",fontSize:20}}>SUBSETS &amp; INSERTS IN THIS SET</h3><div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(240px,1fr))",gap:8}}>{detailSubsets.map(sub=><div key={sub.id} style={{border:"1px solid var(--line)",borderRadius:8,padding:"10px 12px"}}><div style={{display:"flex",justifyContent:"space-between",gap:8}}><strong>{sub.name}</strong><span className="chip" style={{background: sub.type==="Base Subset"?"var(--surface-2)":sub.type==="Insert"?"#fff0c9":"#ffe8ea",whiteSpace:"nowrap"}}>{sub.type}</span></div><p style={{margin:"6px 0 0",fontSize:13,color:"var(--muted)"}}>Size: {sub.approx?"~":""}{sub.size} cards · {sub.notes}</p><p style={{margin:"4px 0 0",fontSize:12,color:"var(--muted)"}}>{sub.type==="Base Subset"?"Counts toward base completion.":"Separate checklist — does NOT count toward base completion."}</p></div>)}</div></div>}
                {detail.baseCards===0 ? <div><p><strong>No base checklist — add hits manually.</strong> This set is tracked by autographs, relics, and hits.</p><button className="btn btn-red" onClick={()=>startAdd({setId:detail.id,parallel:"Auto"})}>Add a Hit</button></div> : <>
                  <p style={{fontSize:14}}>Click a slot to add that card. <span style={{color:"var(--green)",fontWeight:700}}>Green = owned</span> · <span style={{color:"var(--gold)",fontWeight:700}}>Gold = wantlist</span></p>
                  {(detail.id==="s1"||detail.id==="s2"||detail.id==="update"||detail.id==="chrome"||detail.id==="bowman"||detail.id==="bowman-prospects"||detail.id==="bowman-chrome"||detail.id==="bowman-draft"||detail.id==="heritage"||detail.id==="ag"||detail.id==="gypsy"||detail.id==="opening-day"||detail.id==="stadium"||detail.id==="big-league") ? <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(240px,1fr))",gap:7,maxHeight:480,overflowY:"auto",padding:4}}>{((detail.id==="bowman-chrome" || detail.id==="bowman-draft") ? slotNumbersForSet(detail) : Array.from({length:detail.baseCards},(_,i)=>(detail.id==="s2"?351:1)+i).map(n=>String(n))).map((labelNumRaw,idx)=>{ const n = (detail.id==="bowman-chrome" || detail.id==="bowman-draft") ? idx+1 : Number(labelNumRaw); const labelNum = detail.id==="update" ? `U-${n}` : detail.id==="bowman-prospects" ? `BP-${n}` : (detail.id==="bowman-chrome" || detail.id==="bowman-draft") ? String(labelNumRaw) : String(n); const found=cards.find(c=>{ if(detail.id==="bowman-prospects") return (c.value.setId==="bowman-prospects" || c.value.setId==="bowman") && normalizeCardNumber(c.value.setId, c.value.cardNumber)===labelNum && isBaseCard(c.value); return c.value.setId===detail.id && normalizeCardNumber(detail.id, c.value.cardNumber)===labelNum && isBaseCard(c.value); }); const e=lookupCardName(detail.id,labelNum); const label = found?.value.player ? `${labelNum} - ${found.value.player} - ${found.value.team}` : e ? `${labelNum} - ${e.player} - ${e.team}` : `${labelNum}`; const cls=found?.value.owned|| (found && qtyOwnedOf(found.value)>0) ?"slot owned":found?.value.wantlist?"slot want":"slot"; return <button key={labelNum} className={cls} style={{height:"auto",minHeight:42,padding:"8px 10px",textAlign:"left",whiteSpace:"normal",lineHeight:1.25}} onClick={()=>found?editCard(found):startAdd({setId:detail.id,cardNumber:labelNum})} title={found?`${found.value.player || e?.player || "Blank slot"} — click to edit`:`Add #${labelNum}`}>{label}{e?.note?` · ${e.note}`:""}</button>})}</div> : <div className="check-grid">{Array.from({length:detail.baseCards},(_,i)=>i+1).map(n=>{ const found=cards.find(c=>c.value.setId===detail.id && c.value.cardNumber===String(n) && isBaseCard(c.value)); const cls=found?.value.owned|| (found && qtyOwnedOf(found.value)>0) ?"slot owned":found?.value.wantlist?"slot want":"slot"; return <button key={n} className={cls} onClick={()=>found?editCard(found):startAdd({setId:detail.id,cardNumber:String(n)})} title={found?`${found.value.player || "Blank slot"} — click to edit`:`Add #${n}`}>{n}</button>})}</div>}
                </>}
                <div style={{marginTop:14}}><button className="btn btn-navy" onClick={()=>{setTab("collection");}}>View in My Collection →</button></div>
              </div>
            )}
          </section>
        )}

        {tab==="inventory" && (
          <section>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-end",flexWrap:"wrap",gap:10}}><div><h2 style={{margin:0,fontSize:32}}>INVENTORY</h2><p style={{color:"var(--muted)",margin:"6px 0 0"}}>Quantity-focused view. Grouped by Set + Card # + Player + Parallel. Total Qty = Qty Owned + Qty For Trade. Total Value = Qty Owned × Unit Value.</p></div><button className="btn btn-red" onClick={()=>startAdd()}><Plus size={18}/> Add Card</button></div>
            <div style={{marginTop:12}}><Banner /></div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(170px,1fr))",gap:12}}>
              {[
                {label:"Unique Cards Owned", val:String(invUnique), sub:"Distinct Set + Card # + Parallel with Qty > 0"},
                {label:"Total Cards Owned", val:String(invTotalOwned), sub:"Sum of Qty Owned"},
                {label:"Total Duplicates", val:String(invDuplicates), sub:"Total − Unique"},
                {label:"Total For Trade", val:String(invTotalForTrade), sub:"Sum of Qty For Trade"},
                {label:"Total Inventory Value", val:money(invTotalValue), sub:"Sum of Qty Owned × Unit Value"},
              ].map(x=><div key={x.label} style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10,padding:16}}><div style={{color:"var(--red)",fontSize:12,fontWeight:800,textTransform:"uppercase",letterSpacing:".07em"}}>{x.label}</div><div className="display" style={{fontSize:34,lineHeight:1,marginTop:8}}>{x.val}</div><div style={{color:"var(--muted)",fontSize:13,marginTop:5}}>{x.sub}</div></div>)}
            </div>
            <div style={{display:"flex",gap:10,flexWrap:"wrap",alignItems:"end",margin:"14px 0 12px"}}>
              <div style={{flex:"1 1 220px"}}><label className="label">Search inventory</label><input className="field" value={invSearch} onChange={e=>setInvSearch(e.target.value)} placeholder="Player, set, card #, location…"/></div>
              <div><label className="label">Set</label><select className="field" value={invSet} onChange={e=>setInvSet(e.target.value)}><option value="All">All sets</option>{sets.map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select></div>
              <div><label className="label">Sort</label><select className="field" value={invSort} onChange={e=>setInvSort(e.target.value)}><option value="player">Player</option><option value="set">Set</option><option value="number">Card #</option><option value="qty">Qty Owned</option><option value="value">Total Value</option></select></div>
              <div style={{fontSize:13,color:"var(--muted)"}}>Showing <strong style={{color:"var(--ink)"}}>{filteredInv.length}</strong> groups · {invTotalOwned} total owned</div>
            </div>
            {invSelected.size>0 && <div style={{background:"var(--navy)",color:"white",borderRadius:8,padding:"10px 12px",display:"flex",gap:8,flexWrap:"wrap",alignItems:"center",marginBottom:10}}><strong>{invSelected.size} selected</strong><button className="btn btn-red" onClick={()=>bulkInvAdjust(1)} disabled={busy}>+1 Qty</button><button className="btn btn-light" onClick={()=>bulkInvAdjust(-1)} disabled={busy}>−1 Qty</button><button className="btn btn-light" onClick={()=>setShowSetQty(!showSetQty)}>Set Qty…</button><button className="btn btn-light" onClick={bulkInvWantlist} disabled={busy}>Move to Wantlist</button>{!invConfirmDelete ? <button className="btn btn-light" onClick={()=>setInvConfirmDelete(true)}>Delete</button> : <span style={{display:"inline-flex",gap:8,alignItems:"center"}}><strong>Delete selected?</strong><button className="btn btn-red" onClick={bulkInvDelete} disabled={busy}>Yes, Delete</button><button className="btn btn-light" onClick={()=>setInvConfirmDelete(false)}>Keep</button></span>}<button className="btn btn-outline" style={{color:"white",borderColor:"white"}} onClick={()=>{setInvSelected(new Set()); setShowSetQty(false); setInvConfirmDelete(false);}}>Clear Selection</button>{showSetQty && <span style={{display:"inline-flex",gap:6,alignItems:"center"}}><label style={{fontSize:13}}>Qty <input className="field" style={{width:80,minHeight:32,background:"white",color:"var(--ink)"}} type="number" min="0" max="999" value={invBulkQty} onChange={e=>setInvBulkQty(e.target.value)}/></label><button className="btn btn-red" onClick={bulkInvSetQty} disabled={busy}>Apply Set Qty</button></span>}</div>}
            <div style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10}} className="table-wrap">
              <table><thead><tr><th><input type="checkbox" checked={filteredInv.length>0 && filteredInv.every(g=>invSelected.has(g.key))} onChange={e=>setInvSelected(e.target.checked?new Set(filteredInv.map(g=>g.key)):new Set())} aria-label="Select all inventory"/></th><th>Set</th><th>Card #</th><th>Player</th><th>Parallel</th><th>Qty Owned</th><th>Qty For Trade</th><th>Total Qty</th><th>Unit Value</th><th>Total Value</th><th>Location</th><th>Condition</th><th>Actions</th></tr></thead><tbody>
                {filteredInv.map(g=><tr key={g.key}><td><input type="checkbox" checked={invSelected.has(g.key)} onChange={()=>{const n=new Set(invSelected); n.has(g.key)?n.delete(g.key):n.add(g.key); setInvSelected(n);}}/></td><td><strong>{setById.get(g.setId)?.name||g.setId}</strong></td><td>#{g.cardNumber}</td><td><strong>{g.player || "— Unfilled Slot —"}</strong>{g.subsetName? <div style={{fontSize:12,color:"var(--muted)"}}>{g.subsetName}</div>:null}</td><td>{g.parallel}</td><td><span style={{display:"inline-flex",alignItems:"center",gap:4}}><button className="btn btn-light" style={{padding:"4px 7px"}} aria-label={`Decrease quantity for ${g.player || g.cardNumber}`} onClick={()=>adjustGroupQty(g,-1)}><Minus size={14}/></button><strong style={{minWidth:22,textAlign:"center"}}>{g.qtyOwned}</strong><button className="btn btn-light" style={{padding:"4px 7px"}} aria-label={`Increase quantity for ${g.player || g.cardNumber}`} onClick={()=>adjustGroupQty(g,1)}><Plus size={14}/></button></span></td><td>{g.qtyForTrade}</td><td><strong>{g.totalQty}</strong></td><td>{money(g.unitValue)}</td><td><strong>{money(g.totalValue)}</strong></td><td>{g.locations || "—"}</td><td>{g.condition}</td><td style={{whiteSpace:"nowrap"}}><button className="btn btn-light" style={{padding:"6px 8px",marginRight:5}} onClick={()=>editCard(g.rep)}><Pencil size={15}/> Edit</button><button className="btn btn-light" style={{padding:"6px 8px"}} onClick={()=>deleteCard(g.rep.id)}><Trash2 size={15}/></button></td></tr>)}
                {!filteredInv.length && <tr><td colSpan={14} style={{textAlign:"center",padding:30,color:"var(--muted)"}}>No inventory matches. Generate checklist slots in a set, or add a card.</td></tr>}
              </tbody></table>
            </div>
            <p style={{color:"var(--muted)",fontSize:13}}>Showing {filteredInv.length} groups. Zero-qty blank slots appear here so you can click + to add them. Completion still uses Unique cards only.</p>
          </section>
        )}

        {tab==="subsets" && (
          <section>
            <h2 style={{margin:"0 0 8px",fontSize:32}}>SUBSETS &amp; INSERTS</h2>
            <p style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:8,padding:"13px 15px",margin:"0 0 14px",fontSize:15,lineHeight:1.6}}>Base Subsets live <strong>INSIDE</strong> the base set count. Inserts and Parallels are <strong>SEPARATE</strong> checklists — they do <strong>NOT</strong> count toward base completion. Use Subset Type to track them.</p>
            <div style={{display:"flex",gap:10,flexWrap:"wrap",alignItems:"end",marginBottom:12}}>
              <div style={{flex:"1 1 220px"}}><label className="label">Search subsets / inserts</label><div style={{position:"relative"}}><Search size={18} style={{position:"absolute",left:10,top:12,color:"var(--muted)"}}/><input className="field" style={{paddingLeft:36}} value={subSearch} onChange={e=>setSubSearch(e.target.value)} placeholder="1985, Prospects, Refractor…"/></div></div>
              <div><label className="label">Set</label><select className="field" value={subSet} onChange={e=>setSubSet(e.target.value)}><option value="All">All sets</option>{sets.map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select></div>
              <div><label className="label">Type</label><select className="field" value={subType} onChange={e=>setSubType(e.target.value)}><option>All</option><option>Base Subset</option><option>Insert</option><option>Parallel</option><option>Auto</option><option>Relic</option><option>Insert / Parallel</option></select></div>
              <div style={{fontSize:13,color:"var(--muted)"}}>Showing <strong style={{color:"var(--ink)"}}>{filteredSubsets.length}</strong> of {SUBSETS.length} definitions</div>
            </div>
            <div style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10}} className="table-wrap">
              <table><thead><tr><th>Set</th><th>Subset / Insert Name</th><th>Type</th><th>Size (cards)</th><th>Notes</th><th></th></tr></thead><tbody>
                {filteredSubsets.map(s=><tr key={s.id}><td><strong>{setById.get(s.setId)?.name||s.setId}</strong></td><td><strong>{s.name}</strong></td><td><span className="chip" style={{background: s.type==="Base Subset"?"var(--surface-2)":s.type==="Insert"?"#fff0c9":"#ffe8ea"}}>{s.type}</span></td><td>{s.approx?"~":""}{s.size}</td><td>{s.notes}</td><td><button className="btn btn-outline" style={{padding:"6px 10px",whiteSpace:"nowrap"}} onClick={()=>startAdd({setId:s.setId,subsetName:s.name,subsetType:subsetTypeForDef(s)})}>Add Card →</button></td></tr>)}
                {!filteredSubsets.length && <tr><td colSpan={6} style={{textAlign:"center",padding:30,color:"var(--muted)"}}>No subsets match these filters.</td></tr>}
              </tbody></table>
            </div>
            <p style={{color:"var(--muted)",fontSize:13}}>Base Subsets count toward base completion. Inserts, Parallels, Autos and Relics are tracked separately and do not change the base %.</p>
          </section>
        )}

        {tab==="collection" && (
          <section>
            <div style={{display:"flex",gap:10,flexWrap:"wrap",alignItems:"end",marginBottom:12}}>
              <div style={{flex:"1 1 220px"}}><label className="label">Search player / set</label><input className="field" value={colSearch} onChange={e=>setColSearch(e.target.value)} placeholder="Trout, Series 1…"/></div>
              <div><label className="label">Set</label><select className="field" value={colSet} onChange={e=>setColSet(e.target.value)}><option value="All">All sets</option>{sets.map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select></div>
              <div><label className="label">Status</label><select className="field" value={colOwned} onChange={e=>setColOwned(e.target.value)}><option>All</option><option>Owned</option><option>Wantlist</option></select></div>
              <div><label className="label">Parallel</label><select className="field" value={colParallel} onChange={e=>setColParallel(e.target.value)}><option>All</option>{PARALLELS.map(p=><option key={p}>{p}</option>)}</select></div>
              <div><label className="label">Subset Type</label><select className="field" value={colSubsetType} onChange={e=>setColSubsetType(e.target.value)}><option>All</option>{SUBSET_TYPES.map(t=><option key={t}>{t}</option>)}</select></div>
              <div><label className="label">Subset Name</label><select className="field" value={colSubsetName} onChange={e=>setColSubsetName(e.target.value)}><option>All</option><option>None - Base Card</option><option>Other</option>{subsetNameOptions.map(n=><option key={n}>{n}</option>)}</select></div>
              <div><label className="label">Sort</label><select className="field" value={colSort} onChange={e=>setColSort(e.target.value)}><option value="player">Player</option><option value="set">Set</option><option value="number">Card #</option><option value="value">Value</option><option value="date">Date Added</option></select></div>
            </div>
            {selected.size>0 && <div style={{background:"var(--navy)",color:"white",borderRadius:8,padding:"10px 12px",display:"flex",gap:8,flexWrap:"wrap",alignItems:"center",marginBottom:10}}><strong>{selected.size} selected</strong><button className="btn btn-red" onClick={bulkOwned} disabled={busy}>Mark Owned</button><button className="btn btn-light" onClick={bulkDelete} disabled={busy}>Delete Selected</button><button className="btn btn-outline" style={{color:"white",borderColor:"white"}} onClick={()=>setSelected(new Set())}>Clear Selection</button></div>}
            <div style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10}} className="table-wrap">
              <table><thead><tr><th><input type="checkbox" checked={filteredCards.length>0 && filteredCards.every(c=>selected.has(c.id))} onChange={e=>setSelected(e.target.checked?new Set(filteredCards.map(c=>c.id)):new Set())} aria-label="Select all"/></th><th>Set</th><th>Card #</th><th>Player</th><th>Team</th><th>Parallel / Variant</th><th>Subset / Insert</th><th>Subset Type</th><th>Condition</th><th>Graded</th><th>Owned</th><th>For Trade</th><th>Qty Owned</th><th>Qty For Trade</th><th>Location</th><th>Value</th><th>Notes</th><th>Actions</th></tr></thead><tbody>
                {filteredCards.map(c=>{ const v=c.value; return <tr key={c.id}><td><input type="checkbox" checked={selected.has(c.id)} onChange={()=>{const n=new Set(selected); n.has(c.id)?n.delete(c.id):n.add(c.id); setSelected(n);}}/></td><td><strong>{setById.get(v.setId)?.name||v.setId}</strong></td><td>#{v.cardNumber}</td><td><strong>{v.player || "— Unfilled Slot —"}</strong></td><td>{v.team}</td><td>{v.parallel}</td><td>{v.subsetName||"—"}</td><td>{v.subsetType||"Base Card"}</td><td>{v.condition}</td><td>{v.gradedCompany}{v.grade?` ${v.grade}`:""}</td><td><input type="checkbox" checked={effectiveOwned(v)} onChange={e=>toggleOwned(c,e.target.checked)}/></td><td>{v.forTrade?"Yes":"—"}</td><td><span style={{display:"inline-flex",alignItems:"center",gap:4}}><button className="btn btn-light" style={{padding:"4px 7px"}} aria-label={`Decrease quantity for ${v.player || v.cardNumber}`} onClick={()=>adjustQty(c,-1)}><Minus size={14}/></button><strong style={{minWidth:22,textAlign:"center"}}>{qtyOwnedOf(v)}</strong><button className="btn btn-light" style={{padding:"4px 7px"}} aria-label={`Increase quantity for ${v.player || v.cardNumber}`} onClick={()=>adjustQty(c,1)}><Plus size={14}/></button></span></td><td>{qtyForTradeOf(v)}</td><td>{locationOf(v) || "—"}</td><td>{money(v.currentValue)}</td><td style={{maxWidth:180,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{v.notes}</td><td style={{whiteSpace:"nowrap"}}><button className="btn btn-light" style={{padding:"6px 8px",marginRight:5}} onClick={()=>editCard(c)}><Pencil size={15}/> Edit</button><button className="btn btn-light" style={{padding:"6px 8px"}} onClick={()=>deleteCard(c.id)}><Trash2 size={15}/></button></td></tr>})}
                {!filteredCards.length && <tr><td colSpan={18} style={{textAlign:"center",padding:30,color:"var(--muted)"}}>No cards match these filters. Add a card or adjust the filters.</td></tr>}
              </tbody></table>
            </div>
            <p style={{color:"var(--muted)",fontSize:13}}>Showing {filteredCards.length} of {cards.length} cards. Total value shown: {money(filteredCards.reduce((a,c)=>a+qtyOwnedOf(c.value)*c.value.currentValue,0))}. Base completion counts Base Card / Base Subset only.</p>
          </section>
        )}

        {tab==="wantlist" && (
          <section>
            <h2 style={{margin:"0 0 6px",fontSize:32}}>WANTLIST</h2><p style={{color:"var(--muted)",marginTop:0}}>Cards marked Wantlist that are not yet owned. {wantCards.length} card{wantCards.length===1?"":"s"} to find.</p>
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(280px,1fr))",gap:12}}>
              {wantCards.map(c=>{ const v=c.value; return <article key={c.id} style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10,padding:16}}><div style={{display:"flex",justifyContent:"space-between"}}><h3 style={{margin:0,fontSize:24}}>{v.player || "— Unfilled Slot —"}</h3><span className="chip" style={{background:"#fff0c9"}}>Want</span></div><p style={{color:"var(--muted)",margin:"6px 0"}}>{setById.get(v.setId)?.name} · #{v.cardNumber} · {v.parallel}{v.subsetName?` · ${v.subsetName} (${v.subsetType||"Base Card"})`:""}</p><p style={{fontSize:14}}>{v.team} · {v.condition} · Est. {money(v.currentValue)}{locationOf(v)?` · ${locationOf(v)}`:""}</p><p style={{fontSize:13,color:"var(--muted)"}}>{v.notes}</p><div style={{display:"flex",gap:7}}><button className="btn btn-red" onClick={()=>moveToOwned(c)}>Move to Owned</button><button className="btn btn-outline" onClick={()=>editCard(c)}>Edit</button></div></article>})}
              {!wantCards.length && <p style={{color:"var(--muted)"}}>Your wantlist is empty. Mark a card as Wantlist in Add Card, or add one from a set checklist.</p>}
            </div>
          </section>
        )}

        {tab==="checklists" && (
          <section>
            <h2 style={{margin:"0 0 6px",fontSize:32}}>CHECKLISTS — SERIES 1, SERIES 2, UPDATE, CHROME, BOWMAN, BOWMAN DRAFT, HERITAGE, ALLEN &amp; GINTER, GYPSY QUEEN, OPENING DAY, STADIUM CLUB &amp; BIG LEAGUE</h2>
            <p style={{background:"#fff4d6",border:"1px solid #e5c24f",borderRadius:8,padding:"11px 13px",margin:"0 0 14px",fontSize:14}}><strong>Series 1 names added (350/350). Series 2 names added (350/350). Update names added (300/300). Chrome names added (200/200). Bowman names added (100/100 base + 150/150 prospects = 250 + 1990 Bowman Insert 50/50). Bowman Draft names added (200/200). Heritage names added (500/500). Allen &amp; Ginter names added (350/350). Gypsy Queen names added (320/320). Opening Day names added (201/201). Stadium Club names added (300/300). Big League names added (300/300).</strong> All 350 Series 1 cards, all 350 Series 2 cards, all 300 Update cards, all 200 Chrome cards, all 100 Bowman base cards, all 150 Bowman Prospects cards, all 200 Bowman Draft cards, all 500 Heritage cards, all 350 Allen &amp; Ginter cards, all 320 Gypsy Queen cards, all 201 Opening Day cards, and all 300 Stadium Club cards, and all 300 Big League cards with player, team, and subset / note. Flagship named: 1000 / 1000 (Series 1 350 + Series 2 350 + Update 300). Chrome named: 200 / 200. Bowman named: 250 / 250 + 1990 Bowman Insert 50 / 50. Bowman Draft named: 200 / 200. Heritage named: 500 / 500 (1–400 base, 401–500 short prints). Allen &amp; Ginter named: 350 / 350 (1–300 base, 301–350 short prints). Gypsy Queen named: 320 / 320 (1–300 base, 301–320 Extended Base SPs). Opening Day named: 201 / 201 (1–200 base, 201 short print). Stadium Club named: 300 / 300 (1–300). Big League named: 300 / 300 (1–300). Total named: 3671 / 3671.</p>
            <h3 style={{margin:"18px 0 8px",fontSize:24}}>SERIES 1 — #1–350</h3>
            <div style={{display:"flex",gap:10,flexWrap:"wrap",alignItems:"end",marginBottom:12}}>
              <div style={{flex:"1 1 220px"}}><label className="label">Search player or card #</label><input className="field" value={checkSearch} onChange={e=>setCheckSearch(e.target.value)} placeholder="Trout, 1, Alonso…"/></div>
              <div><label className="label">Team</label><select className="field" value={checkTeam} onChange={e=>setCheckTeam(e.target.value)}>{checklistTeams.map(t=><option key={t}>{t}</option>)}</select></div>
              <div><label className="label">Subset / Note</label><select className="field" value={checkNote} onChange={e=>setCheckNote(e.target.value)}>{checklistNotes.map(n=><option key={n}>{n}</option>)}</select></div>
              <div><label className="label">Owned</label><select className="field" value={checkOwned} onChange={e=>setCheckOwned(e.target.value)}><option>All</option><option>Owned</option><option>Not Owned</option></select></div>
              <div style={{fontSize:13,color:"var(--muted)"}}>Showing <strong style={{color:"var(--ink)"}}>{filteredChecklist.length}</strong> of 350 · Owned: <strong style={{color:"var(--ink)"}}>{checklistRows.filter(r=>r.owned).length}</strong></div>
            </div>
            <div style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10}} className="table-wrap">
              <table><thead><tr><th>Card #</th><th>Player</th><th>Team</th><th>Subset / Note</th><th>Qty Owned</th><th>Owned</th><th></th></tr></thead><tbody>
                {filteredChecklist.map(r=><tr key={r.num}><td><strong>{r.num}</strong></td><td><strong>{r.entry.player}</strong></td><td>{r.entry.team}</td><td>{r.entry.note || "—"}</td><td>{r.qty}</td><td><input type="checkbox" checked={r.owned} onChange={()=>toggleChecklist(r)} aria-label={`Owned ${r.num} - ${r.entry.player}`}/></td><td style={{whiteSpace:"nowrap"}}><button className="btn btn-outline" style={{padding:"6px 10px"}} onClick={()=>startAdd({setId:"s1",cardNumber:String(r.num)})}>Add Card →</button></td></tr>)}
                {!filteredChecklist.length && <tr><td colSpan={7} style={{textAlign:"center",padding:30,color:"var(--muted)"}}>No Series 1 cards match these filters.</td></tr>}
              </tbody></table>
            </div>
            <h3 style={{margin:"22px 0 8px",fontSize:24}}>SERIES 2 — #351–700</h3>
            <p style={{color:"var(--muted)",margin:"0 0 12px",fontSize:14}}>Showing <strong style={{color:"var(--ink)"}}>{filteredChecklist2.length}</strong> of 350 · Owned: <strong style={{color:"var(--ink)"}}>{checklistRows2.filter(r=>r.owned).length}</strong>. Use the same search and Team / Subset / Owned filters above.</p>
            <div style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10}} className="table-wrap">
              <table><thead><tr><th>Card #</th><th>Player</th><th>Team</th><th>Subset / Note</th><th>Qty Owned</th><th>Owned</th><th></th></tr></thead><tbody>
                {filteredChecklist2.map(r=><tr key={r.num}><td><strong>{r.num}</strong></td><td><strong>{r.entry.player}</strong></td><td>{r.entry.team}</td><td>{r.entry.note || "—"}</td><td>{r.qty}</td><td><input type="checkbox" checked={r.owned} onChange={()=>toggleChecklist(r,"s2")} aria-label={`Owned ${r.num} - ${r.entry.player}`}/></td><td style={{whiteSpace:"nowrap"}}><button className="btn btn-outline" style={{padding:"6px 10px"}} onClick={()=>startAdd({setId:"s2",cardNumber:String(r.num)})}>Add Card →</button></td></tr>)}
                {!filteredChecklist2.length && <tr><td colSpan={7} style={{textAlign:"center",padding:30,color:"var(--muted)"}}>No Series 2 cards match these filters.</td></tr>}
              </tbody></table>
            </div>
            <h3 style={{margin:"22px 0 8px",fontSize:24}}>UPDATE — U-1–U-300</h3>
            <p style={{color:"var(--muted)",margin:"0 0 12px",fontSize:14}}>Showing <strong style={{color:"var(--ink)"}}>{filteredChecklistUpdate.length}</strong> of 300 · Owned: <strong style={{color:"var(--ink)"}}>{checklistRowsUpdate.filter(r=>r.owned).length}</strong>. Use the same search and Team / Subset / Owned filters above. Filter by Team / Rookie / RC Debut / AS / Active Leaders / HR Derby / Combo. Enter U-1 or 1 — both normalize to U-1. CMP codes: Base ends #588, SP ends #631, SSP ends #632, SSSP ends #633, Advanced Stat ends #634. Update Total: Base 300 + SP 50 + SSP 25 + SSSP 5 + Inserts 375 = 755 checklist entries (plus Clear /10 variant). Flagship Trilogy: Series 1 Total 965 + Series 2 Total 1,220 + Update Total 755 = 2,940.</p>
            <div style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10}} className="table-wrap">
              <table><thead><tr><th>Card #</th><th>Player</th><th>Team</th><th>Subset / Note</th><th>Qty Owned</th><th>Owned</th><th></th></tr></thead><tbody>
                {filteredChecklistUpdate.map(r=><tr key={r.numLabel}><td><strong>{r.numLabel}</strong></td><td><strong>{r.entry.player}</strong></td><td>{r.entry.team}</td><td>{r.entry.note || "—"}</td><td>{r.qty}</td><td><input type="checkbox" checked={r.owned} onChange={()=>toggleChecklist(r,"update")} aria-label={`Owned ${r.numLabel} - ${r.entry.player}`}/></td><td style={{whiteSpace:"nowrap"}}><button className="btn btn-outline" style={{padding:"6px 10px"}} onClick={()=>startAdd({setId:"update",cardNumber:r.numLabel})}>Add Card →</button></td></tr>)}
                {!filteredChecklistUpdate.length && <tr><td colSpan={7} style={{textAlign:"center",padding:30,color:"var(--muted)"}}>No Update cards match these filters.</td></tr>}
              </tbody></table>
            </div>
            <h3 style={{margin:"22px 0 8px",fontSize:24}}>UPDATE SP / SSP / SSSP VARIATIONS — 50 + 25 + 5</h3>
            <p style={{color:"var(--muted)",margin:"0 0 12px",fontSize:14}}>CMP codes: Base ends #588, SP ends #631, SSP ends #632, SSSP ends #633, Advanced Stat ends #634. In Add Card, Set = Update Series, Variant offers all 18 Update parallels + Base + SP Variation + SSP Variation + SSSP Variation + Clear Variation. Each variation stores Subset + Code + Variant separately, so the same U- number can exist as Base, SP, SSP and SSSP rows.</p>
            <div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:12}}>{(["SP Variation","SSP Variation","SSSP Variation"] as const).map(v=><button key={v} onClick={()=>setUpdVarId(v)} style={{border:0,borderRadius:999,padding:"8px 13px",fontWeight:700,fontSize:13,background:updVarId===v?"var(--red)":"var(--surface-2)",color:updVarId===v?"white":"var(--ink)"}}>{v} ({v==="SP Variation"?50:v==="SSP Variation"?25:5})</button>)}</div>
            <p style={{margin:"0 0 10px",fontSize:14}}><strong>{updVarId}</strong> · Showing <strong>{filteredUpdVarRows.length}</strong> of {updVarId==="SP Variation"?50:updVarId==="SSP Variation"?25:5} · Owned: <strong>{updVarRows.filter(r=>r.owned).length}</strong></p>
            <div style={{display:"flex",gap:10,flexWrap:"wrap",alignItems:"end",marginBottom:12}}><div style={{flex:"1 1 220px"}}><label className="label">Search Update variations</label><input className="field" value={updVarSearch} onChange={e=>setUpdVarSearch(e.target.value)} placeholder="Player, code, team…"/></div></div>
            <div style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10}} className="table-wrap">
              <table><thead><tr><th>Code</th><th>Player</th><th>Team</th><th>Note</th><th>Qty Owned</th><th>Owned</th><th></th></tr></thead><tbody>
                {filteredUpdVarRows.map(r=><tr key={r.code}><td><strong>{r.code}</strong></td><td><strong>{r.player}</strong></td><td>{r.team}</td><td>{r.note || "—"}</td><td>{r.qty}</td><td><input type="checkbox" checked={r.owned} onChange={()=>toggleUpdVariation(r)} aria-label={`Owned ${r.code} ${updVarId} - ${r.player}`}/></td><td style={{whiteSpace:"nowrap"}}><button className="btn btn-outline" style={{padding:"6px 10px"}} onClick={()=>startAdd({setId:"update",cardNumber:r.code,player:r.player,team:fullTeamName(r.team)==="—"?"Other":fullTeamName(r.team),parallel:updVarId,subsetName:updVarId,subsetType:"Parallel",notes:r.note})}>Add Card →</button></td></tr>)}
                {!filteredUpdVarRows.length && <tr><td colSpan={7} style={{textAlign:"center",padding:30,color:"var(--muted)"}}>No Update variation cards match these filters.</td></tr>}
              </tbody></table>
            </div>
            <h3 style={{margin:"22px 0 8px",fontSize:24}}>UPDATE CLEAR VARIATION — HOBBY /10</h3>
            <p style={{color:"var(--muted)",margin:"0 0 12px",fontSize:14}}>Variant type Clear Variation, available for Update base. The Clear checklist is SP-based — no full 100 list is invented here. In Add Card, Set = Update Series, pick a base U- number and Variant = Clear Variation.</p>
            <div style={{display:"flex",gap:8,flexWrap:"wrap"}}><button className="btn btn-outline" onClick={()=>startAdd({setId:"update",parallel:"Clear Variation",subsetName:"Clear Variation",subsetType:"Parallel"})}>Add Clear Variation Card →</button></div>
            <h3 style={{margin:"22px 0 8px",fontSize:24}}>UPDATE INSERTS, AUTOS &amp; RELICS — 886 CARDS</h3>
            <p style={{color:"var(--muted)",margin:"0 0 12px",fontSize:14}}>Inserts 375 (Decades Best Update 80 + Prospects 30 + A Numbers Game 25 + 1985 TB Update 50 + 20 Years of the Captain 20 + Acuna Highlights 20 + Turkey Red Update 50 + Chrome Turkey Red Update 50 + Chrome Promo Update 50) + full autos / auto-relics / relics 511 (Decades Best Auto 39 + Prospects Autos 20 + A Numbers Game Autos 15 + Captain Autos 20 + Acuna Autos 20 + Baseball Stars Autos 43 + Baseball Stars Dual Autos 12 + 1985 Autos 49 + 1985 Chrome Promo Autos 44 + Captain Patch Autos 20 + Jeter Final Season Patch Autos 9 + Major League Material Autos 35 + All Star Stitch Autos 28 + All Star Stitch Dual Autos 10 + All Star Jumbo Patch Autos 19 + Coin Cards Autos 38 + Reverence Autos 21 + Captain Patch Relics 20 + Jeter Final Season Patch Relics 10 + Major League Material Relics 39) = 886. Update Total: Base 300 + SP 50 + SSP 25 + SSSP 5 + Hub 886 = 1,266 checklist entries (plus Clear /10 variant). Each entry stores Subset + Code + Variant separately, so Series 1 DB-1, Series 2 DB-1 and Update DB-1 are all different rows.</p>
            <div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:12}}>{UPD_HUB_DEFS.map(d=><button key={d.id} onClick={()=>setUpdInsertId(d.id)} style={{border:0,borderRadius:999,padding:"8px 13px",fontWeight:700,fontSize:13,background:updInsertId===d.id?"var(--red)":"var(--surface-2)",color:updInsertId===d.id?"white":"var(--ink)"}}>{d.name} ({d.size})</button>)}</div>
            <p style={{margin:"0 0 10px",fontSize:14}}><strong>{activeUpdInsertDef.name}</strong> · {activeUpdInsertDef.notes} · Parallels: {activeUpdInsertDef.parallels} · Showing <strong>{filteredUpdInsertRows.length}</strong> of {activeUpdInsertDef.size} · Owned: <strong>{updInsertRows.filter(r=>r.owned).length}</strong></p>
            <div style={{display:"flex",gap:10,flexWrap:"wrap",alignItems:"end",marginBottom:12}}><div style={{flex:"1 1 220px"}}><label className="label">Search Update inserts</label><input className="field" value={updInsertSearch} onChange={e=>setUpdInsertSearch(e.target.value)} placeholder="Player, code, team…"/></div></div>
            <div style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10}} className="table-wrap">
              <table><thead><tr><th>Code</th><th>Player</th><th>Team</th><th>Qty Owned</th><th>Owned</th><th></th></tr></thead><tbody>
                {filteredUpdInsertRows.map(r=><tr key={r.code}><td><strong>{r.code}</strong></td><td><strong>{r.player}</strong></td><td>{r.team}</td><td>{r.qty}</td><td><input type="checkbox" checked={r.owned} onChange={()=>toggleUpdInsert(r)} aria-label={`Owned ${r.code} - ${r.player}`}/></td><td style={{whiteSpace:"nowrap"}}><button className="btn btn-outline" style={{padding:"6px 10px"}} onClick={()=>startAdd({setId:"update",cardNumber:r.code,player:r.player,team:fullTeamName(r.team)==="—"?"Other":fullTeamName(r.team),parallel:"Base",subsetName:activeUpdInsertDef.name,subsetType:activeUpdInsertDef.type})}>Add Card →</button></td></tr>)}
                {!filteredUpdInsertRows.length && <tr><td colSpan={6} style={{textAlign:"center",padding:30,color:"var(--muted)"}}>No Update insert cards match these filters.</td></tr>}
              </tbody></table>
            </div>
            <h3 style={{margin:"22px 0 8px",fontSize:24}}>OTHER UPDATE INSERT HUB SETS — CODE-BASED</h3>
            <p style={{color:"var(--muted)",margin:"0 0 12px",fontSize:14}}>These sets are tracked by Code in Add Card (Set = Update Series, Subset = the set name). Entering a known Code auto-fills Player.</p>
            <div style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10}} className="table-wrap">
              <table><thead><tr><th>Set</th><th>Codes</th><th>Size</th><th>Parallels</th><th>Examples / Add support</th><th></th></tr></thead><tbody>
                {UPD_OTHER_INSERTS.map(s=><tr key={s.name}><td><strong>{s.name}</strong></td><td>{s.codes}</td><td>{s.size}</td><td>{s.parallels}</td><td>{s.examples}</td><td style={{whiteSpace:"nowrap"}}><button className="btn btn-outline" style={{padding:"6px 10px"}} onClick={()=>startAdd({setId:"update",subsetName:s.name,subsetType:s.parallels==="Relic"?"Relic":"Auto"})}>Add Card →</button></td></tr>)}
              </tbody></table>
            </div>
            <h3 style={{margin:"22px 0 8px",fontSize:24}}>CHROME — #1–200</h3>
            <p style={{color:"var(--muted)",margin:"0 0 12px",fontSize:14}}>Showing <strong style={{color:"var(--ink)"}}>{filteredChecklistChrome.length}</strong> of 200 · Owned: <strong style={{color:"var(--ink)"}}>{checklistRowsChrome.filter(r=>r.owned).length}</strong>. Use the same search and Team / Subset / Owned filters above. Filter by Team / Rookie.</p>
            <div style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10}} className="table-wrap">
              <table><thead><tr><th>Card #</th><th>Player</th><th>Team</th><th>Subset / Note</th><th>Qty Owned</th><th>Owned</th><th></th></tr></thead><tbody>
                {filteredChecklistChrome.map(r=><tr key={r.num}><td><strong>{r.num}</strong></td><td><strong>{r.entry.player}</strong></td><td>{r.entry.team}</td><td>{r.entry.note || "—"}</td><td>{r.qty}</td><td><input type="checkbox" checked={r.owned} onChange={()=>toggleChecklist(r,"chrome")} aria-label={`Owned ${r.num} - ${r.entry.player}`}/></td><td style={{whiteSpace:"nowrap"}}><button className="btn btn-outline" style={{padding:"6px 10px"}} onClick={()=>startAdd({setId:"chrome",cardNumber:String(r.num)})}>Add Card →</button></td></tr>)}
                {!filteredChecklistChrome.length && <tr><td colSpan={7} style={{textAlign:"center",padding:30,color:"var(--muted)"}}>No Chrome cards match these filters.</td></tr>}
              </tbody></table>
            </div>
            <h3 style={{margin:"22px 0 8px",fontSize:24}}>BOWMAN — #1–100</h3>
            <p style={{color:"var(--muted)",margin:"0 0 12px",fontSize:14}}>Showing <strong style={{color:"var(--ink)"}}>{filteredChecklistBowman.length}</strong> of 100 · Owned: <strong style={{color:"var(--ink)"}}>{checklistRowsBowman.filter(r=>r.owned).length}</strong>. Use the same search and Team / Subset / Owned filters above. Filter by Team / Rookie / RC.</p>
            <div style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10}} className="table-wrap">
              <table><thead><tr><th>Card #</th><th>Player</th><th>Team</th><th>Subset / Note</th><th>Qty Owned</th><th>Owned</th><th></th></tr></thead><tbody>
                {filteredChecklistBowman.map(r=><tr key={r.numLabel}><td><strong>{r.numLabel}</strong></td><td><strong>{r.entry.player}</strong></td><td>{r.entry.team}</td><td>{r.entry.note || "—"}</td><td>{r.qty}</td><td><input type="checkbox" checked={r.owned} onChange={()=>toggleChecklist(r,"bowman")} aria-label={`Owned ${r.numLabel} - ${r.entry.player}`}/></td><td style={{whiteSpace:"nowrap"}}><button className="btn btn-outline" style={{padding:"6px 10px"}} onClick={()=>startAdd({setId:"bowman",cardNumber:r.numLabel})}>Add Card →</button></td></tr>)}
                {!filteredChecklistBowman.length && <tr><td colSpan={7} style={{textAlign:"center",padding:30,color:"var(--muted)"}}>No Bowman cards match these filters.</td></tr>}
              </tbody></table>
            </div>
            <h3 style={{margin:"22px 0 8px",fontSize:24}}>BOWMAN PROSPECTS — BP-1–BP-150</h3>
            <p style={{color:"var(--muted)",margin:"0 0 12px",fontSize:14}}>Showing <strong style={{color:"var(--ink)"}}>{filteredChecklistBowmanProspects.length}</strong> of 150 · Owned: <strong style={{color:"var(--ink)"}}>{checklistRowsBowmanProspects.filter(r=>r.owned).length}</strong>. Use the same search and Team / Subset / Owned filters above. Filter by Team / Prospect. Enter BP-1 or 1 — both normalize to BP-1 when Set is Bowman Prospects. Same names as Bowman Chrome Prospects BCP-1 to BCP-150.</p>
            <div style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10}} className="table-wrap">
              <table><thead><tr><th>Card #</th><th>Player</th><th>Team</th><th>Subset / Note</th><th>Qty Owned</th><th>Owned</th><th></th></tr></thead><tbody>
                {filteredChecklistBowmanProspects.map(r=><tr key={r.numLabel}><td><strong>{r.numLabel}</strong></td><td><strong>{r.entry.player}</strong></td><td>{r.entry.team}</td><td>{r.entry.note || "—"}</td><td>{r.qty}</td><td><input type="checkbox" checked={r.owned} onChange={()=>toggleChecklist(r,"bowman-prospects")} aria-label={`Owned ${r.numLabel} - ${r.entry.player}`}/></td><td style={{whiteSpace:"nowrap"}}><button className="btn btn-outline" style={{padding:"6px 10px"}} onClick={()=>startAdd({setId:"bowman-prospects",cardNumber:r.numLabel})}>Add Card →</button></td></tr>)}
                {!filteredChecklistBowmanProspects.length && <tr><td colSpan={7} style={{textAlign:"center",padding:30,color:"var(--muted)"}}>No Bowman Prospects cards match these filters.</td></tr>}
              </tbody></table>
            </div>
            <h3 style={{margin:"22px 0 8px",fontSize:24}}>BOWMAN DRAFT — BD-1–BD-200</h3>
            <p style={{color:"var(--muted)",margin:"0 0 12px",fontSize:14}}>Showing <strong style={{color:"var(--ink)"}}>{filteredChecklistBowmanDraft.length}</strong> of 200 · Owned: <strong style={{color:"var(--ink)"}}>{checklistRowsBowmanDraft.filter(r=>r.owned).length}</strong>. Use the same search and Team / Subset / Owned filters above. Filter by Team / Prospect. Enter BD-1 or 1 — both normalize to BD-1 when Set is Bowman Draft.</p>
            <div style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10}} className="table-wrap">
              <table><thead><tr><th>Card #</th><th>Player</th><th>Team</th><th>Subset / Note</th><th>Qty Owned</th><th>Owned</th><th></th></tr></thead><tbody>
                {filteredChecklistBowmanDraft.map(r=><tr key={r.numLabel}><td><strong>{r.numLabel}</strong></td><td><strong>{r.entry.player}</strong></td><td>{r.entry.team}</td><td>{r.entry.note || "—"}</td><td>{r.qty}</td><td><input type="checkbox" checked={r.owned} onChange={()=>toggleChecklist(r,"bowman-draft")} aria-label={`Owned ${r.numLabel} - ${r.entry.player}`}/></td><td style={{whiteSpace:"nowrap"}}><button className="btn btn-outline" style={{padding:"6px 10px"}} onClick={()=>startAdd({setId:"bowman-draft",cardNumber:r.numLabel})}>Add Card →</button></td></tr>)}
                {!filteredChecklistBowmanDraft.length && <tr><td colSpan={7} style={{textAlign:"center",padding:30,color:"var(--muted)"}}>No Bowman Draft cards match these filters.</td></tr>}
              </tbody></table>
            </div>
            <h3 style={{margin:"22px 0 8px",fontSize:24}}>BOWMAN — 1990 BOWMAN INSERT (90B) — 50 CARDS</h3>
            <p style={{color:"var(--muted)",margin:"0 0 12px",fontSize:14}}>Parallels: Atomic /150, Green /99 Retail, Gold /50, Orange /25 Hobby, Red /5, SuperFractor 1/1. Showing <strong style={{color:"var(--ink)"}}>{filteredBowInsertRows.length}</strong> of 50 · Owned: <strong style={{color:"var(--ink)"}}>{bowInsertRows.filter(r=>r.owned).length}</strong>. In Add Card, Set = Bowman, Card # = 90B-AA (or another 90B code), Subset = 1990 Bowman Insert — Player / Team auto-fill.</p>
            <div style={{display:"flex",gap:10,flexWrap:"wrap",alignItems:"end",marginBottom:12}}><div style={{flex:"1 1 220px"}}><label className="label">Search 1990 Bowman Insert</label><input className="field" value={bowInsertSearch} onChange={e=>setBowInsertSearch(e.target.value)} placeholder="Player, code, team…"/></div></div>
            <div style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10}} className="table-wrap">
              <table><thead><tr><th>Code</th><th>Player</th><th>Team</th><th>Qty Owned</th><th>Owned</th><th></th></tr></thead><tbody>
                {filteredBowInsertRows.map(r=><tr key={r.code}><td><strong>{r.code}</strong></td><td><strong>{r.player}</strong></td><td>{r.team}</td><td>{r.qty}</td><td><input type="checkbox" checked={r.owned} onChange={()=>toggleBowInsert(r)} aria-label={`Owned ${r.code} - ${r.player}`}/></td><td style={{whiteSpace:"nowrap"}}><button className="btn btn-outline" style={{padding:"6px 10px"}} onClick={()=>startAdd({setId:"bowman",cardNumber:r.code,player:r.player,team:fullTeamName(r.team)==="—"?"Other":fullTeamName(r.team),parallel:"Base",subsetName:activeBowInsertDef.name,subsetType:activeBowInsertDef.type})}>Add Card →</button></td></tr>)}
                {!filteredBowInsertRows.length && <tr><td colSpan={6} style={{textAlign:"center",padding:30,color:"var(--muted)"}}>No 1990 Bowman Insert cards match these filters.</td></tr>}
              </tbody></table>
            </div>
            <h3 style={{margin:"22px 0 8px",fontSize:24}}>BOWMAN — HIDDEN FINDS (HF-) — 20 CARDS</h3>
            <p style={{color:"var(--muted)",margin:"0 0 12px",fontSize:14}}>Parallels: Refractor /99, Orange /25, Red /5, SuperFractor 1/1. Showing <strong style={{color:"var(--ink)"}}>{filteredBowHfRows.length}</strong> of 20 · Owned: <strong style={{color:"var(--ink)"}}>{bowHfRows.filter(r=>r.owned).length}</strong>. In Add Card, Set = Bowman, Card # = HF-CM (or another HF code), Subset = Bowman Hidden Finds — Player / Team auto-fill.</p>
            <div style={{display:"flex",gap:10,flexWrap:"wrap",alignItems:"end",marginBottom:12}}><div style={{flex:"1 1 220px"}}><label className="label">Search Bowman Hidden Finds</label><input className="field" value={bowHfSearch} onChange={e=>setBowHfSearch(e.target.value)} placeholder="Player, code, team…"/></div></div>
            <div style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10}} className="table-wrap">
              <table><thead><tr><th>Code</th><th>Player</th><th>Team</th><th>Subset / Note</th><th>Qty Owned</th><th>Owned</th><th></th></tr></thead><tbody>
                {filteredBowHfRows.map(r=><tr key={r.code}><td><strong>{r.code}</strong></td><td><strong>{r.player}</strong></td><td>{r.team}</td><td>{r.note || "—"}</td><td>{r.qty}</td><td><input type="checkbox" checked={r.owned} onChange={()=>toggleBowHf(r,bowHfDef)} aria-label={`Owned ${r.code} - ${r.player}`}/></td><td style={{whiteSpace:"nowrap"}}><button className="btn btn-outline" style={{padding:"6px 10px"}} onClick={()=>startAdd({setId:"bowman",cardNumber:r.code,player:r.player,team:fullTeamName(r.team)==="—"?"Other":fullTeamName(r.team),parallel:"Base",subsetName:bowHfDef.name,subsetType:bowHfDef.type})}>Add Card →</button></td></tr>)}
                {!filteredBowHfRows.length && <tr><td colSpan={7} style={{textAlign:"center",padding:30,color:"var(--muted)"}}>No Bowman Hidden Finds cards match these filters.</td></tr>}
              </tbody></table>
            </div>
            <h3 style={{margin:"22px 0 8px",fontSize:24}}>BOWMAN — HIDDEN FINDS AUTOGRAPHS — 12 CARDS</h3>
            <p style={{color:"var(--muted)",margin:"0 0 12px",fontSize:14}}>Hidden Finds Autograph Variation. Parallels: Refractor /99, Orange /25, Red /5, SuperFractor 1/1. Showing <strong style={{color:"var(--ink)"}}>{filteredBowHfAutoRows.length}</strong> of 12 · Owned: <strong style={{color:"var(--ink)"}}>{bowHfAutoRows.filter(r=>r.owned).length}</strong>. Same HF codes as above.</p>
            <div style={{display:"flex",gap:10,flexWrap:"wrap",alignItems:"end",marginBottom:12}}><div style={{flex:"1 1 220px"}}><label className="label">Search Hidden Finds Autographs</label><input className="field" value={bowHfAutoSearch} onChange={e=>setBowHfAutoSearch(e.target.value)} placeholder="Player, code, team…"/></div></div>
            <div style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10}} className="table-wrap">
              <table><thead><tr><th>Code</th><th>Player</th><th>Team</th><th>Subset / Note</th><th>Qty Owned</th><th>Owned</th><th></th></tr></thead><tbody>
                {filteredBowHfAutoRows.map(r=><tr key={r.code}><td><strong>{r.code}</strong></td><td><strong>{r.player}</strong></td><td>{r.team}</td><td>{r.note || "—"}</td><td>{r.qty}</td><td><input type="checkbox" checked={r.owned} onChange={()=>toggleBowHf(r,bowHfAutoDef)} aria-label={`Owned ${r.code} - ${r.player}`}/></td><td style={{whiteSpace:"nowrap"}}><button className="btn btn-outline" style={{padding:"6px 10px"}} onClick={()=>startAdd({setId:"bowman",cardNumber:r.code,player:r.player,team:fullTeamName(r.team)==="—"?"Other":fullTeamName(r.team),parallel:"Base",subsetName:bowHfAutoDef.name,subsetType:bowHfAutoDef.type})}>Add Card →</button></td></tr>)}
                {!filteredBowHfAutoRows.length && <tr><td colSpan={7} style={{textAlign:"center",padding:30,color:"var(--muted)"}}>No Hidden Finds Autograph cards match these filters.</td></tr>}
              </tbody></table>
            </div>
            <article style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10,padding:16,marginTop:22,display:"flex",flexDirection:"column",gap:6}}>
              <h3 style={{margin:0,fontSize:26,lineHeight:1}}><a href="https://cloutsnchara.com/checklist/2020-bowman-baseball-checklist/" target="_blank" rel="noopener">2020 Bowman Baseball Checklist</a></h3>
              <p style={{color:"var(--muted)",fontSize:13,margin:0}}>Reference checklist · CloutsnChara</p>
              <p style={{fontSize:14,margin:0}}>Full 2020 Bowman checklist reference, including Bowman Hidden Finds.</p>
              <div><a href="https://cloutsnchara.com/checklist/2020-bowman-baseball-checklist/" target="_blank" rel="noopener" className="btn btn-outline">View Checklist →</a></div>
            </article>
            <h3 style={{margin:"22px 0 8px",fontSize:24}}>HERITAGE — #1–500</h3>
            <p style={{color:"var(--muted)",margin:"0 0 12px",fontSize:14}}>Showing <strong style={{color:"var(--ink)"}}>{filteredChecklistHeritage.length}</strong> of 500 · Owned: <strong style={{color:"var(--ink)"}}>{checklistRowsHeritage.filter(r=>r.owned).length}</strong>. Use the same search and Team / Subset / Owned filters above. Filter by Team / SP / RC. Cards #1–400 are base; #401–500 are short prints (SP). League Leaders are #61–72, Highlights #195–206, World Series Highlights #327–334.</p>
            <div style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10}} className="table-wrap">
              <table><thead><tr><th>Card #</th><th>Player</th><th>Team</th><th>Subset / Note</th><th>Qty Owned</th><th>Owned</th><th></th></tr></thead><tbody>
                {filteredChecklistHeritage.map(r=><tr key={r.num}><td><strong>{r.num}</strong></td><td><strong>{r.entry.player}</strong></td><td>{r.entry.team}</td><td>{r.entry.note || "—"}</td><td>{r.qty}</td><td><input type="checkbox" checked={r.owned} onChange={()=>toggleChecklist(r,"heritage")} aria-label={`Owned ${r.num} - ${r.entry.player}`}/></td><td style={{whiteSpace:"nowrap"}}><button className="btn btn-outline" style={{padding:"6px 10px"}} onClick={()=>startAdd({setId:"heritage",cardNumber:String(r.num)})}>Add Card →</button></td></tr>)}
                {!filteredChecklistHeritage.length && <tr><td colSpan={7} style={{textAlign:"center",padding:30,color:"var(--muted)"}}>No Heritage cards match these filters.</td></tr>}
              </tbody></table>
            </div>
            <h3 style={{margin:"22px 0 8px",fontSize:24}}>ALLEN &amp; GINTER — #1–350</h3>
            <p style={{color:"var(--muted)",margin:"0 0 12px",fontSize:14}}>Showing <strong style={{color:"var(--ink)"}}>{filteredChecklistAG.length}</strong> of 350 · Owned: <strong style={{color:"var(--ink)"}}>{checklistRowsAG.filter(r=>r.owned).length}</strong>. Use the same search and Team / Subset / Owned filters above. Filter by Team / SP / Rookie / Non-Baseball. Cards #1–300 are base; #301–350 are short prints (SP). Non-baseball personalities show their role as Team, with Non-Baseball in the note.</p>
            <div style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10}} className="table-wrap">
              <table><thead><tr><th>Card #</th><th>Player</th><th>Team</th><th>Subset / Note</th><th>Qty Owned</th><th>Owned</th><th></th></tr></thead><tbody>
                {filteredChecklistAG.map(r=><tr key={r.num}><td><strong>{r.num}</strong></td><td><strong>{r.entry.player}</strong></td><td>{r.entry.team}</td><td>{r.entry.note || "—"}</td><td>{r.qty}</td><td><input type="checkbox" checked={r.owned} onChange={()=>toggleChecklist(r,"ag")} aria-label={`Owned ${r.num} - ${r.entry.player}`}/></td><td style={{whiteSpace:"nowrap"}}><button className="btn btn-outline" style={{padding:"6px 10px"}} onClick={()=>startAdd({setId:"ag",cardNumber:String(r.num)})}>Add Card →</button></td></tr>)}
                {!filteredChecklistAG.length && <tr><td colSpan={7} style={{textAlign:"center",padding:30,color:"var(--muted)"}}>No Allen &amp; Ginter cards match these filters.</td></tr>}
              </tbody></table>
            </div>
            <h3 style={{margin:"22px 0 8px",fontSize:24}}>GYPSY QUEEN — #1–320</h3>
            <p style={{color:"var(--muted)",margin:"0 0 12px",fontSize:14}}>Showing <strong style={{color:"var(--ink)"}}>{filteredChecklistGypsy.length}</strong> of 320 · Owned: <strong style={{color:"var(--ink)"}}>{checklistRowsGypsy.filter(r=>r.owned).length}</strong>. Use the same search and Team / Subset / Owned filters above. Filter by Team / SP / Rookie. Cards #1–300 are base; #301–320 are Extended Base SPs (legends).</p>
            <div style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10}} className="table-wrap">
              <table><thead><tr><th>Card #</th><th>Player</th><th>Team</th><th>Subset / Note</th><th>Qty Owned</th><th>Owned</th><th></th></tr></thead><tbody>
                {filteredChecklistGypsy.map(r=><tr key={r.num}><td><strong>{r.num}</strong></td><td><strong>{r.entry.player}</strong></td><td>{r.entry.team}</td><td>{r.entry.note || "—"}</td><td>{r.qty}</td><td><input type="checkbox" checked={r.owned} onChange={()=>toggleChecklist(r,"gypsy")} aria-label={`Owned ${r.num} - ${r.entry.player}`}/></td><td style={{whiteSpace:"nowrap"}}><button className="btn btn-outline" style={{padding:"6px 10px"}} onClick={()=>startAdd({setId:"gypsy",cardNumber:String(r.num)})}>Add Card →</button></td></tr>)}
                {!filteredChecklistGypsy.length && <tr><td colSpan={7} style={{textAlign:"center",padding:30,color:"var(--muted)"}}>No Gypsy Queen cards match these filters.</td></tr>}
              </tbody></table>
            </div>
            <h3 style={{margin:"22px 0 8px",fontSize:24}}>OPENING DAY — #1–201</h3>
            <p style={{color:"var(--muted)",margin:"0 0 12px",fontSize:14}}>Showing <strong style={{color:"var(--ink)"}}>{filteredChecklistOpeningDay.length}</strong> of 201 · Owned: <strong style={{color:"var(--ink)"}}>{checklistRowsOpeningDay.filter(r=>r.owned).length}</strong>. Use the same search and Team / Subset / Owned filters above. Filter by Team / SP / Rookie. Cards #1–200 are base; #201 Luis Robert is a short print (SP).</p>
            <div style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10}} className="table-wrap">
              <table><thead><tr><th>Card #</th><th>Player</th><th>Team</th><th>Subset / Note</th><th>Qty Owned</th><th>Owned</th><th></th></tr></thead><tbody>
                {filteredChecklistOpeningDay.map(r=><tr key={r.num}><td><strong>{r.num}</strong></td><td><strong>{r.entry.player}</strong></td><td>{r.entry.team}</td><td>{r.entry.note || "—"}</td><td>{r.qty}</td><td><input type="checkbox" checked={r.owned} onChange={()=>toggleChecklist(r,"opening-day")} aria-label={`Owned ${r.num} - ${r.entry.player}`}/></td><td style={{whiteSpace:"nowrap"}}><button className="btn btn-outline" style={{padding:"6px 10px"}} onClick={()=>startAdd({setId:"opening-day",cardNumber:String(r.num)})}>Add Card →</button></td></tr>)}
                {!filteredChecklistOpeningDay.length && <tr><td colSpan={7} style={{textAlign:"center",padding:30,color:"var(--muted)"}}>No Opening Day cards match these filters.</td></tr>}
              </tbody></table>
            </div>
            <h3 style={{margin:"22px 0 8px",fontSize:24}}>STADIUM CLUB — #1–300</h3>
            <p style={{color:"var(--muted)",margin:"0 0 12px",fontSize:14}}>Showing <strong style={{color:"var(--ink)"}}>{filteredChecklistStadium.length}</strong> of 300 · Owned: <strong style={{color:"var(--ink)"}}>{checklistRowsStadium.filter(r=>r.owned).length}</strong>. Use the same search and Team / Subset / Owned filters above. Filter by Team / Rookie.</p>
            <div style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10}} className="table-wrap">
              <table><thead><tr><th>Card #</th><th>Player</th><th>Team</th><th>Subset / Note</th><th>Qty Owned</th><th>Owned</th><th></th></tr></thead><tbody>
                {filteredChecklistStadium.map(r=><tr key={r.num}><td><strong>{r.num}</strong></td><td><strong>{r.entry.player}</strong></td><td>{r.entry.team}</td><td>{r.entry.note || "—"}</td><td>{r.qty}</td><td><input type="checkbox" checked={r.owned} onChange={()=>toggleChecklist(r,"stadium")} aria-label={`Owned ${r.num} - ${r.entry.player}`}/></td><td style={{whiteSpace:"nowrap"}}><button className="btn btn-outline" style={{padding:"6px 10px"}} onClick={()=>startAdd({setId:"stadium",cardNumber:String(r.num)})}>Add Card →</button></td></tr>)}
                {!filteredChecklistStadium.length && <tr><td colSpan={7} style={{textAlign:"center",padding:30,color:"var(--muted)"}}>No Stadium Club cards match these filters.</td></tr>}
              </tbody></table>
            </div>
            <h3 style={{margin:"22px 0 8px",fontSize:24}}>BIG LEAGUE — #1–300</h3>
            <p style={{color:"var(--muted)",margin:"0 0 12px",fontSize:14}}>Showing <strong style={{color:"var(--ink)"}}>{filteredChecklistBigLeague.length}</strong> of 300 · Owned: <strong style={{color:"var(--ink)"}}>{checklistRowsBigLeague.filter(r=>r.owned).length}</strong>. Use the same search and Team / Subset / Owned filters above. Filter by Team / Rookie / Leaders / Award. Cards #1–235 are base players; #236–265 are Leaders, #266–285 are Awards, and #286–300 are Highlights.</p>
            <div style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10}} className="table-wrap">
              <table><thead><tr><th>Card #</th><th>Player</th><th>Team</th><th>Subset / Note</th><th>Qty Owned</th><th>Owned</th><th></th></tr></thead><tbody>
                {filteredChecklistBigLeague.map(r=><tr key={r.num}><td><strong>{r.num}</strong></td><td><strong>{r.entry.player}</strong></td><td>{r.entry.team}</td><td>{r.entry.note || "—"}</td><td>{r.qty}</td><td><input type="checkbox" checked={r.owned} onChange={()=>toggleChecklist(r,"big-league")} aria-label={`Owned ${r.num} - ${r.entry.player}`}/></td><td style={{whiteSpace:"nowrap"}}><button className="btn btn-outline" style={{padding:"6px 10px"}} onClick={()=>startAdd({setId:"big-league",cardNumber:String(r.num)})}>Add Card →</button></td></tr>)}
                {!filteredChecklistBigLeague.length && <tr><td colSpan={7} style={{textAlign:"center",padding:30,color:"var(--muted)"}}>No Big League cards match these filters.</td></tr>}
              </tbody></table>
            </div>
            <h3 style={{margin:"22px 0 8px",fontSize:24}}>SERIES 2 CLEAR VARIATION (100)</h3>
            <p style={{color:"var(--muted)",margin:"0 0 12px",fontSize:14}}>Variant type “Clear Variation”. Player / Team = same as the base card number. Showing <strong style={{color:"var(--ink)"}}>{filteredClearRowsS2.length}</strong> of 100 · Owned: <strong style={{color:"var(--ink)"}}>{clearVariationRowsS2.filter(r=>r.owned).length}</strong>. Use the same search above.</p>
            <div style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10}} className="table-wrap">
              <table><thead><tr><th>Card #</th><th>Player</th><th>Team</th><th>Variant</th><th>Qty Owned</th><th>Owned</th><th></th></tr></thead><tbody>
                {filteredClearRowsS2.map(r=><tr key={r.num}><td><strong>{r.num}</strong></td><td><strong>{r.entry.player}</strong></td><td>{r.entry.team}</td><td>Clear Variation</td><td>{r.qty}</td><td><input type="checkbox" checked={r.owned} onChange={()=>toggleClearVariationS2(r)} aria-label={`Owned ${r.num} Clear Variation - ${r.entry.player}`}/></td><td style={{whiteSpace:"nowrap"}}><button className="btn btn-outline" style={{padding:"6px 10px"}} onClick={()=>startAdd({setId:"s2",cardNumber:String(r.num),player:r.entry.player,team:fullTeamName(r.entry.team),parallel:"Clear Variation",subsetName:"Clear Variation",subsetType:"Parallel"})}>Add Card →</button></td></tr>)}
                {!filteredClearRowsS2.length && <tr><td colSpan={7} style={{textAlign:"center",padding:30,color:"var(--muted)"}}>No Series 2 Clear Variation cards match these filters.</td></tr>}
              </tbody></table>
            </div>
            <h3 style={{margin:"22px 0 8px",fontSize:24}}>SERIES 2 INSERTS — 770 CARDS</h3>
            <p style={{color:"var(--muted)",margin:"0 0 12px",fontSize:14}}>Decades Best 100 + Decades Best Chrome 100 + Warriors 50 + Player of Decade 25 + Significant Stats 25 + Topps 2030 20 + 1985 TB 50 + 1985 All Stars 50 + Empire State 30 + Tatis Highlights 30 + Turkey Red S2 100 + Chrome Turkey Red S2 100 + HR Challenge 30 + 1985 Chrome Promo 50 + Best of Topps Now 10 = 770. Series 2 Total: Base 350 + Clear Variation 100 + Inserts 770 = 1,220. Series 1 Total 965 + Series 2 Total 1,220 = 2,185 for Series 1+2 alone. Each insert stores Subset + Code + Variant separately, so Series 1 DB-1 and Series 2 DB-1 are different rows.</p>
            <div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:12}}>{S2_HUB_DEFS.map(d=><button key={d.id} onClick={()=>setS2InsertId(d.id)} style={{border:0,borderRadius:999,padding:"8px 13px",fontWeight:700,fontSize:13,background:s2InsertId===d.id?"var(--red)":"var(--surface-2)",color:s2InsertId===d.id?"white":"var(--ink)"}}>{d.name} ({d.size})</button>)}</div>
            <p style={{margin:"0 0 10px",fontSize:14}}><strong>{activeS2InsertDef.name}</strong> · {activeS2InsertDef.notes} · Parallels: {activeS2InsertDef.parallels} · Showing <strong>{filteredS2InsertRows.length}</strong> of {activeS2InsertDef.size} · Owned: <strong>{s2InsertRows.filter(r=>r.owned).length}</strong></p>
            <div style={{display:"flex",gap:10,flexWrap:"wrap",alignItems:"end",marginBottom:12}}><div style={{flex:"1 1 220px"}}><label className="label">Search Series 2 inserts</label><input className="field" value={s2InsertSearch} onChange={e=>setS2InsertSearch(e.target.value)} placeholder="Player, code, team…"/></div></div>
            <div style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10}} className="table-wrap">
              <table><thead><tr><th>Code</th><th>Player</th><th>Team</th><th>Qty Owned</th><th>Owned</th><th></th></tr></thead><tbody>
                {filteredS2InsertRows.map(r=><tr key={r.code}><td><strong>{r.code}</strong></td><td><strong>{r.player}</strong></td><td>{r.team}</td><td>{r.qty}</td><td><input type="checkbox" checked={r.owned} onChange={()=>toggleS2Insert(r)} aria-label={`Owned ${r.code} - ${r.player}`}/></td><td style={{whiteSpace:"nowrap"}}><button className="btn btn-outline" style={{padding:"6px 10px"}} onClick={()=>startAdd({setId:"s2",cardNumber:r.code,player:r.player,team:fullTeamName(r.team)==="—"?"Other":fullTeamName(r.team),parallel:"Base",subsetName:activeS2InsertDef.name,subsetType:activeS2InsertDef.type})}>Add Card →</button></td></tr>)}
                {!filteredS2InsertRows.length && <tr><td colSpan={6} style={{textAlign:"center",padding:30,color:"var(--muted)"}}>No Series 2 insert cards match these filters.</td></tr>}
              </tbody></table>
            </div>
            <h3 style={{margin:"22px 0 8px",fontSize:24}}>OTHER SERIES 2 INSERT HUB SETS — CODE-BASED</h3>
            <p style={{color:"var(--muted)",margin:"0 0 12px",fontSize:14}}>These sets are tracked by Code in Add Card (Set = Series 2, Subset = the set name). Entering a known Code auto-fills Player.</p>
            <div style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10}} className="table-wrap">
              <table><thead><tr><th>Set</th><th>Codes</th><th>Size</th><th>Parallels</th><th>Examples / Add support</th><th></th></tr></thead><tbody>
                {S2_OTHER_INSERTS.map(s=><tr key={s.name}><td><strong>{s.name}</strong></td><td>{s.codes}</td><td>{s.size}</td><td>{s.parallels}</td><td>{s.examples}</td><td style={{whiteSpace:"nowrap"}}><button className="btn btn-outline" style={{padding:"6px 10px"}} onClick={()=>startAdd({setId:"s2",subsetName:s.name,subsetType:s.parallels==="Relic"?"Relic":"Auto"})}>Add Card →</button></td></tr>)}
              </tbody></table>
            </div>
            <p style={{color:"var(--muted)",fontSize:13}}>Qty Owned comes from Inventory / My Collection for Series 1, Series 2, Update, Chrome, Bowman, Bowman Prospects, Bowman Draft, Heritage, Allen &amp; Ginter, Gypsy Queen, Opening Day, Stadium Club, and Big League. Checking Owned creates or updates that card in your collection.</p>
          </section>
        )}

        {tab==="parallels" && (
          <section>
            <h2 style={{margin:"0 0 8px",fontSize:32}}>PARALLELS</h2>
            <p style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:8,padding:"13px 15px",margin:"0 0 14px",fontSize:15,lineHeight:1.6}}><strong>Update Base Parallels: 18</strong> + Base + SP Variation (50) + SSP Variation (25) + SSSP Variation (5) + Clear Variation (Hobby /10). CMP codes: Base ends #588, SP ends #631, SSP ends #632, SSSP ends #633, Advanced Stat ends #634. <strong>Series 1 Base Parallels: 17</strong> + Base + Clear Variation (100). <strong>Series 2 Base Parallels: 17</strong> + Base + Clear Variation (100). The 17 are: Yellow, Purple, Rainbow Foil, Gold Foil (Jumbo), Gold /2020, Advanced Stat /300, Vintage Stock /99, Independence Day /76, Black /69, Mother&apos;s Day Hot Pink /50, Father&apos;s Day Blue /50, Memorial Day Camo /25, Platinum 1/1, Cyan Printing Plate 1/1, Magenta Printing Plate 1/1, Yellow Printing Plate 1/1, Black Printing Plate 1/1. In Add Card, Set = Series 2, Variant dropdown offers all 17 + Base + Clear Variation.</p>
            <div style={{display:"flex",gap:10,flexWrap:"wrap",alignItems:"end",marginBottom:12}}>
              <div style={{flex:"1 1 220px"}}><label className="label">Search parallels</label><input className="field" value={parSearch} onChange={e=>setParSearch(e.target.value)} placeholder="Gold, /50, Printing Plate…"/></div>
              <div><label className="label">Set</label><select className="field" value={parSet} onChange={e=>setParSet(e.target.value)}><option value="All">All</option><option value="s1">Series 1</option><option value="s2">Series 2</option><option value="update">Update Series</option><option value="chrome">Chrome</option><option value="archives">Archives</option></select></div>
              <div style={{fontSize:13,color:"var(--muted)"}}>Showing <strong style={{color:"var(--ink)"}}>{s1ParallelsFiltered.length}</strong> parallels</div>
            </div>
            <div style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10}} className="table-wrap">
              <table><thead><tr><th>Set</th><th>Parallel / Variant</th><th>Rarity</th><th>Notes</th><th></th></tr></thead><tbody>
                {s1ParallelsFiltered.map((d,i)=><tr key={`${d.setName}-${d.name}-${i}`}><td><strong>{d.setName}</strong></td><td><strong>{d.name}</strong></td><td>{d.rarity}</td><td>{d.notes}</td><td><button className="btn btn-outline" style={{padding:"6px 10px",whiteSpace:"nowrap"}} onClick={()=>startAdd({setId:d.setName==="Series 2"?"s2":d.setName==="Series 1"?"s1":d.setName==="Update Series"?"update":d.setName==="Chrome"?"chrome":"archives",parallel:d.name,subsetName:(d.name==="Clear Variation"||d.name==="SP Variation"||d.name==="SSP Variation"||d.name==="SSSP Variation")?d.name:"",subsetType:(d.name==="Clear Variation"||d.name==="SP Variation"||d.name==="SSP Variation"||d.name==="SSSP Variation")?"Parallel":"Base Card"})}>Add Card →</button></td></tr>)}
                {!s1ParallelsFiltered.length && <tr><td colSpan={5} style={{textAlign:"center",padding:30,color:"var(--muted)"}}>No parallels match these filters.</td></tr>}
              </tbody></table>
            </div>
          </section>
        )}

        {tab==="add" && (
          <section style={{maxWidth:900}}>
            <h2 style={{margin:"0 0 6px",fontSize:32}}>{editingId?"EDIT CARD":"ADD CARD"}</h2><p style={{color:"var(--muted)",marginTop:0}}>Saving writes to your durable database. Date Added is set automatically and can be edited below. Base Subsets count toward base completion; Inserts / Parallels do not. Existing cards without a quantity default to Qty Owned = 1 if Owned, 0 if not.</p>
            <form onSubmit={saveCard} style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10,padding:18,display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(200px,1fr))",gap:14}}>
              <div><label className="label">Set *</label><select className="field" value={form.setId} onChange={e=>handleFormSetChange(e.target.value)}>{sets.map(s=><option key={s.id} value={s.id}>{s.name} — {s.category}</option>)}</select></div>
              <div><label className="label">Card # *</label><div style={{display:"flex",gap:7}}><input className="field" value={form.cardNumber} onChange={e=>handleCardNumberChange(e.target.value)} placeholder="1 or U-100 or BP-1 or BD-1"/><button type="button" className="btn btn-navy" style={{whiteSpace:"nowrap"}} onClick={lookupName}>Lookup Name</button></div><p style={{fontSize:12,color:"var(--muted)",margin:"5px 0 0"}}>Series 1 / Series 2 / Update / Chrome / Bowman / Bowman Prospects / Bowman Draft / Heritage / Allen &amp; Ginter / Gypsy Queen / Opening Day / Stadium Club / Big League: entering a Card # auto-fills Player / Team. For Update, enter U-1 or 1 — both normalize to U-1. For Bowman Prospects, enter BP-1 or 1 — both normalize to BP-1. For Bowman Draft, enter BD-1 or 1 — both normalize to BD-1. For Bowman Chrome, BCP-1 auto-fills the same prospect name. You can override it, or use Lookup Name.</p></div>
              <div><label className="label">Player *</label><input className="field" value={form.player} onChange={e=>setForm({...form,player:e.target.value})} placeholder="Player name"/></div>
              <div><label className="label">Team</label><select className="field" value={form.team} onChange={e=>setForm({...form,team:e.target.value})}>{TEAMS.map(t=><option key={t}>{t}</option>)}</select></div>
              <div><label className="label">Parallel / Variant</label><select className="field" value={form.parallel} onChange={e=>setForm({...form,parallel:e.target.value})}>{PARALLELS.map(p=><option key={p}>{p}</option>)}</select></div>
              <div><label className="label">Subset / Insert</label><select className="field" value={form.subsetName||""} onChange={e=>handleSubsetNameChange(e.target.value)}><option value="">None - Base Card</option>{formSubsets.map(s=><option key={s.id} value={s.name}>{s.name} — {s.type}</option>)}<option value="Other">Other</option></select></div>
              <div><label className="label">Subset Type</label><select className="field" value={form.subsetType||"Base Card"} onChange={e=>setForm({...form,subsetType:e.target.value as SubsetType})}>{SUBSET_TYPES.map(t=><option key={t}>{t}</option>)}</select></div>
              <div><label className="label">Condition</label><select className="field" value={form.condition} onChange={e=>setForm({...form,condition:e.target.value})}>{CONDITIONS.map(c=><option key={c}>{c}</option>)}</select></div>
              <div><label className="label">Graded Company</label><select className="field" value={form.gradedCompany} onChange={e=>setForm({...form,gradedCompany:e.target.value})}>{["Raw","PSA","BGS","SGC","CGC"].map(c=><option key={c}>{c}</option>)}</select></div>
              <div><label className="label">Grade</label><input className="field" value={form.grade} onChange={e=>setForm({...form,grade:e.target.value})} placeholder="10, 9.5, or blank"/></div>
              <div><label className="label">Qty Owned</label><input className="field" type="number" min="0" max="999" value={form.qtyOwned ?? 1} onChange={e=>{const n=Math.max(0,Number(e.target.value)||0); setForm({...form,qtyOwned:n, owned:n>0});}} /></div>
              <div><label className="label">Qty For Trade</label><input className="field" type="number" min="0" max="999" value={form.qtyForTrade ?? 0} onChange={e=>{const n=Math.max(0,Number(e.target.value)||0); setForm({...form,qtyForTrade:n, forTrade:n>0});}} /></div>
              <div><label className="label">Qty Graded</label><input className="field" type="number" min="0" max="999" value={form.qtyGraded ?? 0} onChange={e=>setForm({...form,qtyGraded:Math.max(0,Number(e.target.value)||0)})} /></div>
              <div><label className="label">Location / Box</label><input className="field" value={form.location||""} onChange={e=>setForm({...form,location:e.target.value})} placeholder="Binder 1, Page 3 or Box A"/></div>
              <div><label className="label">Purchase Price ($)</label><input className="field" type="number" min="0" step="0.01" value={form.purchasePrice} onChange={e=>setForm({...form,purchasePrice:Number(e.target.value)})}/></div>
              <div><label className="label">Current Value ($)</label><input className="field" type="number" min="0" step="0.01" value={form.currentValue} onChange={e=>setForm({...form,currentValue:Number(e.target.value)})}/></div>
              <div><label className="label">Date Added</label><input className="field" type="date" value={form.dateAdded} onChange={e=>setForm({...form,dateAdded:e.target.value})}/></div>
              <div style={{gridColumn:"1 / -1"}}><label className="label">Notes</label><textarea className="field" rows={3} value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})} placeholder="Short print, trade notes, provenance…"/></div>
              <div style={{gridColumn:"1 / -1",display:"flex",gap:18,flexWrap:"wrap"}}><label><input type="checkbox" checked={form.owned} onChange={e=>{const checked=e.target.checked; setForm({...form,owned:checked, qtyOwned: checked ? Math.max(1, qtyOwnedOf(form)) : 0});}}/> Owned</label><label><input type="checkbox" checked={form.wantlist} onChange={e=>setForm({...form,wantlist:e.target.checked})}/> Wantlist</label><label><input type="checkbox" checked={form.forTrade} onChange={e=>setForm({...form,forTrade:e.target.checked})}/> For Trade</label></div>
              <div style={{gridColumn:"1 / -1",display:"flex",gap:8,flexWrap:"wrap"}}><button className="btn btn-red" type="submit" disabled={busy}>{busy?"Saving…":editingId?"Save Changes":"Save Card"}</button>{editingId && <button className="btn btn-outline" type="button" onClick={()=>{setEditingId(null); setForm({...emptyForm,dateAdded:new Date().toISOString().slice(0,10)});}}>Cancel Edit</button>}<button className="btn btn-outline" type="button" onClick={()=>setTab("collection")}>Back to Collection</button></div>
            </form>
          </section>
        )}

        <section style={{background:"var(--paper)",border:"1px solid var(--line)",borderRadius:10,padding:18,marginTop:24}}>
          <h2 style={{margin:"0 0 12px",fontSize:26}}>IMPORT / EXPORT / DATA TOOLS</h2>
          <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
            <button className="btn btn-navy" onClick={exportCSV}><Download size={16}/> Export Collection as CSV</button>
            <button className="btn btn-outline" onClick={exportJSON}><Download size={16}/> Export as JSON</button>
            <button className="btn btn-outline" onClick={()=>fileRef.current?.click()}><Upload size={16}/> Import JSON</button>
            <input ref={fileRef} type="file" accept="application/json,.json" style={{display:"none"}} onChange={e=>{ const f=e.target.files?.[0]; if(f) importJSON(f); e.target.value=""; }}/>
            <button className="btn btn-outline" onClick={loadSample} disabled={busy}><Package size={16}/> Sample Data — 12 Cards</button>
            {!confirmClear ? <button className="btn btn-outline" onClick={()=>setConfirmClear(true)}><Trash2 size={16}/> Clear All</button> : <span style={{display:"inline-flex",gap:8,alignItems:"center"}}><strong>Clear all {cards.length} cards?</strong><button className="btn btn-red" onClick={clearAll} disabled={busy}>Yes, Clear All</button><button className="btn btn-light" onClick={()=>setConfirmClear(false)}>Keep Cards</button></span>}
          </div>
          <p style={{color:"var(--muted)",fontSize:13,margin:"12px 0 0"}}>Import expects JSON with a <code>cards</code> array, matching the exported format. Storage is shared and limited to 1,000 records across the app; very large imports may be rejected when that limit is reached.</p>
        </section>
      </main>
      <footer style={{maxWidth:1240,margin:"0 auto",padding:"0 16px 28px",color:"var(--muted)",fontSize:13,lineHeight:1.6}}>Base sizes are base set only — parallels, inserts, autos and relics not counted. Edit any set size in Sets Library if your checklist differs. Bowman family included — Bowman (100) + Bowman Prospects (BP-1 to BP-150) = 250 Bowman cards; Bowman Chrome Prospects use the same prospect names with BCP- prefix; Bowman Draft (BD-1 to BD-200) = 200 cards. Bowman 1990 Bowman Insert (90B-*) = 50 cards. Opening Day included — #1–201 (1–200 base + #201 Luis Robert SP). Stadium Club included — #1–300. Big League included — #1–300.</footer>

      {duplicate && (
        <div role="dialog" aria-modal="true" aria-label="Duplicate card found" style={{position:"fixed",inset:0,background:"rgba(0,0,0,.55)",display:"flex",alignItems:"center",justifyContent:"center",padding:16,zIndex:50}}>
          <div style={{background:"var(--paper)",borderRadius:12,padding:22,maxWidth:480,width:"100%"}}>
            <h2 style={{margin:"0 0 8px",fontSize:28}}>Duplicate found</h2>
            <p style={{margin:"0 0 6px",fontSize:15}}>You already have <strong>{qtyOwnedOf(duplicate.existing.value)}</strong> of this. Add +1 to quantity?</p>
            <p style={{margin:"0 0 16px",color:"var(--muted)",fontSize:14}}>{setById.get(duplicate.existing.value.setId)?.name} · #{duplicate.existing.value.cardNumber} · {duplicate.existing.value.player} · {duplicate.existing.value.parallel}</p>
            <div style={{display:"flex",gap:8,flexWrap:"wrap"}}><button className="btn btn-red" onClick={addToExisting} disabled={busy}>Add to Existing +1</button><button className="btn btn-outline" onClick={createSeparateEntry} disabled={busy}>Create Separate Entry</button><button className="btn btn-light" onClick={()=>setDuplicate(null)}>Cancel</button></div>
          </div>
        </div>
      )}
    </div>
  );
}
